%% demo_pisco_E6_sensitivity_biomask_extended.m
% E6: PISCO hyperparameter sensitivity on biological-mask simulation.
%
% Ground truth: real FP emission spectra loaded from
%   PISCO_M_32x4_HyU_strict_quasar32.mat (M: 32 x 4).
% Abundances: build_Strue_from_masks.m, masks in ./use/<scene>/masks,
%   Gaussian smoothing, sum-to-one and maximum purity 0.8.
% Observation: Poisson photons + Gaussian read-out noise (sigma=1 count),
%   photons denote MEAN PHOTONS PER SPECTRAL CHANNEL.
%
% OAT: vary exactly one of 10 hyperparameters at a time, with all other
% parameters held at SI v32c defaults. Shared default is trained once
% per repeat. For the ETA arm, ETA_END is always changed together with
% ETA to the SAME value, ensuring fixed eta with NO annealing.
%
% PARAMS(7) is LAMBDA_MNONNEG (the trainer's actual inputParser key),
% corresponding to lambda_mnn in the supplementary information.
% For mask-derived abundances SI v32c specifies LAMBDA_ENCLOSE=0.3;
% the older E6 demo used 10 (the i.i.d. synthetic setting).
% Explicitly pass SIGMA_CAP=0.03 and fixed ETA=ETA_END=0.4 because the
% supplied trainer function's internal defaults are not aligned with SI.
%
% Output CSV: original columns plus eta_start,eta_end,sigma_cap for audit.
% Column 'lambda' is retained for backward compatibility, and denotes
% the scanned VALUE even for SIGMA_CAP and ETA (not physically a lambda).
% Three figures (not auto-saved):
%  Fig 1: SAD / abundance MSE for PARAMS 1-5
%  Fig 2: SAD / abundance MSE for PARAMS 6-10 (including ETA)
%  Fig 3: four matched endmember spectra for DEFAULT, run 1
% Error bars are mean +/- sample standard deviation (n=N_RUNS).
%
% Requires deep_mvsa_invflow_poisson_explicit_Warmup.m,
% build_Strue_from_masks.m and Statistics and Machine Learning Toolbox.
% Target: MATLAB R2023a.  QUICK=true for a reduced 3-level sweep.
%
clear all; close all; clc;

%% A.0 Protocol ---------------------------------------------------------
QUICK      = false;   % true: 2 repeats, 800 iters, 3 levels for EACH parameter
N_RUNS     = 30;      % initial test; use 30 for manuscript statistics
BASE_SEED  = 42;
SIZE       = 96;      % scene: 96 x 96
PHOTONS    = 20;      % mean photons per spectral channel
READ_SIG   = 1.0;     % Gaussian read-out noise, counts (design v5)
MM_ITERS   = 2500;    % joint-phase length (SI Table 3 default)
WARM_UP    = 600;     % warm-up length (SI Table 3 default)
T_CRIT     = NaN;    % computed after QUICK adjustment from N_RUNS
OUT_CSV    = 'pisco_E6_sensitivity_results_extended1.csv';

% Biological mask settings: identical to the supplied E1 biomask demo.
THIS_SCRIPT = mfilename('fullpath');
SCRIPT_DIR = fileparts(THIS_SCRIPT);
if isempty(SCRIPT_DIR), SCRIPT_DIR = pwd; end
MASK_ROOT       = fullfile(SCRIPT_DIR,'use');
MASK_SIGMA      = 2.0;
MASK_BACKGROUND = 0.02;
MAX_PURITY      = 0.8;
M_FILE          = fullfile(SCRIPT_DIR,'PISCO_M_32x4_HyU_strict_quasar32.mat');

% --- OAT sweep: first five preserved, next five appended -----------------
PARAMS(1) = struct('name','LAMBDA_VOL',    'defval',0.008, ...
                   'levels',[0 0.004 0.008 0.032 0.08]);
PARAMS(2) = struct('name','LAMBDA_NONNEG', 'defval',3, ...
                   'levels',[0.3 1 3 10 30]);
PARAMS(3) = struct('name','LAMBDA_EQ',     'defval',100, ...
                   'levels',[10 30 100 300 1000]);
PARAMS(4) = struct('name','LAMBDA_SUMONE', 'defval',2, ...
                   'levels',[0.2 1 2 10 20]);
PARAMS(5) = struct('name','LAMBDA_SPATIAL','defval',2, ...
                   'levels',[0 1 2 10 20]);

% New: SI v32c, Supplementary Table 1, with representative interior levels.
PARAMS(6) = struct('name','SIGMA_CAP',    'defval',0.15, ...
                   'levels',[0 0.01 0.15 0.5 1]);
PARAMS(7) = struct('name','LAMBDA_MNONNEG','defval',10, ...
                   'levels',[0 1 10 30 100]);
PARAMS(8) = struct('name','LAMBDA_SMOOTH','defval',0.1, ...
                   'levels',[0 0.01 0.1 0.3 1]);
PARAMS(9) = struct('name','LAMBDA_ENCLOSE','defval',0.3, ...
                   'levels',[0 0.1 0.3 10 100]);
PARAMS(10) = struct('name','ETA',          'defval',0.3, ...
                    'levels',[0.1 0.2 0.3 0.4 0.5]);

if QUICK
    N_RUNS = 2; MM_ITERS = 800; WARM_UP = 200;
    % All 10 parameters still tested: minimum / default / maximum.
    for q = 1:numel(PARAMS)
        vv = PARAMS(q).levels;
        PARAMS(q).levels = unique([vv(1) PARAMS(q).defval vv(end)], 'stable');
    end
end
if N_RUNS < 2
    error('N_RUNS must be >= 2 for standard-deviation and CI statistics.');
end
T_CRIT = tinv(0.975, N_RUNS-1);  % 95%% CI for textual summaries only

% --- de-duplicated configuration table (see header) -------------------
% A single shared all-default configuration is trained once per repeat.
% Number of configurations = 1 + sum_q (numel(levels_q)-1).
% cfg fields: param (char; 'DEFAULT' for the shared default config),
% lambda (scan value; -1 sentinel for the default config), overrides
% (struct with the single swept name/value pair; empty for default).
cfg = struct('param',{}, 'lambda',{}, 'overrides',{});
default_added = false;
for q = 1:numel(PARAMS)
    for v = PARAMS(q).levels
        if v == PARAMS(q).defval
            if default_added, continue; end   % default trained once
            default_added = true;
            cfg(end+1) = struct('param','DEFAULT', 'lambda',-1, ...
                'overrides',struct());
        else
            cfg(end+1) = struct('param',PARAMS(q).name, 'lambda',v, ...
                'overrides',struct(PARAMS(q).name, v));
        end
    end
end
nC = numel(cfg);     % 40 full, 21 QUICK with the levels above
DEF_CFG = find(strcmp({cfg.param}, 'DEFAULT'), 1);

% cmap(q,k) = config index of parameter q at level k (summary/figures);
% the default level of every parameter maps to the shared DEF_CFG row.
nP = numel(PARAMS);
cmap = zeros(nP, max(arrayfun(@(z) numel(z.levels), PARAMS)));
for q = 1:nP
    for k = 1:numel(PARAMS(q).levels)
        v = PARAMS(q).levels(k);
        if v == PARAMS(q).defval
            cmap(q,k) = DEF_CFG;
        else
            cmap(q,k) = find(strcmp({cfg.param}, PARAMS(q).name) & ...
                [cfg.lambda] == v, 1);
        end
    end
end

%% A.1 Real-protein spectra and biological mask scenes -------------------
% Same source, validation and scene discovery as the supplied E1 biomask.
if ~isfile(M_FILE)
    error('Cannot find protein spectrum file: %s', M_FILE);
end
Dspec = load(M_FILE);
if ~isfield(Dspec,'M')
    error('%s does not contain variable M.', M_FILE);
end
M_true = double(Dspec.M);
[L,p] = size(M_true);
if L ~= 32 || p ~= 4
    error('Expected M_true 32 x 4, got %d x %d.', L, p);
end
if any(~isfinite(M_true(:))) || any(M_true(:)<0) || any(sum(M_true,1)<=0)
    error('M_true must be finite, nonnegative, and have nonzero columns.');
end
if isfield(Dspec,'channel_centers_nm')
    wl = double(Dspec.channel_centers_nm(:));
    if numel(wl) ~= L
        error('channel_centers_nm must have %d entries.', L);
    end
else
    wl = linspace(410.5,694.9,L)';
end
if isfield(Dspec,'endmember_names')
    endmember_names = cellstr(string(Dspec.endmember_names));
else
    endmember_names = {'Citrine','tdTomato','mKO2','mRuby'};
end
clear Dspec;
IMG_H = SIZE; IMG_W = SIZE; N = IMG_H*IMG_W;
if ~isfolder(MASK_ROOT)
    error('Cannot find biological-mask root: %s', MASK_ROOT);
end
Dscene = dir(MASK_ROOT);
Dscene = Dscene([Dscene.isdir]);
Dscene = Dscene(~ismember({Dscene.name},{'.','..'}));
scene_dirs = {};
for ii = 1:numel(Dscene)
    candidate = fullfile(MASK_ROOT,Dscene(ii).name);
    mask_dir = fullfile(candidate,'masks');
    if isfolder(mask_dir) && ~isempty(dir(fullfile(mask_dir,'*.png')))
        scene_dirs{end+1} = candidate; %#ok<SAGROW>
    end
end
if isempty(scene_dirs)
    error('No scenes with masks/*.png under %s', MASK_ROOT);
end
[~,ord_scene] = sort(lower(string(scene_dirs)));
scene_dirs = scene_dirs(ord_scene);
nScenes = numel(scene_dirs);
fprintf('Real protein spectra: %s (%d x %d)\n', M_FILE, L, p);
fprintf('Biomask scenes found: %d under %s\n', nScenes, MASK_ROOT);

%% A.2 Monte-Carlo OAT sensitivity sweep (PISCO only) -------------------
SAD_m = zeros(nC, N_RUNS);      % endmember SAD (deg)
MAB_m = zeros(nC, N_RUNS);      % abundance MSE
MRC_m = zeros(nC, N_RUNS);      % reconstruction MSE (vs noise-free rates)
T_m   = zeros(nC, N_RUNS);      % wall-clock seconds

fprintf(['E6 biological masks (PISCO only): %d repeats x %d configs ' ...
    '(OAT sweep of %d parameters), scene %dx%d, %d mean photons/channel, ' ...
    'MM_ITERS=%d\n'], N_RUNS, nC, nP, IMG_H, IMG_W, PHOTONS, MM_ITERS);
fprintf('Total scheduled trainings: %d (%d configs x %d repeats)\n', ...
    nC * N_RUNS, nC, N_RUNS);

fid = fopen(OUT_CSV, 'w');
fprintf(fid, 'param,lambda,run,photons,SAD_deg,MSE_ab,MSE_rec,time_s,eta_start,eta_end,sigma_cap\n');
n_csv_rows = 0;

rep_done = false;
for r = 1:N_RUNS
    % Cycle through the same mask scenes as the E1 biomask benchmark.
    scene_idx = 1 + mod(r-1,nScenes);
    scene_dir = scene_dirs{scene_idx};
    S_true = build_Strue_from_masks( ...
        scene_dir,IMG_H,IMG_W,p,MAX_PURITY, ...
        BASE_SEED + r,MASK_SIGMA,MASK_BACKGROUND);
    if ~isequal(size(S_true),[p,N])
        error('build_Strue_from_masks returned %s, expected [%d %d].', ...
              mat2str(size(S_true)),p,N);
    end
    Y_clean = M_true*S_true;

    % Separate noise RNG exactly as in the supplied E1 biomask demo.
    rng(BASE_SEED + 10000 + r, 'twister');
    % PHOTONS = average photon count per spectral channel.
    g = PHOTONS * N * L / sum(Y_clean(:));
    Y_counts = poissrnd(g * Y_clean) + READ_SIG * randn(L,N);
    Y_in = double(Y_counts) / g;
    % All OAT configurations of this repeat use the identical Y_in.

    % --- single baseline: override OAT parameter values IN PLACE -------
    % 10 for enclosure was intended for i.i.d. synthetic abundances;
    % masked biological abundances use 0.3 in SI v32c Table 1.
    % ETA=ETA_END=0.4 disables annealing (fixed chance level).
    base_args = {'spherize','yes', 'verbose',0, ...
        'MM_ITERS',MM_ITERS, 'WARM_UP',WARM_UP, 'LR',3e-4, ...
        'LAMBDA_VOL',0.008, 'LAMBDA_NONNEG',3, 'LAMBDA_EQ',100, ...
        'LAMBDA_SUMONE',2, 'LAMBDA_ENCLOSE',0.3, ...
        'IMG_H',IMG_H, 'IMG_W',IMG_W, 'LAMBDA_SPATIAL',2, ...
        'LAMBDA_MNONNEG',10, 'LAMBDA_SMOOTH',0.1, ...
        'NOISE_MODEL','poisson', 'NOISE_WEIGHT','uniform', ...
        'SIGMA_CAP',0.15, 'ETA',0.3, 'ETA_END',0.3, ...
        'PHOTON_GAIN',g, 'PHOTON_FLOOR',1, 'READ_SIGMA',READ_SIG};
    % Fail early if PARAMS key cannot be passed to the actual trainer.
    for qq = 1:numel(PARAMS)
        if ~any(strcmp(base_args(1:2:end), PARAMS(qq).name))
            error('Missing trainer argument for scanned parameter %s',PARAMS(qq).name);
        end
    end

    for c = 1:nC
        % apply this configuration's single-lambda override in place
        targs = base_args;
        ov = cfg(c).overrides;
        if ~isempty(fieldnames(ov))
            fn = fieldnames(ov);
            for q2 = 1:numel(fn)
                khit = find(strcmp(targs(1:2:end), fn{q2}), 1);
                targs{2*khit} = ov.(fn{q2});
            end
        end

        % ETA arm must keep ETA_END equal to ETA (NO annealing).
        if strcmp(cfg(c).param,'ETA')
            keta_end = find(strcmp(targs(1:2:end),'ETA_END'),1);
            targs{2*keta_end} = cfg(c).lambda;
        end
        keta  = find(strcmp(targs(1:2:end),'ETA'),1);
        kend  = find(strcmp(targs(1:2:end),'ETA_END'),1);
        ksig  = find(strcmp(targs(1:2:end),'SIGMA_CAP'),1);
        if targs{2*keta} ~= targs{2*kend}
            error('ETA must equal ETA_END in fixed-eta E6 experiment.');
        end

        % Strictly paired stochastic initialization across OAT configs:
        % same biological masks, noisy Y_in, and initial random stream.
        rng(BASE_SEED + 100000 + r, 'twister');
        t_run = tic;
        [M_est, S_est] = deep_mvsa_invflow_poisson_explicit_Warmup(Y_in, p, targs{:});
        T_m(c,r) = toc(t_run);

        % ---- metrics ----
        [perm, ~] = e6_match(M_true, M_est);
        [SAD_m(c,r), MAB_m(c,r), MRC_m(c,r)] = ...
            e6_metrics(M_true, S_true, Y_clean, M_est, S_est, perm);

        fprintf(['run %2d/%d | cfg %2d/%d %-14s | SAD %5.2f deg | ' ...
            'MSE_ab %.3e | MSE_rec %.3e | t %5.1fs\n'], r, N_RUNS, ...
            c, nC, cfg(c).param, ...
            SAD_m(c,r), MAB_m(c,r), MRC_m(c,r), T_m(c,r));
        fprintf(fid, '%s,%.10g,%d,%d,%.8f,%.10e,%.10e,%.4f,%.8g,%.8g,%.8g\n', ...
            cfg(c).param, cfg(c).lambda, r, PHOTONS, ...
            SAD_m(c,r), MAB_m(c,r), MRC_m(c,r), T_m(c,r), ...
            targs{2*keta}, targs{2*kend}, targs{2*ksig});
        n_csv_rows = n_csv_rows + 1;

        % keep representative run (first repeat, DEFAULT config)
        if r == 1 && c == DEF_CFG && ~rep_done
            rep_M = M_est; rep_perm = perm; rep_done = true;
        end
    end
end
fclose(fid);
fprintf('Per-run results written to %s (%d data rows)\n', ...
    OUT_CSV, n_csv_rows);

%% A.3 Summary (per parameter x level; default vs worst degradation) ----
fprintf('\n===== E6 SUMMARY over %d repeats (PISCO only, %d photons) =====\n', ...
    N_RUNS, PHOTONS);
for q = 1:nP
    lv = PARAMS(q).levels; nLv = numel(lv);
    defk = find(lv == PARAMS(q).defval, 1);
    fprintf('\n-- %s (default %g) --\n', PARAMS(q).name, PARAMS(q).defval);
    fprintf(['lambda      | SAD (deg) mean+/-std [95%% CI] | ' ...
        'MSE_ab mean+/-std | MSE_rec mean+/-std\n']);
    mSAD = zeros(1,nLv); mMAB = zeros(1,nLv);
    for k = 1:nLv
        cidx = cmap(q,k);
        dm = ' '; if k == defk, dm = '*'; end
        ci = T_CRIT * std(SAD_m(cidx,:)) / sqrt(N_RUNS);
        fprintf('%9g%s | %6.2f +/- %5.2f [+/-%4.2f] | %9.3e +/- %8.2e | %9.3e +/- %8.2e\n', ...
            lv(k), dm, mean(SAD_m(cidx,:)), std(SAD_m(cidx,:)), ci, ...
            mean(MAB_m(cidx,:)), std(MAB_m(cidx,:)), ...
            mean(MRC_m(cidx,:)), std(MRC_m(cidx,:)));
        mSAD(k) = mean(SAD_m(cidx,:));
        mMAB(k) = mean(MAB_m(cidx,:));
    end
    [worstSAD, kw] = max(mSAD);
    fprintf(['default vs worst level: SAD %+.2f deg ' ...
        '(%.2f at %g -> %.2f at %g), MSE_ab x%.2f\n'], ...
        worstSAD - mSAD(defk), mSAD(defk), lv(defk), ...
        worstSAD, lv(kw), mMAB(kw) / mMAB(defk));
end

%% A.4 Figure 1/2: all 10 sensitivity curves (mean +/- sample s.d.) --
% Five parameter columns per figure, two rows: SAD, abundance MSE.
% Each parameter has its own categorical levels; 0 is supported.
MUTE = [0.44 0.54 0.62];
nFigures = ceil(nP/5);
for fig_idx = 1:nFigures
    qfirst = (fig_idx-1)*5 + 1;
    qlast  = min(fig_idx*5,nP);
    groupN = qlast - qfirst + 1;
    figure('Name',sprintf('E6 sensitivity - group %d of %d',fig_idx,nFigures), ...
        'Position',[40 40 max(850,285*groupN) 650], 'Color','w');
    for j = 1:groupN
        q = qfirst + j - 1;
        lv = PARAMS(q).levels; nLv = numel(lv);
        defk = find(lv == PARAMS(q).defval, 1);
        labels = arrayfun(@(x) sprintf('%g',x),lv,'UniformOutput',false);
        mSAD = zeros(1,nLv); sSAD = zeros(1,nLv);
        mMAB = zeros(1,nLv); sMAB = zeros(1,nLv);
        for k = 1:nLv
            cidx = cmap(q,k);
            mSAD(k) = mean(SAD_m(cidx,:));
            sSAD(k) = std(SAD_m(cidx,:),0,2);
            mMAB(k) = mean(MAB_m(cidx,:));
            sMAB(k) = std(MAB_m(cidx,:),0,2);
        end
        subplot(2,groupN,j);
        errorbar(1:nLv,mSAD,sSAD,'s-','LineWidth',1.3, ...
            'MarkerSize',5,'Color',MUTE,'MarkerFaceColor',MUTE);
        hold on; xline(defk,'--','Color',[0.6 0.6 0.6]);
        set(gca,'XTick',1:nLv,'XTickLabel',labels, ...
            'XLim',[0.5 nLv+0.5],'Box','off');
        title(strrep(PARAMS(q).name,'_','\_'));
        ylabel('SAD (deg)'); grid on;

        subplot(2,groupN,groupN+j);
        % Linear scale is retained for MSE error bars (mean +/- s.d. can
        % otherwise extend below zero on a logarithmic axis).
        errorbar(1:nLv,mMAB,sMAB,'s-','LineWidth',1.3, ...
            'MarkerSize',5,'Color',MUTE,'MarkerFaceColor',MUTE);
        hold on; xline(defk,'--','Color',[0.6 0.6 0.6]);
        set(gca,'XTick',1:nLv,'XTickLabel',labels, ...
            'XLim',[0.5 nLv+0.5],'Box','off');
        xlabel('Parameter value'); ylabel('Abundance MSE'); grid on;
    end
    sgtitle(sprintf('E6 OAT sensitivity, parameters %d-%d (mean +/- s.d., n=%d)', ...
        qfirst,qlast,N_RUNS));
end

%% A.5 Figure 3: DEFAULT spectra from representative run -----------------
if rep_done
    figure('Name','E6: endmembers, DEFAULT config (run 1)', ...
        'Position',[50 50 950 600], 'Color','w');
    for i = 1:p
        subplot(2,2,i);
        plot(wl, M_true(:,i), 'k-', 'LineWidth',2); hold on;
        ep = rep_M(:,rep_perm(i));
        ep = ep/max(max(ep),eps);
        plot(wl, ep, '--', 'LineWidth',1.2, ...
            'Color',[0.64 0.08 0.18]);
        xlabel('Wavelength (nm)'); ylabel('Normalized intensity');
        title(endmember_names{i}, 'Interpreter','none'); grid on;
        if i==1
            legend('Ground truth', 'PISCO (default)', 'Location', 'best');
        end
    end
    sgtitle(sprintf(['Endmembers, DEFAULT configuration, run 1 ' ...
        '(%d mean photons/channel)'], PHOTONS));
end

%% ==================== local functions ================================
function [perm, sad_v] = e6_match(M_true, M_est)
% Greedy permutation matching by spectral angle distance.
p = size(M_true, 2);
Cmat = zeros(p);
for i = 1:p
    for j = 1:p
        Cmat(i,j) = acosd(max(-1, min(1, ...
            (M_true(:,i)'*M_est(:,j)) / ...
            (norm(M_true(:,i))*norm(M_est(:,j))))));
    end
end
perm = zeros(1,p); taken = false(1,p);
for i = 1:p
    [~,jj] = min(Cmat(i,:) + taken*1e6); perm(i) = jj; taken(jj) = true;
end
sad_v = Cmat(sub2ind([p p], 1:p, perm));
end

function [sad, mse_ab, mse_rec] = e6_metrics(M_true, S_true, Y_clean, ...
    M_est, S_est, perm)
[~, sad_v] = e6_match(M_true, M_est);
sad     = mean(sad_v);
mse_ab  = mean((S_true(:) - reshape(S_est(perm,:), [], 1)).^2);
mse_rec = mean((Y_clean(:) - reshape(M_est*S_est, [], 1)).^2);
end
