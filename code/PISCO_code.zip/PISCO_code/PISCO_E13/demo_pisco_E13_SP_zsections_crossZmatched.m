%% demo_pisco_E13_SP_zsections.m
% E13-SP: single-photon HyU zebrafish Z-section reproducibility.
% Main script (not a function): five independent NoASC PISCO fits,
% anchor-based cross-Z full-spectrum SAD assignment, and consistency analysis.
%
% Based on:
%   demo_pisco_E9_A_GYL66_E1_L2_residual_with_ROI5_NoASC.m
%   demo_pisco_E13_zsections.m
%
% IMPORTANT SCIENTIFIC CONVENTIONS
%   * NO external endmember spectra are used for matching or evaluation.
%   * Z=13 is the anchor; other Z planes are aligned to it by globally
%     minimizing the total 5-by-5 SAD assignment (one-to-one permutation).
%   * Component_1..Component_5 are cross-Z correspondence labels, NOT
%     confirmed protein identities. They are not biological labels.
%   * Z sections from one fish are NOT independent biological specimens.
%   * Adjacent-Z abundance Pearson is descriptive; anatomical changes between
%     sections and misregistration can also reduce correlation.
%   * ROI-derived crosstalk is an internal mixture statistic, NOT verified
%     fluorescence bleed-through measured with single-stain controls.
%   * External reference MAT is read ONLY for the 32-channel wavelength axis;
%     its endmember matrix/names are not loaded or compared.
%   * S contains the original NoASC coefficients (no sum-to-one, no FCLS,
%     no nonnegative S-polish, no multiplication by observed intensity).
%   * Saved full-resolution maps are in ORIGINAL raster orientation.
%     Left/right mirroring and percentile stretch are DISPLAY ONLY.
%
% REQUIRED INPUTS (same layout as E9-A)
%   ./data_E9/fig2_e_01-fish5-muscle-fl.lsm
%   ./PISCO_M_32x4_HyU_strict_quasar32.mat (or '(10)' variant)
%   deep_mvsa_invflow_poisson_explicit_Warmup2_NoASC.m on MATLAB path
%
% OUTPUTS: ./E13_SP_output/<parameter_profile>[/QUICK]/
%   E13z_SP_z09.mat ... E13z_SP_z17.mat (self-contained per-Z, <100MB typical)
%   pisco_E13_SP_results.csv
%   pisco_E13_SP_crossZ_matching.csv
%   pisco_E13_SP_pairwise.csv
%   pisco_E13_SP_consistency.csv
%   E13_SP_plotdata.mat (lightweight, enough for overview plots)
%   E13_SP_all_endmembers.svg / overview / spectrum / numerical SVG
%
% MATLAB R2023a+ with Image Processing Toolbox; training function required.
% Source code is assembled from supplied examples; execution on the original
% LSM and the external PISCO trainer must be verified on the user's machine.

clearvars; close all; clc;

%% 0. User configuration -------------------------------------------------
Z_LIST       = [11 12 13 14 15];
P            = 5;
SEED0        = 1001;
SEED_POLICY  = 'fixed';   % 'fixed' -> 1001 for each Z; 'by_z' -> 1001+Z

% 'E9A' uses the exact E9-A source's TRAINER options, including the
% absence of an explicit SIGMA_CAP argument (trainer default is used).
% 'E13_PLAN' uses the original E13 draft parameters but swaps in the
% production NoASC trainer. They are intentionally saved separately.
PARAM_PROFILE = 'E9A';   % 'E9A' or 'E13_PLAN'

QUICK          = false;  % true: central crop, diagnostic ONLY
QUICK_CROP     = 256;
ANALYSIS_ONLY  = false;  % true: load MATs; do not train or read LSM
FORCE_RETRAIN  = false;  % false: resume using matching saved MATs
SHOW_FIGURES   = true;
SAVE_SVG       = true;   % save SVG figures alongside numerical results
DISPLAY_FLIP_LR = true;
DISPLAY_LOW_PCT = 65;
DISPLAY_HIGH_PCT = 99.5;
DISPLAY_GAMMA  = 0.85;
PREVIEW_SIZE   = 320;     % pixels, lightweight display data per Z
RESID_BLOCK_N  = 32768;   % reconstruction diagnostics, avoid full Yhat

switch upper(PARAM_PROFILE)
    case 'E9A'
        MM_ITERS = 2500; WARM_UP = 600; READ_SIG = 2;
        LAMBDA_ENCLOSE = 0.1; LAMBDA_SPATIAL = 25;
        SIGMA_CAP_OVERRIDE = [];  % E9-A source does not pass SIGMA_CAP
    case 'E13_PLAN'
        MM_ITERS = 3500; WARM_UP = 600; READ_SIG = 1;
        LAMBDA_ENCLOSE = 10; LAMBDA_SPATIAL = 2;
        SIGMA_CAP_OVERRIDE = 0.03;
    otherwise
        error('E13SP:badProfile', 'PARAM_PROFILE must be E9A or E13_PLAN.');
end
assert(numel(unique(Z_LIST)) == numel(Z_LIST) && all(Z_LIST >= 1) && ...
    all(Z_LIST == round(Z_LIST)), 'E13SP:ZList', 'Invalid Z_LIST.');
assert(P == 5, 'E13SP:p', 'This SP protocol uses exactly 5 endmembers.');
assert(ismember(lower(SEED_POLICY), {'fixed','by_z'}), ...
    'E13SP:seedPolicy','Choose fixed or by_z.');

%% 1. Locations and wavelength-axis metadata -----------------------------
script_dir = fileparts(mfilename('fullpath'));
if isempty(script_dir), script_dir = pwd; end
addpath(script_dir);
F_MAIN = fullfile(script_dir, 'data_E9', 'fig2_e_01-fish5-muscle-fl.lsm');
if exist(F_MAIN,'file') ~= 2
    F_MAIN = fullfile(script_dir, 'fig2_e_01-fish5-muscle-fl.lsm');
end
REF_MAT = fullfile(script_dir, 'PISCO_M_32x4_HyU_strict_quasar32.mat');
if exist(REF_MAT,'file') ~= 2
    REF_MAT = fullfile(script_dir, 'PISCO_M_32x4_HyU_strict_quasar32(10).mat');
end
if exist(REF_MAT,'file') ~= 2
    candidates=dir(fullfile(script_dir,'PISCO_M_32x4_HyU_strict_quasar32*.mat'));
    assert(numel(candidates)==1, 'E13SP:ReferenceAmbiguous', ...
        ['Expected exactly one candidate reference MAT when the canonical ' ...
         'and (10) versions are absent. Found %d; rename the intended ' ...
         'reference as PISCO_M_32x4_HyU_strict_quasar32.mat.'],numel(candidates));
    REF_MAT=fullfile(script_dir,candidates(1).name);
end
assert(exist(REF_MAT,'file') == 2, 'E13SP:MissingRef', ...
    'Missing wavelength-axis metadata MAT (PISCO_M_32x4_HyU_strict_quasar32.mat).');
% The MAT is used ONLY as wavelength-axis metadata. Its reference spectra
% and protein names are deliberately not loaded or used for matching.
R = load(REF_MAT,'channel_centers_nm','channel_edges_nm');
assert(isfield(R,'channel_centers_nm'), 'E13SP:Wavelengths', ...
    'Wavelength metadata MAT must contain channel_centers_nm.');
wl = double(R.channel_centers_nm(:).');
assert(numel(wl)==32 && all(isfinite(wl)) && all(diff(wl)>0), ...
    'E13SP:Wavelengths','Wavelength axis must have 32 increasing values.');
if isfield(R,'channel_edges_nm')
    edges = double(R.channel_edges_nm(:).');
    assert(numel(edges)==33 && abs(edges(1)-410.5)<1 && ...
        abs(edges(end)-694.9)<1, 'E13SP:RefGrid', ...
        'Wavelength band edges do not match the HyU 32-channel grid.');
end

out_dir = fullfile(script_dir,'E13_SP_output1', upper(PARAM_PROFILE));
if QUICK, out_dir=fullfile(out_dir,sprintf('QUICK_%d',QUICK_CROP)); end
if exist(out_dir,'dir')~=7, mkdir(out_dir); end

% Record ALL algorithm-affecting settings for checking cached outputs.
config = struct();
config.profile = upper(PARAM_PROFILE);
config.z_list = Z_LIST;
config.p = P;
config.seed0 = SEED0;
config.seed_policy = lower(SEED_POLICY);
config.mm_iters = MM_ITERS;
config.warm_up = WARM_UP;
config.read_sigma = READ_SIG;
config.lambda_enclose = LAMBDA_ENCLOSE;
config.lambda_spatial = LAMBDA_SPATIAL;
config.sigma_cap_override = SIGMA_CAP_OVERRIDE;
config.eta = 0.3;
config.lambda_vol = 0.008;
config.lambda_nonneg = 3;
config.lambda_eq = 100;
config.lambda_sumone = 0;
config.lr = 3e-4;
config.spherize = 'yes';
config.verbose = 0;
config.photon_gain = 1;
config.photon_floor = 1;
config.noise_model = 'poisson';
config.quick = QUICK;
config.quick_crop = QUICK_CROP;
config.training_function = 'deep_mvsa_invflow_poisson_explicit_Warmup2_NoASC';
config.ref_file = REF_MAT; % retained for cache compatibility; wavelength metadata only

fprintf('\nE13-SP single-photon | profile=%s | Z=[%s] | p=%d\n', ...
    config.profile, num2str(Z_LIST), P);
fprintf('Input: %s\nOutput: %s\nWavelength-axis metadata: %s (no reference spectra used)\n', ...
    F_MAIN,out_dir,REF_MAT);
fprintf('Note: one fish / five Z planes; NOT five independent biological samples.\n');

if ~ANALYSIS_ONLY
    assert(exist(F_MAIN,'file')==2,'E13SP:MissingLSM', ...
        'LSM not found; place the file in data_E9 beside this script.');
    assert(~isempty(which(config.training_function)), 'E13SP:MissingTrainer', ...
        'Put deep_mvsa_invflow_poisson_explicit_Warmup2_NoASC.m on MATLAB path.');
    fprintf('Trainer: %s\n', which(config.training_function));
end

%% 2. Train each Z plane (or resume) -------------------------------------
for iz = 1:numel(Z_LIST)
    z = Z_LIST(iz);
    if strcmpi(SEED_POLICY,'fixed'), seed = SEED0;
    else, seed = SEED0 + z;
    end
    matf = fullfile(out_dir, sprintf('E13z_SP_z%02d.mat',z));

    if exist(matf,'file')==2 && ~FORCE_RETRAIN
        saved = load(matf,'config','z','seed','names');
        assert(isfield(saved,'config') && isfield(saved,'z') && ...
            isfield(saved,'seed'), 'E13SP:LegacyMat', ...
            'Saved MAT lacks configuration: %s; set FORCE_RETRAIN=true.',matf);
        chk = saved.config;
        assert(isequaln(chk, config) && saved.z==z && saved.seed==seed, ...
            'E13SP:CachedMismatch', ...
            'Saved MAT settings differ from current run: %s. Set FORCE_RETRAIN=true.',matf);
        fprintf('Z=%2d | existing MAT verified; skip training.\n',z);
        continue
    end
    assert(~ANALYSIS_ONLY, 'E13SP:MissingSaved', ...
        'ANALYSIS_ONLY=true but no matching saved MAT for Z=%d.',z);

    fprintf('\n----- E13-SP Z=%d (%d/%d), seed=%d -----\n', ...
        z,iz,numel(Z_LIST),seed);
    t_read = tic;
    [Y_cube,z_used] = e13sp_read_lsm_plane(F_MAIN,z);
    [L,H0,W0] = size(Y_cube);
    assert(L==32 && z_used==z,'E13SP:ReadShape','Unexpected LSM data shape.');
    if QUICK
        assert(H0>=QUICK_CROP && W0>=QUICK_CROP && ...
            mod(QUICK_CROP,2)==0,'E13SP:QuickCrop','Invalid QUICK_CROP.');
        r0 = floor((H0-QUICK_CROP)/2)+1;
        c0 = floor((W0-QUICK_CROP)/2)+1;
        Y_cube=Y_cube(:,r0:r0+QUICK_CROP-1,c0:c0+QUICK_CROP-1);
    end
    [~,H,W]=size(Y_cube);
    Y=reshape(Y_cube,32,[]); clear Y_cube
    N=H*W;
    total_img=reshape(sum(Y,1),H,W);
    fprintf('  Read %.1f s | %d x %d x 32 | %d pixels\n',toc(t_read),H,W,N);

    % Exactly the E9-A signal-mask convention, log total intensity Otsu.
    valid_img=isfinite(total_img) & total_img>0;
    log_img=log1p(max(total_img,0));
    gray_img=mat2gray(log_img);
    otsu_level=graythresh(gray_img);
    mask=valid_img & (gray_img>otsu_level);
    if ~any(mask(:))
        warning('E13SP:EmptyMask','Otsu signal mask empty at Z=%d; use positive pixels.',z);
        mask=valid_img;
    end
    assert(any(mask(:)),'E13SP:NoSignal','No positive observation pixels at Z=%d.',z);

    rng(seed);    % Keep raster order, required for 4-neighbour spatial term.
    train_args = {'spherize','yes','verbose',0, ...
        'MM_ITERS',MM_ITERS,'WARM_UP',WARM_UP,'LR',3e-4, ...
        'LAMBDA_VOL',0.008,'LAMBDA_NONNEG',3,'LAMBDA_EQ',100, ...
        'LAMBDA_SUMONE',0,'LAMBDA_ENCLOSE',LAMBDA_ENCLOSE, ...
        'IMG_H',H,'IMG_W',W,'LAMBDA_SPATIAL',LAMBDA_SPATIAL, ...
        'NOISE_MODEL','poisson','ETA',0.3, ...
        'PHOTON_GAIN',1,'PHOTON_FLOOR',1,'READ_SIGMA',READ_SIG};
    if ~isempty(SIGMA_CAP_OVERRIDE)
        train_args=[train_args,{'SIGMA_CAP',SIGMA_CAP_OVERRIDE}]; %#ok<AGROW>
    end

    fprintf('  Training NoASC, p=5, MM_ITERS=%d, WARM_UP=%d...\n',MM_ITERS,WARM_UP);
    t_train=tic;
    [M_est_raw,S_est_raw]= ...
        deep_mvsa_invflow_poisson_explicit_Warmup2_NoASC(Y,P,train_args{:});
    time_s=toc(t_train);
    if isa(M_est_raw,'gpuArray'), M_est_raw=gather(M_est_raw); end
    if isa(S_est_raw,'gpuArray'), S_est_raw=gather(S_est_raw); end
    M_est_raw=double(M_est_raw);
    assert(isequal(size(M_est_raw),[32 P]) && ...
        isequal(size(S_est_raw),[P N]),'E13SP:TrainerShape', ...
        'Unexpected trainer M/S dimensions.');
    assert(all(isfinite(M_est_raw(:))) && all(isfinite(S_est_raw(:))), ...
        'E13SP:NonFinite','Trainer returned non-finite M or S.');
    fprintf('  Training done in %.1f s\n',time_s);

    % Preserve the trainer's native component order. No external reference
    % spectra are used to rename, reorder, or score the estimated endmembers.
    M_est = M_est_raw;
    S_est = reshape(double(S_est_raw),P,H,W);
    clear S_est_raw

    % Native (unmodified) reconstruction using double coefficients.
    % Only the SAVED S is compressed to single precision (<100MB per MAT).
    [rmap,frob,mean_E1_signal,median_E1_signal] = ...
        e13sp_residual(Y,M_est,S_est,mask,RESID_BLOCK_N);
    % Temporary raw-order ROI/crosstalk; recomputed after cross-Z alignment.
    ROI=false(P,H,W);
    for j=1:P
        sj=double(squeeze(S_est(j,:,:)));
        ROI(j,:,:) = e13sp_segment(sj,'A1') | e13sp_segment(sj,'A2');
    end
    C=e13sp_crosstalk(S_est,ROI);
    row_leak_pct=100*(sum(C,2,'omitnan')-diag(C));
    row_leak_pct(all(isnan(C),2))=NaN;
    offdiag=C(~eye(P));
    mean_leak_pct=100*mean(offdiag,'omitnan');
    clear ROI

    % Save original trainer order. Cross-Z matching is a separate analysis
    % stage after all five independently trained endmember matrices exist.
    D=struct();
    D.M_est=M_est;                 % 32 x 5, native trainer order (pre-alignment)
    D.M_est_raw=M_est_raw;         % 32 x 5, native trainer order
    D.S=single(S_est);             % 5 x H x W, native trainer order
    D.S_order='raw';
    D.mask=logical(mask);          % H x W, signal ROI
    D.rmap=single(rmap);           % H x W, exact E1 per-pixel relative L2
    D.total_intensity=single(total_img);   % H x W original spectral sum
    D.C=C;                         % raw-order ROI mixture; recomputed after alignment
    D.row_leak_pct=row_leak_pct;
    D.mean_leak_pct=mean_leak_pct;
    D.frob=frob;                   % masked global relative Frobenius residual
    D.mean_E1_signal=mean_E1_signal;
    D.median_E1_signal=median_E1_signal;
    D.names=arrayfun(@(k)sprintf('Component_%d',k),1:P,'UniformOutput',false);
    D.wl=wl;
    D.z=z; D.seed=seed; D.p=P; D.H=H; D.W=W;
    D.mask_px=nnz(mask);
    D.otsu_level=otsu_level;
    D.time_s=time_s;
    D.modality='SP';
    D.config=config;
    D.train_args=train_args;      % exact trainer argument list for this Z
    D.provenance=['single fish, one FOV, z section; independent NoASC fits; ' ...
        'native trainer component order; no external reference spectra used'];
    save(matf,'-struct','D','-v7.3');
    fprintf('  Saved Z=%d | masked Fro=%.4f | E1 signal=%.4f | leak=%.2f%%\n', ...
        z,frob,mean_E1_signal,mean_leak_pct);
    fprintf('  MAT: %s\n',matf);
    clear D M_est M_est_raw S_est Y total_img rmap mask C
end

%% 3. Load native estimates and align all Z planes to the Z=13 anchor ------
% This stage is also backward-compatible with the previous script version:
% old MAT files stored S in external-reference order and retained D.ord,
% which maps displayed columns back to the original trainer columns.
resfile=fullfile(out_dir,'pisco_E13_SP_results.csv');
oldmatchfile=fullfile(out_dir,'pisco_E13_SP_matches.csv');
anchorfile=fullfile(out_dir,'pisco_E13_SP_crossZ_matching.csv');
pairfile=fullfile(out_dir,'pisco_E13_SP_pairwise.csv');
consfile=fullfile(out_dir,'pisco_E13_SP_consistency.csv');
if exist(oldmatchfile,'file')==2
    delete(oldmatchfile); % prevent stale reference-matching results being misread
end

ANCHOR_Z = 13;
anchor_idx=find(Z_LIST==ANCHOR_Z,1);
assert(~isempty(anchor_idx),'E13SP:AnchorMissing', ...
    'ANCHOR_Z=%d must be included in Z_LIST.',ANCHOR_Z);
labels=arrayfun(@(k)sprintf('Component_%d',k),1:P,'UniformOutput',false);
nZ=numel(Z_LIST);
Mraw_list=cell(nZ,1);

% First pass: load only the raw endmember matrices needed for matching.
for iz=1:nZ
    z=Z_LIST(iz);
    matf=fullfile(out_dir,sprintf('E13z_SP_z%02d.mat',z));
    assert(exist(matf,'file')==2,'E13SP:MissingMat', ...
        'Required saved result not found: %s',matf);
    T=load(matf,'config','M_est_raw','M_est','ord');
    assert(isfield(T,'config') && isequaln(T.config,config), ...
        'E13SP:ConfigMismatch','Saved MAT config differs: %s',matf);
    if isfield(T,'M_est_raw')
        Mraw=double(T.M_est_raw);
    elseif isfield(T,'ord') && numel(T.ord)==P
        % Fallback for a legacy MAT that stored only reference-ordered M_est.
        Mraw=zeros(size(T.M_est),'like',T.M_est);
        Mraw(:,T.ord)=T.M_est;
        Mraw=double(Mraw);
    else
        Mraw=double(T.M_est);
    end
    assert(isequal(size(Mraw),[32 P]) && all(isfinite(Mraw(:))), ...
        'E13SP:SavedM','Invalid native endmember matrix in %s.',matf);
    Mraw_list{iz}=Mraw;
end

% Z=13 defines the component order. For every other Z, solve the exact
% one-to-one assignment that minimizes the SUM of all five SAD values.
M_anchor=Mraw_list{anchor_idx};
ord_by_z=cell(nZ,1);
anchor_sad_by_z=NaN(nZ,P);
anchor_sad_matrix_by_z=cell(nZ,1);
for iz=1:nZ
    if iz==anchor_idx
        ord=1:P;
        Dsad=e13sp_sad_matrix(M_anchor,M_anchor);
        sad_anchor=diag(Dsad).';
    else
        [ord,sad_anchor,Dsad]=e13sp_global_min_sad_assignment( ...
            M_anchor,Mraw_list{iz});
    end
    ord_by_z{iz}=ord;
    anchor_sad_by_z(iz,:)=sad_anchor;
    anchor_sad_matrix_by_z{iz}=Dsad;
    fprintf('Z=%2d aligned to anchor Z=%d | total SAD=%.3f deg | order=[%s]\n', ...
        Z_LIST(iz),ANCHOR_Z,sum(sad_anchor),num2str(ord));
end

% Open fresh summary files; each run regenerates all CSVs from the MATs.
fr=fopen(resfile,'w');
fa=fopen(anchorfile,'w');
fp=fopen(pairfile,'w');
fc=fopen(consfile,'w');
assert(fr>0 && fa>0 && fp>0 && fc>0,'E13SP:OpenCSV', ...
    'Cannot open one or more E13-SP summary CSV files.');
clean_fr=onCleanup(@() fclose(fr));
clean_fa=onCleanup(@() fclose(fa));
clean_fp=onCleanup(@() fclose(fp));
clean_fc=onCleanup(@() fclose(fc));
fprintf(fr,['modality,z,seed,p,H,W,npix,mask_px,mask_frac,time_s,' ...
    'masked_frob_resid,mean_E1_signal,median_E1_signal,mean_leak_pct\n']);
fprintf(fa,['z,anchor_z,component,anchor_component_index,' ...
    'original_estimated_column,SAD_to_anchor_deg,is_anchor\n']);
fprintf(fp,'component,z1,z2,pairwise_SAD_deg,adjacent_Pearson,mask_intersection_px\n');
fprintf(fc,'modality,component,metric,mean,sd,n\n');

Mlist=cell(nZ,1);
C_list=cell(nZ,1);
row_leak=NaN(nZ,P);
mask_frob=NaN(nZ,1);
mean_leak=NaN(nZ,1);
mask_frac=NaN(nZ,1);
preview_ab=cell(nZ,1);
preview_each=cell(nZ,P);
preview_res=cell(nZ,1);
pearson_adj=NaN(nZ-1,P);
overlap_adj=zeros(nZ-1,1);
prev_S=[]; prev_mask=[];

% Second pass: recover native S order, apply anchor assignment, recalculate
% ROI-derived crosstalk in the aligned order, and update each MAT in place.
for iz=1:nZ
    z=Z_LIST(iz);
    matf=fullfile(out_dir,sprintf('E13z_SP_z%02d.mat',z));
    D=load(matf);
    if isfield(D,'S_order') && strcmpi(D.S_order,'crossZ_aligned')
        Sraw=e13sp_unalign_components(D.S,D.crossz_ord,P);
    elseif isfield(D,'S_order') && strcmpi(D.S_order,'raw')
        Sraw=D.S;
    elseif isfield(D,'ord') && numel(D.ord)==P
        % Compatibility with the earlier external-reference-matched MATs.
        Sraw=e13sp_unalign_components(D.S,D.ord,P);
    else
        Sraw=D.S;
    end
    assert(size(Sraw,1)==P && size(Sraw,2)==D.H && size(Sraw,3)==D.W, ...
        'E13SP:SavedS','Cannot recover native S order in %s.',matf);

    ord=ord_by_z{iz};
    S_aligned=Sraw(ord,:,:);
    M_aligned=Mraw_list{iz}(:,ord);
    D.M_est=M_aligned;
    D.M_est_raw=Mraw_list{iz};
    D.S=single(S_aligned);
    D.S_order='crossZ_aligned';
    D.crossz_ord=ord;  % aligned component j came from native column ord(j)
    D.crossz_anchor_z=ANCHOR_Z;
    D.crossz_sad_to_anchor=anchor_sad_by_z(iz,:);
    D.crossz_sad_matrix=anchor_sad_matrix_by_z{iz};
    D.names=labels;
    D.matching_mode='global_one_to_one_minimum_total_SAD_to_Z13_anchor';

    % Recalculate abundance-derived ROI/crosstalk after component alignment.
    ROI=false(P,D.H,D.W);
    for j=1:P
        sj=double(squeeze(D.S(j,:,:)));
        ROI(j,:,:) = e13sp_segment(sj,'A1') | e13sp_segment(sj,'A2');
    end
    C=e13sp_crosstalk(double(D.S),ROI);
    row_leak_pct=100*(sum(C,2,'omitnan')-diag(C));
    row_leak_pct(all(isnan(C),2))=NaN;
    offdiag=C(~eye(P));
    mean_leak_pct=100*mean(offdiag,'omitnan');
    D.C=C;
    D.row_leak_pct=row_leak_pct;
    D.mean_leak_pct=mean_leak_pct;

    % Remove legacy reference-matching fields so the MAT cannot be mistaken
    % for a result evaluated against external protein spectra.
    legacy={'ord','ref_idx_by_plot','sad_by_plot','SAD_ref_est', ...
        'ref_names','M_reference'};
    for il=1:numel(legacy)
        if isfield(D,legacy{il}), D=rmfield(D,legacy{il}); end
    end
    D.provenance=['single fish, one FOV, independent Z fits; components ' ...
        'globally one-to-one matched to Z=13 by minimum total spectral angle; ' ...
        'no external reference endmember spectra used'];
    save(matf,'-struct','D','-v7.3');

    % Per-Z training and reconstruction statistics.
    fprintf(fr,'SP,%d,%d,%d,%d,%d,%d,%d,%.8f,%.3f,%.8f,%.8f,%.8f,%.6f\n', ...
        z,D.seed,P,D.H,D.W,D.H*D.W,D.mask_px, ...
        D.mask_px/(D.H*D.W),D.time_s,D.frob, ...
        D.mean_E1_signal,D.median_E1_signal,D.mean_leak_pct);
    for j=1:P
        fprintf(fa,'%d,%d,%s,%d,%d,%.8f,%d\n', ...
            z,ANCHOR_Z,labels{j},j,ord(j),anchor_sad_by_z(iz,j),iz==anchor_idx);
    end

    Mlist{iz}=M_aligned;
    C_list{iz}=C;
    row_leak(iz,:)=row_leak_pct(:).';
    mask_frob(iz)=D.frob;
    mean_leak(iz)=mean_leak_pct;
    mask_frac(iz)=D.mask_px/(D.H*D.W);

    % Adjacent-Z abundance Pearson on the intersection of signal masks.
    if ~isempty(prev_S)
        msk=prev_mask & D.mask;
        overlap=nnz(msk);
        overlap_adj(iz-1)=overlap;
        for j=1:P
            if overlap>100
                pmap=double(squeeze(prev_S(j,:,:)));
                cmap=double(squeeze(D.S(j,:,:)));
                v1=pmap(msk); v2=cmap(msk);
                if std(v1)>0 && std(v2)>0
                    cc=corrcoef(v1,v2);
                    pearson_adj(iz-1,j)=cc(1,2);
                end
            end
        end
    end
    prev_S=D.S; prev_mask=D.mask;

    preview_ab{iz}=e13sp_preview_rgb(D.S,labels, ...
        PREVIEW_SIZE,DISPLAY_LOW_PCT,DISPLAY_HIGH_PCT, ...
        DISPLAY_GAMMA,DISPLAY_FLIP_LR);
    for j=1:P
        preview_each{iz,j}=e13sp_preview_each( ...
            double(squeeze(D.S(j,:,:))),j,PREVIEW_SIZE, ...
            DISPLAY_LOW_PCT,DISPLAY_HIGH_PCT,DISPLAY_GAMMA,DISPLAY_FLIP_LR);
    end
    tmp=double(D.rmap);
    hi=prctile(tmp(isfinite(tmp)),99);
    if ~isfinite(hi)||hi<=0, hi=1; end
    tmp=max(0,min(1,tmp/hi));
    tmp=imresize(tmp,[PREVIEW_SIZE PREVIEW_SIZE]);
    if DISPLAY_FLIP_LR, tmp=fliplr(tmp); end
    preview_res{iz}=single(tmp);
    clear D Sraw S_aligned ROI C
end

%% 4. Cross-Z pairwise SAD + consistency summaries -----------------------
SAD_pairwise=cell(P,1);
for j=1:P
    sadvals=[];
    for a=1:nZ-1
        for b=a+1:nZ
            v1=double(Mlist{a}(:,j)); v2=double(Mlist{b}(:,j));
            cosine=(v1.'*v2)/(norm(v1)*norm(v2));
            sad=acosd(max(-1,min(1,cosine)));
            sadvals(end+1)=sad; %#ok<SAGROW>
            if b==a+1
                rr=pearson_adj(a,j); ov=overlap_adj(a);
            else
                rr=NaN; ov=NaN;
            end
            fprintf(fp,'%s,%d,%d,%.8f,%.8f,%.0f\n', ...
                labels{j},Z_LIST(a),Z_LIST(b),sad,rr,ov);
        end
    end
    SAD_pairwise{j}=sadvals;
    e13sp_write_metric(fc,'SP',labels{j},'crossZ_pairwise_SAD_deg',sadvals);
    e13sp_write_metric(fc,'SP',labels{j},'adjacent_abundance_Pearson', ...
        pearson_adj(:,j));
    e13sp_write_metric(fc,'SP',labels{j},'row_leak_pct',row_leak(:,j));
    nonanchor=true(nZ,1); nonanchor(anchor_idx)=false;
    e13sp_write_metric(fc,'SP',labels{j},'SAD_to_Z13_anchor_deg', ...
        anchor_sad_by_z(nonanchor,j));
end
% These are descriptive summaries over five Z planes from one specimen.
e13sp_write_metric(fc,'SP','ALL','masked_frob_resid',mask_frob);
e13sp_write_metric(fc,'SP','ALL','mean_leak_pct',mean_leak);
e13sp_write_metric(fc,'SP','ALL','mask_fraction',mask_frac);
clear clean_fr clean_fa clean_fp clean_fc

%% 5. Lightweight data for Supplementary Fig. 6 --------------------------
plotdata=struct();
plotdata.modality='SP';
plotdata.zlist=Z_LIST;
plotdata.anchor_z=ANCHOR_Z;
plotdata.matching_mode='global_one_to_one_minimum_total_SAD_to_Z13_anchor';
plotdata.M_aligned=Mlist;
plotdata.C=C_list;
plotdata.labels=labels;
plotdata.crossz_ord_by_z=ord_by_z;
plotdata.SAD_to_anchor_deg=anchor_sad_by_z;
plotdata.SAD_to_anchor_matrices=anchor_sad_matrix_by_z;
plotdata.wl=wl;
plotdata.pairwise_SAD_deg=SAD_pairwise;
plotdata.adjacent_Pearson=pearson_adj;
plotdata.adjacent_mask_overlap_px=overlap_adj;
plotdata.row_leak_pct=row_leak;
plotdata.mean_leak_pct=mean_leak;
plotdata.masked_frob_resid=mask_frob;
plotdata.mask_fraction=mask_frac;
plotdata.preview_abundance_rgb=preview_ab;
plotdata.preview_individual_rgb=preview_each;
plotdata.preview_residual_scaled=preview_res;
plotdata.preview_residual_is_display_only=true;
plotdata.display_flip_lr=DISPLAY_FLIP_LR;
plotdata.config=config;
plotdata.note=['Endmembers are matched across Z planes only; no external ' ...
    'reference spectra are used. Full-resolution aligned M/S, masks and ' ...
    'unscaled residuals are saved in E13z_SP_zXX.mat.'];
save(fullfile(out_dir,'E13_SP_plotdata.mat'),'plotdata','-v7.3');

%% 6. Show figures; do not save PNG ---------------------------------------
if SHOW_FIGURES
    f1=figure('Name','E13-SP | Z-section abundances and residuals', ...
        'Color','w','Position',[40 40 1200 1350]);
    t1=tiledlayout(f1,nZ,2,'TileSpacing','compact','Padding','compact');
    for iz=1:nZ
        ax=nexttile(t1,2*iz-1);
        image(ax,preview_ab{iz}); axis(ax,'image'); axis(ax,'off');
        title(ax,sprintf('Z=%d | 5-endmember NoASC overlay',Z_LIST(iz)));
        ax=nexttile(t1,2*iz);
        imagesc(ax,preview_res{iz},[0 1]); axis(ax,'image'); axis(ax,'off');
        colormap(ax,'turbo');
        title(ax,sprintf('Z=%d | E1 residual (P99 display scale)',Z_LIST(iz)));
    end
    title(t1,'E13-SP: independent Z fits, Z=13 anchor-aligned components');

    f2=figure('Name','E13-SP | Spectral consistency', ...
        'Color','w','Position',[80 50 1350 850]);
    t2=tiledlayout(f2,2,3,'TileSpacing','compact','Padding','compact');
    cmap=lines(nZ);
    for j=1:P
        ax=nexttile(t2,j); hold(ax,'on');
        for iz=1:nZ
            v=Mlist{iz}(:,j);
            plot(ax,wl,v/max(max(v),eps),'Color',cmap(iz,:), ...
                'LineWidth',1.4,'DisplayName',sprintf('Z=%d',Z_LIST(iz)));
        end
        title(ax,labels{j},'Interpreter','none');
        xlabel(ax,'Wavelength (nm)'); ylabel(ax,'Peak-normalised value');
        xlim(ax,[wl(1) wl(end)]); grid(ax,'on'); hold(ax,'off');
        if j==1, legend(ax,'Location','best','FontSize',8); end
    end
    ax=nexttile(t2,6);
    sad_mean=cellfun(@(v) mean(v,'omitnan'),SAD_pairwise);
    bar(ax,1:P,sad_mean);
    xticks(ax,1:P); xticklabels(ax,labels); xtickangle(ax,35);
    ylabel(ax,'Cross-Z mean SAD (deg)');
    title(ax,'Mean pairwise SAD after Z=13 alignment');
    grid(ax,'on');
    title(t2,'E13-SP: full-spectrum cross-Z alignment (no external reference)');

    f3=figure('Name','E13-SP | Numerical stability', ...
        'Color','w','Position',[110 80 1000 550]);
    t3=tiledlayout(f3,1,2,'TileSpacing','compact','Padding','compact');
    ax=nexttile(t3,1);
    plot(ax,Z_LIST,mask_frob,'-o','LineWidth',1.6);
    xlabel(ax,'Z section'); ylabel(ax,'Masked relative Frobenius residual'); grid(ax,'on');
    ax=nexttile(t3,2);
    imagesc(ax,pearson_adj,[-1 1]); colormap(ax,'parula'); colorbar(ax);
    xticks(ax,1:P); xticklabels(ax,labels); xtickangle(ax,35);
    yticks(ax,1:nZ-1);
    pair_labels = arrayfun(@(a,b) sprintf('%d-%d',a,b), ...
        Z_LIST(1:end-1), Z_LIST(2:end), 'UniformOutput', false);
    yticklabels(ax,pair_labels);
    title(ax,'Adjacent-Z abundance Pearson');
    title(t3,'E13-SP numerical summaries (one fish, five sections)');
    f4=figure('Name','E13-SP | Each endmember across five Z sections', ...
        'Color','k','Position',[140 50 1650 1650]);
    t4=tiledlayout(f4,nZ,P,'TileSpacing','compact','Padding','compact');
    for iz=1:nZ
        for j=1:P
            ax=nexttile(t4,(iz-1)*P+j);
            image(ax,preview_each{iz,j}); axis(ax,'image'); axis(ax,'off');
            set(ax,'Color','k');
            if iz==1
                title(ax,labels{j},'Interpreter','none','Color','w', ...
                    'FontSize',11);
            end
            if j==1
                text(ax,0.02,0.95,sprintf('Z=%d',Z_LIST(iz)), ...
                    'Units','normalized','Color','w','FontSize',12, ...
                    'FontWeight','bold','VerticalAlignment','top');
            end
        end
    end
    title(t4,'E13-SP | 5 endmembers x 5 Z sections (display only)', ...
        'Color','w','FontSize',15);
    if SAVE_SVG
        % print -dsvg is supported by older MATLAB versions than some
        % exportgraphics(...,svg) configurations. Raster microscopy pixels
        % remain embedded rasters; annotations/axes are vector elements.
        print(f1,fullfile(out_dir,'E13_SP_overview.svg'),'-dsvg');
        print(f2,fullfile(out_dir,'E13_SP_spectral_consistency.svg'),'-dsvg');
        print(f3,fullfile(out_dir,'E13_SP_numerical_summary.svg'),'-dsvg');
        print(f4,fullfile(out_dir,'E13_SP_all_endmembers.svg'),'-dsvg');
    end
end

fprintf('\n=========== E13-SP FINISHED ===========\n');
fprintf('Output directory: %s\n',out_dir);
fprintf('Z sections: [%s] | trained/present: %d\n',num2str(Z_LIST),nZ);
fprintf('Masked Frobenius mean +/- SD: %.4f +/- %.4f\n', ...
    mean(mask_frob),std(mask_frob));
fprintf('ROI leakage mean +/- SD: %.3f +/- %.3f %%\n', ...
    mean(mean_leak),std(mean_leak));
for j=1:P
    ss=SAD_pairwise{j};
    rr = pearson_adj(:,j); rr = rr(isfinite(rr));
    if isempty(rr), rr_mean = NaN; else, rr_mean = mean(rr); end
    fprintf('  %-15s | cross-Z SAD mean %.2f, max %.2f deg | adj Pearson %.4f\n', ...
        labels{j},mean(ss),max(ss),rr_mean);
end
fprintf('Caution: Z sections are correlated technical sections, NOT independent specimens.\n');
fprintf('Caution: Component_1..5 are cross-Z correspondence labels, not protein identities.\n');

%% =============== local helpers (main experiment is a script) ===========
function [Y_cube,z_used]=e13sp_read_lsm_plane(fname,zsel)
% Same directory-selection logic as supplied E9-A reader; retains first
% 32 spectral channels, removes 33rd transmission image.
t=Tiff(fname,'r');
cleaner=onCleanup(@() t.close()); %#ok<NASGU>
have_info=false; Xi=0; Yi=0;
try
    tag=uint8(t.getTag(34412)); tag=tag(:);
    if numel(tag)>=28
        Xi=double(typecast(tag(9:12),'int32'));
        Yi=double(typecast(tag(13:16),'int32'));
        have_info=(Xi>0 && Yi>0);
    end
catch
    have_info=false;
end
ws=[]; hs=[]; spp=0;
while true
    ws(end+1)=t.getTag(Tiff.TagID.ImageWidth); %#ok<AGROW>
    hs(end+1)=t.getTag(Tiff.TagID.ImageLength); %#ok<AGROW>
    if spp==0, spp=t.getTag(Tiff.TagID.SamplesPerPixel); end
    if t.lastDirectory(), break; end
    t.nextDirectory();
end
if have_info
    is_data=(ws==Xi) & (hs==Yi);
else
    is_data=(ws.*hs)==max(ws.*hs);
end
datapages=find(is_data);
assert(~isempty(datapages),'E13SP:NoDataPage','No LSM full-resolution data pages.');
assert(spp>=32,'E13SP:Channels','Expected at least 32 channels.');
Z=numel(datapages);
assert(isscalar(zsel) && isnumeric(zsel) && zsel==round(zsel) && ...
    zsel>=1 && zsel<=Z, 'E13SP:BadZ', ...
    'Z=%d outside 1..%d in %s.',zsel,Z,fname);
z_used=zsel;
t.setDirectory(datapages(z_used));
A=t.read();
assert(ndims(A)==3 && size(A,3)>=32,'E13SP:BadRead', ...
    'Expected H x W x >=32 spectral LSM page, got %s.',mat2str(size(A)));
Y_cube=double(permute(A(:,:,1:32),[3 1 2]));
end

function [ord,sad_by_anchor,SAD]=e13sp_global_min_sad_assignment(M_anchor,M_current)
% Exact one-to-one minimum-total-SAD assignment for p=5.
% For five components, enumeration of all 5!=120 permutations is small,
% deterministic, toolbox-independent, and gives the same global optimum
% as the square linear-assignment/Hungarian objective.
SAD=e13sp_sad_matrix(M_anchor,M_current);
p=size(SAD,1);
assert(isequal(size(SAD),[p p]),'E13SP:AssignmentShape', ...
    'Anchor/current endmember counts must match.');
all_perm=perms(1:p);
best_cost=Inf; best_perm=1:p;
rows=1:p;
for k=1:size(all_perm,1)
    q=all_perm(k,:);
    idx=sub2ind([p p],rows,q);
    cost=sum(SAD(idx));
    if cost<best_cost
        best_cost=cost;
        best_perm=q;
    end
end
ord=best_perm;
sad_by_anchor=SAD(sub2ind([p p],rows,ord));
end

function SAD=e13sp_sad_matrix(M1,M2)
% Full-spectrum spectral-angle matrix: rows=M1 components, cols=M2.
assert(size(M1,1)==size(M2,1),'E13SP:SADDim', ...
    'Spectra must have the same number of wavelength channels.');
assert(all(isfinite(M1(:))) && all(isfinite(M2(:))), ...
    'E13SP:SADFinite','Endmember spectra must be finite.');
n1=sqrt(sum(double(M1).^2,1));
n2=sqrt(sum(double(M2).^2,1));
assert(all(n1>0) && all(n2>0),'E13SP:SADZero','Zero-norm endmember.');
A=double(M1)./n1;
B=double(M2)./n2;
cosine=max(-1,min(1,A.'*B));
SAD=acosd(cosine);
end

function Sraw=e13sp_unalign_components(Sordered,ord,p)
% Invert Sordered(j,:,:)=Sraw(ord(j),:,:).
assert(numel(ord)==p && isequal(sort(double(ord(:).')),1:p), ...
    'E13SP:BadOrder','Component order must be a permutation of 1:p.');
Sraw=zeros(size(Sordered),'like',Sordered);
for j=1:p
    Sraw(ord(j),:,:)=Sordered(j,:,:);
end
end

function [rmap,masked_frob,mean_signal,median_signal]= ...
    e13sp_residual(Y,M,S_img,mask,blockN)
% E9-A E1 EXACT pixelwise relative L2 residual, plus global masked Fro.
[L,N]=size(Y); [p,H,W]=size(S_img);
assert(size(M,1)==L && size(M,2)==p && H*W==N && ...
    isequal(size(mask),[H W]),'E13SP:ResidualDim','M/S/Y/mask mismatch.');
mask_vec=mask(:).';
rv=zeros(1,N,'single'); numerator=0; denominator=0;
for k=1:blockN:N
    ids=k:min(N,k+blockN-1);
    Yb=double(Y(:,ids));
    Sb=double(reshape(S_img(:,ids),p,[]));
    Yhat=M*Sb;
    delta=Yb-Yhat;
    err_sq=sum(delta.^2,1);
    obs_sq=sum(Yb.^2,1);
    rv(ids)=single(sqrt(err_sq)./max(sqrt(obs_sq),eps));
    m=mask_vec(ids);
    numerator=numerator+sum(err_sq(m));
    denominator=denominator+sum(obs_sq(m));
end
masked_frob=sqrt(numerator/max(denominator,eps));
rmap=reshape(rv,H,W);
x=double(rmap(mask & isfinite(rmap)));
assert(~isempty(x),'E13SP:NoResidual','No finite residual inside mask.');
mean_signal=mean(x);
median_signal=median(x);
end

function m=e13sp_segment(img,variant)
% Same E9-A deterministic abundance-derived mask ROI definitions.
g=mat2gray(img);
switch upper(variant)
    case 'A1'
        m=g>graythresh(g);
        m=bwareaopen(m,50);
        m=imclose(m,strel('disk',3));
    case 'A2'
        T=adaptthresh(g,0.5,'ForegroundPolarity','bright');
        m=imbinarize(g,T);
        m=bwareaopen(m,200);
        m=imclose(m,strel('disk',5));
    otherwise
        error('E13SP:ROIType','Invalid segmentation variant.');
end
m=logical(m);
end

function C=e13sp_crosstalk(S_img,ROI)
% E9-A row-normalised abundance contribution (not true bleedthrough).
p=size(S_img,1);
C=NaN(p);
for i=1:p
    m=double(squeeze(ROI(i,:,:)));
    row=zeros(1,p);
    for j=1:p
        v=double(squeeze(S_img(j,:,:)));
        row(j)=sum(v(:).*m(:));
    end
    if sum(row)>0, C(i,:)=row/sum(row); end
end
end

function e13sp_write_metric(fid,modality,component,metric,values)
x=double(values(:)); x=x(isfinite(x));
if isempty(x)
    mu=NaN; sd=NaN;
else
    mu=mean(x); sd=std(x);
end
fprintf(fid,'%s,%s,%s,%.10g,%.10g,%d\n', ...
    modality,component,metric,mu,sd,numel(x));
end

function rgb=e13sp_preview_rgb(S_img,names,preview_sz,lo,hi,gamma,flip_lr)
% Black background, percentile stretch; colors are fixed by aligned component.
p=size(S_img,1);
assert(p==numel(names),'E13SP:DisplayNames','Bad display name count.');
palette=[0.00 1.00 0.05; ...  % Component 1: green
         1.00 0.87 0.00; ...  % Component 2: yellow
         1.00 0.00 0.90; ...  % Component 3: magenta
         0.00 0.90 1.00; ...  % Component 4: cyan
         0.15 0.35 1.00];    % Component 5: blue
acc=zeros(size(S_img,2),size(S_img,3),3,'single');
for j=1:p
    color=palette(j,:);
    x=double(squeeze(S_img(j,:,:)));
    x(~isfinite(x))=0; x=max(0,x);
    low=prctile(x(:),lo); high=prctile(x(:),hi);
    if high<=low
        y=zeros(size(x),'single');
    else
        y=single(max(0,min(1,(x-low)/(high-low))).^gamma);
    end
    for c=1:3, acc(:,:,c)=acc(:,:,c)+y*single(color(c)); end
end
acc=max(0,min(1,acc));
acc=imresize(acc,[preview_sz preview_sz]);
if flip_lr, acc=fliplr(acc); end
rgb=im2uint8(acc);
end

function rgb=e13sp_preview_each(I,component_index,preview_sz,lo,hi,gamma,flip_lr)
% Single component; color is fixed by the anchor-aligned component index.
palette=[0.00 1.00 0.05; ...
         1.00 0.87 0.00; ...
         1.00 0.00 0.90; ...
         0.00 0.90 1.00; ...
         0.15 0.35 1.00];
assert(component_index>=1 && component_index<=size(palette,1), ...
    'E13SP:BadComponentColor','Invalid component index.');
color=palette(component_index,:);
x=double(I); x(~isfinite(x))=0; x=max(0,x);
low=prctile(x(:),lo); high=prctile(x(:),hi);
if high<=low
    x=zeros(size(x));
else
    x=max(0,min(1,(x-low)/(high-low))).^gamma;
end
intensity=imresize(single(x),[preview_sz preview_sz]);
rgb=zeros(preview_sz,preview_sz,3,'single');
for c=1:3
    rgb(:,:,c)=intensity*single(color(c));
end
if flip_lr, rgb=fliplr(rgb); end
rgb=im2uint8(rgb);
end
