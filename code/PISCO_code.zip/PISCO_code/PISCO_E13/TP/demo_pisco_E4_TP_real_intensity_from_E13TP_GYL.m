%% demo_pisco_E4_TP_real_intensity_from_E13TP_GYL.m
% E-4 | Real-acquisition intensity versus cross-Z spectral consistency.
% Standalone MATLAB SCRIPT (no PISCO retraining; no raw LSM reading).
%
% SOURCE: demo_pisco_E13_TP_SPstyle_minimal95MB_GYL.m, specifically:
%   E13_TP_Z##_core.mat: M_est, mask_u8, intensity_map, stats, config.
% Only the five core MATs are needed. Abundance part files are NOT needed.
%
% Scientific meaning:
% - intensity_map = sum over 32 ORIGINAL recorded intensity channels, BEFORE
%   model reconstruction (stored as single by E13-TP).
% - Unless independent detector calibration is available, these values are
%   RECORDED DIGITAL INTENSITY, NOT measured photon counts.
% - Spectral SAD is inter-section spectral disagreement relative to a
%   high-intensity section, NOT endmember error against independent truth.
% - Section differences may reflect real biological/composition differences.
% - The reference section has SAD=0 by definition; never treat it as an
%   independent recovery-accuracy observation.
%
% OUTPUT ONLY (separate folder; E13-TP data remain untouched):
%   E4_TP_real_intensity_results/pisco_E4_TP_real_intensity_results.csv
%   E4_TP_real_intensity_results/pisco_E4_TP_intensity_vs_SAD.svg
%
% MATLAB R2021b+; base MATLAB only. No Image Processing/Statistics Toolbox.

clear; close all; clc;

%% =================== CONFIGURATION ======================================
SCRIPT_DIR = fileparts(mfilename('fullpath'));
if isempty(SCRIPT_DIR), SCRIPT_DIR = pwd; end
E13_DIR = fullfile(SCRIPT_DIR, 'E13_TP_NoASC_BandLoss_FixedQTail_output2');
% If E13-TP results are elsewhere, replace E13_DIR with the full folder path.
E4_DIR = fullfile(SCRIPT_DIR, 'E4_TP_real_intensity_results');

Z_LIST = [8 9 10 11 12];   % EXACT latest uploaded E13-TP SPstyle script
P = 8;                     % expected endmembers
CHANNELS = 32;             % original spectral bands
EXPECTED_H = 2048;
EXPECTED_W = 2560;

% Automatically use the BRIGHTEST section on the COMMON spatial ROI as the
% spectral reference (independent of the original Z=12 alignment).
% Switch to 'z12' only when intentionally retaining Z=12 as the reference;
% in that case do NOT call Z=12 a high-intensity anchor unless verified.
REFERENCE_MODE = 'brightest';  % 'brightest' or 'z12'

% Physical photon conversion is OFF unless independently calibrated.
% PHOTONS_PER_DIGITAL_UNIT must be supplied from detector calibration;
% the PISCO option PHOTON_GAIN=0.1 is NOT that calibration.
HAVE_PHOTON_CALIBRATION = false;
PHOTONS_PER_DIGITAL_UNIT = NaN;

OUT_CSV = fullfile(E4_DIR, 'pisco_E4_TP_real_intensity_results.csv');
OUT_SVG = fullfile(E4_DIR, 'pisco_E4_TP_intensity_vs_SAD.svg');
%% ========================================================================

assert(numel(Z_LIST)>=2 && numel(unique(Z_LIST))==numel(Z_LIST), ...
    'E4:ZList','Z_LIST must contain at least two distinct sections.');
assert(all(Z_LIST==round(Z_LIST)) && all(Z_LIST>=1), ...
    'E4:ZList','Invalid Z section index.');
assert(any(strcmpi(REFERENCE_MODE,{'brightest','z12'})), ...
    'E4:ReferenceMode','REFERENCE_MODE must be brightest or z12.');
if HAVE_PHOTON_CALIBRATION
    assert(isscalar(PHOTONS_PER_DIGITAL_UNIT) && ...
        isfinite(PHOTONS_PER_DIGITAL_UNIT) && PHOTONS_PER_DIGITAL_UNIT>0, ...
        'E4:PhotonCal','Provide a verified, positive PHOTONS_PER_DIGITAL_UNIT.');
end
assert(isfolder(E13_DIR),'E4:MissingSource', ...
    'E13-TP result folder does not exist: %s',E13_DIR);
if ~isfolder(E4_DIR)
    [ok,msg]=mkdir(E4_DIR);
    assert(ok,'E4:OutputFolder','Cannot create E4 folder: %s',msg);
end

nZ=numel(Z_LIST);
core_files=cell(nZ,1);
M_by_z=cell(nZ,1);
mask_pixels=zeros(nZ,1);
masked_RRE=nan(nZ,1);
mean_full=nan(nZ,1);
mean_mask=nan(nZ,1);
mean_common=nan(nZ,1);
median_common=nan(nZ,1);
common_mask=[];
H=[]; W=[];

%% 1. Fixed/common ROI = intersection of five original E13-TP masks.
% This controls for changing pixel membership when comparing z intensities.
for i=1:nZ
    z=Z_LIST(i);
    f=fullfile(E13_DIR,sprintf('E13_TP_Z%02d_core.mat',z));
    assert(isfile(f),'E4:MissingCore','Missing E13-TP core MAT: %s',f);
    core_files{i}=f;
    A=load(f,'mask_u8','H_saved','W_saved','p','z','config');
    assert(isfield(A,'mask_u8') && isfield(A,'H_saved') && ...
           isfield(A,'W_saved') && isfield(A,'p') && isfield(A,'z'), ...
           'E4:CoreFields','Missing essential metadata in %s',f);
    if i==1
        H=double(A.H_saved); W=double(A.W_saved);
        common_mask=true(H,W);
    end
    assert(H==double(A.H_saved) && W==double(A.W_saved) && ...
           isequal(size(A.mask_u8),[H W]) && A.p==P && A.z==z, ...
           'E4:CoreMismatch','Mismatched Z, dimensions, p or mask in %s',f);
    assert(H==EXPECTED_H && W==EXPECTED_W, ...
           'E4:NotFullFrame','A cropped E13-TP result was supplied: %s',f);
    if isfield(A,'config') && isstruct(A.config)
        if isfield(A.config,'quick')
            assert(~logical(A.config.quick),'E4:PilotData', ...
                'Z=%d is a QUICK pilot; E-4 requires full-resolution core MAT.',z);
        end
    end
    this_mask=logical(A.mask_u8);
    mask_pixels(i)=nnz(this_mask);
    assert(mask_pixels(i)>0,'E4:EmptyMask','Empty Z=%d ROI.',z);
    common_mask=common_mask & this_mask;
    clear A this_mask;
end

common_pixels=nnz(common_mask);
assert(common_pixels>=1000,'E4:CommonROI', ...
    'The five-way common ROI is too small (%d pixels). Inspect masks.',common_pixels);
fprintf('E-4: %d complete Z sections, shared ROI=%d pixels (%.2f%% of field).\n', ...
    nZ,common_pixels,100*common_pixels/(H*W));

%% 2. Read original-recorded-intensity summaries + PISCO final endmembers.
% Never use E13-TP results.csv's "mean_E1_signal" as a photon/count measure:
% it is computed from the residual_map in the supplied E13-TP code.
for i=1:nZ
    z=Z_LIST(i);
    D=load(core_files{i},'M_est','intensity_map','mask_u8','stats');
    assert(isfield(D,'M_est') && isfield(D,'intensity_map') && ...
           isfield(D,'mask_u8') && isfield(D,'stats') && ...
           isfield(D.stats,'linear_frob'), ...
           'E4:CoreFields','Required data absent in Z=%d core MAT.',z);
    assert(isequal(size(D.M_est),[CHANNELS P]) && ...
           isequal(size(D.intensity_map),[H W]), ...
           'E4:CoreShape','Unexpected M_est or intensity_map shape, Z=%d.',z);
    assert(all(isfinite(D.M_est(:))), ...
           'E4:BadEndmembers','Nonfinite endmember at Z=%d.',z);
    assert(all(isfinite(D.intensity_map(:))) && all(D.intensity_map(:)>=0), ...
           'E4:BadIntensity','Invalid original recorded intensity at Z=%d.',z);
    M_by_z{i}=double(D.M_est);
    I=double(D.intensity_map);  % 32-band integrated original digital intensity
    m=logical(D.mask_u8);
    mean_full(i)=mean(I(:))/CHANNELS;
    mean_mask(i)=mean(I(m))/CHANNELS;
    mean_common(i)=mean(I(common_mask))/CHANNELS;
    median_common(i)=median(I(common_mask))/CHANNELS;
    masked_RRE(i)=double(D.stats.linear_frob);
    assert(all(isfinite([mean_full(i),mean_mask(i),mean_common(i), ...
        median_common(i),masked_RRE(i)])) && mean_common(i)>0, ...
        'E4:InvalidMetric','Invalid intensity or RRE for Z=%d.',z);
    fprintf('  Z=%d: common mean=%.6g DN/channel | own-mask mean=%.6g | RRE=%.5f\n', ...
        z,mean_common(i),mean_mask(i),masked_RRE(i));
    clear D I m;
end
clear common_mask;

%% 3. Select reference and match 8 endmembers (global 1:1 min-total-SAD).
if strcmpi(REFERENCE_MODE,'brightest')
    [~,idx_ref]=max(mean_common);
else
    idx_ref=find(Z_LIST==12,1);
    assert(~isempty(idx_ref),'E4:NoZ12','Z=12 is not in Z_LIST.');
end
REF_Z=Z_LIST(idx_ref);
M_ref=M_by_z{idx_ref};
ref_norm=sqrt(sum(M_ref.^2,1));
assert(all(ref_norm>1e-12),'E4:BadRef','Zero reference endmember spectrum.');

SAD_comp=nan(nZ,P);
matched_columns=nan(nZ,P);
allperm=perms(1:P);       % 8! = 40,320 permutations; EXACT like E13-TP
row_inds=repmat(1:P,size(allperm,1),1);
for i=1:nZ
    M=M_by_z{i};
    norms=sqrt(sum(M.^2,1));
    assert(all(norms>1e-12),'E4:ZeroEndmember', ...
        'Zero spectrum found at Z=%d, invalid SAD.',Z_LIST(i));
    C=max(-1,min(1, (M_ref./ref_norm)'*(M./norms)));
    cost=acosd(C);  % reference component row, raw-Z component column
    if i==idx_ref
        ord=1:P;
    else
        inds=sub2ind([P P],row_inds,allperm);
        totals=sum(cost(inds),2);
        [~,best]=min(totals);
        ord=allperm(best,:);
    end
    matched_columns(i,:)=ord;
    SAD_comp(i,:)=cost(sub2ind([P P],1:P,ord));
    if i==idx_ref
        SAD_comp(i,:)=0;  % fixed-reference self comparison, by definition
    end
    fprintf('  Z=%d vs reference Z=%d: matched mean SAD=%.4f deg\n', ...
        Z_LIST(i),REF_Z,mean(SAD_comp(i,:)));
end
clear M_by_z M_ref allperm row_inds;

SAD_mean=mean(SAD_comp,2);
SAD_sd=std(SAD_comp,0,2);    % among 8 components; NOT biological replicates
SAD_max=max(SAD_comp,[],2);
SAD_median=median(SAD_comp,2);
relative_brightness=mean_common/mean_common(idx_ref);

mean_photons=nan(nZ,1);
if HAVE_PHOTON_CALIBRATION
    mean_photons=mean_common*PHOTONS_PER_DIGITAL_UNIT;
end

%% 4. One compact, self-contained per-section statistical CSV.
% The reference's zero SAD is not included in independent accuracy claims.
T=table(Z_LIST(:),repmat(REF_Z,nZ,1),mask_pixels, ...
    repmat(common_pixels,nZ,1),mean_full,mean_mask, ...
    mean_common,median_common,relative_brightness,mean_photons, ...
    SAD_mean,SAD_sd,SAD_median,SAD_max,masked_RRE, ...
    'VariableNames',{'z','reference_z','signal_mask_pixels', ...
    'common_mask_pixels','mean_full_recorded_per_channel', ...
    'mean_mask_recorded_per_channel','mean_common_recorded_per_channel', ...
    'median_common_recorded_per_channel','relative_common_intensity', ...
    'mean_common_photons_per_channel','SAD_mean_deg','SAD_sd_deg', ...
    'SAD_median_deg','SAD_max_deg','reconstruction_RRE'});
for j=1:P
    T.(sprintf('SAD_component_%02d_deg',j))=SAD_comp(:,j);
end
for j=1:P
    T.(sprintf('matched_raw_column_%02d',j))=matched_columns(:,j);
end
T=sortrows(T,'mean_common_recorded_per_channel','ascend');
writetable(T,OUT_CSV);

%% 5. One genuinely editable VECTOR SVG (no embedded raster images).
fig=figure('Visible','off','Color','w','Position',[100 100 1250 570], ...
    'Renderer','painters');
t=tiledlayout(fig,1,2,'Padding','compact','TileSpacing','compact');
xx=mean_common;
if HAVE_PHOTON_CALIBRATION
    xx=mean_photons;
    xname='Mean detected photons / channel (calibrated)';
else
    xname='Mean recorded intensity / channel (uncalibrated units)';
end

ax=nexttile(t,1); hold(ax,'on');
for i=1:nZ
    if i==idx_ref
        plot(ax,xx(i),SAD_mean(i),'ks','MarkerSize',9, ...
            'MarkerFaceColor',[0.92 0.72 0.18],'LineWidth',1.4);
    else
        errorbar(ax,xx(i),SAD_mean(i),SAD_sd(i),'o', ...
            'Color',[0.13 0.37 0.69], ...
            'MarkerFaceColor',[0.13 0.37 0.69], ...
            'MarkerSize',7,'CapSize',5,'LineWidth',1.2);
    end
    text(ax,xx(i),SAD_mean(i),sprintf('  Z=%d',Z_LIST(i)), ...
        'FontName','Times New Roman','FontSize',10, ...
        'VerticalAlignment','bottom');
end
xlabel(ax,xname);ylabel(ax,'Mean cross-Z spectral angle (deg)');
title(ax,sprintf('Spectral agreement relative to Z=%d',REF_Z));
grid(ax,'on');box(ax,'on');hold(ax,'off');

ax=nexttile(t,2); hold(ax,'on');
for i=1:nZ
    if i==idx_ref
        plot(ax,xx(i),masked_RRE(i),'ks','MarkerSize',9, ...
            'MarkerFaceColor',[0.92 0.72 0.18],'LineWidth',1.4);
    else
        plot(ax,xx(i),masked_RRE(i),'o','MarkerSize',8, ...
            'Color',[0.16 0.53 0.43], 'MarkerFaceColor',[0.16 0.53 0.43]);
    end
    text(ax,xx(i),masked_RRE(i),sprintf('  Z=%d',Z_LIST(i)), ...
        'FontName','Times New Roman','FontSize',10, ...
        'VerticalAlignment','bottom');
end
xlabel(ax,xname);ylabel(ax,'Signal-mask relative Frobenius residual');
title(ax,'Measured-data reconstruction residual');
grid(ax,'on');box(ax,'on');hold(ax,'off');

allAxes=findall(fig,'Type','axes');
set(allAxes,'FontName','Times New Roman','FontSize',11);
title(t,'E-4 | Real two-photon Z-section intensity and spectral consistency', ...
    'FontName','Times New Roman','FontWeight','bold');
set(fig,'PaperPositionMode','auto');
print(fig,OUT_SVG,'-dsvg');
close(fig);

fprintf('\nE-4 DONE. Ref Z=%d (relative intensity %.4f).\n',REF_Z, ...
    relative_brightness(idx_ref));
fprintf('Common-ROI recorded intensity range: %.6g ... %.6g DN/channel (ratio %.3f).\n', ...
    min(mean_common),max(mean_common), ...
    max(mean_common)/max(min(mean_common),eps));
fprintf('Output CSV: %s\nOutput vector SVG: %s\n',OUT_CSV,OUT_SVG);
if ~HAVE_PHOTON_CALIBRATION
    fprintf(['NOTE: original LSM intensities are not calibrated photon counts; ' ...
             'the photon column remains NaN.\n']);
end
fprintf(['NOTE: cross-Z SAD measures spectral consistency (no external truth); ' ...
         'zero at reference is by definition.\n']);
if max(mean_common)/max(min(mean_common),eps)<1.5
    warning('E4:NarrowIntensityRange', ...
        ['Across-Z common-ROI intensity varies by less than 1.5x. ' ...
         'This may be inadequate to substantiate a low-count gradient.']);
end
