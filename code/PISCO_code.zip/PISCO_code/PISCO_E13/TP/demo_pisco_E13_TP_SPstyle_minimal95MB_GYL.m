%% demo_pisco_E13_TP_SPstyle_minimal95MB.m
% E13-Two-photon arm only.
%
% Purpose:
%   Independently unmix five Z sections of the HyU Fig.5e two-photon LSM
%   volume, then evaluate cross-Z endmember reproducibility without using
%   external reference spectra.
%
% Data:
%   fig5_e_01-fish1-four-hinbrain_eye-autofl.lsm
%   2048 x 2560 x 27 x 32 (metadata documented by the E9-B1 driver).
%
% Sections:
%   Z = [10 11 12 13 14], p = 8, anchor Z = 12.
%   This retains the Z_LIST from the user-uploaded TP minimal95MB script.
%
% Model:
%   Exact driver/trainer interface and parameter values copied from
%   demo_pisco_E9_B1_NoASC_BandLoss_FixedQTail_FinalOnly_GYL.m.
%   NoASC: LAMBDA_SUMONE = 0; forward reconstruction is M*S.
%   Fixed-Q tail output S_est is the final abundance used for evaluation.
%
% Cross-Z matching:
%   No external fluorophore/reference spectra are used.
%   Each non-anchor section is matched one-to-one to Z=12 by exact global
%   minimum-SAD assignment (p=8, exhaustive 8! permutations).
%
% Outputs (SP-compatible report layout, with TP-specific source/model):
%   E13_TP_NoASC_BandLoss_FixedQTail_output/
%     E13_TP_Z##_core.mat                 (native-order M, ROI, residuals)
%     E13_TP_Z##_abund_part###.mat       (native-order FINAL S_est only)
%     pisco_E13_TP_results.csv
%     pisco_E13_TP_crossZ_matching.csv
%     pisco_E13_TP_pairwise.csv
%     pisco_E13_TP_consistency.csv
%     E13_TP_plotdata.mat                (lightweight previews + all statistics)
%     E13_TP_overview.svg
%     E13_TP_spectral_consistency.svg
%     E13_TP_numerical_summary.svg
%     E13_TP_all_endmembers.svg
%
% Memory / output files:
%   One Z plane is read/trained at a time. Only the final Fixed-Q-tail
%   abundance S_est is persisted. For p=8 single precision, each abundance
%   chunk contains at most 2,700,000 pixels (86.4 MB raw payload). Core
%   and abundance MAT files, plus the lightweight plot MAT, are checked
%   against a strict 95,000,000-byte limit. A full
%   2048x2560 section therefore needs only two abundance MAT files. Legacy
%   abundance chunks are repacked without retraining when compatible.
%   The full-frame trainer is not a verified streaming solver. QUICK=true
%   is available for a 256x256 pilot, but the publication-scale run uses
%   QUICK=false.
%
% MATLAB: R2023a or later; Image Processing Toolbox, PISCO trainer,
% TIFF reader or Bio-Formats fallback. Plot images/SVGs follow E13-SP style.
% Existing TP results may be reused/repacked without retraining if compatible.
% Previous versions' extra CSV/PNG/SVG files are NOT deleted automatically.

clear; close all; clc;

%% --------------------------- CONFIGURATION ------------------------------
DATA_FILE_CANDIDATES = { ...
    'fig5_e_01-fish1-four-hinbrain_eye-autofl.lsm', ... % exact E9-B1 driver name
    'fig5_e_01-fish1-four-hindbrain_eye-autofl.lsm'};   % spelling in E13 draft
DATA_DIR = 'data_E9';

OUT_DIR_NAME = 'E13_TP_NoASC_BandLoss_FixedQTail_output2';

Z_LIST = [8 9 10 11 12];
ANCHOR_Z = 12;
P_FIXED = 8;                    % Prespecified Fig.5 comparison; not proof p_true=8
SEED = 1001;                    % Same production seed as E9-B1 for every Z

QUICK = false;                  % false: full 2048x2560; true: 256x256 center crop
if QUICK
    CROP_HW = [256 256];
    MAX_PIXELS = 256*256;
else
    CROP_HW = [0 0];
    MAX_PIXELS = 2048*2560;
end

TRAINER = 'deep_mvsa_invflow_poisson_explicit_Warmup2_FixedQTail';
REUSE_EXISTING_MAT = true;      % Reuse per-Z results when compatible
ANALYSIS_ONLY = false;          % true: MAT-only summary/replot, no LSM/trainer
FORCE_RETRAIN = false;          % true: retrain all five Z sections
ABUNDANCE_CHUNK_PIXELS = 2700000;  % 8 x 2.7M single values = 86.4 MB raw
MAX_ABUNDANCE_MAT_BYTES = 95000000;  % strict decimal 95 MB ceiling
RECON_BLOCK = 20000;
SHOW_FIGURES = true;
SAVE_SVG = true;
DISPLAY_FLIP_LR = true;
DISPLAY_LOW_PCT = 65;
DISPLAY_HIGH_PCT = 99.5;
DISPLAY_GAMMA = 0.85;
PREVIEW_SIZE = 320;
% SP follows log-intensity Otsu; this TP arm intentionally keeps the E9-B1
% intensity > P25 signal mask to preserve the acquired TP ROI / residual protocol.
% The rest of the SP report (CSV definitions and four-figure layout) is matched.


% Exact E9-B1 NoASC + BandLoss + Fixed-Q-tail settings.
OPT = struct( ...
    'MM_ITERS',2500, ...
    'WARM_UP',600, ...
    'LAMBDA_BAND',5, ...
    'LAMBDA_ENCLOSE',10, ...
    'LAMBDA_SPATIAL',2, ...
    'LAMBDA_SMOOTH',0.1, ...
    'LAMBDA_MNONNEG',10, ...
    'NOISE_MODEL','poisson', ...
    'NOISE_WEIGHT','uniform', ...
    'PHOTON_GAIN',0.1, ...
    'PHOTON_FLOOR',1, ...
    'READ_SIGMA',1, ...
    'ETA',0.4, ...
    'ETA_END',0.4, ...
    'SIGMA_CAP',0.15, ...
    'PASS_SIGMA_CAP',true, ...
    'TAIL_ITERS',400, ...
    'TAIL_LR',3e-4, ...
    'TAIL_REPORT_EVERY',100, ...
    'TAIL_ROLLBACK_IF_WORSE',true);

SIGNAL_PERCENTILE = 25;         % E9-B1 signal mask: total intensity > P25
RECON_MODE = 'linear';          % NoASC forward model is M*S only
wl = 410.5 + (0:31)*8.9;        % Provisional wavelength grid; verify metadata
N_CHANNELS = 32;
EXPECTED_H = 2048;
EXPECTED_W = 2560;
EXPECTED_Z = 27;

%% --------------------------- PATHS / CHECKS -----------------------------
script_dir = fileparts(mfilename('fullpath'));
if isempty(script_dir), script_dir = pwd; end
OUT_DIR = fullfile(script_dir, OUT_DIR_NAME);
if exist(OUT_DIR,'dir') ~= 7, mkdir(OUT_DIR); end

if ~ANALYSIS_ONLY
    assert(exist(TRAINER,'file') == 2, 'E13TP:Trainer', ...
        'Cannot find trainer %s. Add it and its dependencies to the MATLAB path.', TRAINER);
    fname = e13tp_find_data_file(DATA_FILE_CANDIDATES, DATA_DIR, script_dir);
    assert(~isempty(fname), 'E13TP:NoLSM', ...
        'Cannot find the two-photon LSM file. Checked both documented filename spellings.');
else
    assert(REUSE_EXISTING_MAT && ~FORCE_RETRAIN,'E13TP:AnalysisOptions', ...
        'ANALYSIS_ONLY requires REUSE_EXISTING_MAT=true and FORCE_RETRAIN=false.');
    fname = '(MAT-only analysis)';
end

assert(any(Z_LIST == ANCHOR_Z), 'E13TP:Anchor', ...
    'ANCHOR_Z must be included in Z_LIST.');
assert(P_FIXED == 8, 'E13TP:P', ...
    'This E13-TP configuration is designed for the published Fig.5 p=8 comparison.');

if QUICK
    fprintf(2,'E13-TP PILOT MODE: center crop %d x %d.\n',CROP_HW(1),CROP_HW(2));
else
    fprintf(2,['E13-TP FULL-FRAME MODE: %d x %d pixels per Z plane.\n' ...
        'WARNING: E9-B1 explicitly notes that the trainer is not a verified ' ...
        'streaming solver and may exceed RAM/GPU memory.\n'],EXPECTED_H,EXPECTED_W);
end

fprintf('\n=== E13 two-photon cross-Z experiment ===\n');
fprintf('Input: %s\n',fname);
fprintf('Z sections: %s | anchor Z=%d | p=%d | seed=%d\n', ...
    mat2str(Z_LIST),ANCHOR_Z,P_FIXED,SEED);
fprintf('Trainer: %s\n',which(TRAINER));
fprintf('Output: %s\n\n',OUT_DIR);

%% --------------------------- OUTPUT INITIALIZATION ----------------------
% Re-create SP-style CSVs AFTER all sections have been trained/loaded and
% cross-Z endmembers have been aligned. No intermediate training CSV is saved.

%% --------------------------- TRAIN / LOAD EACH Z ------------------------
for iz = 1:numel(Z_LIST)
    z = Z_LIST(iz);
    core_file = fullfile(OUT_DIR,sprintf('E13_TP_Z%02d_core.mat',z));
    do_train = FORCE_RETRAIN || ~REUSE_EXISTING_MAT || exist(core_file,'file') ~= 2;
    if ~do_train
        Dcheck = load(core_file,'config','H_saved','W_saved','p','z');
        compatible = isfield(Dcheck,'config') && isfield(Dcheck,'H_saved') && ...
            isfield(Dcheck,'W_saved') && isfield(Dcheck,'p') && isfield(Dcheck,'z') && ...
            Dcheck.z == z && Dcheck.p == P_FIXED && ...
            isfield(Dcheck.config,'quick') && Dcheck.config.quick == QUICK && ...
            isfield(Dcheck.config,'seed') && Dcheck.config.seed == SEED && ...
            isfield(Dcheck.config,'anchor_z') && Dcheck.config.anchor_z == ANCHOR_Z && ...
            isfield(Dcheck.config,'options') && isequaln(Dcheck.config.options,OPT) && ...
            isfield(Dcheck.config,'chunk_pixels') && ...
            isfinite(Dcheck.config.chunk_pixels) && Dcheck.config.chunk_pixels >= 1;
        if QUICK
            compatible = compatible && Dcheck.H_saved == CROP_HW(1) && Dcheck.W_saved == CROP_HW(2);
        else
            compatible = compatible && Dcheck.H_saved == EXPECTED_H && Dcheck.W_saved == EXPECTED_W;
        end
        if ~compatible
            fprintf('Z=%d: existing core MAT is incompatible; retraining this section.\n',z);
            do_train = true;
        else
            oldChunkPixels = double(Dcheck.config.chunk_pixels);
            nOldParts = ceil((Dcheck.H_saved*Dcheck.W_saved)/oldChunkPixels);
            for ip = 1:nOldParts
                part_file = e13tp_part_filename(OUT_DIR,z,ip);
                if exist(part_file,'file') ~= 2
                    error('E13TP:MissingPart', ...
                        'Missing abundance chunk %s. Set FORCE_RETRAIN=true.',part_file);
                end
            end
            % Repack legacy abundance chunks only when needed. This reads
            % only S_est_chunk, discards any legacy S_joint_chunk, and does
            % not rerun the expensive PISCO training.
            nNewParts = ceil((Dcheck.H_saved*Dcheck.W_saved)/ABUNDANCE_CHUNK_PIXELS);
            needRepack = oldChunkPixels ~= ABUNDANCE_CHUNK_PIXELS || ...
                nOldParts ~= nNewParts || numel(dir(fullfile(OUT_DIR, ...
                sprintf('E13_TP_Z%02d_abund_part*.mat',z)))) ~= nNewParts;
            for ip = 1:nOldParts
                part_file = e13tp_part_filename(OUT_DIR,z,ip);
                vinfo = whos('-file',part_file);
                vnames = {vinfo.name};
                needRepack = needRepack || any(strcmp(vnames,'S_joint_chunk'));
            end
            if needRepack
                e13tp_rechunk_abundance(OUT_DIR,z,P_FIXED, ...
                    Dcheck.H_saved*Dcheck.W_saved,oldChunkPixels, ...
                    ABUNDANCE_CHUNK_PIXELS,MAX_ABUNDANCE_MAT_BYTES);
            end

            config = Dcheck.config;
            config_needs_update = config.chunk_pixels ~= ABUNDANCE_CHUNK_PIXELS || ...
                ~isfield(config,'max_abundance_mat_bytes') || ...
                config.max_abundance_mat_bytes ~= MAX_ABUNDANCE_MAT_BYTES;
            if config_needs_update
                config.chunk_pixels = ABUNDANCE_CHUNK_PIXELS;
                config.max_abundance_mat_bytes = MAX_ABUNDANCE_MAT_BYTES;
                save(core_file,'config','-append');
            end
            core_vars = whos('-file',core_file);
            core_names = {core_vars.name};
            legacy_core = any(ismember(core_names, ...
                {'M_preclip','roi_info','wl','tail_info'}));
            if legacy_core
                e13tp_compact_core_file(core_file,MAX_ABUNDANCE_MAT_BYTES);
            end
            if needRepack || legacy_core || config_needs_update
                fprintf('Z=%d: output migrated to %d pixels/chunk; legacy intermediate fields removed.\n', ...
                    z,ABUNDANCE_CHUNK_PIXELS);
            end
        end
        clear Dcheck;
    end

    if do_train
        assert(~ANALYSIS_ONLY,'E13TP:MissingCached', ...
            'ANALYSIS_ONLY requires a compatible MAT result for Z=%d.',z);
        fprintf('\n--- E13-TP Z=%d: read / mask / train ---\n',z);
        [Y,roi_info] = e13tp_read_lsm_roi(fname,z,CROP_HW,MAX_PIXELS, ...
            EXPECTED_H,EXPECTED_W,EXPECTED_Z,N_CHANNELS);
        [L,N] = size(Y);
        H = roi_info.H; W = roi_info.W;
        assert(L == N_CHANNELS && H*W == N, 'E13TP:DataShape', ...
            'Unexpected loaded data dimensions.');

        mask = e13tp_signal_mask(Y,SIGNAL_PERCENTILE);
        fprintf('Signal mask: %d / %d pixels (%.2f%%)\n', ...
            nnz(mask),N,100*nnz(mask)/N);

        rng(SEED,'twister');
        args = e13tp_train_options(H,W,OPT);
        fprintf('PISCO NoASC + BandLoss + Fixed-Q tail: p=%d, seed=%d ...\n',P_FIXED,SEED);
        ticTrain = tic;
        [M_est,S_est,~,~,theta_audit] = feval(TRAINER,Y,P_FIXED,args{:});
        train_time_s = toc(ticTrain);

        % The E9-B1 trainer exposes these audit values through its 5th output.
        assert(isstruct(theta_audit) && ...
            isfield(theta_audit,'M_before_clip_bandloss_audit') && ...
            isfield(theta_audit,'S_before_tail') && ...
            isfield(theta_audit,'tail_info') && ...
            isfield(theta_audit,'endmember_clip_relative'), ...
            'E13TP:TrainerAudit', ...
            'Trainer audit fields do not match the supplied E9-B1 driver.');

        M_preclip = theta_audit.M_before_clip_bandloss_audit;
        S_joint = theta_audit.S_before_tail;
        tail_info = theta_audit.tail_info;
        band_clip_relative = theta_audit.endmember_clip_relative;
        clear theta_audit;

        M_est = e13tp_to_cpu(M_est);
        S_est = e13tp_to_cpu(S_est);
        M_preclip = e13tp_to_cpu(M_preclip);
        S_joint = e13tp_to_cpu(S_joint);
        M_est = double(M_est);
        M_preclip = double(M_preclip);
        S_est = single(S_est);
        S_joint = single(S_joint);

        assert(isequal(size(M_est),[N_CHANNELS P_FIXED]) && ...
            isequal(size(S_est),[P_FIXED N]) && ...
            isequal(size(S_joint),[P_FIXED N]), ...
            'E13TP:ModelShape','Unexpected M/S dimensions from the trainer.');

        % Only linear M*S is the valid NoASC forward reconstruction.
        [stats,residual_map] = e13tp_residual_metrics( ...
            Y,M_est,M_preclip,S_est,S_joint,mask,RECON_BLOCK);
        [intensity_joint_median,intensity_tail_median] = ...
            e13tp_tail_intensity_ratio(Y,M_est,S_joint,S_est,mask);

        fprintf(['[Fixed-Q tail] joint PRECLIP %.6f | joint POSTCLIP %.6f | ' ...
            'tail PRECLIP %.6f | tail POSTCLIP %.6f\n'], ...
            stats.joint_preclip_frob,stats.joint_postclip_frob, ...
            stats.tail_preclip_frob,stats.tail_postclip_frob);
        fprintf('[NoASC] final linear ROI residual = %.6f | train time = %.1f s\n', ...
            stats.linear_frob,train_time_s);

        % Persist only the final Fixed-Q-tail abundance. S_joint is used
        % above for Joint-vs-Tail diagnostics, but is not a final result and
        % is deliberately not written to disk.
        clear S_joint;
        nParts = ceil(N/ABUNDANCE_CHUNK_PIXELS);
        oldParts = dir(fullfile(OUT_DIR,sprintf('E13_TP_Z%02d_abund_part*.mat',z)));
        for q = 1:numel(oldParts)
            delete(fullfile(OUT_DIR,oldParts(q).name));
        end
        for ip = 1:nParts
            i1 = (ip-1)*ABUNDANCE_CHUNK_PIXELS + 1;
            i2 = min(ip*ABUNDANCE_CHUNK_PIXELS,N);
            S_est_chunk = single(S_est(:,i1:i2));
            pixel_start = i1; pixel_end = i2; %#ok<NASGU>
            part_file = e13tp_part_filename(OUT_DIR,z,ip);
            save(part_file,'S_est_chunk','pixel_start','pixel_end','-v7');
            part_info = dir(part_file);
            if isempty(part_info) || part_info.bytes > MAX_ABUNDANCE_MAT_BYTES
                if exist(part_file,'file')==2, delete(part_file); end
                error('E13TP:AbundanceMatTooLarge', ...
                    'Abundance MAT %s exceeded the strict 95 MB limit.',part_file);
            end
            fprintf('Saved final abundance chunk %d/%d: pixels %d-%d | %.2f MB\n', ...
                ip,nParts,i1,i2,part_info.bytes/1e6);
            clear S_est_chunk part_info;
        end

        intensity_map = reshape(single(sum(Y,1)),H,W);
        mask_u8 = reshape(uint8(mask),H,W);
        config = struct();
        config.input_file = fname;
        config.trainer = TRAINER;
        config.trainer_path = which(TRAINER);
        config.z = z;
        config.anchor_z = ANCHOR_Z;
        config.p = P_FIXED;
        config.seed = SEED;
        config.quick = QUICK;
        config.crop_hw = CROP_HW;
        config.signal_percentile = SIGNAL_PERCENTILE;
        config.reconstruction = 'NoASC linear M*S';
        config.abundance = 'S_est after Fixed-Q tail; free nonnegative coefficients; no sum-to-one';
        config.wavelengths_nm_provisional = wl;
        config.input_is_calibrated_photons = false;
        config.chunk_pixels = ABUNDANCE_CHUNK_PIXELS;
        config.max_abundance_mat_bytes = MAX_ABUNDANCE_MAT_BYTES;
        config.reader_method = roi_info.method;
        config.crop_rows = roi_info.rows;
        config.crop_cols = roi_info.cols;
        config.full_image_size = [roi_info.fullH roi_info.fullW];
        config.options = OPT;

        % Keep only the three scalar Tail audit fields actually used later.
        tail_iters = e13tp_getfield(tail_info,'iterations_done',NaN);
        tail_lr = e13tp_getfield(tail_info,'lr',NaN);
        tail_rolled_back = logical(e13tp_getfield(tail_info,'rolled_back',false));

        H_saved = H; W_saved = W; p = P_FIXED; %#ok<NASGU>
        % M_preclip, roi_info, wl (already recorded in config/plotdata), and
        % the full tail_info structure are not needed after diagnostics.
        save(core_file,'M_est','mask_u8','residual_map','intensity_map', ...
            'stats','tail_iters','tail_lr','tail_rolled_back', ...
            'band_clip_relative','train_time_s', ...
            'intensity_joint_median','intensity_tail_median', ...
            'config','H_saved','W_saved','p','z','-v7');
        core_info = dir(core_file);
        if isempty(core_info) || core_info.bytes > MAX_ABUNDANCE_MAT_BYTES
            if exist(core_file,'file')==2, delete(core_file); end
            error('E13TP:CoreMatTooLarge', ...
                'Core MAT %s exceeded the strict 95 MB limit.',core_file);
        end
        clear Y M_est M_preclip S_est S_joint intensity_map mask_u8 ...
            residual_map stats tail_info tail_iters tail_lr tail_rolled_back ...
            roi_info config theta_audit core_info;
    else
        fprintf('\n--- E13-TP Z=%d: reusing saved core MAT and abundance chunks ---\n',z);
    end

    D = load(core_file,'stats','H_saved','W_saved','mask_u8');
    fprintf('Z=%d complete/reused | ROI=%d/%d | residual=%.6f\n', ...
        z,nnz(D.mask_u8),D.H_saved*D.W_saved,D.stats.linear_frob);
    clear D;

end

%% --------------------------- LOAD / ALIGN ALL Z -------------------------
% Keep the original trainer order in each core/chunk MAT. The cross-Z order
% is recorded in plotdata.crossz_ord_by_z and matching CSV, as in E13-SP.
nZ = numel(Z_LIST);
labels = arrayfun(@(k)sprintf('Component_%d',k),1:P_FIXED,'UniformOutput',false);
M_raw = cell(nZ,1);
mask_cell = cell(nZ,1);
H = []; W = []; N = [];
for iz = 1:nZ
    z = Z_LIST(iz);
    D = load(fullfile(OUT_DIR,sprintf('E13_TP_Z%02d_core.mat',z)), ...
        'M_est','mask_u8','H_saved','W_saved','p');
    M_raw{iz} = double(D.M_est);
    mask_cell{iz} = logical(D.mask_u8(:));
    assert(isequal(size(M_raw{iz}),[N_CHANNELS P_FIXED]), ...
        'E13TP:MSize','Unexpected endmember shape at Z=%d.',z);
    if isempty(H)
        H=D.H_saved; W=D.W_saved; N=H*W;
    else
        assert(D.H_saved==H && D.W_saved==W, ...
            'E13TP:DimensionMismatch','All Z sections must have the same dimensions.');
    end
    clear D;
end
anchor_idx = find(Z_LIST==ANCHOR_Z,1);
M_anchor = M_raw{anchor_idx};
ord_by_z = cell(nZ,1);
Mlist = cell(nZ,1);
anchor_sad_by_z = NaN(nZ,P_FIXED);
anchor_sad_matrix_by_z = cell(nZ,1);
for iz = 1:nZ
    cost=e13tp_sad_matrix(M_anchor,M_raw{iz});
    if iz==anchor_idx
        ord=1:P_FIXED;
    else
        ord=e13tp_exact_assignment(cost);
    end
    ord_by_z{iz}=ord;
    Mlist{iz}=M_raw{iz}(:,ord);
    anchor_sad_by_z(iz,:)=diag(cost(:,ord)).';
    if iz==anchor_idx, anchor_sad_by_z(iz,:)=0; end
    anchor_sad_matrix_by_z{iz}=cost;
    fprintf('Z=%d | anchor Z=%d | endmember order=[%s] | total SAD %.3f deg\n', ...
        Z_LIST(iz),ANCHOR_Z,num2str(ord),sum(anchor_sad_by_z(iz,:)));
end

%% --------------------------- SP-STYLE CSV HEADERS ------------------------
resfile = fullfile(OUT_DIR,'pisco_E13_TP_results.csv');
anchorfile = fullfile(OUT_DIR,'pisco_E13_TP_crossZ_matching.csv');
pairfile = fullfile(OUT_DIR,'pisco_E13_TP_pairwise.csv');
consfile = fullfile(OUT_DIR,'pisco_E13_TP_consistency.csv');
fr=fopen(resfile,'w'); fa=fopen(anchorfile,'w');
fp=fopen(pairfile,'w'); fc=fopen(consfile,'w');
assert(fr>0 && fa>0 && fp>0 && fc>0,'E13TP:OpenCSV', ...
    'Cannot create all four SP-style summary CSVs.');
clean_fr=onCleanup(@()fclose(fr));
clean_fa=onCleanup(@()fclose(fa));
clean_fp=onCleanup(@()fclose(fp));
clean_fc=onCleanup(@()fclose(fc));
fprintf(fr,['modality,z,seed,p,H,W,npix,mask_px,mask_frac,time_s,' ...
    'masked_frob_resid,mean_E1_signal,median_E1_signal,mean_leak_pct\n']);
fprintf(fa,['z,anchor_z,component,anchor_component_index,' ...
    'original_estimated_column,SAD_to_anchor_deg,is_anchor\n']);
fprintf(fp,'component,z1,z2,pairwise_SAD_deg,adjacent_Pearson,mask_intersection_px\n');
fprintf(fc,'modality,component,metric,mean,sd,n\n');

%% --------------------------- ALIGNED PER-Z STATS / PREVIEWS ------------
% The SP experiment uses abundance-derived A1/A2 ROIs for its composition
% matrix; this is an INTERNAL, row-normalised mixture statistic, not physical
% cross-talk determined using single-stain measurements.
C_list=cell(nZ,1);
row_leak=NaN(nZ,P_FIXED);
mask_frob=NaN(nZ,1);
mean_leak=NaN(nZ,1);
mask_frac=NaN(nZ,1);
preview_ab=cell(nZ,1);
preview_each=cell(nZ,P_FIXED);
preview_res=cell(nZ,1);

for iz=1:nZ
    z=Z_LIST(iz);
    D=load(fullfile(OUT_DIR,sprintf('E13_TP_Z%02d_core.mat',z)), ...
        'residual_map','stats','mask_u8','train_time_s');
    Sraw=e13tp_load_abundance(OUT_DIR,z,P_FIXED,N, ...
        ABUNDANCE_CHUNK_PIXELS,'S_est_chunk');
    Saligned=Sraw(ord_by_z{iz},:);
    C=e13tp_sp_crosstalk(Saligned,H,W,RECON_BLOCK);
    C_list{iz}=C;
    row_leak(iz,:)=100*(1-diag(C)).';
    offdiag=C(~eye(P_FIXED));
    mean_leak(iz)=100*mean(offdiag,'omitnan');
    mask_frob(iz)=D.stats.linear_frob;
    mask_frac(iz)=nnz(D.mask_u8)/N;

    rr=double(D.residual_map(:));
    valid=logical(D.mask_u8(:)) & isfinite(rr);
    assert(any(valid),'E13TP:MissingROIResidual', ...
        'No residual pixels in the signal mask at Z=%d.',z);
    mean_signal=mean(rr(valid));
    median_signal=median(rr(valid));

    fprintf(fr,'TP,%d,%d,%d,%d,%d,%d,%d,%.8f,%.3f,%.8f,%.8f,%.8f,%.6f\n', ...
        z,SEED,P_FIXED,H,W,N,nnz(D.mask_u8),mask_frac(iz), ...
        D.train_time_s,mask_frob(iz),mean_signal,median_signal,mean_leak(iz));
    for j=1:P_FIXED
        fprintf(fa,'%d,%d,%s,%d,%d,%.8f,%d\n', ...
            z,ANCHOR_Z,labels{j},j,ord_by_z{iz}(j), ...
            anchor_sad_by_z(iz,j),iz==anchor_idx);
    end

    [preview_ab{iz},preview_row] = e13tp_sp_previews( ...
        Saligned,H,W,PREVIEW_SIZE,DISPLAY_LOW_PCT, ...
        DISPLAY_HIGH_PCT,DISPLAY_GAMMA,DISPLAY_FLIP_LR);
    for j=1:P_FIXED
        preview_each{iz,j}=preview_row{j};
    end
    vr=rr(isfinite(rr));
    lim=prctile(vr,99);
    if ~isfinite(lim) || lim<=0, lim=1; end
    rmap=reshape(rr,H,W);
    rmap(~isfinite(rmap))=0;
    rmap=max(0,min(1,rmap/lim));
    rmap=imresize(single(rmap),[PREVIEW_SIZE PREVIEW_SIZE]);
    if DISPLAY_FLIP_LR, rmap=fliplr(rmap); end
    preview_res{iz}=single(rmap);
    fprintf('Z=%d: masked Fro=%.4f | internal mean overlap=%.2f%%\n', ...
        z,mask_frob(iz),mean_leak(iz));
    clear D Sraw Saligned preview_row rr rmap vr C;
end

%% --------------------------- PAIRWISE SAD / ADJACENT PEARSON -----------
pearson_adj=NaN(nZ-1,P_FIXED);
overlap_adj=zeros(nZ-1,1);
for iz=1:nZ-1
    [r,ncommon]=e13tp_abundance_pearson( ...
        OUT_DIR,Z_LIST(iz),Z_LIST(iz+1), ...
        ord_by_z{iz},ord_by_z{iz+1}, ...
        mask_cell{iz},mask_cell{iz+1},P_FIXED,N,ABUNDANCE_CHUNK_PIXELS);
    pearson_adj(iz,:)=r(:).';
    overlap_adj(iz)=ncommon(1);
end
SAD_pairwise=cell(P_FIXED,1);
for j=1:P_FIXED
    sadvals=[];
    for a=1:nZ-1
        for b=a+1:nZ
            va=Mlist{a}(:,j); vb=Mlist{b}(:,j);
            sad=e13tp_sad(va,vb);
            sadvals(end+1)=sad; %#ok<AGROW>
            if b==a+1
                r=pearson_adj(a,j); ov=overlap_adj(a);
            else
                r=NaN; ov=NaN;
            end
            fprintf(fp,'%s,%d,%d,%.8f,%.8f,%.0f\n', ...
                labels{j},Z_LIST(a),Z_LIST(b),sad,r,ov);
        end
    end
    SAD_pairwise{j}=sadvals;
    e13tp_sp_write_metric(fc,'TP',labels{j}, ...
        'crossZ_pairwise_SAD_deg',sadvals);
    e13tp_sp_write_metric(fc,'TP',labels{j}, ...
        'adjacent_abundance_Pearson',pearson_adj(:,j));
    e13tp_sp_write_metric(fc,'TP',labels{j},'row_leak_pct',row_leak(:,j));
    nonanchor=true(nZ,1); nonanchor(anchor_idx)=false;
    e13tp_sp_write_metric(fc,'TP',labels{j}, ...
        sprintf('SAD_to_Z%d_anchor_deg',ANCHOR_Z), ...
        anchor_sad_by_z(nonanchor,j));
end
% The five Z sections are correlated technical sections, not five specimens.
e13tp_sp_write_metric(fc,'TP','ALL','masked_frob_resid',mask_frob);
e13tp_sp_write_metric(fc,'TP','ALL','mean_leak_pct',mean_leak);
e13tp_sp_write_metric(fc,'TP','ALL','mask_fraction',mask_frac);
clear clean_fr clean_fa clean_fp clean_fc;

%% --------------------------- LIGHTWEIGHT PLOT MAT -----------------------
% SP-like plotdata. Full-resolution S is stored only in the two abundance
% chunk MAT files per Z, in original trainer order; ord_by_z restores the
% cross-Z aligned order. No intermediate S_joint is persisted.
plotdata=struct();
plotdata.modality='TP';
plotdata.zlist=Z_LIST;
plotdata.anchor_z=ANCHOR_Z;
plotdata.matching_mode=sprintf( ...
    'global_one_to_one_minimum_total_SAD_to_Z%d_anchor',ANCHOR_Z);
plotdata.M_aligned=Mlist;
plotdata.C=C_list;
plotdata.labels=labels;
plotdata.crossz_ord_by_z=ord_by_z;
plotdata.SAD_to_anchor_deg=anchor_sad_by_z;
plotdata.SAD_to_anchor_matrices=anchor_sad_matrix_by_z;
plotdata.wl=wl;
plotdata.wavelength_axis_is_provisional=true;
plotdata.pairwise_SAD_deg=SAD_pairwise;
plotdata.adjacent_Pearson=pearson_adj;
plotdata.adjacent_mask_overlap_px=overlap_adj;
plotdata.row_leak_pct=row_leak;
plotdata.mean_leak_pct=mean_leak;
plotdata.masked_frob_resid=mask_frob;
plotdata.mask_fraction=mask_frac;
plotdata.preview_abundance_rgb=preview_ab;
plotdata.preview_individual_rgb=preview_each;
plotdata.preview_residual_scaled=preview_res;
plotdata.preview_residual_is_display_only=true;
plotdata.display_flip_lr=DISPLAY_FLIP_LR;
plotdata.display_low_pct=DISPLAY_LOW_PCT;
plotdata.display_high_pct=DISPLAY_HIGH_PCT;
plotdata.display_gamma=DISPLAY_GAMMA;
plotdata.abundance_source='raw-order S_est_chunk in abundance part files';
plotdata.max_mat_bytes=MAX_ABUNDANCE_MAT_BYTES;
Dconfig=load(fullfile(OUT_DIR,sprintf('E13_TP_Z%02d_core.mat',ANCHOR_Z)), ...
    'config');
plotdata.config=Dconfig.config;
clear Dconfig;
plotdata.note=['No reference spectra used; component labels mean only ' ...
    'cross-Z correspondence. Signal ROI is TP original-intensity > P25, ' ...
    'not SP log-Otsu. ROI mixture statistics are not verified physical ' ...
    'cross-talk. One fish / five correlated Z sections.'];
plotmat=fullfile(OUT_DIR,'E13_TP_plotdata.mat');
tmpplot=[plotmat '.saving_tmp.mat'];
if exist(tmpplot,'file')==2, delete(tmpplot); end
save(tmpplot,'plotdata','-v7');
e13tp_check_mat_limit(tmpplot,MAX_ABUNDANCE_MAT_BYTES);
[ok,msg]=movefile(tmpplot,plotmat,'f');
assert(ok,'E13TP:PlotDataMove','Cannot save E13_TP_plotdata.mat: %s',msg);

%% --------------------------- FOUR SP-STYLE FIGURES ----------------------
% As in E13-SP, figures are SHOWN and optionally saved as FOUR SVG files.
% No PNG exports. Embedded microscope RGB previews are necessarily raster
% portions inside SVG; axes, labels and chart lines remain vector graphics.
if SHOW_FIGURES
    f1=figure('Name','E13-TP | Z-section abundances and residuals', ...
        'Color','w','Position',[40 40 1200 1350]);
    t1=tiledlayout(f1,nZ,2,'TileSpacing','compact','Padding','compact');
    for iz=1:nZ
        ax=nexttile(t1,2*iz-1);
        image(ax,preview_ab{iz}); axis(ax,'image'); axis(ax,'off');
        title(ax,sprintf('Z=%d | %d-endmember NoASC overlay', ...
            Z_LIST(iz),P_FIXED));
        ax=nexttile(t1,2*iz);
        imagesc(ax,preview_res{iz},[0 1]); axis(ax,'image'); axis(ax,'off');
        colormap(ax,'turbo');
        title(ax,sprintf('Z=%d | relative-L2 residual (P99 display scale)',Z_LIST(iz)));
    end
    title(t1,sprintf('E13-TP: independent Z fits, Z=%d anchor-aligned components', ...
        ANCHOR_Z));

    f2=figure('Name','E13-TP | Spectral consistency', ...
        'Color','w','Position',[80 50 1400 1050]);
    spec_rows=ceil((P_FIXED+1)/3);
    t2=tiledlayout(f2,spec_rows,3,'TileSpacing','compact','Padding','compact');
    cmap=lines(nZ);
    for j=1:P_FIXED
        ax=nexttile(t2,j); hold(ax,'on');
        for iz=1:nZ
            v=Mlist{iz}(:,j);
            plot(ax,wl,v/max(max(v),eps),'Color',cmap(iz,:), ...
                'LineWidth',1.4,'DisplayName',sprintf('Z=%d',Z_LIST(iz)));
        end
        title(ax,labels{j},'Interpreter','none');
        xlabel(ax,'Provisional wavelength (nm)');
        ylabel(ax,'Peak-normalised value');
        xlim(ax,[wl(1) wl(end)]); grid(ax,'on'); hold(ax,'off');
        if j==1, legend(ax,'Location','best','FontSize',8); end
    end
    ax=nexttile(t2,P_FIXED+1);
    sad_mean=cellfun(@(v)mean(v,'omitnan'),SAD_pairwise);
    bar(ax,1:P_FIXED,sad_mean);
    xticks(ax,1:P_FIXED); xticklabels(ax,labels); xtickangle(ax,35);
    ylabel(ax,'Cross-Z mean SAD (deg)');
    title(ax,sprintf('Mean pairwise SAD after Z=%d alignment',ANCHOR_Z));
    grid(ax,'on');
    title(t2,'E13-TP: full-spectrum cross-Z alignment (no reference spectra)');

    f3=figure('Name','E13-TP | Numerical stability', ...
        'Color','w','Position',[110 80 1100 600]);
    t3=tiledlayout(f3,1,2,'TileSpacing','compact','Padding','compact');
    ax=nexttile(t3,1);
    plot(ax,Z_LIST,mask_frob,'-o','LineWidth',1.6);
    xlabel(ax,'Z section');
    ylabel(ax,'Masked relative Frobenius residual'); grid(ax,'on');
    ax=nexttile(t3,2);
    imagesc(ax,pearson_adj,[-1 1]); colormap(ax,'parula'); colorbar(ax);
    xticks(ax,1:P_FIXED); xticklabels(ax,labels); xtickangle(ax,35);
    yticks(ax,1:nZ-1);
    pair_labels=arrayfun(@(a,b)sprintf('%d-%d',a,b), ...
        Z_LIST(1:end-1),Z_LIST(2:end),'UniformOutput',false);
    yticklabels(ax,pair_labels);
    title(ax,'Adjacent-Z abundance Pearson');
    title(t3,'E13-TP numerical summaries (one fish, five sections)');

    f4=figure('Name','E13-TP | Each endmember across five Z sections', ...
        'Color','k','Position',[140 50 2000 1350]);
    t4=tiledlayout(f4,nZ,P_FIXED,'TileSpacing','compact','Padding','compact');
    for iz=1:nZ
        for j=1:P_FIXED
            ax=nexttile(t4,(iz-1)*P_FIXED+j);
            image(ax,preview_each{iz,j}); axis(ax,'image'); axis(ax,'off');
            set(ax,'Color','k');
            if iz==1
                title(ax,labels{j},'Interpreter','none','Color','w', ...
                    'FontSize',10);
            end
            if j==1
                text(ax,0.02,0.95,sprintf('Z=%d',Z_LIST(iz)), ...
                    'Units','normalized','Color','w','FontSize',12, ...
                    'FontWeight','bold','VerticalAlignment','top');
            end
        end
    end
    title(t4,sprintf('E13-TP | %d endmembers x %d Z sections (display only)', ...
        P_FIXED,nZ),'Color','w','FontSize',15);
    if SAVE_SVG
        print(f1,fullfile(OUT_DIR,'E13_TP_overview.svg'),'-dsvg');
        print(f2,fullfile(OUT_DIR,'E13_TP_spectral_consistency.svg'),'-dsvg');
        print(f3,fullfile(OUT_DIR,'E13_TP_numerical_summary.svg'),'-dsvg');
        print(f4,fullfile(OUT_DIR,'E13_TP_all_endmembers.svg'),'-dsvg');
    end
end

fprintf('\n=========== E13-TP FINISHED (SP-style output) ===========\n');
fprintf('Output directory: %s\n',OUT_DIR);
fprintf('Z sections: [%s] | n=%d | p=%d | anchor=%d\n', ...
    num2str(Z_LIST),nZ,P_FIXED,ANCHOR_Z);
fprintf('Masked Frobenius mean +/- SD: %.4f +/- %.4f\n', ...
    mean(mask_frob),std(mask_frob));
fprintf('Internal ROI mixture overlap mean +/- SD: %.3f +/- %.3f %%\n', ...
    mean(mean_leak,'omitnan'),std(mean_leak,'omitnan'));
for j=1:P_FIXED
    vals=SAD_pairwise{j};
    rr=pearson_adj(:,j); rr=rr(isfinite(rr));
    if isempty(rr), rr_mean=NaN; else, rr_mean=mean(rr); end
    fprintf('  %-15s | cross-Z SAD mean %.2f max %.2f deg | adj Pearson %.4f\n', ...
        labels{j},mean(vals),max(vals),rr_mean);
end
fprintf('MAT strict size cap: %.1f MB (decimal), checked on disk.\n', ...
    MAX_ABUNDANCE_MAT_BYTES/1e6);
fprintf('Caution: correlated Z sections are not independent biological replicates.\n');
fprintf('Caution: labels are cross-Z correspondences, not protein identities.\n');

%% =========================== LOCAL FUNCTIONS ============================

function fname = e13tp_find_data_file(names,data_dir,script_dir)
    roots = {pwd,fullfile(pwd,data_dir),script_dir,fullfile(script_dir,data_dir)};
    fname = '';
    for i = 1:numel(names)
        for j = 1:numel(roots)
            candidate = fullfile(roots{j},names{i});
            if exist(candidate,'file') == 2
                fname = candidate;
                return;
            end
        end
    end
end

function part_file = e13tp_part_filename(outdir,z,ip)
    part_file = fullfile(outdir,sprintf('E13_TP_Z%02d_abund_part%03d.mat',z,ip));
end

function e13tp_rechunk_abundance(outdir,z,p,N,old_chunk,new_chunk,max_bytes)
% Repack legacy S_est chunks into the new minimum-count layout. Only the
% final abundance is copied; any S_joint_chunk in old files is discarded.
    assert(old_chunk>=1 && new_chunk>=1 && old_chunk==round(old_chunk) && ...
        new_chunk==round(new_chunk) && p==8, ...
        'E13TP:RechunkConfig','Invalid abundance rechunk configuration.');
    old_n = ceil(N/old_chunk);
    new_n = ceil(N/new_chunk);
    old_files = cell(old_n,1);
    tmp_files = cell(new_n,1);
    final_files = cell(new_n,1);
    old_listing = dir(fullfile(outdir,sprintf('E13_TP_Z%02d_abund_part*.mat',z)));
    assert(numel(old_listing)>=old_n,'E13TP:MissingOldChunk', ...
        'Found %d old abundance chunks, but %d are required for Z=%d.', ...
        numel(old_listing),old_n,z);

    for ip = 1:old_n
        old_files{ip} = e13tp_part_filename(outdir,z,ip);
        assert(exist(old_files{ip},'file')==2,'E13TP:MissingOldChunk', ...
            'Missing legacy abundance chunk: %s',old_files{ip});
    end

    % Remove abandoned temporary files from an interrupted earlier repack.
    stale = dir(fullfile(outdir,sprintf('E13_TP_Z%02d_abund_repack_tmp_part*.mat',z)));
    for k = 1:numel(stale), delete(fullfile(outdir,stale(k).name)); end

    for ip = 1:new_n
        i1 = (ip-1)*new_chunk+1;
        i2 = min(ip*new_chunk,N);
        S_est_chunk = zeros(p,i2-i1+1,'single');
        covered = false(1,i2-i1+1);
        old_first = floor((i1-1)/old_chunk)+1;
        old_last = floor((i2-1)/old_chunk)+1;

        for old_ip = old_first:old_last
            A = load(old_files{old_ip},'S_est_chunk','pixel_start','pixel_end');
            assert(isfield(A,'S_est_chunk') && isfield(A,'pixel_start') && ...
                isfield(A,'pixel_end') && size(A.S_est_chunk,1)==p, ...
                'E13TP:BadOldChunk','Invalid legacy abundance chunk: %s',old_files{old_ip});
            a1 = max(i1,double(A.pixel_start));
            a2 = min(i2,double(A.pixel_end));
            if a2>=a1
                dst = (a1:a2)-i1+1;
                src = (a1:a2)-double(A.pixel_start)+1;
                S_est_chunk(:,dst) = single(A.S_est_chunk(:,src));
                covered(dst) = true;
            end
            clear A;
        end
        assert(all(covered),'E13TP:RechunkGap', ...
            'Legacy chunks do not fully cover pixels %d-%d for Z=%d.',i1,i2,z);

        pixel_start = i1; pixel_end = i2; %#ok<NASGU>
        tmp_files{ip} = fullfile(outdir,sprintf( ...
            'E13_TP_Z%02d_abund_repack_tmp_part%03d.mat',z,ip));
        final_files{ip} = e13tp_part_filename(outdir,z,ip);
        save(tmp_files{ip},'S_est_chunk','pixel_start','pixel_end','-v7');
        info = dir(tmp_files{ip});
        if isempty(info) || info.bytes>max_bytes
            if exist(tmp_files{ip},'file')==2, delete(tmp_files{ip}); end
            error('E13TP:RepackedMatTooLarge', ...
                'Repacked abundance MAT exceeded %.3f MB.',max_bytes/1e6);
        end
        fprintf('Repacked Z=%d chunk %d/%d | pixels %d-%d | %.2f MB\n', ...
            z,ip,new_n,i1,i2,info.bytes/1e6);
        clear S_est_chunk covered pixel_start pixel_end info;
    end

    % Move old files to temporary backups so the original data can be
    % restored if any final rename fails.
    backup_files = cell(numel(old_listing),1);
    original_files = cell(numel(old_listing),1);
    staged = 0;
    installed = 0;
    try
        for ip = 1:numel(old_listing)
            src = fullfile(outdir,old_listing(ip).name);
            original_files{ip} = src;
            backup_files{ip} = [src '.repack_backup'];
            if exist(backup_files{ip},'file')==2, delete(backup_files{ip}); end
            [ok,msg] = movefile(src,backup_files{ip},'f');
            assert(ok,'E13TP:BackupMove','Cannot stage old chunk: %s',msg);
            staged = ip;
        end
        for ip = 1:new_n
            [ok,msg] = movefile(tmp_files{ip},final_files{ip},'f');
            assert(ok,'E13TP:FinalMove','Cannot install repacked chunk: %s',msg);
            installed = ip;
        end
    catch ME
        for ip = 1:installed
            if exist(final_files{ip},'file')==2, delete(final_files{ip}); end
        end
        for ip = 1:new_n
            if exist(tmp_files{ip},'file')==2, delete(tmp_files{ip}); end
        end
        for ip = 1:staged
            if exist(backup_files{ip},'file')==2
                movefile(backup_files{ip},original_files{ip},'f');
            end
        end
        rethrow(ME);
    end
    for ip = 1:numel(backup_files)
        if exist(backup_files{ip},'file')==2, delete(backup_files{ip}); end
    end
end

function e13tp_compact_core_file(core_file,max_bytes)
% Rewrite an older core MAT with only fields needed by downstream analysis,
% plotting, and the results CSV. This also migrates legacy tail_info to the
% three scalar audit fields actually used by the driver.
    D = load(core_file);
    M_est = D.M_est;
    mask_u8 = D.mask_u8;
    residual_map = D.residual_map;
    intensity_map = D.intensity_map;
    stats = D.stats;
    if isfield(D,'tail_iters')
        tail_iters = D.tail_iters;
        tail_lr = D.tail_lr;
        tail_rolled_back = D.tail_rolled_back;
    elseif isfield(D,'tail_info')
        tail_iters = e13tp_getfield(D.tail_info,'iterations_done',NaN);
        tail_lr = e13tp_getfield(D.tail_info,'lr',NaN);
        tail_rolled_back = logical(e13tp_getfield(D.tail_info,'rolled_back',false));
    else
        tail_iters = NaN; tail_lr = NaN; tail_rolled_back = false;
    end
    band_clip_relative = e13tp_getfield(D,'band_clip_relative',NaN);
    train_time_s = e13tp_getfield(D,'train_time_s',NaN);
    intensity_joint_median = e13tp_getfield(D,'intensity_joint_median',NaN);
    intensity_tail_median = e13tp_getfield(D,'intensity_tail_median',NaN);
    config = D.config;
    H_saved = D.H_saved; W_saved = D.W_saved;
    p = D.p; z = D.z;

    tmp_core = [core_file '.compact_tmp.mat'];
    if exist(tmp_core,'file')==2, delete(tmp_core); end
    save(tmp_core,'M_est','mask_u8','residual_map','intensity_map','stats', ...
        'tail_iters','tail_lr','tail_rolled_back','band_clip_relative', ...
        'train_time_s','intensity_joint_median','intensity_tail_median', ...
        'config','H_saved','W_saved','p','z','-v7');
    info = dir(tmp_core);
    if isempty(info) || info.bytes>max_bytes
        if exist(tmp_core,'file')==2, delete(tmp_core); end
        error('E13TP:CompactCoreTooLarge', ...
            'Compacted core MAT exceeded the strict 95 MB limit.');
    end
    [ok,msg] = movefile(tmp_core,core_file,'f');
    assert(ok,'E13TP:CompactCoreMove','Cannot replace compacted core MAT: %s',msg);
    clear D M_est mask_u8 residual_map intensity_map stats tail_iters tail_lr ...
        tail_rolled_back band_clip_relative train_time_s intensity_joint_median ...
        intensity_tail_median config H_saved W_saved p z info;
end

function x = e13tp_to_cpu(x)
    if isa(x,'gpuArray')
        x = gather(x);
    end
end

function v = e13tp_getfield(s,name,default_value)
    if isstruct(s) && isfield(s,name) && ~isempty(s.(name))
        v = s.(name);
    else
        v = default_value;
    end
end

function [Y,roi_info] = e13tp_read_lsm_roi(fname,z,cropHW,max_pixels, ...
    originalH,originalW,expectedZ,C)
% E9-B1 reader: native TIFF full-resolution directories first, Bio-Formats fallback.
    assert(isscalar(z) && z == round(z) && z >= 1 && z <= expectedZ, ...
        'E13TP:Z','Z must be an integer from 1 to %d.',expectedZ);
    assert(numel(cropHW)==2 && all(cropHW>=0),'E13TP:Crop','Invalid crop size.');

    if all(cropHW == 0)
        rr = 1:originalH;
        cc = 1:originalW;
    else
        h = cropHW(1); w = cropHW(2);
        assert(h<=originalH && w<=originalW && h>=1 && w>=1 && ...
            h==round(h) && w==round(w),'E13TP:Crop','Invalid crop dimensions.');
        r1 = floor((originalH-h)/2)+1;
        c1 = floor((originalW-w)/2)+1;
        rr = r1:(r1+h-1);
        cc = c1:(c1+w-1);
    end

    H = numel(rr); W = numel(cc);
    assert(H*W <= max_pixels,'E13TP:MemoryGuard', ...
        ['Requested %d pixels exceeds MAX_PIXELS=%d. The trainer is not ' ...
         'a verified streaming full-frame solver.'],H*W,max_pixels);

    roi_info = struct('z',z,'H',H,'W',W,'rows',[rr(1),rr(end)], ...
        'cols',[cc(1),cc(end)],'fullH',originalH,'fullW',originalW, ...
        'channels',C,'pixel_count',H*W,'method','');
    Y = [];
    native_error = '';

    try
        tif = Tiff(fname,'r');
        tif_close = onCleanup(@()tif.close()); %#ok<NASGU>
        dirs = e13tp_fullres_dirs(tif,originalW,originalH);
        assert(numel(dirs)>=expectedZ,'E13TP:Directories', ...
            'Found only %d full-resolution TIFF pages; expected at least %d.', ...
            numel(dirs),expectedZ);
        tif.setDirectory(dirs(z));
        A = tif.read();
        assert(size(A,1)==originalH && size(A,2)==originalW && size(A,3)>=C, ...
            'E13TP:TiffShape','Tiff.read returned %s; expected H x W x >=%d.', ...
            mat2str(size(A)),C);
        Y = zeros(C,H*W,'double');
        for c = 1:C
            tmp = A(rr,cc,c);
            Y(c,:) = reshape(double(tmp),1,[]);
        end
        clear A;
        roi_info.method = 'MATLAB Tiff';
    catch ME
        native_error = ME.message;
        Y = [];
        clear tif_close;
    end

    if isempty(Y)
        if exist('bfGetReader','file') ~= 2 || exist('bfGetPlane','file') ~= 2
            error('E13TP:Reader', ...
                ['Native TIFF reader failed: %s\nInstall MATLAB Bio-Formats ' ...
                 '(bfGetReader/bfGetPlane) or inspect the LSM encoding.'],native_error);
        end
        fprintf(2,'Native TIFF reader failed: %s\nTrying Bio-Formats...\n',native_error);
        br = bfGetReader(fname);
        br_close = onCleanup(@()br.close()); %#ok<NASGU>
        br.setSeries(0);
        assert(double(br.getSizeX())==originalW && ...
            double(br.getSizeY())==originalH && ...
            double(br.getSizeZ())>=expectedZ && double(br.getSizeC())>=C, ...
            'E13TP:BFShape','Bio-Formats dimensions do not match expected LSM metadata.');
        Y = zeros(C,H*W,'double');
        for c = 1:C
            plane_id = double(br.getIndex(z-1,c-1,0))+1;
            A = bfGetPlane(br,plane_id);
            tmp = A(rr,cc);
            Y(c,:) = reshape(double(tmp),1,[]);
        end
        roi_info.method = 'Bio-Formats';
    end

    assert(isequal(size(Y),[C H*W]) && all(isfinite(Y(:))) && all(Y(:)>=0), ...
        'E13TP:BadY','Invalid imported spectral data.');
    fprintf('Read Z=%d by %s | %d x %d | %d bands | range %.5g..%.5g\n', ...
        z,roi_info.method,H,W,C,min(Y(:)),max(Y(:)));
end

function dirs = e13tp_fullres_dirs(tif,X,Y)
    dirs = [];
    tif.setDirectory(1);
    idx = 1;
    while true
        x = double(tif.getTag(Tiff.TagID.ImageWidth));
        y = double(tif.getTag(Tiff.TagID.ImageLength));
        if x==X && y==Y
            dirs(end+1) = idx; %#ok<AGROW>
        end
        if tif.lastDirectory(), break; end
        tif.nextDirectory();
        idx = idx+1;
        assert(idx<10000,'E13TP:IFD','Unexpected number of TIFF directories.');
    end
end

function mask = e13tp_signal_mask(Y,percentile)
% Same original-data signal mask as E9-B1: total intensity > P25.
    brightness = sum(Y,1);
    v = sort(brightness(isfinite(brightness)));
    assert(~isempty(v),'E13TP:EmptyData','No finite intensity values.');
    rank = max(1,min(numel(v),round(1+(numel(v)-1)*percentile/100)));
    threshold = v(rank);
    mask = brightness > max(0,threshold);
    if nnz(mask) < max(100,ceil(0.03*numel(mask)))
        mask = brightness > 0;
    end
    assert(nnz(mask)>0,'E13TP:EmptyMask','No illuminated pixels in signal mask.');
end

function args = e13tp_train_options(H,W,opt)
% Exact option list used by the uploaded E9-B1 NoASC BandLoss Fixed-Q driver.
    args = {'spherize','yes','verbose',0, ...
        'MM_ITERS',opt.MM_ITERS,'WARM_UP',opt.WARM_UP,'LR',3e-4, ...
        'LAMBDA_VOL',0.008,'LAMBDA_NONNEG',3,'LAMBDA_EQ',100, ...
        'LAMBDA_SUMONE',0,'LAMBDA_ENCLOSE',opt.LAMBDA_ENCLOSE, ...
        'IMG_H',H,'IMG_W',W, ...
        'LAMBDA_SPATIAL',opt.LAMBDA_SPATIAL, ...
        'LAMBDA_SMOOTH',opt.LAMBDA_SMOOTH, ...
        'LAMBDA_MNONNEG',opt.LAMBDA_MNONNEG, ...
        'NOISE_MODEL',opt.NOISE_MODEL,'NOISE_WEIGHT',opt.NOISE_WEIGHT, ...
        'PHOTON_GAIN',opt.PHOTON_GAIN,'PHOTON_FLOOR',opt.PHOTON_FLOOR, ...
        'READ_SIGMA',opt.READ_SIGMA, ...
        'ETA',opt.ETA,'ETA_END',opt.ETA_END, ...
        'LAMBDA_BAND',opt.LAMBDA_BAND, ...
        'TAIL_ITERS',opt.TAIL_ITERS,'TAIL_LR',opt.TAIL_LR, ...
        'TAIL_REPORT_EVERY',opt.TAIL_REPORT_EVERY, ...
        'TAIL_ROLLBACK_IF_WORSE',opt.TAIL_ROLLBACK_IF_WORSE};
    if opt.PASS_SIGMA_CAP
        args = [args,{'SIGMA_CAP',opt.SIGMA_CAP}];
    end
end

function [stats,residual_map] = e13tp_residual_metrics(Y,M,Mpre,S,Sjoint,mask,block)
% Blockwise metrics. For NoASC, only M*S is the forward reconstruction.
    N = size(Y,2);
    normY = 0;
    sse_tail = 0;
    sse_tail_pre = 0;
    sse_joint_post = 0;
    sse_joint_pre = 0;
    pear = 0;
    dev = 0;
    nvals = 0;
    residual_map = NaN(1,N,'single');

    for i1 = 1:block:N
        ix = i1:min(i1+block-1,N);
        m = logical(mask(ix));
        if ~any(m), continue; end
        obs = double(Y(:,ix));
        St = double(S(:,ix));
        Sj = double(Sjoint(:,ix));

        pred_tail = double(M)*St;
        pred_tail_pre = double(Mpre)*St;
        pred_joint_post = double(M)*Sj;
        pred_joint_pre = double(Mpre)*Sj;

        e_tail = obs-pred_tail;
        e_tail_pre = obs-pred_tail_pre;
        e_joint_post = obs-pred_joint_post;
        e_joint_pre = obs-pred_joint_pre;

        normY = normY + sum(sum(obs(:,m).^2));
        sse_tail = sse_tail + sum(sum(e_tail(:,m).^2));
        sse_tail_pre = sse_tail_pre + sum(sum(e_tail_pre(:,m).^2));
        sse_joint_post = sse_joint_post + sum(sum(e_joint_post(:,m).^2));
        sse_joint_pre = sse_joint_pre + sum(sum(e_joint_pre(:,m).^2));

        den = max(sqrt(sum(obs.^2,1)),1);
        rr = sqrt(sum(e_tail.^2,1))./den;
        rr(~m) = NaN;
        residual_map(ix) = single(rr);

        mu = max(pred_tail(:,m),1e-8);
        yy = obs(:,m);
        pear = pear + sum(sum((yy-mu).^2./mu));
        term = mu-yy;
        pos = yy>0;
        term(pos) = term(pos)+yy(pos).*log(yy(pos)./mu(pos));
        dev = dev + 2*sum(term(:));
        nvals = nvals + numel(yy);
    end

    stats = struct();
    stats.linear_frob = sqrt(sse_tail/max(normY,eps));
    stats.tail_preclip_frob = sqrt(sse_tail_pre/max(normY,eps));
    stats.joint_postclip_frob = sqrt(sse_joint_post/max(normY,eps));
    stats.joint_preclip_frob = sqrt(sse_joint_pre/max(normY,eps));
    stats.tail_postclip_frob = stats.linear_frob;
    stats.pearson_per_count = pear/max(nvals,1);
    stats.poisson_deviance_per_count = dev/max(nvals,1);
    stats.tail_sse_change_pct = 100*(stats.linear_frob^2/ ...
        max(stats.joint_postclip_frob^2,eps)-1);
    stats.n_signal_pixels = nnz(mask);
    stats.n_signal_values = nvals;
end

function [r_joint,r_tail] = e13tp_tail_intensity_ratio(Y,M,S0,S1,mask)
% Same deterministic ROI subsampling concept as E9-B1.
    idx = find(mask);
    stride = max(1,ceil(numel(idx)/150000));
    idx = idx(1:stride:end);
    obs = sum(double(Y(:,idx)),1);
    valid = obs>0;
    idx = idx(valid);
    obs = obs(valid);
    if isempty(idx)
        r_joint = NaN; r_tail = NaN; return;
    end
    pred0 = sum(double(M)*double(S0(:,idx)),1);
    pred1 = sum(double(M)*double(S1(:,idx)),1);
    r_joint = median(pred0./obs);
    r_tail = median(pred1./obs);
end

function D = e13tp_sad_matrix(M1,M2)
    A = e13tp_unit_columns(M1);
    B = e13tp_unit_columns(M2);
    C = max(-1,min(1,A'*B));
    D = acos(C)*180/pi;
end

function U = e13tp_unit_columns(M)
    n = sqrt(sum(double(M).^2,1));
    n(n<eps) = 1;
    U = double(M)./n;
end

function ord = e13tp_exact_assignment(cost)
% Exact global one-to-one assignment by exhaustive permutation.
% For p=8 this evaluates only 8! = 40,320 assignments.
    [p1,p2] = size(cost);
    assert(p1==p2 && p1<=9,'E13TP:AssignmentSize', ...
        'Exact permutation matching supports square matrices up to 9x9.');
    allp = perms(1:p1);
    rows = 1:p1;
    best = Inf;
    ord = 1:p1;
    for q = 1:size(allp,1)
        perm = allp(q,:);
        v = sum(cost(sub2ind([p1 p1],rows,perm)));
        if v < best
            best = v;
            ord = perm;
        end
    end
end

function v = e13tp_sad(a,b)
    a = double(a(:)); b = double(b(:));
    den = norm(a)*norm(b);
    if den <= eps
        v = NaN;
    else
        c = max(-1,min(1,(a'*b)/den));
        v = acos(c)*180/pi;
    end
end

function [r,ncommon] = e13tp_abundance_pearson(outdir,z1,z2,ord1,ord2, ...
    mask1,mask2,p,N,chunk_pixels)
% Exact Pearson correlation accumulated chunkwise over the mask intersection.
    nParts = ceil(N/chunk_pixels);
    acc = zeros(p,6); % n, sum(x), sum(y), sum(x^2), sum(y^2), sum(x*y)
    for ip = 1:nParts
        f1 = e13tp_part_filename(outdir,z1,ip);
        f2 = e13tp_part_filename(outdir,z2,ip);
        A = load(f1,'S_est_chunk','pixel_start','pixel_end');
        B = load(f2,'S_est_chunk','pixel_start','pixel_end');
        assert(A.pixel_start==B.pixel_start && A.pixel_end==B.pixel_end, ...
            'E13TP:ChunkAlignment','Abundance chunk boundaries differ.');
        ix1 = A.pixel_start; ix2 = A.pixel_end;
        common = (mask1(ix1:ix2) & mask2(ix1:ix2)).';
        if any(common)
            for k = 1:p
                x = double(A.S_est_chunk(ord1(k),common));
                y = double(B.S_est_chunk(ord2(k),common));
                acc(k,1) = acc(k,1)+numel(x);
                acc(k,2) = acc(k,2)+sum(x);
                acc(k,3) = acc(k,3)+sum(y);
                acc(k,4) = acc(k,4)+sum(x.^2);
                acc(k,5) = acc(k,5)+sum(y.^2);
                acc(k,6) = acc(k,6)+sum(x.*y);
            end
        end
        clear A B;
    end
    r = NaN(p,1);
    ncommon = acc(:,1);
    for k = 1:p
        n = acc(k,1);
        if n < 3, continue; end
        vx = acc(k,4)-acc(k,2)^2/n;
        vy = acc(k,5)-acc(k,3)^2/n;
        cv = acc(k,6)-acc(k,2)*acc(k,3)/n;
        den = sqrt(max(vx,0)*max(vy,0));
        if den > eps
            r(k) = max(-1,min(1,cv/den));
        end
    end
end

function S = e13tp_load_abundance(outdir,z,p,N,chunk_pixels,fieldname)
    S = zeros(p,N,'single');
    nParts = ceil(N/chunk_pixels);
    for ip = 1:nParts
        D = load(e13tp_part_filename(outdir,z,ip),fieldname,'pixel_start','pixel_end');
        S(:,D.pixel_start:D.pixel_end) = D.(fieldname);
    end
end

function e13tp_check_mat_limit(fname,maxbytes)
    info=dir(fname);
    if isempty(info) || info.bytes>maxbytes
        if exist(fname,'file')==2, delete(fname); end
        error('E13TP:MatTooLarge', ...
            'Saved MAT exceeded %.0f bytes: %s',maxbytes,fname);
    end
end

function e13tp_sp_write_metric(fid,modality,component,metric,values)
    x=double(values(:)); x=x(isfinite(x));
    if isempty(x), mu=NaN; sd=NaN;
    else, mu=mean(x); sd=std(x); end
    fprintf(fid,'%s,%s,%s,%.10g,%.10g,%d\n', ...
        modality,component,metric,mu,sd,numel(x));
end

function m=e13tp_sp_segment(img,variant)
% Identical A1/A2 ROI rules to the supplied E13-SP script.
    g=mat2gray(img);
    switch upper(variant)
        case 'A1'
            m=g>graythresh(g);
            m=bwareaopen(m,50);
            m=imclose(m,strel('disk',3));
        case 'A2'
            T=adaptthresh(g,0.5,'ForegroundPolarity','bright');
            m=imbinarize(g,T);
            m=bwareaopen(m,200);
            m=imclose(m,strel('disk',5));
        otherwise
            error('E13TP:ROIType','Invalid A1/A2 segmentation variant.');
    end
    m=logical(m);
end

function C=e13tp_sp_crosstalk(S,H,W,block)
% Row-normalised abundance composition inside SP-defined A1-or-A2 ROIs.
% This is NOT a measured physical fluorescence bleed-through rate.
    p=size(S,1);
    assert(size(S,2)==H*W,'E13TP:ROISize','Unexpected abundance shape.');
    C=NaN(p,p);
    for i=1:p
        I=reshape(double(S(i,:)),H,W);
        roi=e13tp_sp_segment(I,'A1') | e13tp_sp_segment(I,'A2');
        idx=find(roi(:)).';
        if isempty(idx), continue; end
        masses=zeros(p,1);
        for i1=1:block:numel(idx)
            pix=idx(i1:min(numel(idx),i1+block-1));
            masses=masses+sum(max(double(S(:,pix)),0),2);
        end
        if sum(masses)>0, C(i,:)=masses.'/sum(masses); end
    end
end

function palette=e13tp_sp_palette(p)
% Exact SP colors for components 1..5, extended consistently to 8 TP EMs.
    palette=[0.00 1.00 0.05; ...  % C1 green
             1.00 0.87 0.00; ...  % C2 yellow
             1.00 0.00 0.90; ...  % C3 magenta
             0.00 0.90 1.00; ...  % C4 cyan
             0.15 0.35 1.00; ...  % C5 blue
             1.00 0.48 0.00; ...  % C6 orange
             1.00 0.15 0.17; ...  % C7 red
             0.55 0.25 0.95];    % C8 violet
    assert(p>=1 && p<=size(palette,1),'E13TP:Palette','Need 1..8 components.');
    palette=palette(1:p,:);
end

function [overlay,individual]=e13tp_sp_previews(S,H,W,previewsz,lo,hi,gamma,flipLR)
% Mirrors E13-SP percentile-stretched, gamma-corrected black-background RGB.
% Uses resized per-component intensities to bound peak RAM on 5.24M-pixel TP.
    p=size(S,1);
    palette=e13tp_sp_palette(p);
    acc=zeros(previewsz,previewsz,3,'single');
    individual=cell(1,p);
    for k=1:p
        x=reshape(double(S(k,:)),H,W);
        x(~isfinite(x))=0; x=max(0,x);
        low=prctile(x(:),lo); high=prctile(x(:),hi);
        if high<=low
            y=zeros(previewsz,previewsz,'single');
        else
            y=max(0,min(1,(x-low)/(high-low))).^gamma;
            y=imresize(single(y),[previewsz previewsz]);
        end
        rgb=zeros(previewsz,previewsz,3,'single');
        for c=1:3
            rgb(:,:,c)=y*single(palette(k,c));
            acc(:,:,c)=acc(:,:,c)+rgb(:,:,c);
        end
        if flipLR, rgb=fliplr(rgb); end
        individual{k}=im2uint8(max(0,min(1,rgb)));
        clear x y rgb;
    end
    acc=max(0,min(1,acc));
    if flipLR, acc=fliplr(acc); end
    overlay=im2uint8(acc);
end
