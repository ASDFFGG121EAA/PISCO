%% demo_pisco_E3_MultiView_L488_L561_L639_Base1001_JitterRest_GYL.m
% E-3 MultiView combined-view reference-guided stability experiment.
% seed=1001: ORIGINAL, UNPERTURBED single-stain reference M0=M_ref exactly.
% seeds=1002..1010: smooth, seed-dependent multiplicative spectral jitter
%                   on the same independently measured reference M_ref.
% This is ONE original baseline + NINE perturbed-initialization runs, NOT
% ten independent draws from the same initialisation distribution.
% The unperturbed M_ref always serves as the evaluation SAD reference.
% PISCO NoASC trainer, its loss and training parameters are UNCHANGED.
% Only one CSV is saved; results are stored in a NEW dedicated folder to
% prevent mixing with earlier runs which jittered seed=1001 as well.
% No MAT, figure or supplementary CSV files are created.
%
% The NoASC S_est stores non-normalized coefficients, not fractions.
% Cross-seed abundance r indicates consistency, NOT ground-truth accuracy.
% MATLAB + GPU/Parallel Computing Toolbox required when USE_GPU=true.
% Static check only: training has not been run in MATLAB here.

clear; close all; clc;

%% 0. User settings -------------------------------------------------------
RESUME = true;                         % skip completed seeds from one CSV
INIT_JITTER_LOG_STD = 0.05;            % only seeds 1002..1010 get perturbations
INIT_MAX_TRIES = 15;                   % reject near-singular projected initializers
SEEDS = 1001:1010;                     % 1001 unperturbed, 1002..1010 jittered
VIEW = 'L488_L561_L639';             % ONLY this combination view
DYES = {'AF488','AF514','AF532','AF555','AF594','AF610', ...
        'AF633','AF647','AF660','ATTO542','ATTO620','ATTO655','RRX'};
P = 13;
MM_ITERS = 7500;                     % EXACT original supplied MultiView demo
WARM_UP = 6800;                      % 6800 warm-up + 700 joint updates
ETA = 0.3;
SIGMA_CAP = 0.03;                   % explicitly overrides trainer default
PHOTON_GAIN = 1; READ_SIGMA = 0;
LAMBDA_VOL = 0.008;
LAMBDA_NONNEG = 3;
LAMBDA_EQ = 100;
LAMBDA_ENCLOSE = 0.3;
LAMBDA_SPATIAL = 0.2;
LAMBDA_MNONNEG = 10;
LAMBDA_SMOOTH = 0.1;
NOISE_WEIGHT = 'uniform';
USE_GPU = true;
GPU_PRECISION = 'single';
GPU_DEVICE = 1;
MAX_REFERENCE_PIXELS = 30000;
HYSIME_MAX_PIXELS = 30000;
RESIDUAL_CHUNK = 60000;
REFINIT_RCOND_FAIL = 1e-10;

script_dir=fileparts(mfilename('fullpath'));
if isempty(script_dir), script_dir=pwd; end
addpath(script_dir);
DATA_ROOT=script_dir;                % set here if the MultiView folder is elsewhere
DATA_DIR=fullfile(DATA_ROOT,VIEW,'data');
MIX_PATH=fullfile(DATA_DIR,['mix_' VIEW '.tif']);
OUT_DIR=fullfile(script_dir, ...
    'E3_MultiView_L488_L561_L639_Base1001_JitterRest_CSV_only_results');
OUT_CSV=fullfile(OUT_DIR, ...
    'pisco_E3_MultiView_L488_L561_L639_Base1001_JitterRest_results.csv');

assert(exist('deep_mvsa_invflow_poisson_explicit_Warmup2_NoASC','file')==2, ...
    ['Missing deep_mvsa_invflow_poisson_explicit_Warmup2_NoASC.m. ' ...
     'Rename the dated upload to this exact function filename.']);
assert(isfile(MIX_PATH),'Missing combined-view mixture TIFF: %s',MIX_PATH);
assert(WARM_UP>=0 && WARM_UP<MM_ITERS,'Invalid iteration settings.');
assert(INIT_JITTER_LOG_STD>0 && INIT_JITTER_LOG_STD<=0.15, ...
    'Set INIT_JITTER_LOG_STD in (0,0.15] for a controlled experiment.');
assert(numel(DYES)==P && numel(SEEDS)==10,'Expected 13 dyes and 10 seeds.');

%% 1. Read only combined view and its 13 independently measured references
fprintf('E-3 MultiView: reading %s ...\n',VIEW);
[Y,H,W]=mv_read_tiff(MIX_PATH,[]);
[L,N]=size(Y);
assert(N==H*W && L>P && all(isfinite(Y(:))),'Invalid combined-view cube.');
if any(Y(:)<0)
    warning('Input has negative TIFF values; clipping to zero as original script.');
    Y=max(Y,0);
end
M_ref=zeros(L,P);
for j=1:P
    file=fullfile(DATA_DIR,[DYES{j} '_' VIEW '.tif']);
    assert(isfile(file),'Missing single-stain TIFF: %s',file);
    [Yr,~,~]=mv_read_tiff(file,L);
    [M_ref(:,j),nPix,~]=mv_extract_ref(Yr,MAX_REFERENCE_PIXELS);
    assert(nPix>=2 && norm(M_ref(:,j))>1e-12, ...
        'Empty/invalid %s reference spectrum.',DYES{j});
    clear Yr
end
M_ref=max(M_ref,0);
assert(all(isfinite(M_ref(:))) && all(vecnorm(M_ref,2,1)>0), ...
    'Invalid single-stain reference spectra.');

% Otsu mask used for metrics only; COMPLETE image used in all training runs.
mask=mv_signal_mask(Y);
if nnz(mask)<max(64,round(0.001*N)),mask=sum(Y,1)>0;end
mask=logical(mask(:).');
idx_mask=find(mask);
assert(~isempty(idx_mask),'Empty metric ROI mask.');
hyP=mv_hysime(Y,HYSIME_MAX_PIXELS);  % diagnostic only; P remains 13

% Reproduce supplied preflight once; no reference-dependent TRAINING LOSS.
initStat=mv_refinit_preflight(Y,M_ref,P,mask,RESIDUAL_CHUNK);
fprintf('L=%d, H=%d, W=%d, mask=%d, HySime=%d, p=%d\n', ...
    L,H,W,numel(idx_mask),hyP,P);
fprintf('Projected reference init SAD=%.4f deg, M0 rcond=%.3e\n', ...
    initStat.proj_mean_sad,initStat.work_rcond);
assert(isfinite(initStat.work_rcond) && ...
    initStat.work_rcond>REFINIT_RCOND_FAIL, ...
    'Projected M0 near-singular (rcond=%g).',initStat.work_rcond);
% Cache exactly the NoASC trainer's shape-subspace projection so each
% randomly perturbed M0 can be checked for Q0 invertibility BEFORE training.
shapeCtx = e3_m0_shape_context(Y,P);

%% 2. Exactly one numeric CSV; one row per seed --------------------------
% run_status: 0=pending, 1=successful, -1=failed (will retry on rerun).
% Column names SAD_*, abundance_r_seed1001_* are the 13 SAME-VIEW dye labels.
% The first seed is a RAM-only anchor; its own correlations remain NaN.
sadCols=cell(1,P);corrCols=cell(1,P);
for j=1:P
    sadCols{j}=['SAD_' DYES{j} '_deg'];
    corrCols{j}=['abundance_r_seed1001_' DYES{j}];
end
COLS=[{'seed','run','image_h','image_w','n_channels','p_used', ...
    'hysime_p','mask_pixels','total_iters','warmup_iters','sigma_cap', ...
    'init_jitter_log_std','init_input_sad_mean_deg','init_input_sad_max_deg', ...
    'init_projected_sad_mean_deg','init_m0_rcond'}, ...
    sadCols,{'SAD_mean_deg','SAD_max_deg','n_matched', ...
    'masked_relresid_mean','pearson_rms','final_roi_fro', ...
    'negative_S_fraction'},corrCols, ...
    {'abundance_r_seed1001_mean','M_relFrob_seed1001','time_s','run_status'}];
nRuns=numel(SEEDS);
T=array2table(nan(nRuns,numel(COLS)),'VariableNames',COLS);
T.seed=SEEDS(:);T.run=(1:nRuns)';
T.image_h(:)=H;T.image_w(:)=W;
T.n_channels(:)=L;T.p_used(:)=P;T.hysime_p(:)=hyP;
T.mask_pixels(:)=numel(idx_mask);
T.total_iters(:)=MM_ITERS;T.warmup_iters(:)=WARM_UP;
T.sigma_cap(:)=SIGMA_CAP;
T.init_jitter_log_std(:)=INIT_JITTER_LOG_STD;
T.init_jitter_log_std(1)=0;          % ORIGINAL seed1001 M0=M_ref, no perturbation
% The following initialization diagnostics are generated for EACH seed;
% they are not identical baseline preflight values.
T.run_status(:)=0;

if ~isfolder(OUT_DIR)
    [made,msg]=mkdir(OUT_DIR);
    assert(made,'Cannot create results directory: %s',msg);
end
if RESUME && isfile(OUT_CSV)
    opts=detectImportOptions(OUT_CSV);
    opts=setvartype(opts,COLS,'double');
    old=readtable(OUT_CSV,opts);
    assert(isequal(old.Properties.VariableNames,COLS), ...
        'CSV header differs from this script; move old CSV before running.');
    assert(height(old)==nRuns && isequal(old.seed(:),SEEDS(:)) && ...
        isequal(old.run(:),(1:nRuns)') && all(old.image_h==H) && ...
        all(old.image_w==W) && all(old.n_channels==L) && ...
        all(old.p_used==P) && all(old.hysime_p==hyP) && ...
        all(old.mask_pixels==numel(idx_mask)) && ...
        all(old.total_iters==MM_ITERS) && ...
        all(old.warmup_iters==WARM_UP) && ...
        all(old.sigma_cap==SIGMA_CAP) && ...
        isequal(old.init_jitter_log_std(:),T.init_jitter_log_std(:)), ...
        'Existing CSV is from a different view, seed list or protocol.');
    T=old;
else
    e3_write_one_csv(T,OUT_CSV);
end
fprintf('Only output: %s\n',OUT_CSV);
if all(T.run_status==1)
    fprintf('All ten seeds already successful: no retraining.\n');
    e3_print_summary(T);
    return;
end

%% 3. EXACT baseline at 1001; perturbed-reference starts at 1002 ----
need_anchor=any(T.run_status(2:end)~=1);
anchor_coeff=[];                   % 13 x N_ROI, stored ONLY IN RAM
anchor_M=[];                       % L x 13, stored ONLY IN RAM

for k=1:nRuns
    if T.run_status(k)==1 && ~(k==1 && need_anchor)
        fprintf('Seed %d already completed; skipped.\n',SEEDS(k));
        continue;
    end
    anchor_rebuild = (k==1 && T.run_status(1)==1 && need_anchor);
    if anchor_rebuild
        fprintf('Rebuilding RAM-only seed=%d anchor for resume ...\n',SEEDS(1));
    else
        fprintf('Training %s seed=%d (%d/%d) ...\n',VIEW,SEEDS(k),k,nRuns);
    end
    timer=tic;
    try
        rng(SEEDS(k),'twister');
        % Exact ORIGINAL initialization at seed=1001. In particular, do
        % not call randn or use any jitter generator before the trainer.
        % The training call below is identical to the original reference-M0
        % driver when k==1 (same M_ref, rng(1001), losses and schedule).
        if SEEDS(k)==1001
            M0_used=M_ref;
            m0rcond=initStat.work_rcond;
            m0projected=initStat.projected_band_M0;
            init_d=zeros(P,1);              % exactly M0 = M_ref
            projected_d=diag(mv_sad_matrix(m0projected,M_ref));
            fprintf('  M0 ORIGINAL: seed=1001, jitter=0, projected SAD %.4f deg | rcond %.3e\n', ...
                mean(projected_d),m0rcond);
        else
            % Seeds 1002..1010 only. Jitter changes the reference-guided
            % START, never the unperturbed post-training SAD references.
            % Reject starts with a singular projected Q0 (NoASC geometry).
            m0ok=false;
            for attempt=1:INIT_MAX_TRIES
                M0_used=e3_jitter_reference(M_ref,INIT_JITTER_LOG_STD);
                [m0rcond,m0projected]=e3_check_projected_m0(M0_used,shapeCtx,P);
                if isfinite(m0rcond) && m0rcond>REFINIT_RCOND_FAIL
                    m0ok=true;
                    break;
                end
            end
            assert(m0ok,'Unable to make a nonsingular perturbed reference M0.');
            init_d=diag(mv_sad_matrix(M0_used,M_ref));
            projected_d=diag(mv_sad_matrix(m0projected,M_ref));
            fprintf('  M0 JITTERED: seed=%d, jitter=%.3g, input SAD %.4f deg, projected SAD %.4f deg | rcond %.3e\n', ...
                SEEDS(k),INIT_JITTER_LOG_STD,mean(init_d),mean(projected_d),m0rcond);
        end
        assert(all(isfinite(init_d)) && all(isfinite(projected_d)), ...
            'Invalid reference initialization SAD.');
        % Objective, PCA computation inside trainer and optimization unchanged.
        % Baseline passes exactly M_ref; other seeds pass only jittered M0.
        [M_est,S_est] = deep_mvsa_invflow_poisson_explicit_Warmup2_NoASC( ...
            Y,P,'M0',M0_used, ...
            'MM_ITERS',MM_ITERS,'WARM_UP',WARM_UP, ...
            'LR',3e-4,'LAMBDA_VOL',LAMBDA_VOL, ...
            'LAMBDA_NONNEG',LAMBDA_NONNEG,'LAMBDA_EQ',LAMBDA_EQ, ...
            'LAMBDA_SUMONE',0,'LAMBDA_ENCLOSE',LAMBDA_ENCLOSE, ...
            'LAMBDA_SPATIAL',LAMBDA_SPATIAL, ...
            'LAMBDA_MNONNEG',LAMBDA_MNONNEG, ...
            'LAMBDA_SMOOTH',LAMBDA_SMOOTH,'IMG_H',H,'IMG_W',W, ...
            'NOISE_MODEL','poisson','NOISE_WEIGHT',NOISE_WEIGHT, ...
            'ETA',ETA,'ETA_END',ETA,'SIGMA_CAP',SIGMA_CAP, ...
            'PHOTON_GAIN',PHOTON_GAIN,'PHOTON_FLOOR',1, ...
            'READ_SIGMA',READ_SIGMA,'USE_GPU',USE_GPU, ...
            'GPU_PRECISION',GPU_PRECISION,'GPU_DEVICE',GPU_DEVICE, ...
            'verbose',0);
        elapsed=toc(timer);
        assert(isequal(size(M_est),[L,P]) && ...
               isequal(size(S_est),[P,N]),'Unexpected M_est/S_est dimensions.');
        assert(all(isfinite(M_est(:))) && all(isfinite(S_est(:))), ...
               'Non-finite PISCO outputs.');

        % GLOBAL 13-to-13 Hungarian matching, original paper's metric.
        cost=mv_sad_matrix(M_est,M_ref);
        [estIdx,refIdx,matchedDeg]=mv_assignment(cost);
        assert(numel(estIdx)==P && all(isfinite(matchedDeg)), ...
            'Incomplete/invalid 13-dye matching.');
        idx_by_dye=zeros(1,P);
        sad_by_dye=nan(1,P);
        idx_by_dye(refIdx)=estIdx;
        sad_by_dye(refIdx)=matchedDeg;
        assert(all(idx_by_dye>=1) && all(isfinite(sad_by_dye)), ...
               'SAD labels are incomplete.');

        % Only ROI abundance coefficients for cross-seed comparison in RAM.
        coeff=single(S_est(idx_by_dye,idx_mask));
        M_aligned=M_est(:,idx_by_dye);
        if k==1
            anchor_coeff=coeff;
            anchor_M=M_aligned;
        end
        if anchor_rebuild
            fprintf('Seed=%d anchor restored in RAM (%.1f s).\n',SEEDS(1),elapsed);
            clear M_est S_est M0_used coeff M_aligned cost;
            continue;             % keep original seed1001 metrics unchanged
        end

        [roiMean,pearsonRMS,roiFro]=e3_roi_metrics( ...
            Y,M_est,S_est,mask,RESIDUAL_CHUNK);
        negFrac=nnz(S_est<0)/numel(S_est);
        assert(all(isfinite([roiMean,pearsonRMS,roiFro,negFrac])), ...
            'Invalid residual or non-negativity metric.');

        T.init_input_sad_mean_deg(k)=mean(init_d);
        T.init_input_sad_max_deg(k)=max(init_d);
        T.init_projected_sad_mean_deg(k)=mean(projected_d);
        T.init_m0_rcond(k)=m0rcond;
        for j=1:P, T.(sadCols{j})(k)=sad_by_dye(j); end
        T.SAD_mean_deg(k)=mean(sad_by_dye);
        T.SAD_max_deg(k)=max(sad_by_dye);
        T.n_matched(k)=P;
        T.masked_relresid_mean(k)=roiMean;
        T.pearson_rms(k)=pearsonRMS;
        T.final_roi_fro(k)=roiFro;
        T.negative_S_fraction(k)=negFrac;
        if k>1
            assert(~isempty(anchor_coeff),'Anchor missing in resume path.');
            corrs=nan(1,P);
            for j=1:P
                corrs(j)=e3_pearson(double(anchor_coeff(j,:)), ...
                                   double(coeff(j,:)));
                T.(corrCols{j})(k)=corrs(j);
            end
            T.abundance_r_seed1001_mean(k)=mean(corrs(isfinite(corrs)));
            T.M_relFrob_seed1001(k)=norm(M_aligned-anchor_M,'fro') / ...
                                  max(norm(anchor_M,'fro'),eps);
        end
        T.time_s(k)=elapsed;
        T.run_status(k)=1;
        e3_write_one_csv(T,OUT_CSV); % checkpoints in SAME CSV; no other output
        fprintf('Seed %d OK | SAD %.4f deg | ROI Fro %.5f | %.1fs | %d/%d\n', ...
            SEEDS(k),T.SAD_mean_deg(k),roiFro,elapsed, ...
            nnz(T.run_status==1),nRuns);
        clear M_est S_est coeff M_aligned cost;
    catch ME
        if k==1
            rethrow(ME);          % without seed1001 anchor, other r is undefined
        end
        T.run_status(k)=-1;
        T.time_s(k)=toc(timer);
        e3_write_one_csv(T,OUT_CSV);
        warning('Seed %d failed; can retry on rerun: %s',SEEDS(k),ME.message);
    end
end

%% 4. Print summary only; no summary file --------------------------------
e3_print_summary(T);
fprintf('Only result file: %s\n',OUT_CSV);

%% Local helper functions ------------------------------------------------
function e3_write_one_csv(T,path)
% Fixed CSV path, overwrite same checkpoint after each completed run.
writetable(T,path);
end

function e3_print_summary(T)
ok=(T.run_status==1);
fprintf('\n=== E-3 MultiView 13-dye combined view: %d/%d successful ===\n', ...
    nnz(ok),height(T));
fields={'SAD_mean_deg','SAD_max_deg','masked_relresid_mean', ...
    'pearson_rms','final_roi_fro','abundance_r_seed1001_mean', ...
    'M_relFrob_seed1001','init_input_sad_mean_deg', ...
    'init_projected_sad_mean_deg','time_s'};
for j=1:numel(fields)
    x=T.(fields{j})(ok);
    x=x(isfinite(x));
    if isempty(x)
        fprintf('%-25s: unavailable\n',fields{j});
    else
        fprintf('%-25s: %.7g +/- %.7g, range %.7g .. %.7g, n=%d\n', ...
            fields{j},mean(x),std(x,0),min(x),max(x),numel(x));
    end
end
if any(~ok)
    fprintf('Incomplete seeds: %s\n',num2str(T.seed(~ok).'));
end
if nnz(ok)==height(T)
    a=T.SAD_mean_deg(ok);
    b=T.final_roi_fro(ok);
    if max(a)-min(a)<1e-8 && max(b)-min(b)<1e-10
        warning(['The baseline and nine perturbed initializers produced ' ...
                 'effectively identical final SAD and residuals. ' ...
                 'This indicates low sensitivity to this tested perturbation.']);
    end
end
fprintf(['Note: seed1001 uses EXACT reference M0, seeds1002..1010 use ' ...
         'independently jittered reference M0. This is one baseline + nine ' ...
         'perturbation tests, not 10 identically distributed starts. ' ...
         'Abundance r (n<=9) is consistency, not accuracy.\n']);
end

function M0=e3_jitter_reference(Mref,jitter)
% Smooth, zero-mean-ish, unit-SD random log perturbations per endmember.
% No noisy data augmentation, random training pixels or reference changes.
% Preserve each original single-stain spectrum's integrated intensity.
[L,p]=size(Mref);
Z=conv2(randn(L,p),[1;2;3;2;1]/9,'same');
Z=bsxfun(@minus,Z,mean(Z,1));
Z=bsxfun(@rdivide,Z,max(std(Z,0,1),1e-12));
M0=Mref.*exp(jitter*Z);
M0=bsxfun(@times,M0,sum(Mref,1)./max(sum(M0,1),eps));
assert(all(isfinite(M0(:))) && all(M0(:)>=0) && ...
    all(sum(M0,1)>0),'Invalid perturbed reference M0.');
end

function ctx=e3_m0_shape_context(Y,p)
% Small matrices only: equivalent to NoASC trainer shape geometry.
[L,N]=size(Y);
mu=mean(Y,2);
intensity_ref=sum(mu);
R=eye(L)-mu*(ones(1,L)/intensity_ref);
G=Y*Y'/N;
Gc=R*G*R';
Gc=(Gc+Gc')/2;
[U,D]=svds(Gc,p-1);
ctx.mu=mu;
ctx.intensity_ref=intensity_ref;
ctx.U=U;
ctx.sd=sqrt(diag(D+1e-10*eye(p-1)));
assert(all(ctx.sd>0) && all(isfinite(ctx.sd)), ...
    'PCA whitening scales invalid.');
end

function [rc,M0proj]=e3_check_projected_m0(M0,ctx,p)
% Same band->working M0 construction and projected spectral initializer
% used by provided PISCO NoASC trainer (no random training data).
mu=ctx.mu; U=ctx.U; sd=ctx.sd;
M0band=bsxfun(@times,M0,ctx.intensity_ref./max(sum(M0,1),eps));
centered=bsxfun(@minus,M0band,mu);
M0work=[bsxfun(@rdivide,U'*centered,sd);ones(1,p)]/sqrt(p);
rc=rcond(M0work);
M0proj=mu*ones(1,p)+U*(U'*centered);
end

function r=e3_pearson(a,b)
a=double(a(:));b=double(b(:));
valid=isfinite(a)&isfinite(b);
a=a(valid);b=b(valid);
r=NaN;
if numel(a)<3,return;end
a=a-mean(a);b=b-mean(b);
na=norm(a);nb=norm(b);
if na<=eps || nb<=eps,return;end
r=max(-1,min(1,(a'*b)/(na*nb)));
end

function [rrMean,prRMS,roiFro]=e3_roi_metrics(Y,M,S,mask,chunk)
% EXACT three source MultiView metrics, evaluated without full residual map.
% Relative denominator max(||y_j||_2,1); Pearson RMS weight max(Yhat,1).
N=size(Y,2);L=size(Y,1);
relSum=0;count=0;pearsonSq=0;pearsonN=0;res2=0;data2=0;
for st=1:chunk:N
    ids=st:min(N,st+chunk-1);
    local=mask(ids);
    if ~any(local),continue;end
    jj=ids(local);
    yy=Y(:,jj);
    yh=M*S(:,jj);
    d=yy-yh;
    relSum=relSum+sum(sqrt(sum(d.^2,1))./max(sqrt(sum(yy.^2,1)),1));
    count=count+numel(jj);
    pearsonSq=pearsonSq+sum(d.^2./max(yh,1),'all');
    pearsonN=pearsonN+L*numel(jj);
    res2=res2+sum(d(:).^2);
    data2=data2+sum(yy(:).^2);
end
rrMean=relSum/max(count,1);
prRMS=sqrt(pearsonSq/max(pearsonN,1));
roiFro=sqrt(res2/max(data2,eps));
end

function [Y,H,W] = mv_read_tiff(path,expectedL)
% Returns L x (H*W). Single IFD with SamplesPerPixel>1 or one monochrome
% IFD per channel. Multiscale pyramids / extra Z cannot be guessed safely.
info=imfinfo(path);
assert(~isempty(info),'Empty TIFF: %s',path);
H=double(info(1).Height);W=double(info(1).Width);
nPages=numel(info);
if nPages>1
    assert(all([info.Height]==H) && all([info.Width]==W), ...
        'Mixed resolutions/pages in TIFF %s; identify the spectral series first.',path);
    spp=double(info(1).SamplesPerPixel);
    if spp~=1
        error('Multi-page TIFF with SamplesPerPixel=%d is ambiguous: %s',spp,path);
    end
    L=nPages;
    if ~isempty(expectedL) && L~=expectedL
        error('Channel count mismatch: %s has %d pages; mix has %d.',path,L,expectedL);
    end
    Y=zeros(L,H*W);
    for k=1:L
        a=imread(path,k,'Info',info);
        assert(ismatrix(a) && all(size(a)==[H W]),'Unexpected TIFF page dimension');
        Y(k,:)=reshape(double(a),1,[]);
    end
else
    t=Tiff(path,'r'); cleaner=onCleanup(@()close(t)); %#ok<NASGU>
    a=t.read();
    if ndims(a)==2
        L=1; a=reshape(a,H,W,1);
    elseif ndims(a)==3
        L=size(a,3);
    else
        error('Unsupported TIFF array size %s: %s',mat2str(size(a)),path);
    end
    if ~isempty(expectedL) && L~=expectedL
        error('Channel count mismatch: %s has %d channels; mix has %d',path,L,expectedL);
    end
    Y=reshape(permute(double(a),[3 1 2]),L,[]);
end
assert(size(Y,1)>=2, ['TIFF appears single-band, not a spectral stack: %s. ' ...
    'Check TIFF axes/metadata and adapt mv_read_tiff before running.'],path);
end


function [spec,npx,thr] = mv_extract_ref(Y,maxPix)
% Foreground-mean reference from a pure single-stain sample; avoids bias
% from the dark background. Underlying TIFF retains real dye identity.
Y=max(Y,0);
intensity=sum(Y,1);
thr=mv_otsu(intensity);
idx=find(intensity>thr);
if numel(idx)<32
    idx=find(intensity>0);
end
if numel(idx)<2
    npx=0;spec=zeros(size(Y,1),1);return; % dye not excited/detected
end
if numel(idx)>maxPix
    idx=idx(unique(round(linspace(1,numel(idx),maxPix))));
end
npx=numel(idx);
spec=mean(Y(:,idx),2);
if norm(spec)<=1e-12
    npx=0;spec=zeros(size(Y,1),1);
end
end


function mask=mv_signal_mask(Y)
intensity=sum(Y,1);
mask=intensity>mv_otsu(intensity);
end


function threshold=mv_otsu(x)
x=double(x(:));x=x(isfinite(x));
assert(~isempty(x),'No finite pixels in threshold input');
lo=min(x);hi=max(x);
if hi<=lo,threshold=lo;return;end
edges=linspace(lo,hi,257);
counts=histcounts(x,edges);
w=double(counts(:));w=w/max(sum(w),1);
c=(edges(1:end-1)+edges(2:end))/2;c=c(:);
omega=cumsum(w);mu=cumsum(w.*c);mt=mu(end);
between=(mt*omega-mu).^2 ./ max(omega.*(1-omega),1e-12);
[~,k]=max(between);
threshold=c(k);
end


function p=mv_hysime(Y,maxPixels)
% Covariance-based HySime port following pisco_py/pisco_core.py;
% bounded subsample for noise-covariance estimation (NOT training).
[L,N]=size(Y);
if N>maxPixels
    Y=Y(:,unique(round(linspace(1,N,maxPixels))));
end
N=size(Y,2);
G=(Y*Y')/N; G=(G+G')/2;
E=zeros(L,N);
for i=1:L
    ix=[1:i-1,i+1:L];
    Gi=G(ix,ix); ridge=1e-10*max(trace(Gi)/max(L-1,1),1);
    beta=(Gi+ridge*eye(L-1))\G(ix,i);
    E(i,:)=Y(i,:)-beta'*Y(ix,:);
end
Rw=(E*E')/N;
Rx=G-Rw;Rx=(Rx+Rx')/2;
[V,D]=eig(Rx);
[~,order]=sort(diag(D),'descend');V=V(:,order);
delta=diag(V'*Rx*V)-diag(V'*Rw*V);
[~,imax]=max([0;cumsum(delta)]);
p=max(2,imax-1);
end


function C=mv_sad_matrix(A,B)
assert(size(A,1)==size(B,1),'SAD channel mismatch');
A=max(double(A),0);B=max(double(B),0);
A=A./max(vecnorm(A,2,1),eps);B=B./max(vecnorm(B,2,1),eps);
cosines=min(max(A'*B,-1),1);
C=acosd(cosines);
end


function [rowIdx,colIdx,vals]=mv_assignment(C)
% Hungarian minimum-cost ONE-TO-ONE assignment for rectangular matrices;
% unlike the Turn51 greedy matching, optimizes the full matched SAD sum.
[n0,m0]=size(C);
transposed=false;
if n0>m0,C=C.';transposed=true;end
[n,m]=size(C);assert(n>=1 && m>=n && all(isfinite(C(:))));
u=zeros(n+1,1);v=zeros(m+1,1);p=zeros(m+1,1);way=zeros(m+1,1);
for i=1:n
    p(1)=i;j0=1;
    minv=inf(m+1,1);used=false(m+1,1);
    while true
        used(j0)=true;i0=p(j0);delta=Inf;j1=0;
        for j=2:(m+1)
            if ~used(j)
                cur=C(i0,j-1)-u(i0+1)-v(j);
                if cur<minv(j),minv(j)=cur;way(j)=j0;end
                if minv(j)<delta,delta=minv(j);j1=j;end
            end
        end
        assert(isfinite(delta)&&j1>0,'Assignment solver failed');
        for j=1:(m+1)
            if used(j)
                u(p(j)+1)=u(p(j)+1)+delta;
                v(j)=v(j)-delta;
            else
                minv(j)=minv(j)-delta;
            end
        end
        j0=j1;
        if p(j0)==0,break;end
    end
    while true
        j1=way(j0);p(j0)=p(j1);j0=j1;
        if j0==1,break;end
    end
end
r=zeros(n,1);c=zeros(n,1);
for j=2:(m+1)
    if p(j)>0,r(p(j))=p(j);c(p(j))=j-1;end
end
if transposed,rowIdx=c;colIdx=r;else,rowIdx=r;colIdx=c;end
vals=C(sub2ind(size(C),r,c));
end


function out = mv_refinit_preflight(Y,M_ref,p,mask,chunk)
% Reproduces the provided NoASC trainer's M0 normalization, p-1 principal
% spectral coordinates, last intensity coordinate, and square M0_work.
% Uses a small-matrix identity for covariance to avoid materializing a
% second full 23 x 4.2 million Yc array merely for this preflight.
% Floating-point differences in PCA may cause tiny differences vs trainer.
[L,N]=size(Y);
assert(size(M_ref,1)==L && size(M_ref,2)==p);
my = mean(Y,2);
intensity_ref=sum(my);
assert(intensity_ref>0 && isfinite(intensity_ref));
r = ones(1,L)/intensity_ref;
P = eye(L)-my*r;
G = (Y*Y')/N;
G_c=P*G*P';
G_c=(G_c+G_c')/2;
[U,D]=svds(G_c,p-1);
whiten_scale=sqrt(diag(D+1e-10*eye(p-1)));
assert(all(isfinite(whiten_scale)) && all(whiten_scale>0));

M0_band=bsxfun(@times,M_ref, ...
    intensity_ref./max(sum(M_ref,1),eps));
M0_work=[bsxfun(@rdivide,U'*(M0_band-my*ones(1,p)),whiten_scale); ...
         ones(1,p)]/sqrt(p);
svals=svd(M0_work);
work_rcond=rcond(M0_work);
work_cond=svals(1)/max(svals(end),realmin);

% Lift PCA-projected initial endmembers into the original channel space.
M0_projected=U*(U'*(M0_band-my*ones(1,p)))+my*ones(1,p);
cosine=sum(M0_projected.*M_ref,1)./ ...
    max(vecnorm(M0_projected,2,1).*vecnorm(M_ref,2,1),eps);
cosine=max(min(cosine,1),-1);
sad_by_dye=acosd(cosine);

% Evaluate the PRE-TRAINING coefficients exactly as initialized by PISCO:
% A0=max(Q0*Y_work,0), then rescale each pixel to its observed intensity.
% This is NOT fixed-reference NNLS and should not be confused with the
% previously completed fixed-reference + NNLS comparison.
% If practically singular, stop before constructing Q0. The caller will
% report failure; still allow a preflight CSV to be written above.
if ~isfinite(work_rcond) || work_rcond<1e-12
    init_roi_mean=NaN;
    init_roi_fro=NaN;
else
    Q0=M0_work\eye(p); % algebraically equivalent to inv(M0_work)
    totalRel=0; countRel=0; totalSq=0; totalY2=0;
for st=1:chunk:N
    id=st:min(N,st+chunk-1);
    YY=Y(:,id);
    pixscale=sum(YY,1)/intensity_ref;
    YC=bsxfun(@minus,YY,my*pixscale);
    Yw=[bsxfun(@rdivide,U'*YC,whiten_scale);pixscale]/sqrt(p);
    A0=max(Q0*Yw,0);
    A0=bsxfun(@times,A0,pixscale./max(sum(A0,1),1e-8));
    Yhat=M0_projected*A0;
    roi=mask(id);
    if any(roi)
        diff=YY(:,roi)-Yhat(:,roi);
        normY2=sum(YY(:,roi).^2,1);
        rn=sqrt(sum(diff.^2,1))./max(sqrt(normY2),1);
        totalRel=totalRel+sum(rn);
        countRel=countRel+nnz(roi);
        totalSq=totalSq+sum(diff(:).^2);
        totalY2=totalY2+sum(normY2);
    end
end
    init_roi_mean=totalRel/max(countRel,1);
    init_roi_fro=sqrt(totalSq/max(totalY2,eps));
end
out=struct();
out.projected_band_M0=M0_projected;
out.proj_sad_by_dye=sad_by_dye;
out.proj_mean_sad=mean(sad_by_dye);
out.proj_max_sad=max(sad_by_dye);
out.work_rcond=work_rcond;
out.work_cond=work_cond;
out.init_roi_mean=init_roi_mean;
out.init_roi_fro=init_roi_fro;
end

