% demo_pisco_MultiView_RefInit_13EM_PlotOnly.m (SCRIPT, not function)
% --------------------------------------------------------------
% MultiView / PISCO NoASC - reference-guided 13-endmember INITIALIZATION.
% Only change in the PISCO training call: supply 'M0', M_ref.
% The 13 SAME-VIEW SINGLE-STAIN reference spectra are used during training
% ONLY to initialize the endmembers, NOT fixed as endmembers thereafter.
% This is a REFERENCE-GUIDED experiment, NOT a strictly blind benchmark.
% Default: combined L488_L561_L639 view, seed=1001, p=13.
% The original PISCO model is NOT modified; its objective and all training
% hyperparameters are retained. Outputs go into a separate directory.
% For 5 eligible independent views change VIEWS as shown below.
%
% Required folder structure (put this .m in DATA_ROOT, or edit DATA_ROOT):
% DATA_ROOT/L445/data/{AF488_L445.tif,...,RRX_L445.tif,mix_L445.tif}
% DATA_ROOT/L445/L445.mat  (optional, used only for diagnostics)
% ... likewise L488, L514, L561, L488_L561_L639.
%
% Required external MATLAB functions:
%   deep_mvsa_invflow_poisson_explicit_Warmup2_NoASC.m (USER's model)
%   VCA.m is NOT needed in this reference-initialized branch.
%
% Output (under OUTPUT_ROOT):
%   multiview_summary.csv                   (only summary CSV)
%   <view>/seed_<n>/sad_matches.csv          (only per-run CSV)
%   <view>/seed_<n>/preview.png              (four-panel preview)
%   <view>/seed_<n>/abundance_13_endmembers.png (montage with embedded label strip)
%   <view>/seed_<n>/plot_global.mat          (spectra, full ROI mask,
%       full residual map, label map, dye names and EM-to-reference mapping)
%   <view>/seed_<n>/abundance_<DYE>.mat      (e.g. abundance_AF555.mat)
%       Each file holds one FULL H x W abundance map (not pixel chunks).
%   No metadata, matInfo, raw Y, initialization matrices or other result
%   CSVs are saved. The existing PISCO model and training settings are
%   unchanged. The 13-endmember montage is automatically displayed at the
%   end of training. Use replot_MultiView_RefInit_PlotOnly_v3.m to redraw
%   without running the trainer again.
%
% IMPORTANT REFERENCE POLICY:
%   Default SAD reference is from the 13 SINGLE-STAIN TIFFs, not the mix.
%   Each view's <view>.mat is loaded and compared as an OPTIONAL diagnostic.
%   If the .mat is INDEPENDENTLY extracted from single-stain TIFFs and you
%   want to use it directly for SAD, set REF_SOURCE='mat' and confirm
%   MAT_IS_INDEPENDENT_SINGLE_STAIN=true. If the MAT was fitted on the
%   mix itself, it is NOT independent reference truth.
%
% TIFF orientation: only unambiguous multipage monochrome stacks or one
% multichannel TIFF directory are accepted. Unknown dimensions stop with a
% useful error rather than silently permuting spectral channels.
%
% Notes: MATLAB R2021b+ recommended; MATLAB Image Processing Toolbox NOT
% necessary for masks. GPU training requires MATLAB Parallel Computing
% Toolbox and a supported CUDA GPU. No Python is used.
% --------------------------------------------------------------

%% Start: fresh non-function MATLAB script
clear; clc;
close all force;

%% ============ USER CONFIGURATION =======================================
DATA_ROOT = fileparts(mfilename('fullpath'));
% DATA_ROOT = 'D:\\your_folder\\MultiView'; % edit if placed elsewhere
OUTPUT_ROOT = fullfile(DATA_ROOT, 'MultiView_PISCO_RefInit_13EM_PlotOnly_output');

%VIEWS = {'L488_L561_L639'}; % Initial verification only
% Once verified, enable 5 views:
 VIEWS = {'L488_L561_L639','L445','L488','L514','L561'};
% L594 and L639 are intentionally excluded from p=13 analysis.
SEEDS = [1001];
DYES = {'AF488','AF514','AF532','AF555','AF594','AF610', ...
        'AF633','AF647','AF660','ATTO542','ATTO620','ATTO655','RRX'};

% Reference TIFFs are explicitly used to INITIALIZE PISCO here.
% Therefore same-TIFF SAD results are IN-SAMPLE/REFERENCE-GUIDED and cannot
% be reported as strictly blind recovery or independent validation.
REF_SOURCE = 'single_tiff';  % 'single_tiff' (recommended) or 'mat'
MAT_IS_INDEPENDENT_SINGLE_STAIN = false; % change true ONLY if verified
% Optional: exact MAT columns in order, e.g. DYES. Leave empty to infer
% their association from same-view single-stain TIFFs via one-to-one SAD.
MAT_COLUMN_LABELS = {};

% Keep TRUE for complete, correctly registered spatial fields. No random
% training-pixel subsampling: sampling destroys neighborhood regularity.
USE_GPU = true;
GPU_PRECISION = 'single';
GPU_DEVICE = 1;
MM_ITERS = 7500; WARM_UP = 6800;
ETA = 0.3; SIGMA_CAP = 0.03; % explicitly override trainer default 0.15
PHOTON_GAIN = 1; READ_SIGMA = 0; % verify count units / detector calibration
% Parameters explicitly set to paper-like biological NoASC defaults:
LAMBDA_VOL = 0.008;
LAMBDA_NONNEG = 3;
LAMBDA_EQ = 100;
LAMBDA_ENCLOSE = 0.3;
LAMBDA_SPATIAL = 0.2;
LAMBDA_MNONNEG = 10;
LAMBDA_SMOOTH = 0.1;
NOISE_WEIGHT = 'uniform';

P_MODE = 'fixed';  % 'hysime' or 'fixed'
FIXED_P = 13;      % exactly thirteen physical dye references
HYSIME_MAX_PIXELS = 30000;  % covariance/noise-estimation subset only
HYSIME_USE_SIGNAL_MASK = false;  % false mirrors Python's full-field p selection
HYSIME_MAX_P = 30;

SAVE_MAT = true;
MAT_MAX_MB = 95; % each MAT file must remain < 95 decimal MB
% Store one complete H-by-W abundance map per endmember, no spatial chunks.
% 'double' preserves the trainer's returned abundances exactly (preferred).
% 'single' reduces disk use for plotting; it rounds the abundances.
ABUNDANCE_STORAGE_CLASS = 'double'; % 'double' or 'single' 
MAKE_PREVIEW = true;
SHOW_PREVIEW = true;  % displays per-view/seed previews
MAKE_ABUNDANCE_MONTAGE = true; % draw the 13-dye montage immediately after training
SHOW_ABUNDANCE_MONTAGE = true; % show the montage window (not save-only)
MONTAGE_MAX_DISPLAY_SIDE = 1024; % display only; full-resolution MAT remains unchanged
SKIP_MISSING_VIEWS = true;
MAX_REFERENCE_PIXELS = 30000; % foreground pixel cap per single-stain
RESIDUAL_CHUNK = 60000; % bounded peak memory during metrics
% Guard the internal square Q0 initialization matrix against singularity.
REFINIT_RCOND_WARN = 1e-5;
REFINIT_RCOND_FAIL = 1e-10; % Set to 0 to disable hard stop (not recommended).
%% =======================================================================

assert(exist('deep_mvsa_invflow_poisson_explicit_Warmup2_NoASC','file') == 2, ...
    ['The current NoASC model must be on the MATLAB path, with filename ' ...
     'deep_mvsa_invflow_poisson_explicit_Warmup2_NoASC.m (rename the dated upload).']);
% VCA.m is not called when the external 'M0' is supplied.
if strcmpi(REF_SOURCE,'mat') && ~MAT_IS_INDEPENDENT_SINGLE_STAIN
    error(['REF_SOURCE=mat requires MAT_IS_INDEPENDENT_SINGLE_STAIN=true. ' ...
           'Do not evaluate estimated mix endmembers against themselves.']);
end
if ~exist(OUTPUT_ROOT,'dir'), mkdir(OUTPUT_ROOT); end
fprintf('\n===== MultiView / MATLAB PISCO NoASC =====\n');
fprintf('ROOT: %s\nOUTPUT: %s\n', DATA_ROOT, OUTPUT_ROOT);
fprintf('MODE: SAME-VIEW REFERENCE-GUIDED M0; NO VCA; 13 components per view\n');
fprintf('NOT a strictly blind experiment. Views=%s | seeds=%s\n',strjoin(VIEWS,','),mat2str(SEEDS));

% Collect rows as cell data, write CSV at end (also after each completed run).
headers = {'view','n_channels','n_refs','seed','p', ...
    'masked_relresid_mean','pearson_rms','sad_mean_deg','sad_max_deg', ...
    'n_matched','hysime_p','mask_pixels','negative_S_fraction', ...
    'time_s','reference_source','status', ...
    'init_projected_mean_sad_deg','init_projected_max_sad_deg', ...
    'init_roi_mean','init_roi_fro','final_roi_fro','m0_work_rcond','init_mode'};
summary = cell(0,numel(headers));
for iv = 1:numel(VIEWS)
    view = VIEWS{iv};
    vdir = fullfile(DATA_ROOT,view);
    dataDir = fullfile(vdir,'data');
    mixPath = fullfile(dataDir, ['mix_' view '.tif']);
    if exist(mixPath,'file')~=2
        msg = sprintf('[%s] missing mix file: %s', view, mixPath);
        if SKIP_MISSING_VIEWS
            warning('%s (skipped)',msg); continue
        else
            error('%s',msg);
        end
    end
    fprintf('\n----- %s: reading mix -----\n',view);
    [Y,H,W] = mv_read_tiff(mixPath,[]);
    [L,N] = size(Y);
    assert(N==H*W && all(isfinite(Y(:))), 'Invalid mix spectral matrix');
    if any(Y(:)<0)
        warning('[%s] negative TIFF values found: clipping to 0 for count model.',view);
        Y = max(Y,0);
    end

    % Derive EXPLICITLY LABELLED reference spectra from each single-stain
    % TIFF. Also provides an independent cross-check for the local .mat.
    tifRef = zeros(L,numel(DYES));
    tifMeta = struct('name',DYES,'pixels',num2cell(zeros(1,numel(DYES))), ...
                     'threshold',num2cell(zeros(1,numel(DYES))));
    for j=1:numel(DYES)
        refPath = fullfile(dataDir,[DYES{j} '_' view '.tif']);
        assert(exist(refPath,'file')==2, ...
            'Missing same-view single-stain file: %s',refPath);
        [Yr,~,~] = mv_read_tiff(refPath,L);
        [tifRef(:,j),pix,thr] = mv_extract_ref(Yr,MAX_REFERENCE_PIXELS);
        tifMeta(j).pixels = pix;
        tifMeta(j).threshold = thr;
        clear Yr
    end

    matPath = fullfile(vdir,[view '.mat']);
    matInfo = struct('found',false,'source','','match_sad',[],'labels',{{}});
    matRef = [];
    if exist(matPath,'file')==2
        try
            [matRefRaw,mnames,sourceName] = mv_load_mat_ref(matPath,L,numel(DYES));
            % If MAT labels are absent, infer its column order with
            % one-to-one assignment to same-view TIFF single-stain spectra.
            if ~isempty(MAT_COLUMN_LABELS)
                mnames = MAT_COLUMN_LABELS;
            end
            nMatCols=size(matRefRaw,2);
            if strcmpi(REF_SOURCE,'mat') && nMatCols~=numel(DYES)
                error('MAT has %d endmembers; 13 independently labeled references are required for REF_SOURCE=mat.',nMatCols);
            end
            if isempty(mnames)
                C = mv_sad_matrix(matRefRaw,tifRef);
                [ii,jj,dd] = mv_assignment(C);
                matRef = nan(L,numel(DYES));
                for q=1:numel(ii),matRef(:,jj(q))=matRefRaw(:,ii(q));end
                matInfo.match_sad = dd;
                matInfo.labels = reshape(DYES(jj),1,[]);
                matInfo.source = [sourceName ' (column order inferred by SAD)'];
                warning(['[%s] MAT has no verified dye labels; MAT columns were ' ...
                         'matched to TIFF references by SAD. Inspect ambiguous pairs ' ...
                         'before treating MAT as a labelled standard.'],view);
            else
                mnames = cellstr(string(mnames(:)));
                assert(numel(mnames)==nMatCols, 'MAT dye-name count mismatch.');
                matRef = nan(L,numel(DYES));
                matchedColumns = zeros(1,nMatCols);
                for q=1:nMatCols
                    j=find(strcmpi(strtrim(mnames{q}),DYES));
                    assert(numel(j)==1,'Unknown/duplicate dye label: %s',mnames{q});
                    assert(~any(matchedColumns==j),'Duplicate MAT dye label: %s',mnames{q});
                    matRef(:,j)=matRefRaw(:,q);
                    matchedColumns(q)=j;
                end
                matInfo.labels = reshape(DYES(matchedColumns),1,[]);
                matInfo.source = [sourceName ' (verified label list supplied)'];
                compareC=mv_sad_matrix(matRefRaw,tifRef(:,matchedColumns));
                matInfo.match_sad = diag(compareC);
            end
            matInfo.found = true;
            matInfo.n_endmembers = nMatCols;
            if any(matInfo.match_sad>25)
                warning('[%s] MAT/TIFF spectral mismatch above 25 degrees; check files.',view);
            end
            fprintf('  MAT: %s | mean MAT-vs-TIFF SAD %.2f deg\n', ...
                matInfo.source,mean(matInfo.match_sad));
        catch ME
            if strcmpi(REF_SOURCE,'mat'), rethrow(ME); end
            warning('[%s] MAT diagnostic unavailable: %s',view,ME.message);
        end
    elseif strcmpi(REF_SOURCE,'mat')
        error('Requested MAT reference does not exist: %s',matPath);
    end

    if strcmpi(REF_SOURCE,'mat')
        assert(~isempty(matRef),'No usable MAT reference for %s',view);
        M_ref = matRef;
    elseif strcmpi(REF_SOURCE,'single_tiff')
        M_ref = tifRef;
    else
        error('Unknown REF_SOURCE %s',REF_SOURCE);
    end
    M_ref = max(M_ref,0); % physical nonnegative reference spectrum
    assert(all(size(M_ref)==[L numel(DYES)]), 'Reference dimensions mismatch');
    refValid = vecnorm(M_ref,2,1)>1e-12;
    assert(all(refValid), ...
        '[%s] Reference-guided p=13 requires all 13 nonzero reference columns.',view);
    if nnz(refValid)<numel(DYES)
        warning('[%s] only %d/13 nonzero reference spectra: dark dyes cannot be SAD-matched.', ...
            view,nnz(refValid));
    end
    assert(nnz(refValid)>0,'All single-stain references are dark / invalid.');

    mask = mv_signal_mask(Y); % Otsu on per-pixel integrated intensity
    nMask = nnz(mask);
    if nMask<max(64,round(0.001*N))
        warning('[%s] Otsu mask too small (%d/%d); using positive intensity.',view,nMask,N);
        mask = sum(Y,1)>0; nMask=nnz(mask);
    end
    assert(nMask>0,'Empty valid signal mask on %s',view);

    Y_for_hysime = Y;
    if HYSIME_USE_SIGNAL_MASK, Y_for_hysime = Y(:,mask); end
    if strcmpi(P_MODE,'hysime')
        hyP = mv_hysime(Y_for_hysime,HYSIME_MAX_PIXELS);
        p = min([max(hyP,2),L-1,HYSIME_MAX_P]);
    elseif strcmpi(P_MODE,'fixed')
        hyP = mv_hysime(Y_for_hysime,HYSIME_MAX_PIXELS);
        p = FIXED_P;
        assert(p>=2 && p<L,'Fixed p=%d invalid for L=%d (%s)',p,L,view);
    else
        error('Unknown P_MODE');
    end
    if p < numel(DYES)
        warning('[%s] p=%d < 13: SAD scores cover only matched components, not all 13 dyes.',view,p);
    end
    fprintf('[%s] L=%d H=%d W=%d ROI=%d/%d HySime=%d using p=%d\n', ...
            view,L,H,W,nMask,N,hyP,p);
    assert(strcmpi(P_MODE,'fixed') && p==13, ...
        'Reference-guided experiment requires P_MODE=fixed and FIXED_P=13.');

    % Analyze the ACTUAL model M0 construction rather than claiming that
    % passing raw reference spectra yields exactly zero initial SAD.
    % The trainer normalizes M0 and projects it onto its PCA working space.
    fprintf('  Computing reference-M0 projection / conditioning diagnostic...\n');
    initStat = mv_refinit_preflight(Y,M_ref,p,mask,RESIDUAL_CHUNK);
    vout = fullfile(OUTPUT_ROOT,view);
    if ~exist(vout,'dir'),mkdir(vout);end
    fprintf(['  Raw reference SAD=0 by construction; projected INIT SAD:', ...
             ' mean=%.4f max=%.4f deg\n'], ...
        initStat.proj_mean_sad,initStat.proj_max_sad);
    fprintf(['  Projected M0_work rcond=%.3e | condition=%.3e', ...
             ' | initialization ROI Mean=%.3f%% Fro=%.3f%%\n'], ...
        initStat.work_rcond,initStat.work_cond, ...
        100*initStat.init_roi_mean,100*initStat.init_roi_fro);
    if initStat.work_rcond < REFINIT_RCOND_WARN
        warning('[%s] Reference projected M0_work is ill-conditioned: rcond=%.3e.', ...
            view,initStat.work_rcond);
    end
    if ~isfinite(initStat.work_rcond) || initStat.work_rcond <= REFINIT_RCOND_FAIL
        error(['[%s] Reference M0 leads to nearly singular Q0 initialization', ...
               ' (rcond=%.3e). Stop rather than waste GPU training.'], ...
               view,initStat.work_rcond);
    end
    for is=1:numel(SEEDS)
        seed=SEEDS(is);
        rng(seed,'twister');
        t0=tic;
        try
            [M_est,S_est,Up,my,~] = ...
                deep_mvsa_invflow_poisson_explicit_Warmup2_NoASC(Y,p, ...
                'M0',M_ref, ... % THE ONLY CHANGE TO THE PISCO TRAINING CALL
                'MM_ITERS',MM_ITERS,'WARM_UP',WARM_UP, ...
                'LR',3e-4,'LAMBDA_VOL',LAMBDA_VOL, ...
                'LAMBDA_NONNEG',LAMBDA_NONNEG, ...
                'LAMBDA_EQ',LAMBDA_EQ,'LAMBDA_SUMONE',0, ...
                'LAMBDA_ENCLOSE',LAMBDA_ENCLOSE, ...
                'LAMBDA_SPATIAL',LAMBDA_SPATIAL, ...
                'LAMBDA_MNONNEG',LAMBDA_MNONNEG, ...
                'LAMBDA_SMOOTH',LAMBDA_SMOOTH, ...
                'IMG_H',H,'IMG_W',W, ...
                'NOISE_MODEL','poisson','NOISE_WEIGHT',NOISE_WEIGHT, ...
                'ETA',ETA,'ETA_END',ETA,'SIGMA_CAP',SIGMA_CAP, ...
                'PHOTON_GAIN',PHOTON_GAIN,'PHOTON_FLOOR',1, ...
                'READ_SIGMA',READ_SIGMA,'USE_GPU',USE_GPU, ...
                'GPU_PRECISION',GPU_PRECISION,'GPU_DEVICE',GPU_DEVICE, ...
                'verbose',0);  % Disable iterative training logs
            trainTime=toc(t0);
            assert(isequal(size(M_est),[L,p]) && isequal(size(S_est),[p,N]), ...
                'NoASC trainer output dimensions do not match input');
            assert(all(isfinite(M_est(:))) && all(isfinite(S_est(:))), ...
                'Non-finite model outputs');
            % *** IMPORTANT *** Native NoASC uses Y_hat=M_est*S_est.
            % Do NOT apply the OLD ASC/offset correction my*(sum(S)-1).
            [rrMean,prRMS,residMap] = mv_residual_metrics( ...
                Y,M_est,S_est,mask,RESIDUAL_CHUNK);
            refIds=find(refValid);
            sads=mv_sad_matrix(M_est,M_ref(:,refIds));
            [estIdx,localRefIdx,matchedDeg] = mv_assignment(sads);
            refIdx=refIds(localRefIdx);
            [estIdx,order] = sort(estIdx);refIdx=refIdx(order);matchedDeg=matchedDeg(order);
            finalFro = mv_roi_fro(Y,M_est,S_est,mask,RESIDUAL_CHUNK);
            nm=numel(matchedDeg);
            assert(nm==min(p,nnz(refValid)),'Incomplete assignment');

            % Print PISCO-estimated endmember SAD summary for this view/seed.
            meanSAD = mean(matchedDeg,'omitnan');
            maxSAD = max(matchedDeg);
            fprintf(['[%s] Seed=%d | Mean SAD=%.4f deg | ' ...
                     'Max SAD=%.4f deg | Matched=%d/%d\\n'], ...
                view,seed,meanSAD,maxSAD,nm,nnz(refValid));
            fprintf(['  Reconstruction residual | ' ...
                  'ROI Mean=%.6f (%.2f%%) | ' ...
                    'Pearson RMS=%.6f\n'], ...
                     rrMean, 100*rrMean, prRMS);
            fprintf('  Final ROI relative Fro=%.6f (%.3f%%)\n',finalFro,100*finalFro);
            fprintf('  INIT projected SAD %.4f -> FINAL matched SAD %.4f deg\n', ...
                initStat.proj_mean_sad,meanSAD);

            negfrac=nnz(S_est<0)/numel(S_est);
            sub = fullfile(vout,sprintf('seed_%d',seed));
            if ~exist(sub,'dir'),mkdir(sub);end
            % Exactly TWO CSV types are written by this script:
            % 1. sad_matches.csv here; 2. multiview_summary.csv below.
            matchedNames = reshape(DYES(refIdx),[],1);
            tt = table(estIdx(:),matchedNames,matchedDeg(:), ...
                'VariableNames',{'endmember','reference','sad_deg'});
            writetable(tt,fullfile(sub,'sad_matches.csv'));
            if SAVE_MAT
                % Save only the arrays required to redraw the four preview
                % panels and all 13 abundance maps. Each endmember is stored
                % as a COMPLETE H x W image in a separate MAT file.
                mv_save_plot_by_endmember(sub,M_est,S_est,M_ref,H,W, ...
                    mask,residMap,DYES,estIdx,refIdx,view,seed, ...
                    ABUNDANCE_STORAGE_CLASS,MAT_MAX_MB);
            end
            if MAKE_PREVIEW
                mv_preview(M_est,M_ref,S_est,mask,residMap,H,W, ...
                    DYES,estIdx,refIdx,view,seed, ...
                    fullfile(sub,'preview.png'),SHOW_PREVIEW);
            end
            if MAKE_ABUNDANCE_MONTAGE
                % NEW: immediately SHOW and SAVE the 13-endmember montage.
                % The discrete dye-color strip is INSIDE the montage figure.
                % No separate label_colorbar.png is created.
                mv_show_abundance_montage(S_est,mask,H,W,DYES, ...
                    estIdx,refIdx,view,seed, ...
                    fullfile(sub,'abundance_13_endmembers.png'), ...
                    SHOW_ABUNDANCE_MONTAGE,MONTAGE_MAX_DISPLAY_SIDE);
            end
            summary(end+1,:) = {view,L,nnz(refValid),seed,p, ...
                rrMean,prRMS,mean(matchedDeg),max(matchedDeg),nm, ...
                hyP,nMask,negfrac,trainTime,REF_SOURCE,'ok', ...
                initStat.proj_mean_sad,initStat.proj_max_sad, ...
                initStat.init_roi_mean,initStat.init_roi_fro,finalFro, ...
                initStat.work_rcond,'reference_M0'}; %#ok<AGROW>
            mv_write_summary(fullfile(OUTPUT_ROOT,'multiview_summary.csv'),headers,summary);
            clear S_est M_est residMap
        catch ME
            warning('Run FAILED for %s seed=%d: %s',view,seed,ME.message);
            summary(end+1,:) = {view,L,nnz(refValid),seed,p, ...
                NaN,NaN,NaN,NaN,0,hyP,nMask,NaN,toc(t0),REF_SOURCE,ME.identifier, ...
                initStat.proj_mean_sad,initStat.proj_max_sad, ...
                initStat.init_roi_mean,initStat.init_roi_fro,NaN, ...
                initStat.work_rcond,'reference_M0'}; %#ok<AGROW>
            mv_write_summary(fullfile(OUTPUT_ROOT,'multiview_summary.csv'),headers,summary);
            rethrow(ME); % fail loudly; never silently claim a completed run
        end
    end
    clear Y M_ref tifRef matRef mask
end
fprintf('\nDONE. Summary: %s\n',fullfile(OUTPUT_ROOT,'multiview_summary.csv'));

%% =========================== HELPERS ==================================
function [Y,H,W] = mv_read_tiff(path,expectedL)
% Returns L x (H*W). Single IFD with SamplesPerPixel>1 or one monochrome
% IFD per channel. Multiscale pyramids / extra Z cannot be guessed safely.
info=imfinfo(path);
assert(~isempty(info),'Empty TIFF: %s',path);
H=double(info(1).Height);W=double(info(1).Width);
nPages=numel(info);
if nPages>1
    assert(all([info.Height]==H) && all([info.Width]==W), ...
        'Mixed resolutions/pages in TIFF %s; identify the spectral series first.',path);
    spp=double(info(1).SamplesPerPixel);
    if spp~=1
        error('Multi-page TIFF with SamplesPerPixel=%d is ambiguous: %s',spp,path);
    end
    L=nPages;
    if ~isempty(expectedL) && L~=expectedL
        error('Channel count mismatch: %s has %d pages; mix has %d.',path,L,expectedL);
    end
    Y=zeros(L,H*W);
    for k=1:L
        a=imread(path,k,'Info',info);
        assert(ismatrix(a) && all(size(a)==[H W]),'Unexpected TIFF page dimension');
        Y(k,:)=reshape(double(a),1,[]);
    end
else
    t=Tiff(path,'r'); cleaner=onCleanup(@()close(t)); %#ok<NASGU>
    a=t.read();
    if ndims(a)==2
        L=1; a=reshape(a,H,W,1);
    elseif ndims(a)==3
        L=size(a,3);
    else
        error('Unsupported TIFF array size %s: %s',mat2str(size(a)),path);
    end
    if ~isempty(expectedL) && L~=expectedL
        error('Channel count mismatch: %s has %d channels; mix has %d',path,L,expectedL);
    end
    Y=reshape(permute(double(a),[3 1 2]),L,[]);
end
assert(size(Y,1)>=2, ['TIFF appears single-band, not a spectral stack: %s. ' ...
    'Check TIFF axes/metadata and adapt mv_read_tiff before running.'],path);
end

function [spec,npx,thr] = mv_extract_ref(Y,maxPix)
% Foreground-mean reference from a pure single-stain sample; avoids bias
% from the dark background. Underlying TIFF retains real dye identity.
Y=max(Y,0);
intensity=sum(Y,1);
thr=mv_otsu(intensity);
idx=find(intensity>thr);
if numel(idx)<32
    idx=find(intensity>0);
end
if numel(idx)<2
    npx=0;spec=zeros(size(Y,1),1);return; % dye not excited/detected
end
if numel(idx)>maxPix
    idx=idx(unique(round(linspace(1,numel(idx),maxPix))));
end
npx=numel(idx);
spec=mean(Y(:,idx),2);
if norm(spec)<=1e-12
    npx=0;spec=zeros(size(Y,1),1);
end
end

function mask=mv_signal_mask(Y)
intensity=sum(Y,1);
mask=intensity>mv_otsu(intensity);
end

function threshold=mv_otsu(x)
x=double(x(:));x=x(isfinite(x));
assert(~isempty(x),'No finite pixels in threshold input');
lo=min(x);hi=max(x);
if hi<=lo,threshold=lo;return;end
edges=linspace(lo,hi,257);
counts=histcounts(x,edges);
w=double(counts(:));w=w/max(sum(w),1);
c=(edges(1:end-1)+edges(2:end))/2;c=c(:);
omega=cumsum(w);mu=cumsum(w.*c);mt=mu(end);
between=(mt*omega-mu).^2 ./ max(omega.*(1-omega),1e-12);
[~,k]=max(between);
threshold=c(k);
end

function p=mv_hysime(Y,maxPixels)
% Covariance-based HySime port following pisco_py/pisco_core.py;
% bounded subsample for noise-covariance estimation (NOT training).
[L,N]=size(Y);
if N>maxPixels
    Y=Y(:,unique(round(linspace(1,N,maxPixels))));
end
N=size(Y,2);
G=(Y*Y')/N; G=(G+G')/2;
E=zeros(L,N);
for i=1:L
    ix=[1:i-1,i+1:L];
    Gi=G(ix,ix); ridge=1e-10*max(trace(Gi)/max(L-1,1),1);
    beta=(Gi+ridge*eye(L-1))\G(ix,i);
    E(i,:)=Y(i,:)-beta'*Y(ix,:);
end
Rw=(E*E')/N;
Rx=G-Rw;Rx=(Rx+Rx')/2;
[V,D]=eig(Rx);
[~,order]=sort(diag(D),'descend');V=V(:,order);
delta=diag(V'*Rx*V)-diag(V'*Rw*V);
[~,imax]=max([0;cumsum(delta)]);
p=max(2,imax-1);
end

function [R,names,sourceName]=mv_load_mat_ref(path,L,Rcount)
% Detect L-by-p extracted endmember matrices (2 <= p <= Rcount). MAT from
% a weak view may legitimately contain fewer than 13 extracted columns.
A=load(path);
fn=fieldnames(A);
names={};sourceName='';R=[];
nameCandidates={'names','dye_names','labels','fluorophore_names','endmember_names'};
for k=1:numel(nameCandidates)
    f=nameCandidates{k};
    if isfield(A,f) && (iscell(A.(f)) || isstring(A.(f)))
        names=cellstr(string(A.(f)));break
    end
end
pref={'M_ref','Mref','ref_spectra','reference_spectra','endmembers', ...
      'M','E_sv','E','M_est','spectra'};
for i=1:numel(pref)
    f=pref{i};
    if isfield(A,f)
        [candidate,ok]=mv_accept_matrix(A.(f),L,Rcount);
        if ok,R=candidate;sourceName=f;break;end
    end
end
if isempty(R)
    for i=1:numel(fn)
        [candidate,ok]=mv_accept_matrix(A.(fn{i}),L,Rcount);
        if ok
            if ~isempty(R)
                warning('Multiple MAT candidate matrices; using %s.',sourceName);
                break
            end
            R=candidate;sourceName=fn{i};
        end
    end
end
if isempty(R)
    error('No numeric L-by-p endmember matrix (L=%d, 2<=p<=%d) found in %s; check whos -file.', ...
        L,Rcount,path);
end
R=double(R);
assert(all(isfinite(R(:))),'Non-finite reference matrix');
R=max(R,0);
assert(all(vecnorm(R,2,1)>0),'Zero reference column in MAT');
end

function [R,ok]=mv_accept_matrix(x,L,K)
ok=false;R=[];
if ~(isnumeric(x)&&ismatrix(x)&&isreal(x)),return;end
sz=size(x);
if sz(1)==L && sz(2)>=2 && sz(2)<=K
    R=x;ok=true;
elseif sz(2)==L && sz(1)>=2 && sz(1)<=K
    R=x.';ok=true;
end
end

function C=mv_sad_matrix(A,B)
assert(size(A,1)==size(B,1),'SAD channel mismatch');
A=max(double(A),0);B=max(double(B),0);
A=A./max(vecnorm(A,2,1),eps);B=B./max(vecnorm(B,2,1),eps);
cosines=min(max(A'*B,-1),1);
C=acosd(cosines);
end

function [rowIdx,colIdx,vals]=mv_assignment(C)
% Hungarian minimum-cost ONE-TO-ONE assignment for rectangular matrices;
% unlike the Turn51 greedy matching, optimizes the full matched SAD sum.
[n0,m0]=size(C);
transposed=false;
if n0>m0,C=C.';transposed=true;end
[n,m]=size(C);assert(n>=1 && m>=n && all(isfinite(C(:))));
u=zeros(n+1,1);v=zeros(m+1,1);p=zeros(m+1,1);way=zeros(m+1,1);
for i=1:n
    p(1)=i;j0=1;
    minv=inf(m+1,1);used=false(m+1,1);
    while true
        used(j0)=true;i0=p(j0);delta=Inf;j1=0;
        for j=2:(m+1)
            if ~used(j)
                cur=C(i0,j-1)-u(i0+1)-v(j);
                if cur<minv(j),minv(j)=cur;way(j)=j0;end
                if minv(j)<delta,delta=minv(j);j1=j;end
            end
        end
        assert(isfinite(delta)&&j1>0,'Assignment solver failed');
        for j=1:(m+1)
            if used(j)
                u(p(j)+1)=u(p(j)+1)+delta;
                v(j)=v(j)-delta;
            else
                minv(j)=minv(j)-delta;
            end
        end
        j0=j1;
        if p(j0)==0,break;end
    end
    while true
        j1=way(j0);p(j0)=p(j1);j0=j1;
        if j0==1,break;end
    end
end
r=zeros(n,1);c=zeros(n,1);
for j=2:(m+1)
    if p(j)>0,r(p(j))=p(j);c(p(j))=j-1;end
end
if transposed,rowIdx=c;colIdx=r;else,rowIdx=r;colIdx=c;end
vals=C(sub2ind(size(C),r,c));
end

function [meanRelative,pearsonRMS,residMap]=mv_residual_metrics(Y,M,S,mask,chunk)
N=size(Y,2);L=size(Y,1);
residMap=zeros(1,N,'single');totalRel=0;nRel=0;
pearsonSq=0;nPearson=0;
for st=1:chunk:N
    id=st:min(st+chunk-1,N);
    Yh=M*S(:,id); % NoASC native -- NO my*(sumS-1) correction
    D=Y(:,id)-Yh;
    rn=sqrt(sum(D.^2,1))./max(sqrt(sum(Y(:,id).^2,1)),1);
    residMap(id)=single(rn);
    mk=mask(id);
    if any(mk)
        totalRel=totalRel+sum(rn(mk));nRel=nRel+nnz(mk);
        Dr=D(:,mk);Yhr=Yh(:,mk);
        pearsonSq=pearsonSq+sum(Dr.^2./max(Yhr,1),'all');
        nPearson=nPearson+L*nnz(mk);
    end
end
meanRelative=totalRel/max(nRel,1);
pearsonRMS=sqrt(pearsonSq/max(nPearson,1));
end

function mv_write_summary(file,headers,rows)
fid=fopen(file,'w');assert(fid>0,'Cannot write CSV %s',file);
cleaner=onCleanup(@()fclose(fid)); %#ok<NASGU>
fprintf(fid,'%s\n',strjoin(headers,','));
for i=1:size(rows,1)
    ss=cell(1,size(rows,2));
    for j=1:size(rows,2)
        x=rows{i,j};
        if isnumeric(x)
            if isfinite(x),ss{j}=sprintf('%.10g',x);else,ss{j}='NaN';end
        else
            ss{j}=strrep(char(string(x)),',',';');
        end
    end
    fprintf(fid,'%s\n',strjoin(ss,','));
end
end

function mv_preview(M,Mref,S,mask,R,H,W,names,ii,jj,view,seed,output,showit)
% Preview only: categorical abundance-argmax and shape-normalized spectra.
% Black background outside signal ROI; not a pixelwise ground-truth map.
if showit,visible='on';else,visible='off';end
fig=figure('Visible',visible,'Color','w','Position',[100,100,1300,800]);
if exist('tiledlayout','file')==2
    tiledlayout(fig,2,2,'Padding','compact','TileSpacing','compact');
    nexttile;
else
    subplot(2,2,1);
end
plot(M./max(vecnorm(M,2,1),eps),'LineWidth',1.1);
xlabel('Spectral channel');ylabel('L2-normalized signal');
title(sprintf('PISCO endmembers | %s seed %d',view,seed),'Interpreter','none');
if exist('tiledlayout','file')==2,nexttile;else,subplot(2,2,2);end
plot(Mref./max(vecnorm(Mref,2,1),eps),'LineWidth',0.9);
xlabel('Spectral channel');ylabel('L2-normalized signal');
title('Same-view single-stain reference spectra');
if exist('tiledlayout','file')==2,nexttile;else,subplot(2,2,3);end
% MATLAB image pixels are column-major; S is p x (H*W).
[~,argmax]=max(max(S,0),[],1);
colors=lines(numel(names));
pal=zeros(size(S,1),3);
for k=1:numel(ii),pal(ii(k),:)=colors(jj(k),:);end
rgb=reshape(pal(argmax,:),H,W,3);
for k=1:3
    a=rgb(:,:,k);a(~reshape(mask,H,W))=0;rgb(:,:,k)=a;
end
image(rgb);axis image off;
title('Maximum-coefficient label (black = background)');
if exist('tiledlayout','file')==2,nexttile;else,subplot(2,2,4);end
im=reshape(double(R),H,W);im(~reshape(mask,H,W))=NaN;
imagesc(im);axis image off;colorbar;
title('Per-pixel relative L2 reconstruction residual');
try,exportgraphics(fig,output,'Resolution',160);
catch,saveas(fig,output);end
if ~showit,close(fig);end
end


%% ==================== PLOT-ONLY MAT SAVER ============================
function mv_save_plot_by_endmember(outputDir,M_est,S_est,M_ref,H,W, ...
    mask,residMap,dye_names,estIdx,refIdx,view,seed,storeClass,maxMB)
% Saves ONLY the ingredients needed to replot:
%   plot_global.mat: spectra, full ROI mask, full residual map, full label
%                    map, reference-to-endmember mapping and panel labels.
%   abundance_<DYE>.mat: one FULL H x W abundance map per endmember, named
%                    by the matched dye label (e.g. abundance_AF555.mat).
% The individual EM files are NOT spatially split. No metadata/matInfo.
%
[p,N] = size(S_est);
assert(N==H*W && size(M_est,2)==p && size(M_ref,1)==size(M_est,1), ...
    'Incompatible dimensions for plot-only MAT saving.');
assert(numel(mask)==N && numel(residMap)==N, ...
    'mask/residMap must contain H*W pixels.');
assert(maxMB>0 && maxMB<100, 'MAT_MAX_MB must be below 100.');
assert(any(strcmpi(storeClass,{'double','single'})), ...
    'ABUNDANCE_STORAGE_CLASS must be double or single.');
assert(numel(estIdx)==p && numel(refIdx)==p, ...
    'All p endmembers must be matched before building the color legend.');

% Rebuild the EXACT preview labels from the returned S_est, not from a
% separately normalized, thresholded, or refitted abundance representation.
[~,argmax] = max(max(S_est,0),[],1);
label_map = reshape(uint8(argmax),H,W);
mask = reshape(logical(mask),H,W);
label_map(~mask) = 0; % zero is black background
residMap = reshape(single(residMap),H,W);
em_to_ref_index = zeros(1,p,'uint8');
endmember_names = cell(1,p);
abundance_filenames = cell(1,p);
for k=1:numel(estIdx)
    em_to_ref_index(estIdx(k)) = uint8(refIdx(k));
end
assert(all(em_to_ref_index>0),'At least one EM has no reference color.');
for em=1:p
    refName = char(string(dye_names{double(em_to_ref_index(em))}));
    safeName = mv_safe_filename(refName);
    endmember_names{em} = refName;
    abundance_filenames{em} = ['abundance_' safeName '.mat'];
end
view_name = view;
seed_value = seed;

% Prepare all MAT files first in a separate staging folder. A failed write
% leaves previous finished MAT files untouched.
stage = fullfile(outputDir,'_plotMAT_writing');
if exist(stage,'dir'),rmdir(stage,'s');end
[ok,msg] = mkdir(stage);
assert(ok,'Cannot create plot MAT staging folder: %s',msg);

% Small global file, including a direct categorical label map, so the
% original four-panel preview can be replotted without loading abundance.
globalPath = fullfile(stage,'plot_global.mat');
save(globalPath,'M_est','M_ref','H','W','mask','residMap', ...
    'label_map','dye_names','em_to_ref_index','endmember_names', ...
    'abundance_filenames','view_name','seed_value', ...
    '-v7.3');
mv_check_plot_mat_size(globalPath,maxMB);

for em=1:p
    % MATLAB column-major pixel order exactly matches reshape(S_est(em,:),H,W).
    abundance_map = reshape(cast(S_est(em,:),storeClass),H,W);
    endmember_index = em;
    endmember_name = endmember_names{em};
    reference_index = double(em_to_ref_index(em));
    filename = abundance_filenames{em};
    outPath = fullfile(stage,filename);
    save(outPath,'abundance_map','endmember_index','endmember_name','reference_index','-v7.3');
    mv_check_plot_mat_size(outPath,maxMB);
    clear abundance_map endmember_name reference_index filename
end

% Publish only after the complete new set has passed file-size checks.
% The new OUTPUT_ROOT is deliberately separate from older experiments.
oldGlobal = fullfile(outputDir,'plot_global.mat');
if exist(oldGlobal,'file'),delete(oldGlobal);end
oldEm = dir(fullfile(outputDir,'abundance_*.mat'));
for k=1:numel(oldEm)
    delete(fullfile(outputDir,oldEm(k).name));
end
filenames = [{'plot_global.mat'}, abundance_filenames(:)'];
for k=1:numel(filenames)
    name=filenames{k};
    [ok,msg]=movefile(fullfile(stage,name),fullfile(outputDir,name));
    assert(ok,'Cannot install MAT file %s: %s',name,msg);
end
rmdir(stage,'s');
fprintf('  Plot-only MAT saved: 1 global + %d FULL abundance maps; class=%s\n', ...
    p,storeClass);
end

function mv_check_plot_mat_size(path,maxMB)
stat=dir(path);
assert(~isempty(stat),'Missing MAT file after save: %s',path);
assert(stat.bytes<maxMB*1e6, ...
    ['MAT file exceeds %.1f MB: %s (%.2f MB). ', ...
     'Try ABUNDANCE_STORAGE_CLASS=single when using larger images.'], ...
    maxMB,path,stat.bytes/1e6);
end




function safe = mv_safe_filename(name)
name = char(string(name));
safe = regexprep(name,'[^A-Za-z0-9_\-]','_');
if isempty(safe), safe = 'unnamed'; end
end

%% ================= AUTOMATIC 13-DYE ABUNDANCE MONTAGE ==================
function mv_show_abundance_montage(S_est,mask,H,W,names,estIdx,refIdx,view,seed,outFile,showit,maxDisplaySide)
% Creates the montage immediately after the PISCO training run.
% The top tile is a DISCRETE label-color strip, matched exactly to preview.
% Panels show full-field abundances on black; percentile stretch is PLOT-ONLY.
% Saved abundance MATs are NOT downsampled or normalized here.
[p,N] = size(S_est);
assert(N==H*W && numel(mask)==N, 'Montage: inconsistent spatial dimensions.');
names = cellstr(string(names));
assert(p==numel(names),'Montage requires 13 endmembers and 13 labels.');
refForEm=zeros(1,p);
for j=1:numel(estIdx)
    refForEm(estIdx(j))=refIdx(j);
end
assert(all(refForEm>=1 & refForEm<=numel(names)), ...
    'Montage: missing one-to-one reference assignment.');
colors=lines(numel(names)); % identical to mv_preview color mapping
roi=reshape(logical(mask),H,W);
step=max(1,ceil(max(H,W)/maxDisplaySide));
if showit, visibility='on'; else, visibility='off'; end
fig=figure('Visible',visibility,'Color','w', ...
    'Position',[80,60,1540,1260],'Name',sprintf('%s | %d | 13-dye montage',view,seed));
nCols=4;
nRows=ceil(p/nCols);
t=tiledlayout(fig,nRows+1,nCols,'TileSpacing','compact','Padding','compact');
axStrip=nexttile(t,[1 nCols]);
barLabels=[{'Background'},names(:)'];
imagesc(axStrip,1:(numel(names)+1));
colormap(axStrip,[0 0 0;colors]);
set(axStrip,'XTick',1:numel(barLabels),'XTickLabel',barLabels, ...
    'XTickLabelRotation',32,'YTick',[], ...
    'TickLength',[0 0],'FontSize',10,'Box','on','Color','w');
xlim(axStrip,[0.5 numel(barLabels)+0.5]);
title(axStrip,'Color mapping of matched dye labels','FontWeight','bold');
for em=1:p
    % Read the ORIGINAL, UNMODIFIED coefficients. Only the rendering is changed.
    A=reshape(single(S_est(em,:)),H,W);
    A=max(A,0);
    A(~roi)=0;
    vv=A(roi & A>0);
    if isempty(vv)
        cap=1;
    else
        if numel(vv)>50000
            vv=vv(unique(round(linspace(1,numel(vv),50000))));
        end
        vv=sort(vv);
        cap=max(double(vv(max(1,round(0.995*numel(vv))))),eps);
    end
    % Downsampling below is exclusively for the on-screen montage.
    A=A(1:step:end,1:step:end);
    levels=single(min(double(A)./cap,1).^0.7);
    rgb=zeros(size(A,1),size(A,2),3,'uint8');
    for ch=1:3
        rgb(:,:,ch)=uint8(round(255*double(levels)*colors(refForEm(em),ch)));
    end
    ax=nexttile(t);
    image(ax,rgb);axis(ax,'image');axis(ax,'off');
    title(ax,names{refForEm(em)},'Color','k', ...
        'Interpreter','none','FontSize',12,'FontWeight','bold');
    clear A vv levels rgb
end
for k=p+1:nCols*nRows
    ax=nexttile(t);axis(ax,'off');
end
drawnow;
try
    exportgraphics(fig,outFile,'Resolution',160);
catch
    saveas(fig,outFile);
end
fprintf('  DISPLAYED + SAVED 13-dye montage with embedded label strip: %s\n',outFile);
if ~showit,close(fig);end
end

%% ============== REFERENCE-GUIDED INITIALIZATION DIAGNOSTICS ==============
function out = mv_refinit_preflight(Y,M_ref,p,mask,chunk)
% Reproduces the provided NoASC trainer's M0 normalization, p-1 principal
% spectral coordinates, last intensity coordinate, and square M0_work.
% Uses a small-matrix identity for covariance to avoid materializing a
% second full 23 x 4.2 million Yc array merely for this preflight.
% Floating-point differences in PCA may cause tiny differences vs trainer.
[L,N]=size(Y);
assert(size(M_ref,1)==L && size(M_ref,2)==p);
my = mean(Y,2);
intensity_ref=sum(my);
assert(intensity_ref>0 && isfinite(intensity_ref));
r = ones(1,L)/intensity_ref;
P = eye(L)-my*r;
G = (Y*Y')/N;
G_c=P*G*P';
G_c=(G_c+G_c')/2;
[U,D]=svds(G_c,p-1);
whiten_scale=sqrt(diag(D+1e-10*eye(p-1)));
assert(all(isfinite(whiten_scale)) && all(whiten_scale>0));

M0_band=bsxfun(@times,M_ref, ...
    intensity_ref./max(sum(M_ref,1),eps));
M0_work=[bsxfun(@rdivide,U'*(M0_band-my*ones(1,p)),whiten_scale); ...
         ones(1,p)]/sqrt(p);
svals=svd(M0_work);
work_rcond=rcond(M0_work);
work_cond=svals(1)/max(svals(end),realmin);

% Lift PCA-projected initial endmembers into the original channel space.
M0_projected=U*(U'*(M0_band-my*ones(1,p)))+my*ones(1,p);
cosine=sum(M0_projected.*M_ref,1)./ ...
    max(vecnorm(M0_projected,2,1).*vecnorm(M_ref,2,1),eps);
cosine=max(min(cosine,1),-1);
sad_by_dye=acosd(cosine);

% Evaluate the PRE-TRAINING coefficients exactly as initialized by PISCO:
% A0=max(Q0*Y_work,0), then rescale each pixel to its observed intensity.
% This is NOT fixed-reference NNLS and should not be confused with the
% previously completed fixed-reference + NNLS comparison.
% If practically singular, stop before constructing Q0. The caller will
% report failure; still allow a preflight CSV to be written above.
if ~isfinite(work_rcond) || work_rcond<1e-12
    init_roi_mean=NaN;
    init_roi_fro=NaN;
else
    Q0=M0_work\eye(p); % algebraically equivalent to inv(M0_work)
    totalRel=0; countRel=0; totalSq=0; totalY2=0;
for st=1:chunk:N
    id=st:min(N,st+chunk-1);
    YY=Y(:,id);
    pixscale=sum(YY,1)/intensity_ref;
    YC=bsxfun(@minus,YY,my*pixscale);
    Yw=[bsxfun(@rdivide,U'*YC,whiten_scale);pixscale]/sqrt(p);
    A0=max(Q0*Yw,0);
    A0=bsxfun(@times,A0,pixscale./max(sum(A0,1),1e-8));
    Yhat=M0_projected*A0;
    roi=mask(id);
    if any(roi)
        diff=YY(:,roi)-Yhat(:,roi);
        normY2=sum(YY(:,roi).^2,1);
        rn=sqrt(sum(diff.^2,1))./max(sqrt(normY2),1);
        totalRel=totalRel+sum(rn);
        countRel=countRel+nnz(roi);
        totalSq=totalSq+sum(diff(:).^2);
        totalY2=totalY2+sum(normY2);
    end
end
    init_roi_mean=totalRel/max(countRel,1);
    init_roi_fro=sqrt(totalSq/max(totalY2,eps));
end
out=struct();
out.projected_band_M0=M0_projected;
out.proj_sad_by_dye=sad_by_dye;
out.proj_mean_sad=mean(sad_by_dye);
out.proj_max_sad=max(sad_by_dye);
out.work_rcond=work_rcond;
out.work_cond=work_cond;
out.init_roi_mean=init_roi_mean;
out.init_roi_fro=init_roi_fro;
end

function val=mv_roi_fro(Y,M,S,mask,chunk)
% Pixel-weighted ROI relative Frobenius residual.
N=size(Y,2);resSq=0;Ysq=0;
for st=1:chunk:N
    ix=st:min(N,st+chunk-1);
    roi=mask(ix);
    if ~any(roi),continue;end
    YY=Y(:,ix);
    DD=YY(:,roi)-M*S(:,ix(roi));
    resSq=resSq+sum(DD(:).^2);
    Ytmp=YY(:,roi);
    Ysq=Ysq+sum(Ytmp(:).^2);
end
val=sqrt(resSq/max(Ysq,eps));
end
