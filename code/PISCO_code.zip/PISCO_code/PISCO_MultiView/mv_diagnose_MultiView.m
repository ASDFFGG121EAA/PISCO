% mv_diagnose_MultiView.m   (SCRIPT; no PISCO training)
% -------------------------------------------------------------------------
% MATLAB conversion of mv_diagnose_MultiView_fixed.py.
% Diagnose MultiView 13-dye single-stain references and mixture TIFFs.
%
% Supported data layouts (the first existing matching path is used):
%   DATA_ROOT/<view>/data/<dye>_<view>.tif   [your MATLAB layout]
%   DATA_ROOT/<view>/<dye>_<view>.tif
%   DATA_ROOT/<dye>_<view>.tif              [flat files]
%   DATA_ROOT/data/<dye>_<view>.tif
%
% Diagnostics (not proof of identifiability):
%   - Otsu-foreground mean of each dye's single-stain spectral TIFF
%   - Pairwise reference SAD, nearest other dye and heuristic candidates
%   - SVD of L2-normalized reference columns; cumulative energy / cond.
%   - Per-dye peak channel, foreground fraction and intensity
%   - Mixture top-quartile sampled covariance eigenvalues and uint8 saturation
%
% No HySime calculation is performed (as in the original Python diagnostic).
% The separation threshold is a heuristic, NOT an identifiability lower bound.
% Only real observed single-stain TIFFs are included; missing dyes are shown.
%
% Tested by static inspection only: execute in your own MATLAB environment.
% Requires MATLAB with imread/imfinfo, histcounts, svd, writecell.
% -------------------------------------------------------------------------
clc;
clear;
close all;

%% ===================== USER CONFIGURATION ===============================
DATA_ROOT = fileparts(mfilename('fullpath'));  % place script in MultiView root
% DATA_ROOT = 'D:\MultiView';                 % or set your actual data root
OUTPUT_ROOT = fullfile(DATA_ROOT, 'mv_diag');

% First diagnostic: {'L488_L561_L639'}
% All seven: {'L488_L561_L639','L445','L488','L514','L561','L594','L639'}
VIEWS = {'L488_L561_L639','L445','L488','L514','L561','L594','L639'};
DYES = {'AF488','AF514','AF532','AF555','AF594','AF610','AF633', ...
        'AF647','AF660','ATTO542','ATTO620','ATTO655','RRX'};

NEAREST_SAD_THRESHOLD_DEG = 20; % candidate flag only, not theoretical limit
MAX_COV_PIXELS = 50000;         % mixture covariance subsample only
COV_SAMPLE_SEED = 1001;
SHOW_PLOTS = true;              % display diagnostic figures in MATLAB
SAVE_PLOTS = true;              % PNG files in OUTPUT_ROOT
%% =======================================================================

assert(exist(DATA_ROOT,'dir') == 7, 'DATA_ROOT does not exist: %s', DATA_ROOT);
if ~exist(OUTPUT_ROOT,'dir'), mkdir(OUTPUT_ROOT); end
assert(MAX_COV_PIXELS>=2 && floor(MAX_COV_PIXELS)==MAX_COV_PIXELS, ...
    'MAX_COV_PIXELS must be an integer >=2');
assert(isfinite(NEAREST_SAD_THRESHOLD_DEG) && NEAREST_SAD_THRESHOLD_DEG>=0, ...
    'Invalid SAD threshold');

reportLines = cell(0,1);
reportLines = mv_log(reportLines,'MultiView reference/mix diagnostics | no training, no HySime estimation');
reportLines = mv_log(reportLines,sprintf('DATA_ROOT: %s',DATA_ROOT));
reportLines = mv_log(reportLines,sprintf('OUTPUT_ROOT: %s',OUTPUT_ROOT));
reportLines = mv_log(reportLines,sprintf( ...
    'Candidate criterion: nearest-other SAD > %.2f degrees (heuristic ONLY)', ...
    NEAREST_SAD_THRESHOLD_DEG));
reportLines = mv_log(reportLines,'References: Otsu-foreground means from same-view single-stain TIFF files');

for iv = 1:numel(VIEWS)
    view = VIEWS{iv};
    reportLines = mv_log(reportLines,sprintf('\n===== %s =====',view));

    try
        spectra = cell(1,numel(DYES));
        fgFraction = nan(1,numel(DYES));
        dtypeNames = cell(1,numel(DYES));
        fileNames = cell(1,numel(DYES));
        nChannels = nan(1,numel(DYES));
        heights = nan(1,numel(DYES));
        widths = nan(1,numel(DYES));

        % 1. Read every available single-stain TIFF for this view.
        for j=1:numel(DYES)
            path = mv_resolve_tif(DATA_ROOT,view,[DYES{j} '_' view '.tif']);
            if isempty(path), continue; end
            [spec,fgFrac,L,H,W,dt] = mv_single_stain_mean(path);
            spectra{j} = spec;
            fgFraction(j) = fgFrac;
            dtypeNames{j} = dt;
            fileNames{j} = path;
            nChannels(j) = L;
            heights(j) = H;
            widths(j) = W;
            fprintf('  [%s] reference %2d/%2d: %-8s  L=%d  fg=%.3f\n', ...
                view, j, numel(DYES), DYES{j}, L, fgFrac);
        end

        found = ~cellfun(@isempty,fileNames);
        missingDyes = DYES(~found);
        if ~any(found)
            reportLines = mv_log(reportLines, ...
                'NO REFERENCE TIFF FOUND (check DATA_ROOT and <view>/data/).');
            continue;
        end
        channelsFound = unique(nChannels(found));
        hwFound = unique([heights(found)' widths(found)'],'rows');
        dtypeFound = unique(dtypeNames(found));
        reportLines = mv_log(reportLines,sprintf( ...
            'References: %d/%d | channels=%s | dtypes=%s', ...
            nnz(found),numel(DYES),mat2str(channelsFound),strjoin(dtypeFound,', ')));
        reportLines = mv_log(reportLines,sprintf( ...
            'Reference spatial sizes [H W]: %s', mat2str(hwFound)));
        if isempty(missingDyes)
            reportLines = mv_log(reportLines,'Missing dyes: none');
        else
            reportLines = mv_log(reportLines,['Missing dyes: ' strjoin(missingDyes,', ')]);
        end
        if numel(channelsFound)~=1 || size(hwFound,1)~=1
            reportLines = mv_log(reportLines, ...
                'INCONSISTENT reference channels/spatial size: skipping this view.');
            continue;
        end

        names = DYES(found);
        columns = spectra(found);
        M = cat(2,columns{:});
        columnNorms = sqrt(sum(M.^2,1));
        good = columnNorms>1e-12 & all(isfinite(M),1);
        if any(~good)
            reportLines = mv_log(reportLines, ...
                ['Zero/invalid dye spectra: ' strjoin(names(~good),', ')]);
        end
        names = names(good);
        M = M(:,good);
        columnNorms = columnNorms(good);
        foundIds = find(found);
        foundIds = foundIds(good);
        if numel(names)<2
            reportLines = mv_log(reportLines, ...
                'Not enough valid reference spectra for pairwise SAD (need >=2).');
            continue;
        end
        L=size(M,1);

        % 2. Pairwise SAD, SVD and summary table.
        Mnorm = bsxfun(@rdivide,M,columnNorms);
        cosine = max(-1,min(1,Mnorm'*Mnorm));
        SAD = real(acosd(cosine));
        SAD(1:size(SAD,1)+1:end)=NaN;
        offdiag=SAD(~eye(size(SAD,1)));
        s=svd(Mnorm,'econ');
        energy=cumsum(s.^2)/sum(s.^2);
        ranks=arrayfun(@(t)find(energy>=t,1,'first'),[0.99,0.999,0.9999]);
        if s(end)>eps(max(s)),condnum=s(1)/s(end);else,condnum=Inf;end
        reportLines = mv_log(reportLines,sprintf( ...
            'Reference SAD: min=%.3f, median=%.3f, mean=%.3f deg', ...
            min(offdiag),median(offdiag),mean(offdiag)));
        reportLines = mv_log(reportLines,['Singular values: ' mat2str(s',6)]);
        reportLines = mv_log(reportLines,['Cumulative squared-SV energy: ' mat2str(energy',6)]);
        reportLines = mv_log(reportLines,sprintf( ...
            'Energy rank (NOT HySime): 99%%=%d; 99.9%%=%d; 99.99%%=%d | cond=%.5g', ...
            ranks(1),ranks(2),ranks(3),condnum));

        nearestSAD=zeros(numel(names),1);
        nearestName=cell(numel(names),1);
        peakCh=zeros(numel(names),1);
        peakMean=zeros(numel(names),1);
        totalMean=zeros(numel(names),1);
        fg=zeros(numel(names),1);
        dtype=cell(numel(names),1);
        sourcePath=cell(numel(names),1);
        for j=1:numel(names)
            sadRow=SAD(j,:);
            sadRow(j)=Inf; % explicitly exclude self-match / NaN
            [nearestSAD(j),ix]=min(sadRow);
            nearestName{j}=names{ix};
            [peakMean(j),peakCh(j)]=max(M(:,j));
            totalMean(j)=sum(M(:,j));
            fg(j)=fgFraction(foundIds(j));
            dtype{j}=dtypeNames{foundIds(j)};
            sourcePath{j}=fileNames{foundIds(j)};
            reportLines = mv_log(reportLines,sprintf( ...
                '  %-8s nearest=%6.2f deg (%-8s) | peak_ch=%2d peak=%9.3f total=%9.3f fg=%.4f', ...
                names{j},nearestSAD(j),nearestName{j},peakCh(j), ...
                peakMean(j),totalMean(j),fg(j)));
        end
        candidateNames=names(nearestSAD>NEAREST_SAD_THRESHOLD_DEG);
        reportLines = mv_log(reportLines,sprintf( ...
            'Heuristic separated candidates (%d/%d): %s', ...
            numel(candidateNames),numel(names),strjoin(candidateNames,', ')));

        % Matrix CSV with explicit row/column dye labels and NaN diagonal.
        sadCells=cell(numel(names)+1,numel(names)+1);
        sadCells(1,:)=[{'dye'} names];
        for j=1:numel(names)
            sadCells(j+1,1)=names(j);
            for k=1:numel(names)
                sadCells{j+1,k+1}=SAD(j,k);
            end
        end
        writecell(sadCells,fullfile(OUTPUT_ROOT,[view '_sad_matrix.csv']));
        writecell([{'dye','nearest_other_sad_deg','nearest_dye', ...
            'peak_ch_one_based','peak_mean','total_mean','fg_frac','dtype','file_path'}; ...
            [names(:),num2cell(nearestSAD),nearestName,num2cell(peakCh), ...
            num2cell(peakMean),num2cell(totalMean),num2cell(fg),dtype,sourcePath]], ...
            fullfile(OUTPUT_ROOT,[view '_summary.csv']));
        writecell([{'index','singular_value','cumulative_squared_energy'}; ...
            num2cell([(1:numel(s))',s,energy])], ...
            fullfile(OUTPUT_ROOT,[view '_singular_values.csv']));

        mv_plot_sad(SAD,names,view,OUTPUT_ROOT,SHOW_PLOTS,SAVE_PLOTS);
        mv_plot_singular(s,energy,view,OUTPUT_ROOT,SHOW_PLOTS,SAVE_PLOTS);

        % 3. Mixture covariance eigenvalues from brightest-quartile pixels.
        mixPath=mv_resolve_tif(DATA_ROOT,view,['mix_' view '.tif']);
        if isempty(mixPath)
            reportLines = mv_log(reportLines,'Mix file missing; reference results are still saved.');
            continue;
        end
        [eigvals,rawMedian,saturatedFraction,Lmix,Hmix,Wmix,mixDtype,nCov] = ...
            mv_mix_covariance(mixPath,MAX_COV_PIXELS,COV_SAMPLE_SEED);
        if Lmix~=L
            reportLines = mv_log(reportLines,sprintf( ...
                'WARNING: mix channels=%d but reference channels=%d (covariance still computed).',Lmix,L));
        end
        denom=sum(eigvals);
        if denom>0,fractions=eigvals/denom;else,fractions=zeros(size(eigvals));end
        reportLines = mv_log(reportLines,sprintf( ...
            'Mix: L=%d H=%d W=%d dtype=%s | top-quartile RAW INTENSITY median=%.4f', ...
            Lmix,Hmix,Wmix,mixDtype,rawMedian));
        if isnan(saturatedFraction)
            reportLines = mv_log(reportLines,'Mix: uint8 saturation fraction=NA (image not uint8)');
        else
            reportLines = mv_log(reportLines,sprintf( ...
                'Mix: fraction of pixels with ANY channel=255 is %.6f (%.3f%%)', ...
                saturatedFraction,saturatedFraction*100));
        end
        reportLines = mv_log(reportLines,sprintf( ...
            'Mix covariance eig fractions (n=%d): %s', ...
            nCov,mat2str(fractions(1:min(15,end))',5)));
        writecell([{'index','covariance_eigenvalue','fraction_of_trace'}; ...
            num2cell([(1:numel(eigvals))',eigvals,fractions])], ...
            fullfile(OUTPUT_ROOT,[view '_mix_eigenvalues.csv']));
        mv_plot_covariance(eigvals,view,OUTPUT_ROOT,SHOW_PLOTS,SAVE_PLOTS);
    catch ME
        reportLines=mv_log(reportLines,sprintf( ...
            'ERROR [%s]: %s',view,ME.message));
    end
    mv_write_report(fullfile(OUTPUT_ROOT,'mv_diag_report.txt'),reportLines);
end
mv_write_report(fullfile(OUTPUT_ROOT,'mv_diag_report.txt'),reportLines);
fprintf('\nDiagnostics finished. Report: %s\n',fullfile(OUTPUT_ROOT,'mv_diag_report.txt'));

%% ========================= LOCAL FUNCTIONS ==============================
function reportLines=mv_log(reportLines,message)
fprintf('%s\n',message);
reportLines{end+1,1}=message;
end

function mv_write_report(path,lines)
fid=fopen(path,'w','n','UTF-8');
assert(fid>0,'Cannot write report %s',path);
cleanup=onCleanup(@()fclose(fid)); %#ok<NASGU>
for k=1:numel(lines),fprintf(fid,'%s\n',lines{k});end
end

function path=mv_resolve_tif(root,view,fileName)
candidates={fullfile(root,view,'data',fileName), ...
            fullfile(root,view,fileName), ...
            fullfile(root,fileName), ...
            fullfile(root,'data',fileName)};
path='';
for k=1:numel(candidates)
    if exist(candidates{k},'file')==2
        path=candidates{k};return;
    end
end
end

function [info,L,H,W,isMulti] = mv_tif_layout(path)
info=imfinfo(path);
assert(~isempty(info),'TIFF has no pages: %s',path);
H=double(info(1).Height);W=double(info(1).Width);
isMulti=numel(info)>1;
if isMulti
    assert(all(double([info.Height])==H) && all(double([info.Width])==W), ...
        'Mixed TIFF page sizes: %s',path);
    if isfield(info,'SamplesPerPixel')
        assert(all(double([info.SamplesPerPixel])==1), ...
            'Multi-page TIFF with multichannel pages is ambiguous: %s',path);
    end
    L=numel(info);
else
    % A single IFD can contain a spectral channel dimension (H x W x L).
    if isfield(info,'SamplesPerPixel')
        L=double(info(1).SamplesPerPixel);
    else
        L=1;
    end
end
assert(L>=2,'TIFF lacks a supported spectral stack (L<2): %s',path);
end

function [spec,foregroundFraction,L,H,W,dtype] = mv_single_stain_mean(path)
[info,L,H,W,isMulti]=mv_tif_layout(path);
if isMulti
    img1=imread(path,1,'Info',info);
    dtype=class(img1);
    total=double(img1);
    for b=2:L
        img=imread(path,b,'Info',info);
        assert(isequal(size(img),[H W]),'Invalid TIFF page layout: %s',path);
        total=total+double(img);
    end
    mask=mv_otsu_mask(total);
    if ~any(mask(:)),mask=(total>0);end
    foregroundFraction=nnz(mask)/numel(mask);
    spec=zeros(L,1);
    if any(mask(:))
        spec(1)=mean(double(img1(mask)));
        for b=2:L
            img=imread(path,b,'Info',info);
            spec(b)=mean(double(img(mask)));
        end
    end
else
    img=imread(path);
    assert(ndims(img)==3 && size(img,3)==L, ...
        'Expected HxWxL single-directory TIFF: %s',path);
    dtype=class(img);
    total=zeros(H,W);
    for b=1:L,total=total+double(img(:,:,b));end
    mask=mv_otsu_mask(total);
    if ~any(mask(:)),mask=(total>0);end
    foregroundFraction=nnz(mask)/numel(mask);
    spec=zeros(L,1);
    if any(mask(:))
        for b=1:L
            band=img(:,:,b);
            spec(b)=mean(double(band(mask)));
        end
    end
end
end

function mask=mv_otsu_mask(data)
x=double(data(:));
lo=min(x);hi=max(x);
if hi<=lo
    mask=data>lo;return;
end
edges=linspace(lo,hi,257);
counts=double(histcounts(x,edges));
w=counts(:)/max(sum(counts),1);
mid=((edges(1:end-1)+edges(2:end))/2)';
acc=cumsum(w);
mu=cumsum(w.*mid);
muTotal=mu(end);
den=acc.*(1-acc);
score=zeros(size(acc));
valid=den>1e-12;
score(valid)=(muTotal*acc(valid)-mu(valid)).^2./den(valid);
[~,idx]=max(score);
mask=data>mid(idx);
end

function q=mv_quantile75(x)
% Same linear-interpolation convention as NumPy's default percentile.
sorted=sort(double(x(:)));
n=numel(sorted);
assert(n>0,'Empty quantile input');
pos=1+(n-1)*0.75;
lo=floor(pos);hi=ceil(pos);
q=sorted(lo)+(pos-lo)*(sorted(hi)-sorted(lo));
end

function [eigvals,rawMedian,satFraction,L,H,W,dtype,nCov] = ...
    mv_mix_covariance(path,maxPixels,seed)
[info,L,H,W,isMulti]=mv_tif_layout(path);
N=H*W;
saturated=false(H,W);
if isMulti
    band1=imread(path,1,'Info',info);
    dtype=class(band1);
    total=double(band1);
    if isa(band1,'uint8'),saturated=saturated|(band1==255);end
    for b=2:L
        band=imread(path,b,'Info',info);
        total=total+double(band);
        if isa(band,'uint8'),saturated=saturated|(band==255);end
    end
else
    cube=imread(path);
    assert(ndims(cube)==3 && size(cube,3)==L, ...
        'Invalid single-page multichannel TIFF: %s',path);
    dtype=class(cube);
    total=zeros(H,W);
    for b=1:L
        band=cube(:,:,b);
        total=total+double(band);
        if isa(band,'uint8'),saturated=saturated|(band==255);end
    end
end
if strcmp(dtype,'uint8')
    satFraction=nnz(saturated)/N;
else
    satFraction=NaN;
end
q75=mv_quantile75(total);
idx=find(total>q75);
if isempty(idx)
    error('Mix has no pixels above the 75th intensity percentile: %s',path);
end
rawMedian=median(total(idx));
if numel(idx)>maxPixels
    oldRng=rng;
    guard=onCleanup(@()rng(oldRng)); %#ok<NASGU>
    rng(seed,'twister');
    idx=idx(randperm(numel(idx),maxPixels));
end
nCov=numel(idx);
Y=zeros(L,nCov);
if isMulti
    for b=1:L
        band=imread(path,b,'Info',info);
        Y(b,:)=double(band(idx));
    end
else
    for b=1:L
        band=cube(:,:,b);
        Y(b,:)=double(band(idx));
    end
end
Y=Y-mean(Y,2);
C=(Y*Y')/max(nCov-1,1);
C=(C+C')/2;
eigvals=sort(real(eig(C)),'descend');
% Nonnegative numerical cleanup for nominal covariance eigenvalues.
eigvals=max(eigvals,0);
end

function mv_plot_sad(SAD,names,view,out,showPlot,savePlot)
if ~showPlot && ~savePlot,return;end
visible='off';if showPlot,visible='on';end
fig=figure('Visible',visible,'Color','k','Position',[100,100,900,740]);
ax=axes('Parent',fig,'Color','k');
im=imagesc(ax,SAD);
set(im,'AlphaData',double(isfinite(SAD)));
colormap(ax,parula(256));
c=colorbar(ax);c.Color='w';
set(ax,'XTick',1:numel(names),'XTickLabel',names, ...
       'YTick',1:numel(names),'YTickLabel',names, ...
       'XTickLabelRotation',45,'XColor','w','YColor','w');
axis(ax,'image');
title(ax,[view ': pairwise reference SAD (degrees)'],'Color','w','Interpreter','none');
if savePlot,exportgraphics(fig,fullfile(out,[view '_sad_heatmap.png']),'Resolution',160);end
if ~showPlot,close(fig);end
end

function mv_plot_singular(s,energy,view,out,showPlot,savePlot)
if ~showPlot && ~savePlot,return;end
visible='off';if showPlot,visible='on';end
fig=figure('Visible',visible,'Color','k','Position',[160,160,1100,440]);
t=tiledlayout(fig,1,2,'TileSpacing','compact','Padding','compact');
ax1=nexttile(t);semilogy(ax1,1:numel(s),max(s,eps),'o-','LineWidth',1.3);
set(ax1,'Color','k','XColor','w','YColor','w');
grid(ax1,'on');xlabel(ax1,'Singular-value index');ylabel(ax1,'Singular value (log scale)');
title(ax1,'L2-normalized reference spectra','Color','w');
ax2=nexttile(t);plot(ax2,1:numel(energy),100*energy,'o-','LineWidth',1.3);
hold(ax2,'on');yline(ax2,99,'--');yline(ax2,99.9,'--');
set(ax2,'Color','k','XColor','w','YColor','w');
grid(ax2,'on');xlabel(ax2,'Rank');ylabel(ax2,'Cumulative squared-SV energy (%)');
title(ax2,'Reference energy (NOT HySime)','Color','w');
if savePlot,exportgraphics(fig,fullfile(out,[view '_singular_values.png']),'Resolution',160);end
if ~showPlot,close(fig);end
end

function mv_plot_covariance(eigvals,view,out,showPlot,savePlot)
if ~showPlot && ~savePlot,return;end
visible='off';if showPlot,visible='on';end
fig=figure('Visible',visible,'Color','k','Position',[200,200,850,490]);
ax=axes('Parent',fig,'Color','k');
semilogy(ax,1:numel(eigvals),max(eigvals,eps),'o-','LineWidth',1.3);
set(ax,'XColor','w','YColor','w');grid(ax,'on');
xlabel(ax,'Eigenvalue index');ylabel(ax,'Mixture covariance eigenvalue (log scale)');
title(ax,[view ': top-quartile mix covariance (NOT HySime)'],'Color','w','Interpreter','none');
if savePlot,exportgraphics(fig,fullfile(out,[view '_mix_eigenvalues.png']),'Resolution',160);end
if ~showPlot,close(fig);end
end
