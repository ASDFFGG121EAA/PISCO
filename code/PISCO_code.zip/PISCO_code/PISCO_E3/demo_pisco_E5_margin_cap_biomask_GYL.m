%% demo_pisco_E5_margin_cap_biomask_GYL.m
% E-5: final Poisson propagated-sigma cap-saturation statistics.
% Base: demo_pisco_E3_ablation_b1_biomask_GYL (2026-11-13).
% Runs ONLY the full PISCO configuration (no other ablations).
% At convergence, the minimally instrumented E-5 trainer returns scalar
% cap diagnostics; all large training internals remain in memory and are NOT saved.
%
% Output: ONE CSV inside its own E5_margin_cap_results folder.
% Resumable by successful run, with no MAT, plots, or training logs.
%
% Protocol differences to notice:
%  - Paper-size 512x512 (the supplied E3 driver's live SIZE is 128 despite
%    its 512x512 comment); QUICK=true selects a separate 128x128 pilot.
%  - SIGMA_CAP=0.03 explicitly (the supplied b1_15 trainer defaults to 0.15).
%  - Same E3 full model settings: 10 photons/channel, read noise 1, 30 repeats,
%    MM_ITERS=2500, WARM_UP=600, spatial=0.5, explicit abundance, eta=0.3.
%  - BASE_SEED=42 and the exact E3 scene/noise/training seed offsets.
%  - ROI mask is UNION of binary biological instance masks before smoothing;
%    full-field cap rates are also recorded. Mask is for audit only, NOT train.
%
% Requires: pisco_e3_train_b1_15_E5.m, VCA.m,
%   build_Strue_from_masks.m, PISCO_M_32x4_HyU_strict_quasar32.mat,
%   ./use/<scene>/masks/*.png, and poissrnd (Statistics Toolbox).
% MATLAB R2023a or later. Script, not a function.
clear; close all; clc;

%% --------------------- Settings -------------------------------
QUICK = false;             % true: 2-run 128x128 test, saved separately
N_RUNS = 30;
BASE_SEED = 42;            % identical to supplied E3 driver
SIZE = 128;               % v79 formal scene: 512x512
PHOTONS = 10;             % photons per spectral channel
READ_SIG = 1.0;
MM_ITERS = 2500;
WARM_UP = 600;
SIGMA_CAP = 0.15;         % explicitly override trainer default 0.15
ETA = 0.3;
FAIL_SAD = 20;
MASK_SIGMA = 2.0;
MASK_BACKGROUND = 0.02;
MAX_PURITY = 0.8;
RECON_CHUNK = 50000;      % final E5 statistics memory bound
RESUME_EXISTING = true;

if QUICK
    N_RUNS = 2;
    SIZE = 128;
    MM_ITERS = 800;
    WARM_UP = 200;
    OUT_DIR_NAME = 'E5_margin_cap_quick_results';
else
    OUT_DIR_NAME = 'E5_margin_cap_results';
end

THIS_SCRIPT = mfilename('fullpath');
SCRIPT_DIR = fileparts(THIS_SCRIPT);
if isempty(SCRIPT_DIR), SCRIPT_DIR = pwd; end
addpath(SCRIPT_DIR);  % locate the E-5 trainer and mask builder beside this script
M_FILE = fullfile(SCRIPT_DIR,'PISCO_M_32x4_HyU_strict_quasar32.mat');
MASK_ROOT = fullfile(SCRIPT_DIR,'use');
OUT_DIR = fullfile(SCRIPT_DIR,OUT_DIR_NAME);
OUT_CSV = fullfile(OUT_DIR,'pisco_E5_margin_cap_results.csv');
TRAINER = 'pisco_e3_train_b1_15_E5';

assert(exist(TRAINER,'file')==2,'E5:Trainer', ...
    'Cannot find %s.m on MATLAB path.', TRAINER);
assert(exist('build_Strue_from_masks','file')==2,'E5:MaskBuilder', ...
    'Missing build_Strue_from_masks.m.');
assert(exist('poissrnd','file')==2,'E5:StatisticsToolbox', ...
    'This driver requires poissrnd (Statistics and Machine Learning Toolbox).');
assert(isfile(M_FILE),'E5:MissingSpectra','Missing file: %s',M_FILE);
assert(isfolder(MASK_ROOT),'E5:MissingMasks','Missing biological-mask root: %s',MASK_ROOT);
assert(SIGMA_CAP > 0 && isfinite(SIGMA_CAP),'E5:Cap','Invalid SIGMA_CAP.');
if ~isfolder(OUT_DIR)
    [ok,msg] = mkdir(OUT_DIR);
    assert(ok,'E5:OutputDir','Cannot create output folder: %s',msg);
end

%% ------------------- Real endmembers & scene pool ------------------------
Dspec = load(M_FILE,'M');
assert(isfield(Dspec,'M'),'E5:Spectra','MAT must contain M.');
M_true = double(Dspec.M);
[L,p] = size(M_true);
assert(L==32 && p==4 && all(isfinite(M_true(:))) && all(M_true(:)>=0), ...
    'E5:Endmembers','M must be finite nonnegative 32x4.');
clear Dspec;

Dscene = dir(MASK_ROOT);
Dscene = Dscene([Dscene.isdir]);
Dscene = Dscene(~ismember({Dscene.name},{'.','..'}));
scene_dirs = {};
for i = 1:numel(Dscene)
    candidate = fullfile(MASK_ROOT,Dscene(i).name);
    if isfolder(fullfile(candidate,'masks')) && ...
            ~isempty(dir(fullfile(candidate,'masks','*.png')))
        scene_dirs{end+1} = candidate; %#ok<SAGROW>
    end
end
assert(~isempty(scene_dirs),'E5:NoScenes','No ./use/<scene>/masks/*.png found.');
[~,ord_scene] = sort(lower(string(scene_dirs)));
scene_dirs = scene_dirs(ord_scene);
nScenes = numel(scene_dirs);
N = SIZE*SIZE;

% Include all relevant paper/protocol settings for safe resumption.
PROTOCOL_ID = sprintf('E5_v79_H%d_ph%g_cap%.6g_eta%.6g_it%d_w%d_seed%d', ...
    SIZE,PHOTONS,SIGMA_CAP,ETA,MM_ITERS,WARM_UP,BASE_SEED);
header = ['protocol,run,scene,seed_abundance,seed_noise,seed_train,' ...
    'height,width,photons_per_channel,sigma_cap,eta_final,' ...
    'roi_mask_pixels,roi_cap_pixels,roi_cap_pixel_fraction,roi_cap_entry_fraction,' ...
    'cap_component_01_fraction,cap_component_02_fraction,' ...
    'cap_component_03_fraction,cap_component_04_fraction,' ...
    'full_cap_pixel_fraction,full_cap_entry_fraction,' ...
    'SAD_deg,MSE_ab,MSE_rec,viol_anc,viol_asc,fail,time_s'];

%% ------------------------- Resume check ----------------------------
completed = false(N_RUNS,1);
if isfile(OUT_CSV) && RESUME_EXISTING
    Tprev = readtable(OUT_CSV,'TextType','string');
    expected_cols = strsplit(header,',');
    assert(isequal(Tprev.Properties.VariableNames,expected_cols), ...
        'E5:CSVSchema','Existing CSV header differs. Move old CSV before rerunning.');
    assert(all(Tprev.protocol == string(PROTOCOL_ID)), ...
        'E5:ProtocolMismatch','Existing CSV uses a different E5 protocol.');
    assert(all(isfinite(Tprev.run)) && all(Tprev.run==round(Tprev.run)) && ...
        all(Tprev.run>=1) && all(Tprev.run<=N_RUNS) && ...
        numel(unique(Tprev.run))==height(Tprev), ...
        'E5:BadResume','Invalid or duplicate run IDs in CSV.');
    assert(all(Tprev.height==SIZE) && all(Tprev.width==SIZE) && ...
        all(Tprev.photons_per_channel==PHOTONS) && ...
        all(Tprev.sigma_cap==SIGMA_CAP), ...
        'E5:ResumeConfig','CSV configuration does not match current settings.');
    completed(Tprev.run) = true;
elseif isfile(OUT_CSV) && ~RESUME_EXISTING
    error('E5:NoOverwrite','CSV exists. Set RESUME_EXISTING=true or move it.');
else
    fid = fopen(OUT_CSV,'w');
    assert(fid>0,'E5:CSVCreate','Cannot open CSV: %s',OUT_CSV);
    fprintf(fid,'%s\n',header);
    fclose(fid);
end

fprintf('E5 cap audit | %d runs, %dx%d, %g photons/channel, cap %.4g, eta %.2f\n', ...
    N_RUNS,SIZE,SIZE,PHOTONS,SIGMA_CAP,ETA);
fprintf('Scenes: %d | completed: %d/%d | one CSV: %s\n', ...
    nScenes,nnz(completed),N_RUNS,OUT_CSV);

%% ------------------- 30 full-model simulations --------------------
for r = 1:N_RUNS
    if completed(r)
        fprintf('Skipping completed run %d/%d.\n',r,N_RUNS);
        continue;
    end
    scene_idx = 1 + mod(r-1,nScenes);  % exact supplied E3 cycling
    scene_dir = scene_dirs{scene_idx};
    [~,scene_name] = fileparts(scene_dir);
    scene_name = strrep(scene_name,',','_');

    seed_abundance = BASE_SEED + r;
    seed_noise = BASE_SEED + 10000 + r;
    seed_train = BASE_SEED + 100000 + r;

    % Exact E3 source generation and noise convention.
    S_true = build_Strue_from_masks(scene_dir,SIZE,SIZE,p,MAX_PURITY, ...
        seed_abundance,MASK_SIGMA,MASK_BACKGROUND);
    Y_clean = M_true*S_true;
    rng(seed_noise,'twister');
    g = PHOTONS * N / sum(Y_clean(:)) * L;
    Y_in = double(poissrnd(g*Y_clean) + READ_SIG*randn(L,N)) / g;

    % Strict binary union of the instance masks (analysis only).
    roi_support = e5_load_union_instance_masks(scene_dir,SIZE,SIZE);
    n_roi = nnz(roi_support);
    assert(n_roi>0,'E5:NoSupport','Empty biological ROI in %s.',scene_name);

    % Exactly the existing E3 full arm, except explicit SIGMA_CAP=0.03
    % and E5 diagnostic arguments. Loss, gradients, optimizer unchanged.
    args = {'spherize','yes','verbose',0, ...
        'MM_ITERS',MM_ITERS,'WARM_UP',WARM_UP,'LR',3e-4, ...
        'LAMBDA_VOL',0.008,'LAMBDA_NONNEG',3,'LAMBDA_EQ',100, ...
        'LAMBDA_SUMONE',2,'LAMBDA_ENCLOSE',10, ...
        'IMG_H',SIZE,'IMG_W',SIZE,'LAMBDA_SPATIAL',0.5, ...
        'NOISE_MODEL','poisson','NOISE_WEIGHT','uniform', ...
        'ETA',ETA,'ETA_END',ETA, ...
        'PHOTON_GAIN',g,'PHOTON_FLOOR',1,'READ_SIGMA',READ_SIG, ...
        'ABUNDANCE_MODE','explicit','GATED',true, ...
        'QPARAM','coupled','COORDS','2d', ...
        'SIGMA_CAP',SIGMA_CAP, ...
        'E5_CAP_AUDIT',true, ...
        'E5_MASK',roi_support(:).', ...
        'E5_BLOCK_PIXELS',RECON_CHUNK};

    rng(seed_train,'twister');
    fprintf('Training E5 run %d/%d (%s) ...\n',r,N_RUNS,scene_name);
    tic_run = tic;
    [M_est,S_est,~,~,~,audit] = feval(TRAINER,Y_in,p,args{:});
    time_s = toc(tic_run);

    assert(isstruct(audit) && isfield(audit,'enabled') && audit.enabled && ...
        isfinite(audit.cap_pixel_fraction) && isfinite(audit.cap_entry_fraction) && ...
        audit.mask_pixels==n_roi && audit.total_pixels==N && ...
        numel(audit.cap_component_fraction)==p, ...
        'E5:Audit','Trainer did not return expected E-5 audit fields.');
    assert(audit.cap_pixel_fraction>=0 && audit.cap_pixel_fraction<=1 && ...
        audit.cap_entry_fraction>=0 && audit.cap_entry_fraction<=1 && ...
        audit.cap_pixel_fraction+1e-12>=audit.cap_entry_fraction, ...
        'E5:AuditBounds','Invalid cap fractions.');

    % Retain basic E3 quality metrics to diagnose cap-vs-accuracy.
    [perm,sad_v] = e5_match_greedy_sad(M_true,double(M_est));
    SAD_deg = mean(sad_v);
    S_match = S_est(perm,:);
    MSE_ab = mean((S_true(:)-S_match(:)).^2);
    pred = M_est*S_est;
    MSE_rec = mean((Y_clean(:)-pred(:)).^2);
    viol_anc = mean(min(S_est,[],1)<-1e-4);
    viol_asc = mean(abs(sum(S_est,1)-1)>1e-3);
    fail = double(SAD_deg>FAIL_SAD);

    % Append exactly one row after a successful run (resumable).
    fid = fopen(OUT_CSV,'a');
    assert(fid>0,'E5:CSVAppend','Cannot append output CSV.');
    fmt = ['%s,%d,%s,%d,%d,%d,%d,%d,%.10g,%.10g,%.10g,' ...
        '%d,%d,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,' ...
        '%.12g,%.12g,%.10g,%.12g,%.12g,%.12g,%.12g,%d,%.4f\n'];
    fprintf(fid,fmt,PROTOCOL_ID,r,scene_name,seed_abundance,seed_noise, ...
        seed_train,SIZE,SIZE,PHOTONS,SIGMA_CAP,audit.eta_final, ...
        audit.mask_pixels,audit.cap_pixel_count, ...
        audit.cap_pixel_fraction,audit.cap_entry_fraction, ...
        audit.cap_component_fraction(1),audit.cap_component_fraction(2), ...
        audit.cap_component_fraction(3),audit.cap_component_fraction(4), ...
        audit.full_pixel_fraction,audit.full_entry_fraction, ...
        SAD_deg,MSE_ab,MSE_rec,viol_anc,viol_asc,fail,time_s);
    fclose(fid);
    completed(r)=true;
    fprintf('run %02d/%02d | ROI cap pixels %.2f%% | entries %.2f%% | SAD %.3f | time %.1fs\n', ...
        r,N_RUNS,100*audit.cap_pixel_fraction, ...
        100*audit.cap_entry_fraction,SAD_deg,time_s);
    clear S_true Y_clean Y_in roi_support M_est S_est pred S_match audit;
end

%% ------------------ Summary from the ONE CSV --------------------------
T = readtable(OUT_CSV,'TextType','string');
assert(height(T)==N_RUNS,'E5:Incomplete','Only %d/%d runs completed.',height(T),N_RUNS);
v = T.roi_cap_pixel_fraction;
e = T.roi_cap_entry_fraction;
fprintf('\nE5 COMPLETED (%d runs).\n',height(T));
fprintf('ROI pixel cap ratio: median %.4f%%, mean %.4f%%, SD %.4f%%, range [%.4f%%, %.4f%%]\n', ...
    100*median(v),100*mean(v),100*std(v),100*min(v),100*max(v));
fprintf('ROI pixel-endmember cap ratio: median %.4f%%, range [%.4f%%, %.4f%%]\n', ...
    100*median(e),100*min(e),100*max(e));
fprintf('CSV: %s\n',OUT_CSV);

%% ------------------------- Local functions ----------------------------
function support = e5_load_union_instance_masks(scene_dir,H,W)
% Binary union of exactly the same instance-mask files used by
% build_Strue_from_masks BEFORE smoothing/background normalization.
    mask_dir=fullfile(scene_dir,'masks');
    files=dir(fullfile(mask_dir,'*.png'));
    assert(~isempty(files),'E5:MaskFiles','No masks/*.png in %s.',scene_dir);
    support=false(H,W);
    for k=1:numel(files)
        A=imread(fullfile(files(k).folder,files(k).name));
        if ndims(A)==3
            M=any(A>0,3);
        else
            M=A>0;
        end
        [h0,w0]=size(M);
        if h0==H && w0==W
            Mr=logical(M);
        else
            xq=linspace(1,w0,W);
            yq=linspace(1,h0,H)';
            [Xq,Yq]=meshgrid(xq,yq);
            Mr=interp2(1:w0,(1:h0)',double(M),Xq,Yq,'nearest',0)>0.5;
        end
        support=support|Mr;
    end
end

function [perm,sad_v]=e5_match_greedy_sad(M_true,M_est)
% Preserve E3 driver's greedy SAD matching exactly.
    p=size(M_true,2);
    Cmat=zeros(p);
    for i=1:p
        for j=1:p
            cosv=(M_true(:,i)'*M_est(:,j))/(norm(M_true(:,i))*norm(M_est(:,j)));
            Cmat(i,j)=acosd(max(-1,min(1,cosv)));
        end
    end
    perm=zeros(1,p);taken=false(1,p);
    for i=1:p
        [~,jj]=min(Cmat(i,:)+taken*1e6);
        perm(i)=jj;taken(jj)=true;
    end
    sad_v=Cmat(sub2ind([p p],1:p,perm));
end
