function [M_est, Sest, Up, my, theta] = pisco_e3_train_E2(Y, p, varargin)
% E3a strengthened spatial prior (experimental candidate):
% Multi-offset observed-spectrum edges, bounded gradient balancing for
% BOTH implicit S-Net and explicit p-by-N abundances; all are completely
% disabled when LAMBDA_SPATIAL==0. Switch both SPATIAL_MS_ENABLE and
% SPATIAL_GRAD_BALANCE off to recover the original b1_14 spatial term.
% Do not infer improvements from code alone: validate paired SAD/MSE/residual.
% E3d Warm-up behavior imported from pisco_e3_train_b1_9:
% Freeze Q and gate during warm-up, separate Adam clocks and joint-release ramps.
% Existing E3a spatial and E3b noise implementations from b1_13 are retained.
% Drop-in upgrade of the user's b1_6 / spatial_v2 trainer. 
% Default SPATIAL_GUIDE_MODE='noise_adaptive': no demo edits required.
% Old modes remain available if explicitly requested: 'spectral', 'uniform'.
% Setting LAMBDA_SPATIAL=0 still disables the guide and spatial regularization.
% Experimental pilot; performance improvement is not guaranteed.
% Candidate noise-adaptive E3a spatial regularization. Experimental only.
% Mode NOISE_ADAPTIVE builds weights from observed Poisson+readout noise only.
% Keeps the same Charbonnier spatial penalty and analytical gradient.
% NO M_true/S_true/Y_clean are accessed. Not a benchmarked final model.
% Based on user's spatial-v2 trainer.
% Spatial-v2 candidate: edge-aware, late-annealed spatial regularization.
% Does NOT use S_true, M_true or other ground-truth information.
% Original mode: SPATIAL_SCHEDULE='constant' with original guidance settings.
% New mode: SPATIAL_SCHEDULE='decay' + tuned observed-spectra guide settings.
% Ablation: LAMBDA_SPATIAL=0 disables BOTH the guide and the spatial loss.
%% PISCO-E3-Train: ablation-switchable copy of deep_mvsa_invflow_poisson.m
%  (Invertible Coupled Q + Nonlinear Attention + Spatial Smoothness
%  + POISSON CHANCE CONSTRAINTS)
%
% v1.4-E3: spectrally guided Robust Spatial (SGRS).
%   Build fixed 4-neighbour edge weights from ONLY the observed L-channel Y,
%   using a small Gaussian spatial denoising filter and spectral differences.
%   Adjacent pixels with similar denoised spectra receive stronger spatial
%   smoothing, while likely biological region boundaries receive less.
%   The same weights multiply BOTH the Charbonnier-like spatial loss and its
%   exact abundance gradient. No GT abundance or clean data are accessed.
%   Default parameters: SPATIAL_DELTA=0.08, SPATIAL_GUIDE_SIGMA=1,
%   SPATIAL_GUIDE_TAU=2, SPATIAL_GUIDE_MIN_WEIGHT=0.05,
%   SPATIAL_GUIDE_NORMALIZE=true.
%   LAMBDA_SPATIAL=0 fully disables BOTH the guidance computation and loss.
%   SPATIAL_GUIDE_MODE='uniform' recovers the unweighted v1.3 robust penalty.
% v1.3-E3: replace quadratic spatial Laplacian with smooth edge-preserving
%   Charbonnier-like group penalty on 4-neighbour abundance differences.
%   SPATIAL_DELTA (>0; default 0.08) controls the edge-preserving transition.
%   The spatial term and its exact analytical gradient have both been changed;
%   LAMBDA_SPATIAL=0 still disables the term completely. Other terms unchanged.
% Legacy E3b Gaussian/LS variant (ported from pisco_e3_train.m):
%   No covariance estimation and zero chance margin (hard enclosure).
%   This replaces the fixed-covariance Gaussian chance-margin code that
%   appeared in the original b1_7. Poisson codepaths are unchanged.
% v1.1-E3-v13 (2026-10-08): adds ABUNDANCE_MODE for v13 E3c.
%   'implicit' preserves the original coordinate A-Net/S-Net; 'explicit'
%   directly optimizes a p x N abundance matrix under the same losses.
% v1.0-E3 (2026-09-22): derived from deep_mvsa_invflow_poisson.m v0.9
%   for experiment E3 (ablation suite, design doc v5). Three ADDITIVE
%   switches; all defaults reproduce v0.9 behaviour EXACTLY:
%     ABUNDANCE_MODE (default 'implicit'): 'explicit' -> optimize a free
%             p x N abundance matrix directly instead of the coordinate A-Net/S-Net
%             (v13 E3c: implicit vs explicit abundance representation).
%     GATED  (default true) : false -> c = 0 always (gate branch inert),
%             ablation "− gated nonlinearity" (v13 E3i). Implemented by
%             forcing the abundance net into its linear (warm-up) mode
%             in every phase; grad.c/gate grads are zeroed by the
%             existing warm_up branch of the backward pass.
%     COORDS (default '2d') : '1d' -> A-Net input is the 1-D pixel index
%             instead of (gx, gy), ablation "− 2D coordinates" (E3h).
%             The spatial Laplacian term is UNAFFECTED (H_img/W_img are
%             kept), isolating the coordinate input itself.
%     QPARAM (default 'coupled') : 'free' -> Q = Q0 + Delta with a free
%             p x p Delta (no triangular coupling, no invertibility
%             guarantee), ablation "− invertible parameterization
%             (direct/free transform)" (E3g). The volume term becomes
%             -log|det Q| with gradient -inv(Q)'; all other terms are
%             unchanged. theta.Delta replaces theta.L/R/r_log.
%   Ablation "− warm-up" (E3d) needs no switch: WARM_UP = 0.
%   E3a: LAMBDA_SPATIAL = 0.  v13 E3f is controlled by
%   LAMBDA_NONNEG = 0 or LAMBDA_ENCLOSE = 0 in the demo.
%   Ablation "Gaussian margins" (E3b): NOISE_MODEL = 'gaussian'.
%   LEGACY GAUSSIAN/LS VARIANT (from pisco_e3_train.m): uniform ordinary
%   least-squares reconstruction and ZERO chance margin (hard enclosure).
%   This is not a fixed-covariance Gaussian chance-margin baseline.
%   Ablation "no margin annealing" (E3e): ETA_END = ETA (0.1).
%% (original v0.9 header below)
% DeepMVSA-InvFlow-Poisson: Invertible Coupled Q + Nonlinear Attention
%  + Spatial Smoothness + POISSON CHANCE CONSTRAINTS
%
% Q = L * Q0 * R, L: unit lower-tri, R: upper-tri with positive diagonal.
% A_eff = A_base + c * G .* (A_base.^2)
%
% NEW relative to deep_mvsa_invflow.m (Gaussian version):
%   NOISE_MODEL  : 'gaussian' (default, identical to original) or 'poisson'.
%   Under 'poisson', the noise variance is intensity-dependent. Y may be in
%   any intensity unit; PHOTON_GAIN converts it to counts:
%       counts = Y * PHOTON_GAIN,  Var_counts = counts
%       => Var(Y) = max(Y, PHOTON_FLOOR/PHOTON_GAIN) / PHOTON_GAIN
%   Propagated to the working space (B = whitening/projection operator):
%       Vpix      = (B.^2) * Var(Y)                p x N, per-pixel noise var
%       sigma2_ij = (Q.^2) * Vpix                  q_i' Cov_j q_i,  p x N
%   and the chance-constraint margin becomes pixel-adaptive:
%       margin_ij = Phi^{-1}(ETA) * min(sqrt(sigma2_ij), SIGMA_CAP)  <= 0
%   (stop-gradient).  Two terms change:
%     (1) reconstruction  -> heteroscedastic GLS:  diff^2 ./ Vpix, with the
%         weights normalized to mean 1 so the global loss balance (and all
%         lambda settings) matches the Gaussian model;
%     (2) enclosure       -> min(Q*Y - margin, 0)^2  (RMVSA-style noise-
%         tolerant data enclosure: noisy pixels may poke outside the
%         simplex, bright pixels may not).
%   NON-NEGATIVITY of the abundances stays STRICT (min(A_eff,0)^2):
%   abundances are truly non-negative, so relaxing this constraint by a
%   noise margin only injects bias -- the Poisson tolerance belongs to the
%   data terms, not to the abundance prior.
%   sigma2 is recomputed every iteration from the current Q and treated as
%   constant in the gradient (EM-style), so all gradients remain closed form.
%   ETA          : chance-constraint level (default 0.1; 0.5 = hard MVSA).
%   SIGMA_CAP    : cap on the per-pixel margin scale (default 0.1, in
%                  spherized working units). Prevents nearly-constraint-free
%                  behaviour at very low photon counts.
%   PHOTON_GAIN  : counts per unit of Y (default 1, i.e. Y is counts).
%                  Set it so both models can be compared on the SAME input
%                  scaling (see demo_pisco_vs_deeprmvsa.m).
%   PHOTON_FLOOR : variance floor in photon counts (default 1).
%
% v0.9 (2026-09-22):
%   - SPECTRAL SMOOTHNESS PRIOR (LAMBDA_SMOOTH, default 0.1; 0 = off):
%     2nd-difference Tikhonov penalty on the BAND-SPACE endmembers,
%     LAMBDA_SMOOTH*sum((M_band(3:end,:)-2*M_band(2:end-1,:)+M_band(1:end-2,:)).^2),
%     gradient chained through M = inv(Q) like LAMBDA_MNONNEG. Fluorescence
%     emission spectra are smooth on the ~9 nm channel grid, so this
%     suppresses the spurious narrow peaks/dips that shot noise imprints
%     on the recovered spectra without shifting the true (broad) peaks.
%     Also added to deep_mvsa_invflow.m (fair comparison).
%
% v0.8 (2026-09-21):
%   - MARGIN ANNEALING (ETA_END, default 0.5): the chance level eta is
%     linearly annealed from ETA to ETA_END over the joint phase, so the
%     enclosure margin Phi^{-1}(eta_t)*min(sigma,sigma_cap) decays to zero
%     at convergence. Rationale: in the capped regime the margin is a
%     CONSTANT inward relaxation of the enclosure (verified: sigma > cap
%     for 100% of pixels at all photon levels), which the volume term
%     exploits to pull the simplex inside the data cloud -- a systematic
%     bias that dominates once shot noise becomes small (high photon
%     budgets). Annealing removes the bias asymptotically while retaining
%     the noise tolerance during the critical simplex-formation phase.
%     Monte-Carlo verification (v0.9, self-contained Python package, 6
%     paired repeats, 96x96, real FP spectra): at 100 photons the annealed
%     margin beats the FIXED margin in 6/6 paired draws (mean SAD 7.25 vs
%     7.94 deg) and beats the Gaussian backbone in 6/6 paired draws (7.25
%     vs 7.71 deg, sign test p~0.03); neutral at 5-20 photons.
%     Set ETA_END = ETA to reproduce v0.7 behaviour.
%   - ENDMEMBER NON-NEGATIVITY (LAMBDA_MNONNEG, default 10): fluorescence
%     emission spectra are physically non-negative. Soft penalty
%     LAMBDA_MNONNEG*sum(min(M_band,0).^2) inside the objective (gradient
%     chained through M = inv(Q)), plus a final projection
%     M_est = max(M_est,0) on the returned endmembers. At 5 photons the
%     projection alone recovers ~2 deg SAD in bad-noise draws.
%   - Both mechanisms also added to deep_mvsa_invflow.m (fair comparison).
%
% v0.7 (2026-09-21):
%   - READ_SIGMA (default 0): Gaussian read-out noise in photon-count units,
%     added to the variance model Var(Y) = max(Y, floor/gain)/gain +
%     (READ_SIGMA/gain)^2, so the Poisson chance constraints remain
%     calibrated under the mixed Poisson + read-out noise of real detectors
%     (sCMOS/PMT analogue mode). Also honoured by NOISE_WEIGHT 'irls'.
%
% v0.6 (2026-09-21):
%   - SPATIAL TERM NORMALIZATION FIX (both algorithm files): the Laplacian
%     penalty was a SUM over ~2N neighbour pairs while reconstruction is a
%     MEAN, so the effective smoothing grew with N and compressed the
%     abundance range towards 1/p with over-smoothed maps. The penalty and
%     its gradient are now divided by N; use LAMBDA_SPATIAL ~ 20.
%   - NOISE_WEIGHT (default 'uniform'): after signal-covariance whitening,
%     the working-space noise is only weakly heteroscedastic, and uniform
%     weighting keeps the min-volume geometry anchored by all pixels; the
%     Poisson adaptation is carried by the (capped) enclosure margins.
%     'pearson' = v0.5 plug-in GLS; 'irls' = GLS with variances recomputed
%     from the current reconstruction every iteration (stop-grad), which
%     removes the Pearson plug-in noise feedback. Use 'pearson'/'irls' for
%     data with a large intensity dynamic range.
%   - SIGMA_CAP default tightened 0.1 -> 0.03: with a soft quadratic
%     enclosure penalty, noise excursions are already tolerated smoothly;
%     a wide extra margin double-counts the tolerance and lets the volume
%     term pull the simplex inside the data cloud (SAD degrades ~2 deg).
%   Verified (Python replica of the full pipeline, paired noise draws):
%   uniform+cap0.03 ties Deep RMVSA within ~0.1-0.8 deg SAD at matched MSE,
%   while every wider-margin or plug-in-weight variant trails by 1-2 deg.
%
% v0.5 (2026-09-21):
%   - FIX (critical): the affine working dimension carries no shot noise
%     (B(p,:) = 0), so Vpix(p,:) was exactly zero and its GLS weight
%     1/(0+eps) ~ 1e12 dominated the entire objective -- the network only
%     learned to fit the constant dimension, producing near-uniform
%     abundance maps with high-frequency stripe artifacts and oscillating
%     endmember spectra. The zero/too-small variances are now replaced by
%     the median variance (floor at 1e-3 x median).
%   - FIX: GLS weights normalized to mean 1 (keeps the loss scale, and
%     therefore every lambda, comparable to the Gaussian model; stops
%     dim-pixel noise from dominating the reconstruction).
%   - FIX: chance-constraint margin moved off the abundance non-negativity
%     (now strict, as in the Gaussian model) onto the data-enclosure term
%     only, and capped by SIGMA_CAP. Relaxing a physically exact
%     constraint (A >= 0) biased the solution; noise tolerance is only
%     statistically justified on the data enclosure.
%   Verified against a Python replica of the full pipeline: with these
%   fixes PISCO matches Deep RMVSA in endmember SAD and improves abundance
%   MSE at low photon budgets, and the stripe/oscillation artifacts vanish.
%
% v0.4 (2026-09-21):
%   - PHOTON_GAIN added (fixes the scale mismatch when comparing against
%     the Gaussian model on identically scaled inputs).
%   - FOURIER FEATURE encoding of coordinates (NeRF-style), new parameter
%     FF_K (default 6; 0 = off). Fixes INR spectral bias: plain (gx,gy)
%     inputs let the A-Net learn only smooth low-frequency abundance maps.
%   - Weight init scale raised 0.01 -> 0.05.
%
% Optional terms (unchanged):
%   LAMBDA_ENCLOSE : data-enclosure penalty (synthetic data: set 10).
%   LAMBDA_SPATIAL : 4-neighbour grid Laplacian on abundance maps.
%   IMG_H / IMG_W  : scene dimensions for 2-D coordinates and spatial term.

pStruct = inputParser;
addParameter(pStruct, 'MM_ITERS', 2500, @isnumeric);
addParameter(pStruct, 'WARM_UP', 600, @(x) isnumeric(x) && isscalar(x) && isfinite(x) && x>=0 && mod(x,1)==0);
% E3d: transition scheduling is activated ONLY when WARM_UP > 0.
addParameter(pStruct, 'WARMUP_Q_RELEASE', 100, ...
    @(x) isnumeric(x) && isscalar(x) && isfinite(x) && x>=0 && mod(x,1)==0);
addParameter(pStruct, 'WARMUP_Q_MIN_LR_RATIO', 0.25, ...
    @(x) isnumeric(x) && isscalar(x) && isfinite(x) && x>0 && x<=1);
addParameter(pStruct, 'WARMUP_GATE_RELEASE', 150, ...
    @(x) isnumeric(x) && isscalar(x) && isfinite(x) && x>=0 && mod(x,1)==0);
addParameter(pStruct, 'LR', 3e-4, @isnumeric);
addParameter(pStruct, 'LAMBDA_VOL', 0.005, @isnumeric);
addParameter(pStruct, 'LAMBDA_NONNEG', 3, @isnumeric);
addParameter(pStruct, 'LAMBDA_EQ', 80, @isnumeric);
addParameter(pStruct, 'LAMBDA_SUMONE', 2, @isnumeric);
addParameter(pStruct, 'LAMBDA_ENCLOSE', 0, @isnumeric);   % enclosure term (synthetic data)
addParameter(pStruct, 'LAMBDA_SPATIAL', 0, @isnumeric);   % spatial smoothness (image data)
% E-2 extension: opt-in strict four-neighbor quadratic Laplacian.
% 'charbonnier' reproduces the supplied E3 trainer exactly (default).
% 'quadratic' matches the squared four-neighbor spatial objective in PISCO v77.
addParameter(pStruct, 'SPATIAL_PENALTY', 'charbonnier', ...
    @(x) ischar(x) && ismember(lower(strtrim(x)), {'charbonnier','quadratic'}));
addParameter(pStruct, 'SPATIAL_DELTA', 0.08, ...
    @(x) isnumeric(x) && isscalar(x) && isreal(x) && isfinite(x) && x > 0);  % edge-preservation scale
% Spectrally guided Robust Spatial: weights are built once from observed Y.
addParameter(pStruct, 'SPATIAL_GUIDE_MODE', 'noise_adaptive', ...
    @(x) ischar(x) && ismember(lower(strtrim(x)), {'spectral','uniform','noise_adaptive'}));
addParameter(pStruct, 'SPATIAL_GUIDE_SIGMA', 1.0, ...
    @(x) isnumeric(x) && isscalar(x) && isreal(x) && isfinite(x) && x >= 0);
addParameter(pStruct, 'SPATIAL_GUIDE_TAU', 2.0, ...
    @(x) isnumeric(x) && isscalar(x) && isreal(x) && isfinite(x) && x > 0);
addParameter(pStruct, 'SPATIAL_GUIDE_MIN_WEIGHT', 0.05, ...
    @(x) isnumeric(x) && isscalar(x) && isreal(x) && isfinite(x) && x >= 0 && x <= 1);
addParameter(pStruct, 'SPATIAL_GUIDE_NORMALIZE', true, ...
    @(x) islogical(x) && isscalar(x));
% Pilot only: photon-noise standardized edge testing and local uncertainty.
% The null expectation of the squared standardized difference is ~1 per band.
addParameter(pStruct, 'NOISE_GUIDE_THRESHOLD', 1.5, ...
    @(x) isnumeric(x) && isscalar(x) && isfinite(x) && x >= 0);
addParameter(pStruct, 'NOISE_GUIDE_TAU', 0.6, ...
    @(x) isnumeric(x) && isscalar(x) && isfinite(x) && x > 0);
addParameter(pStruct, 'NOISE_GUIDE_UNCERT_POWER', 0.5, ...
    @(x) isnumeric(x) && isscalar(x) && isfinite(x) && x >= 0);
addParameter(pStruct, 'NOISE_GUIDE_MAX_BOOST', 2.0, ...
    @(x) isnumeric(x) && isscalar(x) && isfinite(x) && x >= 1);
% Spatial-v2: use the same schedule codepath in Full/E3a; lambda=0 stays zero.
% E3a enhanced spatial regularization (all ignored when LAMBDA_SPATIAL = 0).
% Offsets / weights are deterministic, observed-data-only spatial graph links.
addParameter(pStruct, 'SPATIAL_MS_ENABLE', true, @(x) islogical(x) && isscalar(x));
addParameter(pStruct, 'SPATIAL_MS_OFFSETS', [1 2 4], ...
    @(x) isnumeric(x) && isvector(x) && ~isempty(x) && ...
    all(isfinite(x)) && all(x >= 1) && all(mod(x,1) == 0));
addParameter(pStruct, 'SPATIAL_MS_WEIGHTS', [0.55 0.30 0.15], ...
    @(x) isnumeric(x) && isvector(x) && ~isempty(x) && ...
    all(isfinite(x)) && all(x >= 0) && any(x > 0));
% Dynamic spatial gain: stop-gradient balancing, not an exact fixed objective.
addParameter(pStruct, 'SPATIAL_GRAD_BALANCE', true, ...
    @(x) islogical(x) && isscalar(x));
addParameter(pStruct, 'SPATIAL_TARGET_HEAD_RATIO', 0.40, ...
    @(x) isnumeric(x) && isscalar(x) && isfinite(x) && x > 0);
addParameter(pStruct, 'SPATIAL_GAIN_MIN', 0.50, ...
    @(x) isnumeric(x) && isscalar(x) && isfinite(x) && x >= 0);
addParameter(pStruct, 'SPATIAL_GAIN_MAX', 12.0, ...
    @(x) isnumeric(x) && isscalar(x) && isfinite(x) && x >= 1);
addParameter(pStruct, 'SPATIAL_SCHEDULE', 'constant', ...
    @(x) ischar(x) && ismember(lower(strtrim(x)), {'constant','decay'}));
addParameter(pStruct, 'SPATIAL_DECAY_START', 0.40, ...
    @(x) isnumeric(x) && isscalar(x) && isfinite(x) && x >= 0 && x < 1);
addParameter(pStruct, 'SPATIAL_FINAL_RATIO', 0.20, ...
    @(x) isnumeric(x) && isscalar(x) && isfinite(x) && x >= 0 && x <= 1);
addParameter(pStruct, 'IMG_H', [], @isnumeric);           % scene height  (rows)
addParameter(pStruct, 'IMG_W', [], @isnumeric);           % scene width   (cols)
addParameter(pStruct, 'M0', [], @isnumeric);
addParameter(pStruct, 'spherize', 'yes', @ischar);
addParameter(pStruct, 'verbose', 1, @isnumeric);
addParameter(pStruct, 'NOISE_MODEL', 'gaussian', @ischar);% 'gaussian' | 'poisson'
addParameter(pStruct, 'NOISE_WEIGHT', 'uniform', @ischar); % 'uniform' | 'pearson' | 'irls' <<< NEW v0.6
addParameter(pStruct, 'ETA', 0.1, @isnumeric);            % chance level
addParameter(pStruct, 'ETA_END', 0.5, @isnumeric);        % annealed chance level (0.5 = margin -> 0) <<< NEW v0.8
addParameter(pStruct, 'LAMBDA_MNONNEG', 10, @isnumeric);  % endmember non-negativity (band space) <<< NEW v0.8
addParameter(pStruct, 'LAMBDA_SMOOTH', 0.1, @isnumeric);  % spectral smoothness, 2nd-diff Tikhonov on M (0 = off) <<< NEW v0.9
addParameter(pStruct, 'SIGMA_CAP', 0.15, @isnumeric);      % margin cap (working units; 0.03 in v0.6)
addParameter(pStruct, 'PHOTON_GAIN', 1, @isnumeric);      % counts per unit of Y  <<< NEW v0.4
addParameter(pStruct, 'PHOTON_FLOOR', 1, @isnumeric);
addParameter(pStruct, 'READ_SIGMA', 0, @isnumeric);        % Gaussian read-out noise, in COUNTS (v0.7)     % count variance floor
addParameter(pStruct, 'FF_K', 6, @isnumeric);             % Fourier feature bands <<< NEW v0.4
addParameter(pStruct, 'GATED', true, @islogical);          % v13 E3i: false -> c = 0
addParameter(pStruct, 'ABUNDANCE_MODE', 'implicit', @ischar);   % v13 E3c: 'implicit' | 'explicit'
addParameter(pStruct, 'COORDS', '2d', @ischar);            % v1.0-E3: '1d' -> 1-D index input (E3h)
addParameter(pStruct, 'QPARAM', 'coupled', @ischar);       % v1.0-E3: 'free' -> Q = Q0 + Delta (E3g)
parse(pStruct, varargin{:});

if ~ismember(lower(pStruct.Results.ABUNDANCE_MODE), {'implicit','explicit'})
    error('ABUNDANCE_MODE must be ''implicit'' or ''explicit''.');
end

[L, N] = size(Y);
if pStruct.Results.WARM_UP >= pStruct.Results.MM_ITERS && pStruct.Results.WARM_UP > 0
    error('WARM_UP must be strictly smaller than MM_ITERS.');
end

%% --------------------- Preprocessing ---------------------
my = mean(Y,2); Yc = Y - repmat(my,1,N);
[Up, D] = svds(Yc*Yc'/N, p-1);
Yp = Up*Up'*Yc + repmat(my,1,N);
my_ortho = my - Up*Up'*my;
Up = [Up, my_ortho/sqrt(sum(my_ortho.^2))];
Y_proj = Up'*Yp;

if strcmp(pStruct.Results.spherize, 'yes')
    lambda_reg = 1e-10;
    C = diag(1./sqrt(diag(D+lambda_reg*eye(p-1))));
    Ys = C*Up(:,1:p-1)'*(Yp-repmat(my,1,N));
    Ys(p,:) = 1; Ys = Ys/sqrt(p);
    Y_work = Ys;
else
    Y_work = Y_proj; lambda_reg = 0;
end

%% --------- v0.8: lift operator for band-space endmember non-negativity ----
lift_ctx = [];
if pStruct.Results.LAMBDA_MNONNEG > 0 || pStruct.Results.LAMBDA_SMOOTH > 0  % v0.9
    if strcmp(pStruct.Results.spherize, 'yes')
        lift_ctx.mode   = 'sph';
        lift_ctx.Up_sub = Up(:,1:p-1);
        lift_ctx.sD     = sqrt(diag(D+lambda_reg*eye(p-1)));
        lift_ctx.my     = my;
        lift_ctx.sqp    = sqrt(p);
    else
        lift_ctx.mode    = 'proj';
        lift_ctx.Up_full = Up;
    end
end

%% --------------------- Noise covariance / chance-margin preparation ---------------------
noise_model = lower(strtrim(pStruct.Results.NOISE_MODEL));
if ~ismember(noise_model, {'poisson','gaussian'})
    error('NOISE_MODEL must be ''poisson'' or ''gaussian''.');
end
use_poisson  = strcmp(noise_model, 'poisson');
use_gaussian = strcmp(noise_model, 'gaussian');

% Linear map from band-space noise to the p-D working space.  In the
% spherized affine representation the last coordinate is fixed, therefore
% its direct measurement-noise row is zero by construction.
if strcmp(pStruct.Results.spherize, 'yes')
    B = [C*Up(:,1:p-1)'; zeros(1,L)] / sqrt(p);  % L-band -> working space
else
    B = Up';
end
B2 = B.^2;

Vpix = [];             % p x N, used only by the Poisson arm
Dw_gauss = [];          % p x p, fixed Gaussian covariance in working space
irls_ctx = [];
phi_inv = -sqrt(2)*erfcinv(2*pStruct.Results.ETA);       % Phi^{-1}(eta) <= 0

if use_poisson
    gain = pStruct.Results.PHOTON_GAIN;
    VarY = max(Y, pStruct.Results.PHOTON_FLOOR/gain) / gain ...  % shot noise, units of Y
         + (pStruct.Results.READ_SIGMA/gain)^2;                   % Gaussian read-out noise
    Vpix = B2 * VarY;                                            % p x N

    % Stabilize heteroscedastic variances for optional GLS weighting.
    med_v = median(Vpix(Vpix > 0));
    if isempty(med_v) || ~isfinite(med_v) || med_v <= 0
        med_v = 1e-12;
    end
    Vpix(Vpix <= 0 | ~isfinite(Vpix)) = med_v;
    Vpix = max(Vpix, 1e-3*med_v);

    % IRLS context (model-based weights from the reconstruction).
    if strcmpi(pStruct.Results.NOISE_WEIGHT, 'irls')
        if strcmp(pStruct.Results.spherize, 'yes')
            irls_ctx.Up_sub = Up(:,1:p-1);
            irls_ctx.Cinv   = sqrt(diag(D+lambda_reg*eye(p-1)));
            irls_ctx.my     = my;
            irls_ctx.gain   = gain;
            irls_ctx.floor  = pStruct.Results.PHOTON_FLOOR;
            irls_ctx.rs2    = (pStruct.Results.READ_SIGMA/gain)^2;
            irls_ctx.B2     = B2;
        else
            warning('NOISE_WEIGHT ''irls'' requires spherize ''yes''; using ''pearson''.');
            pStruct.Results.NOISE_WEIGHT = 'pearson';
        end
    end

    if pStruct.Results.verbose
        fprintf(['Poisson chance margin: pixel-adaptive covariance, eta=%.2f, ' ...
                 'Phi^{-1}(eta)=%.3f, gain=%.3g\n'], ...
                pStruct.Results.ETA, phi_inv, gain);
    end

elseif use_gaussian
    % Legacy Gaussian/LS branch, matching pisco_e3_train.m:
    % no Gaussian covariance estimation and no noise-tolerant chance margin.
    % Reconstruction remains ordinary unweighted least squares; all usual
    % abundance, simplex and Adam training updates still run normally.
    Dw_gauss = [];
    phi_inv = 0;
end

%% --------------------- Initialization ---------------------
if isempty(pStruct.Results.M0)
    M0 = VCA(Y_work, 'Endmembers', p, 'verbose', 'off');
else
    M0 = pStruct.Results.M0;
    if strcmp(pStruct.Results.spherize, 'yes')
        M0 = M0 - repmat(my,1,p);
        M0 = C*Up(:,1:p-1)'*M0;
        M0(p,:) = 1; M0 = M0/sqrt(p);
    else
        M0 = Up'*M0;
    end
end
Q0 = inv(M0);
qm = ones(1,N)*Y_work'*inv(Y_work*Y_work');

%% --------------------- Spatial coordinates ---------------------
H_img = pStruct.Results.IMG_H;
W_img = pStruct.Results.IMG_W;
if isempty(H_img) || isempty(W_img)
    H_img = round(sqrt(N)); W_img = round(N/H_img);
end
use_spatial = (H_img * W_img == N);
if use_spatial && strcmpi(pStruct.Results.COORDS, '1d')   % v1.0-E3 (E3h)
    % 1-D pixel index input; H_img/W_img are KEPT so the spatial
    % Laplacian term stays active -- isolates the coordinate input.
    coords = linspace(-1,1,N); coords = coords(:)';
elseif use_spatial
    [gx, gy] = meshgrid(linspace(-1,1,W_img), linspace(-1,1,H_img));
    coords = [gx(:)'; gy(:)'];          % 2 x N, column-major = data ordering
else
    if pStruct.Results.LAMBDA_SPATIAL > 0
        warning('IMG_H x IMG_W (%d x %d) ~= N (%d): spatial term disabled.', ...
            H_img, W_img, N);
    end
    H_img = 1; W_img = N;
    coords = linspace(-1,1,N); coords = coords(:)';
end

%% --------- v1.4: Spectral guidance from observed Y (once per training) ---
% Guidance depends on OBSERVED noisy spectra Y only; never on S_true, M_true,
% Y_clean or the current trainable abundance. It is shared for all iterations.
spatial_guide = [];
if pStruct.Results.LAMBDA_SPATIAL > 0 && H_img*W_img == N
    if strcmpi(pStruct.Results.SPATIAL_GUIDE_MODE, 'spectral')
        spatial_guide = build_observation_guidance(Y, H_img, W_img, ...
            pStruct.Results.SPATIAL_GUIDE_SIGMA, ...
            pStruct.Results.SPATIAL_GUIDE_TAU, ...
            pStruct.Results.SPATIAL_GUIDE_MIN_WEIGHT, ...
            pStruct.Results.SPATIAL_GUIDE_NORMALIZE);
    elseif strcmpi(pStruct.Results.SPATIAL_GUIDE_MODE, 'noise_adaptive')
        spatial_guide = build_photon_noise_guidance(Y, H_img, W_img, ...
            pStruct.Results.PHOTON_GAIN, pStruct.Results.READ_SIGMA, ...
            pStruct.Results.PHOTON_FLOOR, ...
            pStruct.Results.NOISE_GUIDE_THRESHOLD, ...
            pStruct.Results.NOISE_GUIDE_TAU, ...
            pStruct.Results.NOISE_GUIDE_UNCERT_POWER, ...
            pStruct.Results.NOISE_GUIDE_MAX_BOOST, ...
            pStruct.Results.SPATIAL_GUIDE_MIN_WEIGHT, ...
            pStruct.Results.SPATIAL_GUIDE_NORMALIZE);
    else
        spatial_guide.v = ones(1, max(H_img-1,0), W_img);
        spatial_guide.h = ones(1, H_img, max(W_img-1,0));
    end
    if pStruct.Results.verbose
        all_w = [spatial_guide.v(:); spatial_guide.h(:)];
        if ~isempty(all_w)
            fprintf('Spatial guide [%s]: min=%.4f, mean=%.4f, max=%.4f\n', ...
                pStruct.Results.SPATIAL_GUIDE_MODE, ...
                min(all_w), mean(all_w), max(all_w));
        end
    end
end

% E3a enhanced: multiscale graph and bounded gradient balancing (explicit/implicit).
% This entire block is bypassed for E3a (LAMBDA_SPATIAL=0).
if pStruct.Results.LAMBDA_SPATIAL > 0 && H_img*W_img == N
    spatial_guide.penalty = lower(strtrim(pStruct.Results.SPATIAL_PENALTY));
    spatial_guide.multiscale = logical(pStruct.Results.SPATIAL_MS_ENABLE);
    spatial_guide.grad_balance = logical(pStruct.Results.SPATIAL_GRAD_BALANCE);
    spatial_guide.target_ratio = double(pStruct.Results.SPATIAL_TARGET_HEAD_RATIO);
    spatial_guide.gain_min = double(pStruct.Results.SPATIAL_GAIN_MIN);
    spatial_guide.gain_max = double(pStruct.Results.SPATIAL_GAIN_MAX);
    if spatial_guide.gain_min > spatial_guide.gain_max
        error('SPATIAL_GAIN_MIN must be <= SPATIAL_GAIN_MAX.');
    end
    if spatial_guide.multiscale
        offsets = double(pStruct.Results.SPATIAL_MS_OFFSETS(:)');
        weights = double(pStruct.Results.SPATIAL_MS_WEIGHTS(:)');
        if numel(offsets) ~= numel(weights) || numel(unique(offsets)) ~= numel(offsets)
            error('SPATIAL_MS_OFFSETS and SPATIAL_MS_WEIGHTS must match, with unique offsets.');
        end
        if any(offsets >= max(H_img,W_img))
            error('Spatial multiscale offsets must be smaller than max(IMG_H,IMG_W).');
        end
        weights = weights/sum(weights);
        spatial_guide.ms_offsets = offsets;
        spatial_guide.ms_weights = weights;
        spatial_guide.ms = cell(1,numel(offsets));
        for iscale = 1:numel(offsets)
            d = offsets(iscale);
            if d == 1
                spatial_guide.ms{iscale}.v = spatial_guide.v;
                spatial_guide.ms{iscale}.h = spatial_guide.h;
            elseif strcmpi(pStruct.Results.SPATIAL_GUIDE_MODE,'noise_adaptive')
                spatial_guide.ms{iscale} = build_noise_guidance_at_offset( ...
                    Y,H_img,W_img,d,pStruct.Results.PHOTON_GAIN, ...
                    pStruct.Results.READ_SIGMA,pStruct.Results.PHOTON_FLOOR, ...
                    pStruct.Results.NOISE_GUIDE_THRESHOLD, ...
                    pStruct.Results.NOISE_GUIDE_TAU, ...
                    pStruct.Results.NOISE_GUIDE_UNCERT_POWER, ...
                    pStruct.Results.NOISE_GUIDE_MAX_BOOST, ...
                    pStruct.Results.SPATIAL_GUIDE_MIN_WEIGHT, ...
                    pStruct.Results.SPATIAL_GUIDE_NORMALIZE);
            elseif strcmpi(pStruct.Results.SPATIAL_GUIDE_MODE,'spectral')
                % For a non-default legacy spectral mode, long-range links
                % use weights computed from observed signal differences.
                spatial_guide.ms{iscale} = build_spectral_guidance_at_offset( ...
                    Y,H_img,W_img,d,pStruct.Results.SPATIAL_GUIDE_SIGMA, ...
                    pStruct.Results.SPATIAL_GUIDE_TAU, ...
                    pStruct.Results.SPATIAL_GUIDE_MIN_WEIGHT, ...
                    pStruct.Results.SPATIAL_GUIDE_NORMALIZE);
            else
                spatial_guide.ms{iscale}.v = ones(1,max(H_img-d,0),W_img);
                spatial_guide.ms{iscale}.h = ones(1,H_img,max(W_img-d,0));
            end
        end
    end
end

%% --------- Fourier feature encoding of coordinates (v0.4) ----------
% NeRF/Tancik-style encoding: t -> [t, sin(2^k*pi*t), cos(2^k*pi*t)]
% for k = 0..K-1, applied per coordinate axis.  A plain coordinate MLP
% suffers from spectral bias and can only learn slowly-varying abundance
% maps (near-uniform fields); multi-scale sinusoidal features remove this
% bottleneck.  coord_dim becomes 1+2K (1-D) or 2+4K (2-D, K=6 -> 26).
if pStruct.Results.FF_K > 0
    K = pStruct.Results.FF_K;
    freqs = (2.^(0:K-1)) * pi;                  % 1 x K
    d0 = size(coords,1);
    enc = zeros(d0*(1+2*K), N);
    r = 1;
    for d = 1:d0
        t = coords(d,:);                         % 1 x N
        enc(r,:)         = t;                    r = r+1;
        enc(r:r+K-1,:)   = sin(t'*freqs).';      r = r+K;
        enc(r:r+K-1,:)   = cos(t'*freqs).';      r = r+K;
    end
    coords = enc;
end
coord_dim = size(coords,1);

%% --------------------- Abundance representation parameters ---------------------
% v13 E3c: implicit abundance uses the original coordinate A-Net/S-Net;
% explicit abundance replaces the network by a free p x N trainable matrix.
if strcmpi(pStruct.Results.ABUNDANCE_MODE, 'explicit')
    % Near-uniform initialization avoids giving the explicit arm a separate
    % data-informed/FCLS initialization advantage.
    theta.S_explicit = ones(p, N) / p;
else
    hidden = 32;
    theta.W1 = 0.05*randn(hidden, coord_dim); theta.b1 = zeros(hidden,1);
    theta.W2 = 0.05*randn(hidden, hidden);    theta.b2 = zeros(hidden,1);
    theta.W3 = 0.05*randn(p, hidden);         theta.b3 = zeros(p,1);
    theta.Wg1 = 0.05*randn(hidden, coord_dim); theta.bg1 = zeros(hidden,1);
    theta.Wg2 = 0.05*randn(p, hidden);         theta.bg2 = zeros(p,1);
    theta.c = 0.05;
end

%% --------------------- Simplex transform parameters ---------------------
if strcmpi(pStruct.Results.QPARAM, 'free')      % v1.0-E3 (E3g): free transform
    theta.Delta = zeros(p,p);                   % Q = Q0 + Delta
else                                            % default: invertible Q = L*Q0*R
    theta.L = zeros(p,p);       % strict lower triangular
    theta.R = zeros(p,p);       % strict upper triangular
    theta.r_log = zeros(p,1);   % R diagonal log
end

%% --------------------- Adam states ---------------------
m = init_adam(theta);
v = init_adam(theta);
lr = pStruct.Results.LR;
iter = 0;

%% --------------------- Warm-up (linear, Q fixed at Q0) ---------------------
if pStruct.Results.verbose, fprintf('Warm-up (linear, fixed Q)...\n'); end
for k = 1:pStruct.Results.WARM_UP
    % Warm-up keeps the spatial prior active to stabilize the initial field.
    spatial_lambda_t = pStruct.Results.LAMBDA_SPATIAL;
    [loss, grad, spatial_stats] = compute_gradients_invflow(theta, Y_work, coords, Q0, qm, p, ...
        0, pStruct.Results.LAMBDA_NONNEG, pStruct.Results.LAMBDA_EQ, ...
        pStruct.Results.LAMBDA_SUMONE, pStruct.Results.LAMBDA_ENCLOSE, ...
        spatial_lambda_t, pStruct.Results.SPATIAL_DELTA, spatial_guide, H_img, W_img, true, ...
        use_poisson, use_gaussian, Vpix, Dw_gauss, phi_inv, pStruct.Results.SIGMA_CAP, ...
        pStruct.Results.NOISE_WEIGHT, irls_ctx, ...
        pStruct.Results.LAMBDA_MNONNEG, pStruct.Results.LAMBDA_SMOOTH, lift_ctx, ...
        pStruct.Results.GATED, pStruct.Results.QPARAM, pStruct.Results.ABUNDANCE_MODE);  % E3 args
    % CRITICAL E3d FIX: Q must remain Q0 during warm-up.  Skip the Q
    % updates AND its Adam moments.  The gate is inactive and skipped too.
    [theta, m, v] = adam_update_struct(theta, grad, m, v, iter+1, lr, ...
        0, 0, 0, false);
    iter = iter + 1;
    if pStruct.Results.verbose && mod(k,100)==0
        fprintf('Warm-up %d/%d, loss=%.6f (Q exactly frozen)\n', ...
            k, pStruct.Results.WARM_UP, loss);
    end
end

% E3d sanity check: all learnable Q parameters must remain at initialization.
if pStruct.Results.WARM_UP > 0
    if isfield(theta,'Delta')
        q_drift = norm(theta.Delta,'fro');
    else
        q_drift = norm(theta.L,'fro') + norm(theta.R,'fro') + norm(theta.r_log);
    end
    assert(q_drift == 0, 'E3d: Q changed during supposedly fixed-Q warm-up.');
    if pStruct.Results.verbose
        fprintf('Warm-up finished: Q parameter drift = %.3g (should be 0).\n', q_drift);
    end
end

%% --------------------- Joint training ---------------------
if pStruct.Results.verbose, fprintf('Joint training (invertible Q + nonlinear)...\n'); end
n_joint = pStruct.Results.MM_ITERS - pStruct.Results.WARM_UP;
eta0 = pStruct.Results.ETA; eta1 = pStruct.Results.ETA_END;      % v0.8: anneal
for k = 1:n_joint
    % v0.8: anneal the chance level ETA -> ETA_END over the joint phase;
    % Phi^{-1}(0.5) = 0, so the enclosure margin decays to zero at
    % convergence (removes the systematic inward simplex bias at high SNR).
    if use_poisson || use_gaussian
        % E3b uses the SAME eta schedule as the Poisson full model so the
        % ablation changes only the covariance/noise model, not annealing.
        prog  = (k-1)/max(1, n_joint-1);
        eta_t = min(max(eta0 + (eta1-eta0)*prog, 1e-6), 1-1e-6);
        phi_t = -sqrt(2)*erfcinv(2*eta_t);
    else
        phi_t = 0;
    end
    % Spatial-v2: denoise early, release high-frequency detail late.
    % Smoothstep avoids an abrupt change in the spatial gradient.
    spatial_lambda_t = pStruct.Results.LAMBDA_SPATIAL;
    if strcmpi(pStruct.Results.SPATIAL_SCHEDULE, 'decay') && spatial_lambda_t > 0
        pos = (k-1) / max(1,n_joint-1);
        t_space = min(1,max(0,(pos - pStruct.Results.SPATIAL_DECAY_START) / ...
            (1 - pStruct.Results.SPATIAL_DECAY_START)));
        smoothstep = t_space^2 * (3 - 2*t_space);
        final_ratio = pStruct.Results.SPATIAL_FINAL_RATIO;
        spatial_lambda_t = spatial_lambda_t * (1 - (1-final_ratio)*smoothstep);
    end
    % E3d: turn on nonlinear gate continuously after the pretraining phase.
    % beta_gate=1 suppresses gate, beta_gate=0 enables it fully.
    % Without warm-up this is exactly zero on every joint iteration.
    gate_suppression = 0;
    if pStruct.Results.WARM_UP > 0 && pStruct.Results.WARMUP_GATE_RELEASE > 0
        gate_progress = min(1, k / pStruct.Results.WARMUP_GATE_RELEASE);
        gate_progress = gate_progress^2 * (3 - 2*gate_progress);
        gate_suppression = 1 - gate_progress;
    end
    % Release Q with a short, explicit parameter-group learning-rate ramp;
    % Adam gradient scaling alone would not reliably reduce its step size.
    q_lr_scale = 1;
    if pStruct.Results.WARM_UP > 0 && pStruct.Results.WARMUP_Q_RELEASE > 0
        q_progress = min(1,k / pStruct.Results.WARMUP_Q_RELEASE);
        q_progress = q_progress^2 * (3 - 2*q_progress);
        q0_scale = pStruct.Results.WARMUP_Q_MIN_LR_RATIO;
        q_lr_scale = q0_scale + (1-q0_scale)*q_progress;
    end
    [loss, grad, spatial_stats] = compute_gradients_invflow(theta, Y_work, coords, Q0, qm, p, ...
        pStruct.Results.LAMBDA_VOL, pStruct.Results.LAMBDA_NONNEG, ...
        pStruct.Results.LAMBDA_EQ, pStruct.Results.LAMBDA_SUMONE, ...
        pStruct.Results.LAMBDA_ENCLOSE, ...
        spatial_lambda_t, pStruct.Results.SPATIAL_DELTA, spatial_guide, H_img, W_img, gate_suppression, ...
        use_poisson, use_gaussian, Vpix, Dw_gauss, phi_t, pStruct.Results.SIGMA_CAP, ...
        pStruct.Results.NOISE_WEIGHT, irls_ctx, ...
        pStruct.Results.LAMBDA_MNONNEG, pStruct.Results.LAMBDA_SMOOTH, lift_ctx, ...
        pStruct.Results.GATED, pStruct.Results.QPARAM, pStruct.Results.ABUNDANCE_MODE);  % E3 args
    % Q/gate Adam clocks start at 1 when these groups first become active;
    % the common S-Net parameters keep their full warm-up iteration count.
    [theta, m, v] = adam_update_struct(theta, grad, m, v, iter+1, lr, ...
        q_lr_scale, k, k, pStruct.Results.GATED);
    iter = iter + 1;
    if pStruct.Results.verbose && mod(k,100)==0
        if isfield(theta,'c')
            fprintf('Joint %d/%d, loss=%.6f, c=%.4f\n', k, n_joint, loss, theta.c);
        else
            fprintf('Joint %d/%d, loss=%.6f, explicit abundance\n', k, n_joint, loss);
        end
        if pStruct.Results.LAMBDA_SPATIAL > 0
            fprintf('  Spatial: loss=%.4g, lambda_eff=%.4g, gain=%.3g, grad_ratio=%.3g\n', ...
                spatial_stats.loss, spatial_stats.effective_lambda, ...
                spatial_stats.gain, spatial_stats.grad_ratio);
        end
    end
end

%% --------------------- Recover endmembers ---------------------
if strcmpi(pStruct.Results.ABUNDANCE_MODE, 'explicit')
    A_eff = theta.S_explicit;
else
    [A_eff, ~, ~, ~] = abundance_net_forward_nl(coords, theta, ~pStruct.Results.GATED);
end
if strcmpi(pStruct.Results.QPARAM, 'free')                  % v1.0-E3 (E3g)
    Q = Q0 + theta.Delta;
else
    L_mat = eye(p) + tril(theta.L, -1);
    R_mat = diag(exp(theta.r_log)) + triu(theta.R, 1);
    Q = L_mat * Q0 * R_mat;
end
M_sub = inv(Q);
Sest = A_eff;
if strcmp(pStruct.Results.spherize, 'yes')
    M_sub = M_sub*sqrt(p);
    M_sub = M_sub(1:p-1,:);
    M_est = Up(:,1:p-1)*diag(sqrt(diag(D+lambda_reg*eye(p-1))))*M_sub + repmat(my,1,p);
else
    M_est = Up*M_sub;
end
M_est = max(M_est, 0);   % v0.8: fluorescence spectra are physically non-negative
end

%% ===================== Sub-functions =====================
function [loss_sp, grad_A] = quadratic_spatial_loss_grad(A,H,W,guide)
% E-2: exact four-neighbor squared differences, normalized by N pixels:
% Lsp = (1/N) sum_{(i,j) in grid edges} ||s_i-s_j||_2^2.
% The guide must be uniform for the paper-matched setting (E-2 driver).
[p,N] = size(A);
A3 = reshape(A,p,H,W);
grad3 = zeros(p,H,W,'like',A3);
loss_sp = 0;
if H > 1
    dv = A3(:,2:end,:) - A3(:,1:end-1,:);
    wv = reshape(guide.v,[1,H-1,W]);
    loss_sp = loss_sp + sum((dv.^2).*wv,'all')/N;
    f = (2/N)*dv.*wv;
    grad3(:,1:end-1,:) = grad3(:,1:end-1,:) - f;
    grad3(:,2:end,:)   = grad3(:,2:end,:) + f;
end
if W > 1
    dh = A3(:,:,2:end) - A3(:,:,1:end-1);
    wh = reshape(guide.h,[1,H,W-1]);
    loss_sp = loss_sp + sum((dh.^2).*wh,'all')/N;
    f = (2/N)*dh.*wh;
    grad3(:,:,1:end-1) = grad3(:,:,1:end-1) - f;
    grad3(:,:,2:end)   = grad3(:,:,2:end) + f;
end
grad_A = reshape(grad3,p,N);
end

function [loss_sp, grad_A] = multiscale_spatial_loss_grad(A,H,W,delta,guide)
% Multiscale robust graph prior; exact derivative for fixed observed weights.
% L = sum_d alpha_d (1/N) sum_(i,j) w_ij rho(A_i - A_j),
% rho(D)=2*delta^2*(sqrt(1+||D||^2/delta^2)-1).
[p,N] = size(A);
A3 = reshape(A,p,H,W);
grad3 = zeros(p,H,W);
loss_sp = 0;
for i = 1:numel(guide.ms_offsets)
    d = guide.ms_offsets(i); alpha = guide.ms_weights(i);
    if alpha == 0, continue; end
    w = guide.ms{i};
    if H > d
        Dv = A3(:,1+d:end,:) - A3(:,1:end-d,:);
        Rv = sqrt(1+sum(Dv.^2,1)/delta^2);
        loss_sp = loss_sp + alpha*2*delta^2*sum(w.v(:).*(Rv(:)-1))/N;
        flux = (2*alpha/N)*(Dv./Rv).*w.v;
        grad3(:,1:end-d,:) = grad3(:,1:end-d,:) - flux;
        grad3(:,1+d:end,:) = grad3(:,1+d:end,:) + flux;
    end
    if W > d
        Dh = A3(:,:,1+d:end) - A3(:,:,1:end-d);
        Rh = sqrt(1+sum(Dh.^2,1)/delta^2);
        loss_sp = loss_sp + alpha*2*delta^2*sum(w.h(:).*(Rh(:)-1))/N;
        flux = (2*alpha/N)*(Dh./Rh).*w.h;
        grad3(:,:,1:end-d) = grad3(:,:,1:end-d) - flux;
        grad3(:,:,1+d:end) = grad3(:,:,1+d:end) + flux;
    end
end
grad_A = reshape(grad3,p,N);
end

function [loss_sp, grad_A] = legacy_spatial_loss_grad(A,H,W,delta,guide)
% Original one-step loss/gradient, retained for backward compatibility.
[p,N] = size(A);
A3 = reshape(A,p,H,W);
grad3 = zeros(p,H,W);
loss_sp = 0;
if H > 1
    Dv = A3(:,2:end,:) - A3(:,1:end-1,:);
    Rv = sqrt(1+sum(Dv.^2,1)/delta^2);
    loss_sp = loss_sp + 2*delta^2*sum(guide.v(:).*(Rv(:)-1))/N;
    flux = (2/N)*(Dv./Rv).*guide.v;
    grad3(:,1:end-1,:) = grad3(:,1:end-1,:) - flux;
    grad3(:,2:end,:) = grad3(:,2:end,:) + flux;
end
if W > 1
    Dh = A3(:,:,2:end) - A3(:,:,1:end-1);
    Rh = sqrt(1+sum(Dh.^2,1)/delta^2);
    loss_sp = loss_sp + 2*delta^2*sum(guide.h(:).*(Rh(:)-1))/N;
    flux = (2/N)*(Dh./Rh).*guide.h;
    grad3(:,:,1:end-1) = grad3(:,:,1:end-1) - flux;
    grad3(:,:,2:end) = grad3(:,:,2:end) + flux;
end
grad_A = reshape(grad3,p,N);
end

function guide = build_noise_guidance_at_offset(Yobs,H,W,d,gain,read_sigma, ...
    floor_counts,threshold,tau,power_unc,max_boost,min_weight,normalize_mean)
% Photon-noise standardised observed links at pixel offset d.
[Lobs,Nobs] = size(Yobs);
assert(H*W==Nobs,'Noise graph image size inconsistent.');
assert(isfinite(gain) && gain > 0,'PHOTON_GAIN must be >0.');
Dv = zeros(max(H-d,0),W);
Dh = zeros(H,max(W-d,0));
mean_count = zeros(H,W);
for b = 1:Lobs
    C = max(gain*reshape(double(Yobs(b,:)),H,W),0);
    V = max(C,floor_counts) + read_sigma^2;
    mean_count = mean_count+C/Lobs;
    if H > d
        dd = C(1+d:end,:) - C(1:end-d,:);
        vv = V(1+d:end,:) + V(1:end-d,:);
        Dv = Dv + (dd.^2)./max(vv,1e-12)/Lobs;
    end
    if W > d
        dd = C(:,1+d:end) - C(:,1:end-d);
        vv = V(:,1+d:end) + V(:,1:end-d);
        Dh = Dh + (dd.^2)./max(vv,1e-12)/Lobs;
    end
end
wv = exp(-max(Dv-threshold,0)/tau);
wh = exp(-max(Dh-threshold,0)/tau);
unc = 1./sqrt(mean_count + read_sigma^2 + max(floor_counts,1));
ref = median(unc(:));
if ~isfinite(ref) || ref <= 0, ref=1; end
unc = max(min(unc/ref,max_boost),1/max_boost).^power_unc;
if H>d, wv=wv.*0.5.*(unc(1+d:end,:)+unc(1:end-d,:)); end
if W>d, wh=wh.*0.5.*(unc(:,1+d:end)+unc(:,1:end-d)); end
wv=max(wv,min_weight); wh=max(wh,min_weight);
if normalize_mean
    n=numel(wv)+numel(wh);
    if n>0
        z=(sum(wv(:))+sum(wh(:)))/n;
        if isfinite(z) && z>0, wv=wv/z; wh=wh/z; end
    end
end
guide.v = reshape(wv,1,max(H-d,0),W);
guide.h = reshape(wh,1,H,max(W-d,0));
end

function guide = build_spectral_guidance_at_offset(Yobs,H,W,d,sigma,tau,min_weight,normalize_mean)
% Legacy-compatible spectral difference links for non-default spectral mode.
[Lobs,Nobs] = size(Yobs);
assert(H*W==Nobs,'Spectral graph image size inconsistent.');
Dv2=zeros(max(H-d,0),W); Dh2=zeros(H,max(W-d,0));
stds=std(double(Yobs),0,2);
pos=stds(isfinite(stds) & stds>0);
if isempty(pos), f=1; else, f=max(0.3*median(pos),1e-12); end
stds(~isfinite(stds))=f; stds=max(stds,f);
if sigma>0
    rad=max(1,ceil(3*sigma)); t=(-rad:rad)';
    ker=exp(-0.5*(t/sigma).^2); ker=ker/sum(ker);
    normmap=max(conv2(conv2(ones(H,W),ker,'same'),ker','same'),realmin('double'));
end
for b=1:Lobs
    Z=reshape(double(Yobs(b,:)),H,W);
    if sigma>0, Z=conv2(conv2(Z,ker,'same'),ker','same')./normmap; end
    if H>d, dv=(Z(1+d:end,:)-Z(1:end-d,:))/stds(b); Dv2=Dv2+dv.^2/Lobs; end
    if W>d, dh=(Z(:,1+d:end)-Z(:,1:end-d))/stds(b); Dh2=Dh2+dh.^2/Lobs; end
end
dist=[sqrt(Dv2(:));sqrt(Dh2(:))];
if isempty(dist) || median(dist)<1e-12
    wv=ones(size(Dv2)); wh=ones(size(Dh2));
else
    bw2=max((tau*median(dist))^2,1e-24);
    wv=max(exp(-0.5*Dv2/bw2),min_weight);
    wh=max(exp(-0.5*Dh2/bw2),min_weight);
end
if normalize_mean
    n=numel(wv)+numel(wh);
    if n>0
        z=(sum(wv(:))+sum(wh(:)))/n;
        if isfinite(z) && z>0, wv=wv/z; wh=wh/z; end
    end
end
guide.v=reshape(wv,1,max(H-d,0),W);
guide.h=reshape(wh,1,H,max(W-d,0));
end

function guide = build_photon_noise_guidance(Yobs, H, W, gain, read_sigma, ...
    floor_counts, threshold, tau, power_unc, max_boost, min_weight, normalize_mean)
% Noise-adaptive weights: observed data only, no ground truth.
% Yobs is in rate units, gain converts it to photon counts.
% Under equal underlying signals, E[(C_i-C_j)^2/(V_i+V_j)] ~ 1.
% A large excess indicates a likely true boundary rather than random noise.
% This is a Gaussian/Poisson plug-in heuristic, not an exact hypothesis test.
% Local low-count uncertainty raises smoothing within otherwise similar areas.
[Lobs, Nobs] = size(Yobs);
assert(H*W == Nobs, 'Noise guidance: incompatible image dimensions.');
assert(isfinite(gain) && gain > 0, 'Noise guidance requires PHOTON_GAIN > 0.');
Dv = zeros(max(H-1,0), W);
Dh = zeros(H, max(W-1,0));
mean_count = zeros(H,W);
for b = 1:Lobs
    C = max(gain*reshape(double(Yobs(b,:)), H, W), 0);
    V = max(C, floor_counts) + read_sigma^2;
    mean_count = mean_count + C/Lobs;
    if H > 1
        d = C(2:end,:) - C(1:end-1,:);
        v = V(2:end,:) + V(1:end-1,:);
        Dv = Dv + (d.^2)./max(v,1e-12)/Lobs;
    end
    if W > 1
        d = C(:,2:end) - C(:,1:end-1);
        v = V(:,2:end) + V(:,1:end-1);
        Dh = Dh + (d.^2)./max(v,1e-12)/Lobs;
    end
end
% Downweight spectrally distinct neighbors, but not differences explained
% by counting noise (D <= threshold). E[D]~1 for homogeneous regions.
wv = exp(-max(Dv-threshold,0)/tau);
wh = exp(-max(Dh-threshold,0)/tau);

% More regularization at low photon levels (uncertainty ~ 1/sqrt(counts)).
% Normalization to the map median prevents global scale drift across scenes.
unc = 1./sqrt(mean_count + read_sigma^2 + max(floor_counts,1));
unc_med = median(unc(:));
if ~isfinite(unc_med) || unc_med <= 0, unc_med=1; end
unc = max(min(unc/unc_med, max_boost),1/max_boost).^power_unc;
if H>1, wv = wv .* 0.5.*(unc(2:end,:) + unc(1:end-1,:)); end
if W>1, wh = wh .* 0.5.*(unc(:,2:end) + unc(:,1:end-1)); end
wv = max(wv,min_weight);
wh = max(wh,min_weight);
if normalize_mean
    n_edges = numel(wv)+numel(wh);
    if n_edges>0
        avg = (sum(wv(:))+sum(wh(:)))/n_edges;
        if isfinite(avg) && avg>0
            wv=wv/avg; wh=wh/avg;
        end
    end
end
guide.v = reshape(wv, 1, max(H-1,0), W);
guide.h = reshape(wh, 1, H, max(W-1,0));
end

function guide = build_observation_guidance(Yobs, H, W, sigma, tau, min_weight, normalize_mean)
% BUILD_OBSERVATION_GUIDANCE  Spectrally guided 4-neighbour edge weights.
% Yobs: L x N observed noisy spectra only (NO GT, NO learned S or M).
% Each band is spatially Gaussian-smoothed to reduce Poisson/readout noise.
% Normalizing each band by a variance-based scale prevents the strongest
% spectral channels from monopolizing edge detection. A 30%% median channel-
% scale floor limits accidental amplification of nearly constant bands.
% Median neighbor distance calibrates tau independently of intensity units.
%
% Output guide.v: 1 x (H-1) x W; guide.h: 1 x H x (W-1).
% Weights are constant within and across training iterations.
[Lobs,Nobs] = size(Yobs);
assert(H*W == Nobs, 'Guidance image size does not match data pixels.');

Dv2 = zeros(max(H-1,0), W);
Dh2 = zeros(H, max(W-1,0));

band_std = std(double(Yobs), 0, 2);
pos = band_std(isfinite(band_std) & band_std > 0);
if isempty(pos)
    floor_std = 1;
else
    floor_std = max(0.30*median(pos), 1e-12);
end
band_std(~isfinite(band_std)) = floor_std;
band_std = max(band_std, floor_std);

if sigma > 0
    radius = max(1, ceil(3*sigma));
    u = (-radius:radius)';
    ker = exp(-0.5*(u/sigma).^2);
    ker = ker/sum(ker);
    % Correct the truncated filter near image boundaries. No toolbox needed.
    norm_map = conv2(conv2(ones(H,W),ker,'same'),ker','same');
    norm_map = max(norm_map, realmin('double'));
end

% Accumulate squared Euclidean distances across channels without storing
% an additional L-by-N denoised data cube (saves memory at 512x512).
for b = 1:Lobs
    Z = reshape(double(Yobs(b,:)),H,W);
    if sigma > 0
        Z = conv2(conv2(Z,ker,'same'),ker','same') ./ norm_map;
    end
    inv_scale = 1/band_std(b);
    dv = (Z(2:end,:) - Z(1:end-1,:))*inv_scale;
    dh = (Z(:,2:end) - Z(:,1:end-1))*inv_scale;
    Dv2 = Dv2 + dv.^2;
    Dh2 = Dh2 + dh.^2;
end
Dv2 = Dv2/max(Lobs,1);
Dh2 = Dh2/max(Lobs,1);

edge_d = [sqrt(Dv2(:));sqrt(Dh2(:))];
if isempty(edge_d)
    wv = ones(size(Dv2)); wh = ones(size(Dh2));
else
    dref = median(edge_d);
    if ~isfinite(dref) || dref < 1e-12
        wv = ones(size(Dv2)); wh = ones(size(Dh2));
    else
        bw2 = max((tau*dref)^2, 1e-24);
        wv = max(exp(-0.5*Dv2/bw2),min_weight);
        wh = max(exp(-0.5*Dh2/bw2),min_weight);
        if normalize_mean
            % Keep the average edge penalty comparable with the prior
            % unweighted robust model at the same LAMBDA_SPATIAL.
            wmean = (sum(wv(:)) + sum(wh(:))) / numel(edge_d);
            if wmean > 0
                wv = wv/wmean;
                wh = wh/wmean;
            end
        end
    end
end

guide.v = reshape(wv,1,max(H-1,0),W);
guide.h = reshape(wh,1,H,max(W-1,0));
end

function adam = init_adam(theta)
fields = fieldnames(theta);
adam = struct();
for i = 1:numel(fields)
    f = fields{i};
    adam.(f) = zeros(size(theta.(f)));
end
end

function [A_eff, A_base, G, cache] = abundance_net_forward_nl(coords, theta, warm_up)
Z1 = theta.W1*coords + theta.b1; H1 = tanh(Z1);
Z2 = theta.W2*H1 + theta.b2;     H2 = tanh(Z2);
Z3 = theta.W3*H2 + theta.b3;
Z3 = Z3 - max(Z3,[],1); expZ = exp(Z3);
A_base = expZ ./ sum(expZ,1);

Zg1 = theta.Wg1*coords + theta.bg1; Hg1 = tanh(Zg1);
Zg2 = theta.Wg2*Hg1 + theta.bg2;
G = 1./(1+exp(-Zg2));

% warm_up in [0,1] is the amount of suppression applied to the gate.
% 1: linear warm-up / 0: full gate / intermediate: smooth transition.
c = (1-warm_up)*theta.c;
A_eff = A_base + c*(G.*(A_base.^2));

cache.Z1=Z1; cache.H1=H1; cache.Z2=Z2; cache.H2=H2; cache.Z3=Z3;
cache.expZ=expZ; cache.coords=coords;
cache.Zg1=Zg1; cache.Hg1=Hg1; cache.Zg2=Zg2; cache.G=G;
cache.A_base=A_base; cache.c=c; cache.warm_up=warm_up;
end

function grad = abundance_net_backward_nl(dA_eff, cache, theta)
A_base = cache.A_base; G = cache.G; c = cache.c; warm_up = cache.warm_up;

dA_base = dA_eff + 2*c*G.*A_base.*dA_eff;
dG = c*(A_base.^2).*dA_eff;
dc = sum(sum((G.*(A_base.^2)).*dA_eff));

if warm_up >= 1
    grad.Wg1 = zeros(size(theta.Wg1)); grad.bg1 = zeros(size(theta.bg1));
    grad.Wg2 = zeros(size(theta.Wg2)); grad.bg2 = zeros(size(theta.bg2));
    grad.c = 0;
else
    dZg2 = dG.*(G.*(1-G));
    grad.Wg2 = dZg2*cache.Hg1'; grad.bg2 = sum(dZg2,2);
    dHg1 = theta.Wg2'*dZg2;
    dZg1 = dHg1.*(1-tanh(cache.Zg1).^2);
    grad.Wg1 = dZg1*cache.coords'; grad.bg1 = sum(dZg1,2);
    % c_effective=(1-warm_up)*theta.c, so chain factor is essential.
    grad.c = (1-warm_up)*dc;
end

A = cache.expZ ./ sum(cache.expZ,1);
dZ3 = A.*(dA_base - sum(A.*dA_base,1));
grad.W3 = dZ3*cache.H2'; grad.b3 = sum(dZ3,2);
dH2 = theta.W3'*dZ3;
dZ2 = dH2.*(1-tanh(cache.Z2).^2);
grad.W2 = dZ2*cache.H1'; grad.b2 = sum(dZ2,2);
dH1 = theta.W2'*dZ2;
dZ1 = dH1.*(1-tanh(cache.Z1).^2);
grad.W1 = dZ1*cache.coords'; grad.b1 = sum(dZ1,2);
end

function [loss, grad, spatial_stats] = compute_gradients_invflow(theta, Y, coords, Q0, qm, p, ...
    lambda_vol, lambda_nonneg, lambda_eq, lambda_sumone, lambda_enclose, ...
    lambda_spatial, spatial_delta, spatial_guide, H_img, W_img, warm_up, use_poisson, use_gaussian, Vpix, Dw_gauss, phi_inv, sigma_cap, ...
    noise_weight, irls_ctx, lambda_mnn, lambda_smooth, lift_ctx, ...
    gated, qparam, abundance_mode)                       % E3 args
% For E3i, suppress the gate entirely; for E3d use the continuous
% suppression level from the joint transition schedule.
net_lin = max(double(warm_up), double(~gated));
if strcmpi(qparam, 'free')                               % v1.0-E3 (E3g): free transform
    Q = Q0 + theta.Delta;
else
    L_mat = eye(p) + tril(theta.L, -1);
    R_mat = diag(exp(theta.r_log)) + triu(theta.R, 1);
    Q = L_mat * Q0 * R_mat;
end
M = inv(Q); % p is small, numerically safe

if strcmpi(abundance_mode, 'explicit')
    A_eff = theta.S_explicit;
    cache = [];
else
    [A_eff, ~, ~, cache] = abundance_net_forward_nl(coords, theta, net_lin);
end

Y_hat = M * A_eff;
diff = Y_hat - Y;

% --- reconstruction weights (v0.6) ------------------------------------
% 'uniform' (default): after signal-covariance whitening the working-space
%   noise is only weakly heteroscedastic, and uniform weighting keeps the
%   min-volume geometry anchored by ALL pixels (bright vertices included);
%   the Poisson adaptation is carried by the enclosure margins below.
% 'pearson': heteroscedastic GLS with plug-in variances (v0.5 behaviour).
% 'irls'   : heteroscedastic GLS with variances recomputed from the
%   CURRENT RECONSTRUCTION every iteration (proper IRLS; removes the
%   Pearson plug-in feedback that lets the net fit its own weight noise).
eps_var = 1e-12;
use_w = use_poisson && ~strcmpi(noise_weight, 'uniform');
if use_poisson && strcmpi(noise_weight, 'irls')
    Yh_chan = irls_ctx.Up_sub * (irls_ctx.Cinv .* (sqrt(p)*Y_hat(1:p-1,:))) + irls_ctx.my;
    VarY = max(Yh_chan, irls_ctx.floor/irls_ctx.gain) / irls_ctx.gain + irls_ctx.rs2;
    Vpix = irls_ctx.B2 * VarY;                          % stop-grad
    med_i = median(Vpix(Vpix > 0)); Vpix(Vpix <= 0) = med_i;
end
if use_w
    W_rec = 1./(Vpix + eps_var);                        % stop-grad weights
    W_rec = W_rec / mean(W_rec(:));                     % mean weight 1
    loss_recon = mean(sum(diff.^2 .* W_rec, 1));
else
    loss_recon = mean(sum(diff.^2,1));
end

if strcmpi(qparam, 'free')                              % v1.0-E3 (E3g)
    loss_vol = -log(max(abs(det(Q)), 1e-300));          % -log|det Q|
else
    loss_vol = -sum(theta.r_log); % log|det(Q0)| omitted as constant
end

% --- chance-constraint margin -------------------------------------------------
% Poisson: original pixel-adaptive chance margin (UNCHANGED).
% Legacy Gaussian/LS: zero noise-tolerance margin (hard QY >= 0 enclosure),
% matching the older pisco_e3_train.m implementation.
if use_poisson
    sigma2 = (Q.^2) * Vpix + eps_var;                    % p x N
    margin = phi_inv * min(sqrt(sigma2), sigma_cap);     % p x N, <= 0
elseif use_gaussian
    margin = 0.5;  % Legacy Gaussian/LS hard enclosure; not a Gaussian chance margin.
else
    margin = 0;
end

penalty = min(A_eff, 0);                               % strict A >= 0 (v0.5)
loss_nonneg = sum(penalty.^2, 'all');

sum_A = sum(A_eff,1);
loss_sumone = sum((sum_A-1).^2, 'all');

col_sums = sum(Q,1);
loss_eq = sum((col_sums - qm).^2, 'all');

% --- optional data-enclosure penalty QY >= margin ---
QY = Q*Y;
pen_enclose = min(QY - margin, 0);
loss_enclose = sum(pen_enclose.^2, 'all');

% E3a enhanced: robust noise-aware multiscale graph loss and exact raw dL/dS.
% All neighbor weights depend only on Y. Their derivatives are zero.
% The pre-existing single-scale implementation is preserved as a fallback.
loss_spatial = 0;
spatial_grad_A = [];
if lambda_spatial > 0 && H_img*W_img == size(Y,2)
    if strcmpi(spatial_guide.penalty,'quadratic')
        [loss_spatial, spatial_grad_A] = quadratic_spatial_loss_grad( ...
            A_eff,H_img,W_img,spatial_guide);
    elseif isfield(spatial_guide,'multiscale') && spatial_guide.multiscale
        [loss_spatial, spatial_grad_A] = multiscale_spatial_loss_grad( ...
            A_eff,H_img,W_img,spatial_delta,spatial_guide);
    else
        [loss_spatial, spatial_grad_A] = legacy_spatial_loss_grad( ...
            A_eff,H_img,W_img,spatial_delta,spatial_guide);
    end
end

loss = loss_recon + lambda_vol*loss_vol + lambda_nonneg*loss_nonneg + ...
    lambda_sumone*loss_sumone + lambda_eq*loss_eq + ...
    lambda_enclose*loss_enclose + lambda_spatial*loss_spatial;

N = size(Y,2);
if use_w
    dY_hat = 2*diff.*W_rec/N;                          % GLS gradient     <<< NEW
else
    dY_hat = 2*diff/N;
end
dM = dY_hat * A_eff';

% --- v0.8/v0.9: band-space endmember priors (spectra >= 0; spectral smoothness)
if (lambda_mnn > 0 || lambda_smooth > 0) && ~isempty(lift_ctx)
    if strcmp(lift_ctx.mode, 'sph')
        M_band = lift_ctx.Up_sub * (lift_ctx.sD .* (lift_ctx.sqp*M(1:p-1,:))) ...
               + lift_ctx.my;                                   % L x p
    else
        M_band = lift_ctx.Up_full * M;
    end
    dM_band = zeros(size(M_band));
    if lambda_mnn > 0
        pen_M = min(M_band, 0);
        loss  = loss + lambda_mnn * sum(pen_M.^2, 'all');
        dM_band = dM_band + 2*lambda_mnn*pen_M;                 % L x p
    end
    if lambda_smooth > 0                                        % <<< NEW v0.9
        % 2nd-difference Tikhonov on the band-space endmembers: suppresses
        % spurious narrow peaks/dips that shot noise imprints on M.
        D2M = M_band(3:end,:) - 2*M_band(2:end-1,:) + M_band(1:end-2,:);
        loss = loss + lambda_smooth * sum(D2M.^2, 'all');
        g2 = zeros(size(M_band));
        g2(3:end,:)   = g2(3:end,:)   + 2*lambda_smooth*D2M;
        g2(2:end-1,:) = g2(2:end-1,:) - 4*lambda_smooth*D2M;
        g2(1:end-2,:) = g2(1:end-2,:) + 2*lambda_smooth*D2M;
        dM_band = dM_band + g2;
    end
    if strcmp(lift_ctx.mode, 'sph')
        gmnn = zeros(p,p);
        gmnn(1:p-1,:) = lift_ctx.sqp * (lift_ctx.sD .* (lift_ctx.Up_sub' * dM_band));
    else
        gmnn = lift_ctx.Up_full' * dM_band;
    end
    dM = dM + gmnn;   % chain rule through M = inv(Q) handled below
end

grad_Q_recon = -M' * dM * M';
grad_Q_eq = 2 * repmat(col_sums - qm, p, 1);
grad_Q_enclose = 2 * pen_enclose * Y';
grad_Q_clean = grad_Q_recon + lambda_eq * grad_Q_eq + lambda_enclose * grad_Q_enclose;

if strcmpi(qparam, 'free')                              % v1.0-E3 (E3g)
    % free transform: d(-log|det Q|)/dQ = -inv(Q)'
    grad.Delta = grad_Q_clean - lambda_vol * inv(Q).';
else
    % Map Q-gradients to triangular parameters
    grad_L_mat = grad_Q_clean * R_mat' * Q0';
    grad_R_mat = Q0' * L_mat' * grad_Q_clean;
    grad.L = tril(grad_L_mat, -1);
    grad.R = triu(grad_R_mat, 1);
    grad.r_log = diag(grad_R_mat) .* exp(theta.r_log) - lambda_vol;
end

% Backprop to abundance network (margin treated as constant)
dA_eff = M' * dY_hat + 2*lambda_nonneg*penalty + ...
    2*lambda_sumone*repmat(sum_A-1, p, 1);

spatial_stats = struct('loss',loss_spatial,'effective_lambda',0, ...
                       'grad_ratio',0,'gain',0);
% E3a enhanced: balance spatial gradient at the parameters it actually updates.
% Implicit: S-Net output/head gradient; Explicit: direct abundance gradient.
% Balancing ratio is stop-gradient for this step, hence a semi-gradient method.
if ~isempty(spatial_grad_A)
    effective_lambda = lambda_spatial;
    if isfield(spatial_guide,'grad_balance') && spatial_guide.grad_balance
        if strcmpi(abundance_mode,'explicit')
            % Explicit abundance has no S-Net; compare p-by-N update gradients.
            gdata = norm(dA_eff,'fro');
            gspat = norm(spatial_grad_A,'fro');
        else
            A_base = cache.A_base;
            jac_diag = 1 + 2*cache.c*cache.G.*A_base;
            ddata = dA_eff .* jac_diag;
            dspat = spatial_grad_A .* jac_diag;
            zdata = A_base .* (ddata - sum(A_base.*ddata,1));
            zspat = A_base .* (dspat - sum(A_base.*dspat,1));
            Wdata = zdata*cache.H2';  Bdata = sum(zdata,2);
            Wspat = zspat*cache.H2';  Bspat = sum(zspat,2);
            gdata = sqrt(sum(Wdata(:).^2) + sum(Bdata(:).^2));
            gspat = sqrt(sum(Wspat(:).^2) + sum(Bspat(:).^2));
        end
        if isfinite(gdata) && isfinite(gspat) && ...
                gdata > 1e-14 && gspat > 1e-14
            desired_gain = spatial_guide.target_ratio*gdata/(lambda_spatial*gspat);
            spatial_gain = min(max(desired_gain,spatial_guide.gain_min), ...
                               spatial_guide.gain_max);
            effective_lambda = lambda_spatial * spatial_gain;
        end
    end
    spatial_stats.effective_lambda = effective_lambda;
    spatial_stats.gain = effective_lambda/max(lambda_spatial,realmin('double'));
    if exist('gdata','var') && exist('gspat','var') && gdata > 0
        spatial_stats.grad_ratio = effective_lambda*gspat/gdata;
    else
        spatial_stats.grad_ratio = NaN;  % balance disabled, not measured
    end
    dA_eff = dA_eff + effective_lambda*spatial_grad_A;
    % Report the loss corresponding to the frozen per-step gain.
    % This is NOT the gradient of one fixed objective when balancing is on.
    loss = loss + (effective_lambda-lambda_spatial)*loss_spatial;
end

if strcmpi(abundance_mode, 'explicit')
    % v13 E3c: direct per-pixel abundance optimization; all losses above
    % are unchanged, only the abundance parameterization is different.
    grad.S_explicit = dA_eff;
else
    grad_net = abundance_net_backward_nl(dA_eff, cache, theta);
    grad.W1 = grad_net.W1; grad.b1 = grad_net.b1;
    grad.W2 = grad_net.W2; grad.b2 = grad_net.b2;
    grad.W3 = grad_net.W3; grad.b3 = grad_net.b3;
    grad.Wg1 = grad_net.Wg1; grad.bg1 = grad_net.bg1;
    grad.Wg2 = grad_net.Wg2; grad.bg2 = grad_net.bg2;
    grad.c = grad_net.c;
end
end

function [theta, m, v] = adam_update_struct(theta, grad, m, v, iter, lr, ...
    q_lr_scale, q_step, gate_step, gate_active)
% Separate Adam bias-correction clocks for Q / nonlinear gate, since these
% groups remain frozen during warm-up. Shared S-Net params use 'iter'.
% Skipping an inactive group also leaves its Adam moment vectors at zero.
beta1 = 0.9; beta2 = 0.999; eps = 1e-8;
fields = fieldnames(theta);
for i = 1:numel(fields)
    f = fields{i};
    is_q = any(strcmp(f, {'L','R','r_log','Delta'}));
    is_gate = any(strcmp(f, {'Wg1','bg1','Wg2','bg2','c'}));
    if is_q
        if q_lr_scale <= 0, continue; end
        t = q_step;
        local_lr = lr*q_lr_scale;
    elseif is_gate
        if ~gate_active, continue; end
        t = gate_step;
        local_lr = lr;
    else
        t = iter;
        local_lr = lr;
    end
    m.(f) = beta1*m.(f) + (1-beta1)*grad.(f);
    v.(f) = beta2*v.(f) + (1-beta2)*grad.(f).^2;
    m_hat = m.(f) / (1 - beta1^t);
    v_hat = v.(f) / (1 - beta2^t);
    theta.(f) = theta.(f) - local_lr * m_hat ./ (sqrt(v_hat) + eps);
end
end
