%% add_demo_pisco_E2_iid_spatial_paired_GYL.m
% E-2: structure-free i.i.d. Dirichlet(1) abundance fields, paired ablation
% of the EXACT four-neighbor quadratic spatial prior in PISCO (v77).
% 30 paired realizations, 100x100, 32 channels, four FP spectra,
% 20 mean detected photons/channel + 1-count Gaussian read-out.
%
% Dependencies (put beside this script or on MATLAB path):
%   pisco_e3_train_E2.m  (small, opt-in spatial-loss extension of supplied E3 model)
%   VCA.m               (original trainer dependency)
%   PISCO_M_32x4_HyU_strict_quasar32.mat  (variable M: 32x4)
%
% This is a SCRIPT (not a function). Existing E3 trainer is NEVER modified.
% Study arms are identical except LAMBDA_SPATIAL = 0 or 2.
% Spatial mode is quadratic, 4-neighbor, unweighted, constant lambda; no
% multiscale links and no automatic gradient balancing.
%
% Exactly ONE result file in ./E2_iid_spatial_results/:
%   pisco_E2_iid_spatial_paired.mat
% It contains all 30 paired per-run metrics, statistical tests and summaries.
% Updated in-place after every arm (restart checkpoint) and after statistics.
% No CSV / SVG / extra MAT is produced. Plotting can be done later from MAT.
%
% Important: statistical non-significance is NOT proof of equivalence/non-inferiority.
% poissrnd is required for the exact Poisson sampler. Wilcoxon signed-rank
% test is implemented directly without signedrank (toolbox-free).
% Requires VCA and PISCO trainer. Not numerically tested in MATLAB.

clear; close all; clc;

%% 0. Formal protocol -----------------------------------------------------
QUICK         = false;              % true: 2 replicates, 12x12, short smoke test
RESUME        = true;               % continue from same protocol checkpoint
BASE_SEED     = 1001;
N_RUNS        = 30;
IMG_H         = 100;
IMG_W         = 100;
PHOTONS       = 20;                 % expected photons PER CHANNEL, after gain
READ_SIG      = 1.0;                % read-out standard deviation in counts
MAX_PURITY    = 0.8;
N_TOTAL_ITERS = 2500;               % includes warm-up
N_WARM       = 600;
FAIL_SAD_DEG  = 20;

if QUICK
    N_RUNS = 2; IMG_H = 12; IMG_W = 12;
    N_TOTAL_ITERS = 100; N_WARM = 20;
end
N = IMG_H*IMG_W;
LAMBDA_GRID = [0 2];
ARM_NAMES   = {'iid_spatial_off', 'iid_spatial_on'};

THIS_SCRIPT = mfilename('fullpath');
SCRIPT_DIR = fileparts(THIS_SCRIPT);
if isempty(SCRIPT_DIR), SCRIPT_DIR = pwd; end
addpath(SCRIPT_DIR);
OUT_DIR = fullfile(SCRIPT_DIR,'E2_iid_spatial_results');
if ~exist(OUT_DIR,'dir'), mkdir(OUT_DIR); end
OUT_MAT = fullfile(OUT_DIR,'pisco_E2_iid_spatial_paired.mat');

assert(exist('pisco_e3_train_E2','file')==2, 'Missing pisco_e3_train_E2.m');
assert(exist('VCA','file')==2, 'Missing VCA.m (required by trainer).');
assert(exist('poissrnd','file')==2, 'Statistics toolbox poissrnd is required.');

M_FILE = fullfile(SCRIPT_DIR,'PISCO_M_32x4_HyU_strict_quasar32.mat');
if ~isfile(M_FILE)
    mloc = which('PISCO_M_32x4_HyU_strict_quasar32.mat');
    assert(~isempty(mloc), 'Cannot find PISCO_M_32x4_HyU_strict_quasar32.mat');
    M_FILE = mloc;
end
T = load(M_FILE);
assert(isfield(T,'M'), 'Reference MAT file must contain variable M.');
M_true = double(T.M);
[L,p] = size(M_true);
assert(L == 32 && p == 4, 'Expected 32x4 matrix M.');
assert(all(isfinite(M_true(:))) && all(M_true(:)>=0), 'Invalid M_true.');
assert(all(vecnorm(M_true)>0), 'M_true contains zero columns.');
clear T;

% Do NOT change these between arms. Each run has fresh abundance, noise,
% and model initialization, all shared by the two arms within that run.
SEEDS = BASE_SEED + (0:N_RUNS-1);
PROTOCOL = struct('N_RUNS',N_RUNS,'H',IMG_H,'W',IMG_W,'PHOTONS',PHOTONS, ...
    'READ_SIG',READ_SIG,'MAX_PURITY',MAX_PURITY, 'N_TOTAL_ITERS',N_TOTAL_ITERS, ...
    'N_WARM',N_WARM,'FAIL_SAD_DEG',FAIL_SAD_DEG,'LAMBDA_GRID',LAMBDA_GRID, ...
    'BASE_SEED',BASE_SEED,'M_FILE',M_FILE,'TRAINER','pisco_e3_train_E2');

metric_names = {'SAD_deg','MSE_ab','MSE_rec_clean','viol_anc','viol_asc','fail','wall_s'};
% Each metric is [arms x run], with first index off then on.
SAD = nan(2,N_RUNS); ABMSE = nan(2,N_RUNS); RECMSE = nan(2,N_RUNS);
ANC = nan(2,N_RUNS); ASC = nan(2,N_RUNS); FAIL = nan(2,N_RUNS);
WALL = nan(2,N_RUNS); DONE = false(2,N_RUNS);

if RESUME && isfile(OUT_MAT)
    A = load(OUT_MAT, 'PROTOCOL','SEEDS','SAD','ABMSE','RECMSE', ...
        'ANC','ASC','FAIL','WALL','DONE');
    assert(isfield(A,'PROTOCOL') && isequaln(A.PROTOCOL,PROTOCOL), ...
        'Existing checkpoint belongs to another protocol. Move it before rerun.');
    assert(isequal(A.SEEDS, SEEDS), 'Checkpoint seed list mismatch.');
    SAD=A.SAD; ABMSE=A.ABMSE; RECMSE=A.RECMSE;
    ANC=A.ANC; ASC=A.ASC; FAIL=A.FAIL; WALL=A.WALL;
    DONE=A.DONE;
    clear A;
end

fprintf('E-2: %dx%d | %d photons/channel | %d paired repeats | p=%d\n', ...
    IMG_H,IMG_W,PHOTONS,N_RUNS,p);
fprintf('Off/on only difference: LAMBDA_SPATIAL = 0 / 2.\n');

%% 1. Paired Monte Carlo experiment ---------------------------------------
for r = 1:N_RUNS
    if all(DONE(:,r))
        fprintf('run %d/%d: already completed, skipping.\n',r,N_RUNS);
        continue;
    end
    sr = SEEDS(r);
    % i.i.d. Dirichlet(1): each pixel independently samples p Gamma(1,1)
    % variables and normalizes them to sum one. Exceeding purity threshold
    % is handled by FULL REJECTION / RESAMPLING, never clipping.
    rng(sr+10000,'twister');
    S_true = zeros(p,N);
    pending = 1:N;
    while ~isempty(pending)
        G = -log(max(rand(p,numel(pending)), realmin('double')));
        S_new = G ./ sum(G,1);
        accept = max(S_new,[],1) <= MAX_PURITY;
        S_true(:,pending(accept)) = S_new(:,accept);
        pending = pending(~accept);
    end
    assert(max(S_true(:)) <= MAX_PURITY+1e-12);
    assert(max(abs(sum(S_true,1)-1)) < 1e-12);

    Y_clean = M_true*S_true;
    % The expected grand mean in CHANNELxPIXEL count space equals PHOTONS.
    photon_gain = PHOTONS * (L*N) / sum(Y_clean(:));
    rng(sr+20000,'twister');
    Y_counts = double(poissrnd(photon_gain*Y_clean)) + READ_SIG*randn(L,N);
    Y_in = Y_counts / photon_gain;

    base_args = { ...
        'spherize','yes', 'verbose',0, ...
        'MM_ITERS',N_TOTAL_ITERS, 'WARM_UP',N_WARM, 'LR',3e-4, ...
        'LAMBDA_VOL',0.008, 'LAMBDA_NONNEG',3, 'LAMBDA_EQ',100, ...
        'LAMBDA_SUMONE',2, 'LAMBDA_ENCLOSE',10, ...
        'LAMBDA_SPATIAL',0, ...          % ONLY value overwritten per arm below
        'LAMBDA_MNONNEG',10, 'LAMBDA_SMOOTH',0.1, ...
        'SPATIAL_PENALTY','quadratic', ...
        'SPATIAL_GUIDE_MODE','uniform', ...
        'SPATIAL_MS_ENABLE',false, ...
        'SPATIAL_GRAD_BALANCE',false, ...
        'SPATIAL_SCHEDULE','constant', ...
        'IMG_H',IMG_H,'IMG_W',IMG_W, ...
        'NOISE_MODEL','poisson', 'NOISE_WEIGHT','uniform', ...
        'ETA',0.3, 'ETA_END',0.3, 'SIGMA_CAP',0.03, ...
        'PHOTON_GAIN',photon_gain, 'PHOTON_FLOOR',1, ...
        'READ_SIGMA',READ_SIG, ...
        'ABUNDANCE_MODE','explicit', 'GATED',true, ...
        'QPARAM','coupled','COORDS','2d'};

    for arm = 1:2
        if DONE(arm,r), continue; end
        args = base_args;
        ix = find(strcmpi(args(1:2:end),'LAMBDA_SPATIAL'));
        assert(numel(ix)==1);
        args{2*ix} = LAMBDA_GRID(arm);
        % Reset the SAME initialization RNG for both arms, irrespective
        % of data generation RNG consumption and previous optimizer runs.
        rng(sr+30000,'twister');
        t0 = tic;
        [M_est,S_est] = pisco_e3_train_E2(Y_in,p,args{:});
        WALL(arm,r) = toc(t0);
        assert(isequal(size(M_est),[L p]), 'Estimated M has wrong size.');
        assert(isequal(size(S_est),[p N]), 'Estimated S has wrong size.');
        assert(all(isfinite(M_est(:))) && all(isfinite(S_est(:))), ...
            'Model returned nonfinite M/S.');

        % Optimal one-to-one assignment by exhaustive permutations (p=4,
        % only 4!=24 candidates). Pairwise SAD ignores column scale.
        C = nan(p,p);
        for ii=1:p
            for jj=1:p
                den = norm(M_true(:,ii))*norm(M_est(:,jj));
                if den > 0
                    c = (M_true(:,ii)'*M_est(:,jj)) / den;
                    C(ii,jj) = acosd(max(-1,min(1,c)));
                end
            end
        end
        assert(all(isfinite(C(:))), 'SAD matching failed: zero endmember.');
        Pi = perms(1:p);
        costs = zeros(size(Pi,1),1);
        for kk=1:size(Pi,1)
            costs(kk) = sum(C(sub2ind([p p],1:p,Pi(kk,:))));
        end
        [~,kbest] = min(costs);
        perm = Pi(kbest,:);   % true index i -> estimated index perm(i)
        id = sub2ind([p p],1:p,perm);
        SAD(arm,r) = mean(C(id));
        ABMSE(arm,r) = mean((S_true(:)-reshape(S_est(perm,:),[],1)).^2);
        Y_hat = M_est*S_est;
        RECMSE(arm,r) = mean((Y_hat(:)-Y_clean(:)).^2);
        ANC(arm,r) = mean(min(S_est,[],1) < -1e-4); % pixel violation
        ASC(arm,r) = mean(abs(sum(S_est,1)-1) > 1e-3); % pixel violation
        FAIL(arm,r) = double(SAD(arm,r) > FAIL_SAD_DEG);
        DONE(arm,r) = true;

        fprintf(['run %02d/%02d | %-17s | SAD=%7.3f deg | ' ...
           'AbMSE=%.4e | ANC=%.2g ASC=%.2g | %.1fs\n'], ...
           r,N_RUNS,ARM_NAMES{arm},SAD(arm,r),ABMSE(arm,r), ...
           ANC(arm,r),ASC(arm,r),WALL(arm,r));
        % Checkpoint each arm to avoid losing results after an interrupted run.
        save(OUT_MAT,'PROTOCOL','SEEDS','metric_names','ARM_NAMES','M_true', ...
            'SAD','ABMSE','RECMSE','ANC','ASC','FAIL','WALL','DONE','-v7');
    end
    clear Y_clean Y_counts Y_in S_true;
end

assert(all(DONE(:)), 'Experiment incomplete. Checkpoint saved; rerun to resume.');

%% 2. Paired Wilcoxon (exact sign-flip null) + means / std ----------------
METRIC_MATS = {SAD,ABMSE,RECMSE,ANC,ASC,FAIL,WALL};
METRIC_LABEL = {'SAD_deg','MSE_ab','MSE_rec_clean','viol_anc', ...
    'viol_asc','failure_fraction','time_s'};
pvals = nan(1,numel(METRIC_MATS));
means = zeros(2,numel(METRIC_MATS));
stds = zeros(2,numel(METRIC_MATS));
medians = zeros(2,numel(METRIC_MATS));
median_delta = nan(1,numel(METRIC_MATS));
n_on_worse = nan(1,numel(METRIC_MATS));

for k=1:numel(METRIC_MATS)
    a = METRIC_MATS{k};
    means(:,k) = mean(a,2);
    stds(:,k) = std(a,0,2);
    medians(:,k) = median(a,2);
    d = a(2,:)-a(1,:);
    median_delta(k) = median(d);
    n_on_worse(k) = nnz(d>0);
    % Two-sided paired Wilcoxon signed-rank test without signedrank/tiedrank.
    % Zero differences are excluded. Absolute differences receive mid-ranks
    % when tied. A subset-sum DP enumerates the null sign-flip distribution
    % exactly (2^n possibilities compressed into rank sums; n<=30 here).
    nonzero = isfinite(d) & abs(d) > 1e-14;
    d_nz = d(nonzero);
    n_valid = numel(d_nz);
    if n_valid == 0
        pvals(k) = 1.0;
    else
        [sorted_abs,order] = sort(abs(d_nz(:)'));
        ranks_sorted = zeros(1,n_valid);
        i = 1;
        while i <= n_valid
            j = i;
            while j < n_valid && sorted_abs(j+1) == sorted_abs(i)
                j = j+1;
            end
            ranks_sorted(i:j) = (i+j)/2; % average ranks for ties
            i = j+1;
        end
        ranks = zeros(1,n_valid);
        ranks(order) = ranks_sorted;
        weights2 = round(2*ranks); % doubled ranks -> integer DP weights
        rank_sum2 = sum(weights2);
        w_observed2 = sum(weights2(d_nz>0));
        mass = zeros(1,rank_sum2+1);
        mass(1) = 1;
        for j = 1:n_valid
            w = weights2(j);
            mass(w+1:end) = mass(w+1:end) + mass(1:end-w);
        end
        rank_grid2 = 0:rank_sum2;
        observed_distance2 = abs(w_observed2-rank_sum2/2);
        is_as_extreme = abs(rank_grid2-rank_sum2/2) >= observed_distance2-1e-10;
        pvals(k) = min(1,sum(mass(is_as_extreme))/2^n_valid);
    end
end

fprintf('\nE-2 PAIRED RESULTS (%d repeats):\n',N_RUNS);
for k=1:numel(METRIC_MATS)
    fprintf('%-17s: off=%g +/- %g, on=%g +/- %g, Wilcoxon p=%.4g\n', ...
        METRIC_LABEL{k},means(1,k),stds(1,k),means(2,k),stds(2,k),pvals(k));
end
fprintf('Failure counts: off=%d, on=%d (SAD>%.0f deg)\n', ...
    sum(FAIL(1,:)),sum(FAIL(2,:)),FAIL_SAD_DEG);

%% 3. Store everything needed for paper analysis in this ONE MAT file ----
% Matrix convention: row 1 = spatial OFF (lambda 0), row 2 = spatial ON
% (lambda 2); columns = paired Monte Carlo realizations (seed 1001..1030).
% METRIC_LABEL aligns with STATS columns and pvals/means/stds/medians.
ratios = nan(1,numel(METRIC_MATS));
nonzero_mean = abs(means(1,:)) > 0;
ratios(nonzero_mean) = means(2,nonzero_mean)./means(1,nonzero_mean);
STATS = struct( ...
    'metric_labels',{METRIC_LABEL}, ...
    'means',means,'stds',stds,'medians',medians, ...
    'paired_wilcoxon_p',pvals, ...
    'mean_difference_on_minus_off',means(2,:)-means(1,:), ...
    'median_difference_on_minus_off',median_delta, ...
    'mean_ratio_on_over_off',ratios, ...
    'n_on_worse',n_on_worse, ...
    'failure_counts',sum(FAIL,2));

% Same MAT was already saved after each arm as a checkpoint. Overwrite it
% with the fully computed statistics, keeping all raw paired observations.
save(OUT_MAT,'PROTOCOL','SEEDS','metric_names','ARM_NAMES','M_true', ...
    'SAD','ABMSE','RECMSE','ANC','ASC','FAIL','WALL','DONE', ...
    'METRIC_LABEL','pvals','means','stds','medians','median_delta', ...
    'n_on_worse','STATS','-v7');
fprintf('\nSingle output MAT: %s\n', OUT_MAT);
fprintf('The MAT contains all paired measurements, summary statistics, and p-values.\n');
