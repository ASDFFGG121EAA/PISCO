%% demo_pisco_E3_ablation.m
% PISCO-only demo for experiment E3 (ablation suite): the full model and
% v13 ablated configurations on biologically calibrated simulated data.
%
% Updated to the experimental-design document v13, E3 entry
% ("E3 消融实验", 512x512 simulation; SI Note 5 / Supplementary Table 8 /
% Supplementary Fig. 4) and the simulation protocol of sec. 2.1:
%   - endmembers   : real FPbase / HyU-calibrated spectra loaded from
%                    PISCO_M_32x4_HyU_strict_quasar32.mat
%                    (p = 4), 32 Quasar channels
%   - abundances   : biological-mask-derived spatial abundance fields using
%                    build_Strue_from_masks.m; purity cap 0.8, no pure pixels
%   - noise        : Poisson photon noise + Gaussian read-out (sigma = 1);
%                    identical photon-count convention to the E2 biomask demo
%   - scene        : 512 x 512 pixels (E3 design size)
%   - photon level : 20 mean photons per channel (reference level for the
%                    ablation table; campaign note: E3a is additionally
%                    specified at 10 photons and the paired arms E3b/E3e
%                    at 100 photons -- rerun this demo with PHOTONS = 10
%                    or 100 for those rows)
%   - repeats      : 30 independent paired Monte-Carlo repeats (v13 formal protocol)
%
% Configurations (v13 E3; PISCO self-ablation):
%   full            default PISCO
%   no_spatial      E3a  LAMBDA_SPATIAL = 0
%   gauss_margin    E3b  NOISE_MODEL = 'gaussian' (kept as current code)
%   explicit_S      E3c  explicit p x N trainable abundances instead of S-Net
%   no_warmup       E3d  WARM_UP = 0
%   no_anneal       E3e  ETA_END = ETA = 0.1
%   no_nonneg       E3f  LAMBDA_NONNEG = 0 (abundance non-negativity term off)
%   no_enclose      E3f  LAMBDA_ENCLOSE = 0 (data-enclosure term off)
%   direct_M        E3g  QPARAM = 'free' (kept as current free-Q implementation)
%   coord_1d        E3h  COORDS = '1d'
%   no_gate         E3i  GATED = false (c = 0)
%   hard_constraint E3j  ETA = ETA_END = 0.5 -> zero chance margin, no annealing
%
% Outputs (matching Supplementary Table 8 columns):
%   SAD (deg), abundance MSE, reconstruction MSE (vs noise-free cube),
%   constraint violation rates (ANC: fraction of pixels with min
%   abundance < -1e-4; ASC: fraction with |sum-1| > 1e-3), convergence-
%   failure flag (SAD > 20 deg; quantifies E3d/E3g stability claims),
%   wall time. CSV per config x run + console summary (mean +/- std) +
%   bar-chart figure (Suppl. Fig. 4 style) + representative spectra.
%
% Trainer: pisco_e3_train.m (v1.0-E3; v0.9 + additive ablation switches,
% defaults identical to v0.9).
%
% v1.0-E3 (2026-09-22): initial release, aligned with design doc v5.
% v1.1-E3 (2026-09-23): MATLAB syntax fix -- replaced the Octave-only
%   expression indexing "(M_est*S_eval)(:)" with the MATLAB-legal
%   reshape(M_est*S_eval, [], 1); numerically identical. (Users who
%   already applied this fix locally: no re-download needed.)
%
% Required on the MATLAB path:
%   VCA.m
%   pisco_e3_train_b1.m
%   build_Strue_from_masks.m
%   PISCO_M_32x4_HyU_strict_quasar32.mat
% Requires the Statistics and Machine Learning Toolbox (poissrnd).
% MATLAB R2023a.
%
% Runtime estimate: QUICK = true -> ~2-4 min (128x128, 2 repeats,
%   4 configs, 800 iters). Formal v13 run uses 512x512, 30 repeats
%   across all configured ablation arms; runtime depends strongly on hardware.

clear all; close all; clc;

%% E3.0 Protocol ---------------------------------------------------------
QUICK       = false;   % true = smoke test (128x128, 2 repeats, 4 configs)
N_RUNS      = 30;      % v13 formal paired Monte-Carlo repeats
BASE_SEED   = 42;
SIZE        = 128;     % E3 design scene: 512 x 512
PHOTONS     = 10;      % reference photon level (see header for 10/100)
READ_SIG    = 1.0;     % Gaussian read-out noise, counts
MM_ITERS    = 2500;    % joint-phase length (SI Table 3 default)
WARM_UP     = 600;     % warm-up length (SI Table 3 default)
FAIL_SAD    = 20;      % convergence-failure threshold (deg SAD)
OUT_CSV     = 'pisco_E3_ablation_v13_biomask_results_Q0.csv';

% Same real FP spectra and biological-mask protocol used by the E2 biomask demo.
THIS_SCRIPT = mfilename('fullpath');
SCRIPT_DIR = fileparts(THIS_SCRIPT);
if isempty(SCRIPT_DIR)
    SCRIPT_DIR = pwd;
end

M_FILE          = fullfile(SCRIPT_DIR,'PISCO_M_32x4_HyU_strict_quasar32.mat');
MASK_ROOT       = fullfile(SCRIPT_DIR,'use');
MASK_SIGMA      = 2.0;    % Gaussian smoothing sigma in target-image pixels
MASK_BACKGROUND = 0.02;   % positive floor before sum-to-one normalization
MAX_PURITY      = 0.8;

% name, design-doc id, trainer overrides, legacy post-refinement flag
% (4th column is retained for compatibility; all v13 E3 arms use false.)
CONFIGS = { ...
 'full',            'E3-full',       {}, false; ...%'LAMBDA_ENCLOSE',0.01
 'no_spatial',      'E3a', {'LAMBDA_SPATIAL',0}, false; ...
 'gauss_margin',    'E3b', {'NOISE_MODEL','gaussian'}, false; ...%13
%% 'explicit_S',      'E3c', {'ABUNDANCE_MODE','explicit'}, false; ...
 'no_warmup',       'E3d', {'WARM_UP',0}, false; ...%9/14
%% 'no_anneal',       'E3e', {'ETA_END',0.1}, false; ...
 'no_nonneg',       'E3f', {'LAMBDA_NONNEG',0}, false; ...
 'no_enclose',      'E3f', {'LAMBDA_ENCLOSE',0}, false; ...
 'no_volume',    'E3f', {'LAMBDA_VOL',0}, false; ...
 'direct_M',        'E3g', {'QPARAM','free'}, false; ...
%% 'coord_1d',        'E3h', {'COORDS','1d'}, false; ...
%% 'no_gate',         'E3i', {'GATED',false}, false; ...
 'hard_constraint', 'E3j', {'ETA',0.5,'ETA_END',0.5}, false;...
  };

if QUICK
    SIZE = 128; N_RUNS = 2; MM_ITERS = 800; WARM_UP = 200;
    CONFIGS = CONFIGS([1, 2, 4, 11], :);
end

%% E3.1 Real endmembers + biological-mask pool ---------------------------
IMG_H = SIZE;
IMG_W = SIZE;
N = IMG_H * IMG_W;

% ---- Load the same real 32x4 protein spectra used by the E2 biomask demo ----
if ~isfile(M_FILE)
    error(['Cannot find %s.\n' ...
           'Put PISCO_M_32x4_HyU_strict_quasar32.mat next to this script.'], ...
          M_FILE);
end

Dspec = load(M_FILE);

if ~isfield(Dspec,'M')
    error('%s does not contain variable M.',M_FILE);
end

M_true = double(Dspec.M);
[L,p] = size(M_true);

if L ~= 32 || p ~= 4
    error('Expected M_true to be 32 x 4, got %d x %d.',L,p);
end

if any(~isfinite(M_true(:))) || any(M_true(:) < 0)
    error('M_true must contain finite nonnegative values.');
end

if isfield(Dspec,'channel_centers_nm')
    wl = double(Dspec.channel_centers_nm(:));
    if numel(wl) ~= L
        error('channel_centers_nm must contain %d values.',L);
    end
else
    wl = linspace(410.5,694.9,L)';
end

if isfield(Dspec,'endmember_names')
    endmember_names = cellstr(string(Dspec.endmember_names));
else
    endmember_names = {'Citrine','tdTomato','mKO2','mRuby'};
end
endmember_names = reshape(endmember_names,1,[]);

clear Dspec;

% ---- Discover biological-mask scenes exactly as in the E2 biomask demo ----
% Expected layout:
%   <this script>/use/<scene_name>/masks/*.png
%   <this script>/use/<scene_name>/images/*    (not used numerically)
if ~isfolder(MASK_ROOT)
    error(['Cannot find biological-mask root folder:\n  %s\n' ...
           'Expected ./use/<scene_name>/masks/*.png next to this script.'], ...
          MASK_ROOT);
end

Dscene = dir(MASK_ROOT);
Dscene = Dscene([Dscene.isdir]);
Dscene = Dscene(~ismember({Dscene.name},{'.','..'}));

scene_dirs = {};
for ii = 1:numel(Dscene)
    candidate = fullfile(MASK_ROOT,Dscene(ii).name);
    mask_dir = fullfile(candidate,'masks');
    if isfolder(mask_dir) && ~isempty(dir(fullfile(mask_dir,'*.png')))
        scene_dirs{end+1} = candidate; %#ok<SAGROW>
    end
end

if isempty(scene_dirs)
    error(['No usable biological scenes were found under:\n  %s\n' ...
           'Each scene must contain masks/*.png.'],MASK_ROOT);
end

[~,ord_scene] = sort(lower(string(scene_dirs)));
scene_dirs = scene_dirs(ord_scene);
nScenes = numel(scene_dirs);

fprintf('============================================================\n');
fprintf('E3 v13 ablation with real protein spectra + biological masks\n');
fprintf('============================================================\n');
fprintf('Loaded spectral file: %s\n',M_FILE);
fprintf('M_true: %d channels x %d endmembers\n',L,p);
fprintf('Scene: %d x %d = %d pixels | photons/channel = %g | repeats = %d\n', ...
    IMG_H,IMG_W,N,PHOTONS,N_RUNS);
fprintf('Biological mask pool: %d usable scenes under %s\n',nScenes,MASK_ROOT);
fprintf('Biomask abundance: sigma=%.2f | background=%.3f | max purity=%.2f\n', ...
    MASK_SIGMA,MASK_BACKGROUND,MAX_PURITY);
fprintf('Noise: Poisson + Gaussian readout, READ_SIG = %.3f counts\n',READ_SIG);
fprintf('Output CSV: %s\n',OUT_CSV);
fprintf('============================================================\n\n');

%% E3.2 Monte-Carlo ablation sweep (PISCO only) --------------------------
nC = size(CONFIGS, 1);
SAD_m  = zeros(nC, N_RUNS);  MAB_m = zeros(nC, N_RUNS);
MRC_m  = zeros(nC, N_RUNS);  VANC  = zeros(nC, N_RUNS);
VASC   = zeros(nC, N_RUNS);  FAIL  = zeros(nC, N_RUNS);
T_m    = zeros(nC, N_RUNS);

fprintf(['E3 demo (PISCO only): %d repeats x %d configs, scene %dx%d, ' ...
    '%d mean photons/channel, MM_ITERS=%d\n'], N_RUNS, nC, IMG_H, IMG_W, PHOTONS, MM_ITERS);

fid = fopen(OUT_CSV, 'w');
fprintf(fid, 'config,eid,run,scene,photons,SAD_deg,MSE_ab,MSE_rec,viol_anc,viol_asc,fail,time_s\n');

rep_done = false;
for r = 1:N_RUNS
    % --- biological-mask abundance scene --------------------------------
    % Cycle deterministically through ./use/<scene>/masks.  The helper
    % resizes/assigns/smooths masks, adds the positive background, enforces
    % sum-to-one, and caps purity at MAX_PURITY.
    scene_idx = 1 + mod(r-1,nScenes);
    scene_dir = scene_dirs{scene_idx};
    [~,scene_name] = fileparts(scene_dir);

    S_true = build_Strue_from_masks( ...
        scene_dir,IMG_H,IMG_W,p,MAX_PURITY, ...
        BASE_SEED + r,MASK_SIGMA,MASK_BACKGROUND);

    Y_clean = M_true * S_true;                 % noise-free rates

    % --- mixed noise: SAME convention as E2 biomask ----------------------
    % Use a separate deterministic RNG stream so biological-mask grouping
    % cannot change the noise realization for this repeat.
    rng(BASE_SEED + 10000 + r,'twister');

    % PHOTONS = mean photons per channel.
    g = PHOTONS * N / sum(Y_clean(:)) * L;

    Y_in = double( ...
        poissrnd(g * Y_clean) + ...
        READ_SIG * randn(L,N)) / g;            % rate units

    % Full-model arguments shared by every paired arm.  Each CONFIGS row
    % replaces only its named ablation variable(s), so every name-value
    % parameter is passed exactly once to inputParser.
    base_args = { ...
        'spherize','yes', 'verbose',0, ...
        'MM_ITERS',MM_ITERS, 'WARM_UP',WARM_UP, 'LR',3e-4, ...
        'LAMBDA_VOL',10, 'LAMBDA_NONNEG',3, 'LAMBDA_EQ',100, ...
        'LAMBDA_SUMONE',2, 'LAMBDA_ENCLOSE',10, ...
        'IMG_H',IMG_H, 'IMG_W',IMG_W, 'LAMBDA_SPATIAL',0.5, ...
        'NOISE_MODEL','poisson', 'ETA',0.3, 'ETA_END',0.3, ...
        'PHOTON_GAIN',g, 'PHOTON_FLOOR',1, 'READ_SIGMA',READ_SIG, ...
        'ABUNDANCE_MODE','explicit', 'GATED',true, ...%implicit    explicit
        'QPARAM','coupled', 'COORDS','2d'};

    for c = 1:nC
        % ---- train PISCO with exactly this config's override(s) ----
        train_args = e3_apply_overrides(base_args, CONFIGS{c,3});

        % Reset the training RNG before EVERY paired arm.  Thus full and
        % ablated models see the same data/noise and the same stochastic
        % initialization stream; the intended ablation is the controlled change.
        rng(BASE_SEED + 100000 + r,'twister');

        t_run = tic;
        [M_est, S_est] = pisco_e3_train_b1_15(Y_in, p, train_args{:});
        T_m(c,r) = toc(t_run);

        % ---- legacy optional post-refinement hook (unused by v13 E3 configs) ----
        if CONFIGS{c,4}
            S_eval = sunsal_fc(Y_in, M_est, 1000, 1e-8);
        else
            S_eval = S_est;
        end

        % ---- metrics ----
        [perm, sad_v] = e3_match(M_true, M_est);
        SAD_m(c,r) = mean(sad_v);
        MAB_m(c,r) = mean((S_true(:) - reshape(S_eval(perm,:),[],1)).^2);
        MRC_m(c,r) = mean((Y_clean(:) - reshape(M_est*S_eval, [], 1)).^2);  % v1.1-E3: MATLAB-legal indexing
        VANC(c,r)  = mean(min(S_eval,[],1) < -1e-4);
        VASC(c,r)  = mean(abs(sum(S_eval,1) - 1) > 1e-3);
        FAIL(c,r)  = SAD_m(c,r) > FAIL_SAD;

        fprintf(['run %2d/%d | %-12s (%s) | SAD %6.2f | MSE_ab %.3e | ' ...
            'viol %.1e/%.1e | t %6.1fs\n'], r, N_RUNS, CONFIGS{c,1}, ...
            CONFIGS{c,2}, SAD_m(c,r), MAB_m(c,r), VANC(c,r), VASC(c,r), ...
            T_m(c,r));
        fprintf(fid, '%s,%s,%d,%s,%g,%.4f,%.6e,%.6e,%.4e,%.4e,%d,%.2f\n', ...
            CONFIGS{c,1}, CONFIGS{c,2}, r, scene_name, PHOTONS, SAD_m(c,r), ...
            MAB_m(c,r), MRC_m(c,r), VANC(c,r), VASC(c,r), FAIL(c,r), T_m(c,r));

        if r == 1 && strcmp(CONFIGS{c,1}, 'full') && ~rep_done
            rep_M = M_est; rep_S = S_est; rep_perm = perm;
            rep_S_true = S_true; rep_done = true;
        end
    end
    clear Y_in Y_counts S_est S_eval M_est
end
fclose(fid);
fprintf('Per-run results written to %s\n', OUT_CSV);

%% E3.3 Summary (mean +/- std; v13 Supplementary Table 8 rows) --------
fprintf('\n===== E3 SUMMARY over %d repeats (PISCO only, %d mean photons/channel) =====\n', ...
    N_RUNS, PHOTONS);
fprintf(['%-12s %-7s | SAD (deg) mean+/-std | MSE_ab mean+/-std | ' ...
    'MSE_rec mean+/-std | viol ANC/ASC | fail%%\n'], 'config', 'id');
for c = 1:nC
    fprintf('%-12s %-7s | %6.2f +/- %5.2f      | %9.3e +/- %8.2e | %9.3e +/- %8.2e | %.1e / %.1e | %3.0f%%\n', ...
        CONFIGS{c,1}, CONFIGS{c,2}, ...
        mean(SAD_m(c,:)), std(SAD_m(c,:)), ...
        mean(MAB_m(c,:)), std(MAB_m(c,:)), ...
        mean(MRC_m(c,:)), std(MRC_m(c,:)), ...
        mean(VANC(c,:)), mean(VASC(c,:)), 100*mean(FAIL(c,:)));
end

%% E3.4 Figures ----------------------------------------------------------
% (1)-(3) Suppl. Fig. 4 style: SAD / abundance MSE / failure rate bars
ciSAD = 1.96 * std(SAD_m, 0, 2) / sqrt(N_RUNS);
ciMAB = 1.96 * std(MAB_m, 0, 2) / sqrt(N_RUNS);
labels = cellfun(@(a,b) sprintf('%s (%s)', a, b), ...
    CONFIGS(:,1), CONFIGS(:,2), 'UniformOutput', false);
figure('Name','E3: ablation suite (PISCO only)', ...
    'Position',[40 40 1350 420], 'Color','w');
subplot(1,3,1);
bar(mean(SAD_m,2), 'FaceColor',[0.72 0.53 0.36]); hold on;
errorbar(1:nC, mean(SAD_m,2), ciSAD, 'k.', 'LineWidth',1.2);
set(gca,'XTick',1:nC,'XTickLabel',labels,'XTickLabelRotation',45);
ylabel('Endmember SAD (deg)'); grid on;
title(sprintf('Spectral fidelity (n = %d, 95%% CI)', N_RUNS));
subplot(1,3,2);
bar(mean(MAB_m,2), 'FaceColor',[0.72 0.53 0.36]); hold on;
errorbar(1:nC, mean(MAB_m,2), ciMAB, 'k.', 'LineWidth',1.2);
set(gca,'XTick',1:nC,'XTickLabel',labels,'XTickLabelRotation',45,'YScale','log');
ylabel('Abundance MSE'); grid on; title('Abundance accuracy');
subplot(1,3,3);
bar(100*mean(FAIL,2), 'FaceColor',[0.55 0.27 0.07]);
set(gca,'XTick',1:nC,'XTickLabel',labels,'XTickLabelRotation',45);
ylabel('Failure rate (%)'); grid on;
title(sprintf('Runs with SAD > %d deg', FAIL_SAD));
sgtitle(sprintf('E3 ablation suite at %d mean photons/channel (PISCO only)', PHOTONS));

if rep_done
    % (4) representative-run endmember spectra (full model, run 1)
    figure('Name','E3: endmembers, full model (run 1)', ...
        'Position',[50 50 950 600], 'Color','w');
    for i = 1:p
        subplot(2,2,i);
        plot(wl, M_true(:,i), 'k-', 'LineWidth',2); hold on;
        ep = rep_M(:,rep_perm(i));
        plot(wl, ep/max(ep), '--', 'LineWidth',1.2, 'Color',[0.64 0.08 0.18]);
        xlabel('Wavelength (nm)'); ylabel('Normalised intensity');
        title(sprintf('%s', endmember_names{i})); grid on;
        if i==1, legend('Ground truth','PISCO full','Location','best'); end
    end
    sgtitle(sprintf('Full model at %d mean photons/channel (run 1)', PHOTONS));

    % Representative biological abundance maps: GT (top) vs full PISCO (bottom).
    figure('Name','E3: biological abundance GT vs full PISCO (run 1)', ...
        'Position',[60 60 1200 520], 'Color','w');
    for i = 1:min(4,p)
        subplot(2,4,i);
        imagesc(reshape(rep_S_true(i,:),IMG_H,IMG_W));
        caxis([0 MAX_PURITY]);
        axis image off;
        colorbar;
        title(sprintf('GT: %s',endmember_names{i}));

        subplot(2,4,4+i);
        imagesc(reshape(rep_S(rep_perm(i),:),IMG_H,IMG_W));
        caxis([0 MAX_PURITY]);
        axis image off;
        colorbar;
        title(sprintf('PISCO: %s',endmember_names{i}));
    end
    sgtitle(sprintf('Biological-mask abundances, full PISCO, %d photons/channel',PHOTONS));
end

%% ==================== local functions ================================
function args = e3_apply_overrides(base_args, overrides)
% Replace existing name-value entries in base_args; append only if absent.
% This keeps the full-model settings explicit while changing only the
% intended E3 ablation variable(s).
args = base_args;
for k = 1:2:numel(overrides)
    name = overrides{k};
    value = overrides{k+1};
    idx = [];
    for j = 1:2:numel(args)
        if strcmpi(args{j}, name)
            idx = j;
            break;
        end
    end
    if isempty(idx)
        args(end+1:end+2) = {name, value};
    else
        args{idx+1} = value;
    end
end
end

function [perm, sad_v] = e3_match(M_true, M_est)
% Greedy permutation matching by spectral angle distance.
p = size(M_true, 2);
Cmat = zeros(p);
for i = 1:p
    for j = 1:p
        Cmat(i,j) = acosd(max(-1, min(1, ...
            (M_true(:,i)'*M_est(:,j)) / ...
            (norm(M_true(:,i))*norm(M_est(:,j))))));
    end
end
perm = zeros(1,p); taken = false(1,p);
for i = 1:p
    [~,jj] = min(Cmat(i,:) + taken*1e6); perm(i) = jj; taken(jj) = true;
end
sad_v = Cmat(sub2ind([p p], 1:p, perm));
end

function S_ref = sunsal_fc(Y, M, max_it, tol)
% Fully constrained per-pixel refinement (SI Note 2.4): min_s 1/2||y-Ms||^2
% s.t. s >= 0 and 1's = 1, by scaled ADMM (SUnSAL with sparsity weight 0
% and the sum-to-one constraint enforced in the x-update via its KKT
% closed form). Vectorized over all pixels; M fixed.
p = size(M, 2);
rho = 1;
A  = M'*M + rho*eye(p);
iA = inv(A);
iA1 = iA * ones(p,1);
denom = sum(iA1);
b0 = M'*Y;                              % p x N
x = zeros(p, size(Y,2)); z = x; u = x;
for k = 1:max_it
    b  = b0 + rho*(z - u);
    xu = iA * b;
    nu = (sum(xu,1) - 1) ./ denom;      % KKT multiplier for 1'x = 1
    x  = xu - iA1 * nu;
    z  = max(x + u, 0);                 % non-negativity projection
    r  = x - z;
    u  = u + r;
    if sqrt(sum(r(:).^2)/numel(x)) < tol
        break;
    end
end
S_ref = z;
end
