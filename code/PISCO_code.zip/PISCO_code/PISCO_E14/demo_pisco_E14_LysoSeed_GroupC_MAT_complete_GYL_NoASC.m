% E14 GROUP C: Lyso-guided PCA subspace + Lyso-seeded VCA initialization.
% MAT archival update: Y_cube and plot labels saved for independent Fig A/C/H
% reproduction without the LSM or training; M0_seed_raw is NOT saved to MAT.
% Companion trainer: deep_mvsa_invflow_poisson_explicit_Warmup2_NoASC_E14C.m
% NoASC output abundances are UNNORMALIZED coefficients, NOT fractions.
% The C-group subspace is retained through the NoASC-adapted anchor parameter.
% IMPORTANT: This is a semi-supervised diagnostic, NOT official blind E14.
% It keeps p=6 with (p-2) principal axes + one Lyso-guided direction.
% Compare the SAME SEEDS and hyperparameters against A and B experiments.
% The five-stain Fig B still uses independent FOVs and its Pearson r is NOT
% a valid pixel-aligned accuracy metric. The figure is retained only for
% consistency with earlier E14 outputs.

%% demo_pisco_E14_benchmark_LysoSeed_B.m
% GROUP B DIAGNOSTIC: Lyso-reference-guided VCA INITIALIZATION ONLY.
% This is NOT blind unmixing; the Lyso reference is used before training.
% The PISCO trainer is unchanged and the seeded vertex remains trainable.
% Select 'vca' below to run a seed-matched GROUP A baseline.
% PISCO-only demo for experiment E14 (public-benchmark controlled
% validation): blind spectral unmixing of REAL PUBLIC benchmark
% hyperspectral fluorescence data with semi ground truth, filling the
% "controlled experiment layer" of the four-layer Nature Methods
% evidence chain (simulation -> controlled -> biological application ->
% reproducibility). Corresponds to SI Note 6 "Controlled validation on
% public benchmarks", Suppl. Fig. 11 (fig:benchmark) and Suppl. Table 9
% (tab:benchmark) of the experimental-design document v7, entry E14.
%
% ARM 1 (main arm, five-label mixed cells):
%   Blind unmixing of the PhasorPy five-label mixed-cell LSM (28
%   channels x 256 x 256; Hoechst + Golgi + Mito + Lyso + CellMask),
%   with the endmember number p ESTIMATED BY HySime (e14_hysime, a port
%   of Bioucas-Dias & Nascimento 2008, identical implementation to the
%   E5 demo). Semi-GT references: 5 single-label LSM files (one dye per
%   file), from which reference spectra and reference images are derived.
%     Metric A: SAD (deg) between each blind endmember spectrum and the
%       matched single-label reference spectrum. Reference-spectrum
%       protocol: Otsu threshold on the total-intensity image of the
%       single-label file -> foreground (cell) mask -> mean spectrum of
%       the foreground pixels (SAD is scale-invariant, so no
%       normalisation is needed).
%     Metric B: per-channel Pearson r between each blind abundance map
%       and the matched single-label reference image. Reference-image
%       protocol: total-intensity image (sum over channels) of the
%       single-label file, imresize'd onto the mixed-FOV grid. NOTE the
%       reference images show DIFFERENT single-labelled cells, not the
%       mixed FOV, so r measures agreement of the recovered spatial
%       pattern with the dye's typical morphology (semi-GT), not a
%       pixel-exact registration.
%     Group B uses the Lyso single-stain spectral reference at INIT TIME
%     and is therefore not blind, even though the rest of PISCO is unchanged.
%     Pairing: greedy one-to-one SAD matching (e14_match, the E1
%       e1_match logic generalised to p_hat ~= 5).
%     Targets (Suppl. Table 9): SAD < 5 deg, Pearson r > 0.9.
%
% ARM 2 (optional arm, FocalCheck fluorescent beads):
%   Core-shell dual-dye bead hyperspectral cube (two emission components
%   with nominal peaks 512 nm / 525 nm + background/autofluorescence).
%   Blind unmixing with p = 3 (two dyes + background); endmember spectra
%   compared with the nominal dye spectra (SAD for reference only, the
%   file's spectral calibration is not certified); core-shell geometry
%   verified by radial abundance profiles (bright bead auto-located by
%   Otsu threshold + largest-component centroid + radial averaging):
%   the shell dye (525) abundance must peak OUTSIDE the core dye (512).
%
% Data (real, public, semi GT; all CC-BY):
%   (1) Five-label mixed-cell LSM, Zenodo record 13625087:
%       https://zenodo.org/records/13625087
%       28 channels x 256 x 256, single z, single t.
%   (2) Five single-label reference LSMs, Zenodo record 14860228:
%       https://zenodo.org/records/14860228
%       (one dye per file: Hoechst / Golgi / Mito / Lyso / CellMask).
%   (3) FocalCheck bead hyperspectral cube, F1000Research data note,
%       Mysore et al. 2016, DOI 10.5256/f1000research.9233.d138682:
%       https://doi.org/10.5256/f1000research.9233.d138682  (CC BY).
%   Third-party one-line reproduction path (comment only; this demo is
%   pure MATLAB and does NOT call Python): PhasorPy users can obtain
%   datasets (1) and (2) via `phasorpy.datasets.fetch()`.
%   Place the downloaded files in DATA_DIR = 'data_E14' and adjust the
%   file-name constants in section A.0 to the actual local names.
%
% Degradation policy:
%   - mixed-cell file missing        -> error (main arm cannot run);
%   - some reference files missing   -> warning; those dyes get NaN in
%                                       the sad_deg / pearson_r columns;
%   - bead file missing / unreadable -> prominent warning; arm 2 is
%                                       skipped (its CSV rows carry NaN).
%
% Trainer settings (design v7 convention): the trainer call block
% (base_args) is IDENTICAL to the E7 real-data demo; the data are RAW
% PHOTON COUNTS, so NOISE_MODEL 'poisson' with PHOTON_GAIN 1 (raw
% counts, g = 1) and READ_SIGMA 1 (read-out noise lower bound of 1
% count, E1 protocol). The trainer v0.9 is only CALLED, never modified.
%
% Outputs (inside script_dir/pisco_E14_<mode>_NoASC_results):
%   (1) pisco_E14_benchmark_results.csv -- Suppl. Table 9 format, one
%       row per endmember: arm,run,seed,p_used,endmember,sad_deg,
%       pearson_r,time_s  (MEAN summary row per arm; readmatrix
%       read-back self-check at the end)
%   (2) pisco_E14_refspectra.csv -- exported reference spectra
%       (L channels x 5 dyes, channel-index first column, dye-name
%       header row; NaN column for a missing reference), for the SI
%       and third-party reproduction
%   (3) Figures (Suppl. Fig. 11 material, PNG):
%       Fig A  mixed-cell render (total intensity)
%       Fig B  blind abundance maps vs single-label reference images,
%              side by side, per-channel Pearson r in the titles
%       Fig C  blind endmember spectra vs reference spectra (per-dye
%              subplots, SAD annotated, channel axis)
%       Fig D  HySime p_hat printed to the command line + residual
%              analysis (residual RMS map + histogram)
%       Fig E  bead render + 512/525 two-component abundance maps
%       Fig F  core-shell radial abundance profiles
%       Fig G  bead component spectra vs nominal dye spectra
%
% v1.0-E14 (2026-09-24): initial release, aligned with the E14 entry of
%   the experimental-design document v7 (Suppl. Fig. 11 / Suppl. Table 9
%   rows). Data type: REAL PUBLIC BENCHMARK, SEMI GT. Code style,
%   trainer call block, paired tic/toc timing, CSV conventions and the
%   LSM reader follow demo_pisco_E7_downstream.m (v1.1-E7); the HySime
%   estimator is copied from demo_pisco_E5_misspec.m (e5_hysime); the
%   greedy SAD matching follows demo_pisco_E1_accuracy.m (e1_match).
%   Target: MATLAB R2023a (no string type, no emoji).
%
% Required on the MATLAB path:
%   deep_mvsa_invflow_poisson.m   (PISCO trainer, code v0.9) -- NOT
%   modified and NOT included here; this script only calls it.
% Requires the Image Processing Toolbox (graythresh, imbinarize,
% bwareaopen, bwconncomp, imresize, mat2gray, strel, imclose). No other
% toolbox is needed.
%
% Runtime estimate:
%   QUICK = true (default, smoke test): central 128 x 128 crop of the
%     mixed-cell FOV, N_RUNS = 2 (unchanged). Dominated by 2 arm-1
%     trainings (2500 iterations on 16384 pixels) plus 2 arm-2
%     trainings: roughly 5-15 min total plus ~1 min for data reading.
%   QUICK = false: full 256 x 256 FOV (4x more pixels, still small):
%     roughly 20-50 min total. The full mode is perfectly acceptable
%     for this dataset size.

clear all; close all; clc;

%% A.0 Configuration ----------------------------------------------------
QUICK   = false;   % true  = smoke test: central 128x128 crop (arm 1)
                  % false = full 256 x 256 FOV; N_RUNS = 2 either way
DATA_DIR = 'data_E14';

% --- file-name constants: adjust to the actual downloaded names -------
% Arm 1: PhasorPy five-label mixed-cell LSM (Zenodo 13625087)
F_MIX      = fullfile(DATA_DIR, '38_Hoechst_Golgi_Mito_Lyso_CellMAsk_404_488_561_633_SP.lsm');
% Arm 1: five single-label reference LSMs (Zenodo 14860228), one dye
% per file; REF_NAMES{i} is the dye of file REF_FILES{i} and is used as
% the endmember label in the CSV and figures.
REF_NAMES  = {'Hoechst', 'Golgi', 'Mito', 'Lyso', 'CellMask'};
REF_FILES  = {fullfile(DATA_DIR, 'spectral hoehst.lsm'), ...
              fullfile(DATA_DIR, 'spectral golgi.lsm'), ...
              fullfile(DATA_DIR, 'spectral mito tracker.lsm'), ...
              fullfile(DATA_DIR, 'spectral lyso tracker green.lsm'), ...
              fullfile(DATA_DIR, 'spectral cell mask.lsm')};
% Arm 2: FocalCheck bead hyperspectral cube (DOI 10.5256/f1000research.
% 9233.d138682). Format is not certified (.lsm/.tif/.czi/.mat all
% plausible): the reader tries several formats (see e14_read_bead).
F_BEAD     = fullfile(DATA_DIR, 'focalcheck_beads.lsm');
%SEEDS    = [1001 7007 7008];
SEEDS    = [7007];   % two independent repeats (trainer init only)
N_RUNS   = 1;
% Supplied NoASC implementation defaults to GPU single precision.
% Set USE_GPU=false on machines without a CUDA-enabled NVIDIA GPU.
USE_GPU = true;
GPU_PRECISION = 'single';
GPU_DEVICE = 1;
MM_ITERS = 2500;          % joint-phase length (SI Table 3 default, as E7)
WARM_UP  = 600;           % warm-up length (SI Table 3 default, as E7)
READ_SIG = 1.0;           % read-out noise lower bound, counts (E1 protocol)
CROP     = 128;           % QUICK central crop size, arm 1 (pixels)
N_DYE    = numel(REF_NAMES);   % 5 reference dyes

% HySime plausibility clamp for the arm-1 endmember number: a return
% value <= 2 or >= 10 is clearly pathological for a five-label sample;
% p_hat is then clamped into [3, 8] and a warning is printed.
P_MIN    = 6;
P_MAX    = 6;
% Mode C default: insert a scaled Lyso reference into a p-1 dimensional
% PCA signal subspace AND replace one VCA initial endmember with that Lyso.
% B and A switches are provided for comparisons without changing files.
% All three modes use the same copied trainer, seed, losses, and p value.
LYSO_INIT_MODE = 'lyso_subspace';  % 'lyso_subspace' (C), 'lyso_seed' (B), 'vca' (A)
assert(any(strcmp(LYSO_INIT_MODE, {'lyso_subspace','lyso_seed','vca'})), ...
    'E14:badMode', 'Mode must be lyso_subspace, lyso_seed or vca.');
LYSO_REF_IDX = find(strcmp(REF_NAMES, 'Lyso'), 1);
switch LYSO_INIT_MODE
    case 'lyso_subspace', ARM1_TAG = 'C_LysoSubspace_NoASC';
    case 'lyso_seed', ARM1_TAG = 'Ccontrol_B_LysoSeed_NoASC';
    otherwise, ARM1_TAG = 'Ccontrol_A_VCA_NoASC';
end
P_SUSPECT_LO = 2;    % p_hat <= 2  -> suspicious, warn
P_SUSPECT_HI = 10;   % p_hat >= 10 -> suspicious, warn

% Arm 2 (FocalCheck beads): p = 3 (core dye 512 nm + shell dye 525 nm +
% background/autofluorescence). Nominal dye emission peaks:
P_BEAD       = 3;
BEAD_PEAK_NM = [512 525];          % nominal emission peaks (nm)
% The bead file's spectral calibration is NOT certified; the nominal
% spectra are built as Gaussians on the channel grid under an assumed
% linear wavelength axis (adjust to the actual file metadata):
BEAD_WL0  = 415;     % assumed first channel centre wavelength (nm)
BEAD_DWL  = 9.7;     % assumed channel spacing (nm), Zeiss-lambda-like
BEAD_SIG  = 12;      % assumed nominal-spectrum width (nm)
BEAD_MAXDIM = 256;   % bead frames larger than this are centre-cropped
                     % (keeps the optional arm's runtime bounded)

% Keep EVERY generated output (figures, CSV, MAT, including optional beads)
% inside one separate subfolder, leaving the script/data directory clean.
script_dir = fileparts(mfilename('fullpath'));
if isempty(script_dir), script_dir = pwd; end
OUTPUT_SUBDIR = sprintf('pisco_E14_%s_results', ARM1_TAG);
OUT_DIR = fullfile(script_dir, OUTPUT_SUBDIR);
if ~exist(OUT_DIR, 'dir')
    [made, message] = mkdir(OUT_DIR);
    assert(made, 'E14:OutputDir', 'Cannot create output folder: %s', message);
end
OUT_CSV  = fullfile(OUT_DIR, sprintf('pisco_E14_%s_results.csv', ARM1_TAG));
REF_CSV  = fullfile(OUT_DIR, sprintf('pisco_E14_%s_refspectra.csv', ARM1_TAG));
DIAG_CSV = fullfile(OUT_DIR, sprintf('pisco_E14_%s_Lyso_init_final_diagnostic.csv', ARM1_TAG));
FIG_PREF = sprintf('pisco_E14_%s_', ARM1_TAG);
fprintf('NoASC results folder: %s\n', OUT_DIR);

fprintf('E14 demo (PISCO only): public-benchmark controlled validation\n');
fprintf('  arm 1: five-label mixed cells, p used clamped, %d runs\n', N_RUNS);
fprintf('  arm 1 mode: %s (Group C/B use Lyso reference; NoASC S is not a fraction)\n', LYSO_INIT_MODE);
fprintf('  WARNING: Fig B Pearson compares different FOVs; not a valid accuracy metric.\n');
fprintf('  arm 2: FocalCheck beads (optional), p = %d\n', P_BEAD);
if QUICK
    fprintf('QUICK = true: central %d x %d crop smoke test (N_RUNS still %d)\n', ...
        CROP, CROP, N_RUNS);
else
    fprintf('QUICK = false: full FOV\n');
end

%% A.1 Data availability ------------------------------------------------
if ~exist(F_MIX, 'file')
    error('E14:missingMix', ['Main data file %s not found. Download the ' ...
        'five-label mixed-cell LSM from Zenodo record 13625087 ' ...
        '(https://zenodo.org/records/13625087, or phasorpy.datasets.' ...
        'fetch() for Python users), place it in %s and update F_MIX ' ...
        'in section A.0.'], F_MIX, DATA_DIR);
end

HAVE_REF = false(1, N_DYE);
for i = 1:N_DYE
    HAVE_REF(i) = exist(REF_FILES{i}, 'file') == 2;
end
if ~all(HAVE_REF)
    fprintf(2, ['\n============================================================\n' ...
        '*** WARNING: %d of %d single-label reference files NOT FOUND.\n' ...
        '*** Missing dyes get NaN in the sad_deg / pearson_r CSV columns.\n' ...
        '*** Download: Zenodo record 14860228\n' ...
        '*** (https://zenodo.org/records/14860228).\n' ...
        '============================================================\n\n'], ...
        N_DYE - sum(HAVE_REF), N_DYE);
    for i = find(~HAVE_REF)
        fprintf(2, '  missing reference: %s (%s)\n', REF_NAMES{i}, REF_FILES{i});
    end
end

HAVE_BEAD = exist(F_BEAD, 'file') == 2;
if ~HAVE_BEAD
    fprintf(2, ['\n============================================================\n' ...
        '*** WARNING: FocalCheck bead file %s NOT FOUND.\n' ...
        '*** Arm 2 (bead core-shell validation, Suppl. Fig. 11e-g) will\n' ...
        '*** be SKIPPED; its CSV rows are written with NaN metrics.\n' ...
        '*** Download: DOI 10.5256/f1000research.9233.d138682 (CC BY).\n' ...
        '============================================================\n\n'], F_BEAD);
end

%% A.2 Arm 1: load the mixed-cell cube (L x H x W photon counts) --------
fprintf('Reading mixed-cell file %s ...\n', F_MIX);
t_read = tic;
Y_cube = e14_read_lsm(F_MIX);       % L x H x W double, raw counts
fprintf('  read %.1f s; cube %d x %d x %d (L x H x W)\n', ...
    toc(t_read), size(Y_cube,1), size(Y_cube,2), size(Y_cube,3));

[~, Hf, Wf] = size(Y_cube);
if QUICK && Hf >= CROP && Wf >= CROP
    % central CROP x CROP crop (smoke test; full FOV when QUICK = false)
    r0 = floor(Hf/2) - CROP/2 + 1;
    c0 = floor(Wf/2) - CROP/2 + 1;
    Y_cube = Y_cube(:, r0:r0+CROP-1, c0:c0+CROP-1);
    fprintf('QUICK mode: central %d x %d crop at rows %d-%d, cols %d-%d\n', ...
        CROP, CROP, r0, r0+CROP-1, c0, c0+CROP-1);
end
[L, H, W] = size(Y_cube);
N = H * W;

% Pixel matrix: L x N, units = raw photon counts (PHOTON_GAIN = 1, so
% no rescaling before the trainer; the Poisson model sees true counts).
Y = reshape(Y_cube, L, []);
fprintf('Pixel matrix: %d channels x %d pixels\n', L, N);

%% A.3 Arm 1: reference spectra and reference images --------------------
% Protocol (SI Note 6): for each single-label reference LSM,
%   reference spectrum = mean spectrum over the foreground (cell) mask,
%     where the mask is the Otsu threshold of the total-intensity image
%     (SAD is scale-invariant, no normalisation required);
%   reference image    = total-intensity image (sum over channels),
%     resized onto the mixed-FOV grid at metric time.
ref_spec = NaN(L, N_DYE);            % reference spectra (mixed grid, L ch)
ref_img  = cell(1, N_DYE);           % reference images (native ref grid)
for i = 1:N_DYE
    if ~HAVE_REF(i), continue; end
    fprintf('Reading reference %s (%s) ...\n', REF_NAMES{i}, REF_FILES{i});
    t_read = tic;
    [spec_i, img_i, fg_i] = e14_ref_from_lsm(REF_FILES{i});
    fprintf('  %d channels, image %d x %d, foreground %.1f %%, read %.1f s\n', ...
        size(spec_i,1), size(img_i,1), size(img_i,2), 100*fg_i, toc(t_read));
    % --- channel alignment: mixed and reference files should both have
    % --- 28 channels; if not, warn and truncate to the common channels
    if size(spec_i,1) ~= L
        fprintf(2, ['WARNING: reference %s has %d channels vs %d in the ' ...
            'mixed file; truncating both to the common %d channels.\n'], ...
            REF_NAMES{i}, size(spec_i,1), L, min(size(spec_i,1), L));
    end
    nc = min(size(spec_i,1), L);
    spec_pad = NaN(L, 1);
    spec_pad(1:nc) = spec_i(1:nc);
    ref_spec(:, i) = spec_pad;
    ref_img{i} = img_i;
end
% If ANY reference had fewer channels than the mixed cube, truncate the
% mixed data as well so spectra are always compared on common channels.
n_common = sum(~isnan(ref_spec(:, find(HAVE_REF, 1))));
if ~isempty(n_common) && n_common < L
    fprintf(2, ['WARNING: truncating the mixed cube from %d to %d ' ...
        'channels to match the reference grid.\n'], L, n_common);
    Y = Y(1:n_common, :);
    Y_cube = Y_cube(1:n_common, :, :);
    L = n_common;
end
ch_axis = (1:L).';                   % channel index axis for spectra plots

% --- export the reference spectra CSV (SI / third-party reproduction) --
fr = fopen(REF_CSV, 'w');
fprintf(fr, 'channel,%s,%s,%s,%s,%s\n', REF_NAMES{:});
for c = 1:L
    fprintf(fr, '%d,%.6g,%.6g,%.6g,%.6g,%.6g\n', c, ref_spec(c, :));
end
fclose(fr);
fprintf('Reference spectra written to %s\n', REF_CSV);

if ~strcmp(LYSO_INIT_MODE, 'vca')
    assert(HAVE_REF(LYSO_REF_IDX) && all(isfinite(ref_spec(:,LYSO_REF_IDX))) && ...
        norm(ref_spec(:,LYSO_REF_IDX)) > 0, 'E14:missingLysoRef', ...
        'Group B/C requires a valid Lyso single-stain reference spectrum.');
end

%% A.4 Arm 1: HySime endmember-number estimate --------------------------
% Same estimator as the E5 demo (verbatim port of Bioucas-Dias &
% Nascimento 2008 hysime.m/estNoise.m with the documented 4x4
% superpixel adaptation). Runs on the RAW COUNTS. If HySime returns a
% clearly pathological value (<= 2 or >= 10 for this five-label
% sample) a warning is printed; p_hat is clamped into [3, 8].
p_raw = NaN;
try
    p_raw = e14_hysime(Y, H, W);
catch ME
    fprintf(2, ['WARNING: e14_hysime failed (%s); falling back to ' ...
        'p_hat = %d (the nominal label count).\n'], ME.message, N_DYE);
    p_raw = N_DYE;
end
fprintf('HySime endmember-number estimate (arm 1): p_raw = %d\n', p_raw);
if p_raw <= P_SUSPECT_LO || p_raw >= P_SUSPECT_HI
    fprintf(2, ['\n*** WARNING: HySime returned p = %d, which is ' ...
        'pathological for a five-label sample (expected ~5);\n' ...
        '*** clamping into [%d, %d]. Check data quality / channel ' ...
        'alignment.\n\n'], p_raw, P_MIN, P_MAX);
end
p_hat = min(max(p_raw, P_MIN), P_MAX);
if p_hat ~= p_raw
    fprintf(2, 'p_hat clamped: %d -> %d\n', p_raw, p_hat);
end

%% A.5 Arm 1 Monte-Carlo repeats: PISCO unmixing + semi-GT metrics ------
% Result accumulators: rows = run, columns = dye (NaN = missing/unmatched)
SAD_m = NaN(N_RUNS, N_DYE);     % endmember SAD (deg) vs reference spectra
PCC_m = NaN(N_RUNS, N_DYE);     % abundance-map Pearson r vs reference images
T1_m  = zeros(N_RUNS, 1);       % wall-clock seconds per arm-1 training

fid = fopen(OUT_CSV, 'w');
fprintf(fid, 'arm,run,seed,p_used,endmember,sad_deg,pearson_r,time_s\n');
n_csv_rows = 0;                 % rows written (read-back self-check)
% Diagnostic: one record per run. In Group A, seeded-initialization fields = NaN.
fd = fopen(DIAG_CSV, 'w');
assert(fd ~= -1, 'E14:badDiagFile', 'Could not open diagnostic CSV.');
fprintf(fd, ['mode,run,seed,p_raw,p_used,lyso_seed_col,' ...
    'lyso_ref_rescaled_sad_deg,lyso_m0_projected_sad_deg,lyso_final_seed_col_sad_deg,' ...
    'lyso_final_min_sad_deg,lyso_final_greedy_sad_deg,lyso_final_best_col,' ...
    'lyso_final_greedy_col,rcond_initial_M0,global_rre,time_s,' ...
    'standard_pca_projection_sad_deg,guided_projection_sad_deg,' ...
    'standard_pca_projection_relerr,guided_projection_relerr,' ...
    'standard_pca_subspace_rre,guided_subspace_rre,' ...
    'guided_axis_variance,original_pc_last_variance\n']);

rep_done = false;               % run-1 products are kept for the figures
for k = 1:N_RUNS
    rng(SEEDS(k));          % independent repeat: trainer network init only.
                            % Pixels MUST stay in raster order: with
                            % IMG_H/IMG_W set and LAMBDA_SPATIAL active, the
                            % trainer's 4-neighbourhood spatial Laplacian is
                            % built on the H x W grid, so any permutation of
                            % the pixel order would corrupt the spatial
                            % coherence term (pillar P1).
    Y_run = Y;

    % --- trainer argument cell: IDENTICAL 18 name/value pairs to the ---
    % --- E7 real-data call block; design v7 convention: the data are ---
    % --- raw counts, so NOISE_MODEL 'poisson', PHOTON_GAIN 1 (raw    ---
    % --- counts, g = 1), READ_SIGMA 1 (read-out noise lower bound of ---
    % --- 1 count, consistent with the E1 protocol). ------------------
    base_args = {'spherize','yes', 'verbose',0, ...
        'MM_ITERS',MM_ITERS, 'WARM_UP',WARM_UP, 'LR',3e-4, ...
        'LAMBDA_VOL',0.008, 'LAMBDA_NONNEG',3, 'LAMBDA_EQ',100, ...
        'LAMBDA_ENCLOSE',0.3, ...
        'IMG_H',H, 'IMG_W',W, 'LAMBDA_SPATIAL',2, ...
        'NOISE_MODEL','poisson', 'ETA',0.3, ...
        'PHOTON_GAIN',1, 'PHOTON_FLOOR',1, 'READ_SIGMA',READ_SIG, ...
        'USE_GPU',USE_GPU, 'GPU_PRECISION',GPU_PRECISION, 'GPU_DEVICE',GPU_DEVICE};

    % Group A: no Lyso information enters training.
    % Group B: ordinary PCA, Lyso replaces one VCA initialization column.
    % Group C: p-2 principal axes plus one Lyso direction, AND seeded M0.
    init_diag = e14_blank_seed_info();
    M0_seed_raw = [];
    trainer_args = base_args;
    if ~strcmp(LYSO_INIT_MODE, 'vca')
        state_before_seed = rng;
        [M0_seed_raw, init_diag] = e14_lyso_seed_m0( ...
            Y_run, p_hat, ref_spec(:, LYSO_REF_IDX), LYSO_INIT_MODE);
        rng(state_before_seed);
        trainer_args = [base_args, {'M0', M0_seed_raw}];
        if strcmp(LYSO_INIT_MODE, 'lyso_subspace')
            trainer_args = [trainer_args, {'SUBSPACE_ANCHOR', init_diag.lyso_scaled}];
        end
        fprintf(['  Lyso seed: replaced VCA EM %d, input scale %.5g, ' ...
            'init SAD %.5f deg, standard PCA projected SAD %.3f deg, ' ...
            'rcond(M0) %.3g\n'], ...
            init_diag.seed_col, init_diag.scale_factor, ...
            init_diag.proj_sad_deg, init_diag.base_proj_sad_deg, ...
            init_diag.rcond_m0);
    end

    % ---- NoASC trainer: intensity-varying pixel coordinate, NO ASC ----
    fprintf('arm 1, run %d/%d (seed %d): training PISCO on %d pixels, p = %d ...\n', ...
        k, N_RUNS, SEEDS(k), N, p_hat);
    t_run = tic;                                % paired handle
    [M_est, S_est, Up_model, my_model] = deep_mvsa_invflow_poisson_explicit_Warmup2_NoASC_E14C(Y_run, p_hat, trainer_args{:});
    time_s = toc(t_run);                        % paired toc
    % The original helper produced ASC/PCA diagnostics. Update the
    % reported *projection* diagnostics to the NoASC shape-space used
    % by this trainer (whose last coordinate is observed pixel intensity).
    if ~strcmp(LYSO_INIT_MODE,'vca')
        init_diag = e14_update_noasc_diagnostics(init_diag, Y_run, ...
            ref_spec(:,LYSO_REF_IDX), M0_seed_raw, Up_model, my_model);
    end
    T1_m(k) = time_s;
    fprintf('  training finished in %.1f s\n', time_s);

    % ---- greedy one-to-one SAD matching: reference i -> endmember ----
    % ---- perm(i) (E1 e1_match logic generalised to p_hat ~= 5);  ----
    % ---- dyes whose reference file is missing stay unmatched (NaN) ----
    [perm, sad_v] = e14_match(ref_spec, M_est, HAVE_REF);

    % ---- Lyso diagnostic independent of the 5-reference greedy matching ---
    % Check both the original seeded column and best attainable Lyso SAD.
    lyso_ref = ref_spec(:,LYSO_REF_IDX);
    lyso_sad_all = NaN(1, size(M_est,2));
    for jj = 1:size(M_est,2)
        lyso_sad_all(jj) = e14_safe_sad(lyso_ref, M_est(:,jj));
    end
    [lyso_min_sad, lyso_best_col] = min(lyso_sad_all);
    lyso_final_seed_sad = NaN;
    if isfinite(init_diag.seed_col)
        lyso_final_seed_sad = lyso_sad_all(init_diag.seed_col);
    end
    global_rre = norm(Y_run - M_est*S_est, 'fro') / max(norm(Y_run,'fro'), eps);
    fprintf(['  Lyso final: best-of-%d SAD %.2f deg at EM %d, ' ...
        'seeded EM SAD %.2f deg, global RRE %.4f\n'], ...
        size(M_est,2), lyso_min_sad, lyso_best_col, lyso_final_seed_sad, global_rre);

    % ---- metrics per dye ----
    for i = 1:N_DYE
        if ~HAVE_REF(i) || isnan(perm(i))
            if HAVE_REF(i) && isnan(perm(i))
                fprintf(2, ['  WARNING: no unmatched endmember left for ' ...
                    'dye %s (p_hat = %d < %d references); NaN written.\n'], ...
                    REF_NAMES{i}, p_hat, N_DYE);
            end
            continue;           % NaN row written after the loop below
        end
        SAD_m(k, i) = sad_v(i);
        % abundance map vs reference image (resized onto the mixed grid)
        ab_i = reshape(S_est(perm(i), :), H, W);
        im_i = imresize(mat2gray(ref_img{i}), [H W]);
        PCC_m(k, i) = e14_pearson(ab_i, im_i);
    end

    % ---- Save diagnostic table, learned matrices and initial matrices ----
    % Group B's initial SAD is for the *projected* Lyso; raw seed matches
    % the reference by construction before subspace projection.
    fprintf(fd, ['%s,%d,%d,%d,%d,%.0f,%.8f,%.8f,%.8f,%.8f,%.8f,%d,%.0f,' ...
        '%.8g,%.8f,%.2f,%.8f,%.8f,%.8g,%.8g,%.8f,%.8f,%.8g,%.8g\n'], ...
        LYSO_INIT_MODE, k, SEEDS(k), p_raw, p_hat, init_diag.seed_col, ...
        init_diag.raw_sad_deg, init_diag.proj_sad_deg, lyso_final_seed_sad, ...
        lyso_min_sad, sad_v(LYSO_REF_IDX), lyso_best_col, ...
        perm(LYSO_REF_IDX), init_diag.rcond_m0, global_rre, time_s, ...
        init_diag.base_proj_sad_deg, init_diag.guided_proj_sad_deg, ...
        init_diag.base_proj_relerr, init_diag.guided_proj_relerr, ...
        init_diag.base_subspace_rre, init_diag.guided_subspace_rre, ...
        init_diag.guided_axis_variance, init_diag.original_last_variance);
    % ---- Self-contained MAT for offline replotting of Fig A, C and H ----
    % Y_cube is the complete L x H x W mixed-cell observation in band space.
    % Do NOT save M0_seed_raw: it is used ONLY transiently for initialization
    % and the original Group C Fig I; it is unnecessary for Fig A/C/H.
    % Original initialization diagnostics in init_diag are retained.
    seed_used = SEEDS(k); %#ok<NASGU>
    run_id = k; %#ok<NASGU>
    model_name = 'deep_mvsa_invflow_poisson_explicit_Warmup2_NoASC_E14C'; %#ok<NASGU>
    abundance_kind = 'NoASC_unscaled_coefficients_not_sum_to_one'; %#ok<NASGU>
    save(fullfile(OUT_DIR, sprintf('pisco_E14_%s_run%02d_M_S.mat',ARM1_TAG,k)), ...
        'Y_cube','M_est','S_est','ref_spec','REF_NAMES','perm','sad_v', ...
        'H','W','p_raw','p_hat','run_id','seed_used','global_rre','init_diag', ...
        'model_name','abundance_kind');
    fprintf('  Complete replot data saved in run%02d MAT (Fig A/C/H; no M0_seed_raw).\n', k);

    % ---- per-dye CSV rows (all 5 dyes; NaN where missing/unmatched) --
    for i = 1:N_DYE
        fprintf(fid, 'arm1_cells,%d,%d,%d,%s,%g,%g,%.2f\n', ...
            k, SEEDS(k), p_hat, REF_NAMES{i}, SAD_m(k,i), PCC_m(k,i), time_s);
        n_csv_rows = n_csv_rows + 1;
    end
    fprintf('  run %d: SAD (deg) per dye [%s] | r [%s]\n', k, ...
        num2str(SAD_m(k,:), ' %.2f'), num2str(PCC_m(k,:), ' %.3f'));

    % ---- keep run-1 products for Figs A-D ----
    if k == 1 && ~rep_done
        r1_M = M_est; r1_S = S_est; r1_perm = perm;
        r1_sad = SAD_m(1, :); r1_pcc = PCC_m(1, :);
        r1_init_diag = init_diag; r1_M0_seed = M0_seed_raw;
        rep_done = true;
    end
end

% ---- arm-1 MEAN summary row (Suppl. Table 9 mean row) ----------------
sad_mean1 = mean(reshape(SAD_m, [], 1), 'omitnan');
pcc_mean1 = mean(reshape(PCC_m, [], 1), 'omitnan');
fprintf(fid, 'arm1_cells,%d,%d,%d,%s,%g,%g,%.2f\n', ...
    0, 0, p_hat, 'MEAN', sad_mean1, pcc_mean1, mean(T1_m));
n_csv_rows = n_csv_rows + 1;
fprintf(['arm 1 done: mean SAD %s deg (target < 5) | mean r %s ' ...
    '(target > 0.9)\n'], num2str(sad_mean1, '%.2f'), ...
    num2str(pcc_mean1, '%.3f'));

%% A.6 Arm 1 figures (run 1; Suppl. Fig. 11a-d material) ----------------
if rep_done
    % --- Fig A: mixed-cell render (total intensity) ---
    figure('Name','E14 Fig A: mixed-cell render', ...
        'Visible','on', 'Position',[40 40 560 520], 'Color','w');
    imagesc(squeeze(sum(Y_cube, 1))); axis image off; colormap gray; colorbar;
    title(sprintf(['E14 arm 1: five-label mixed cell, total intensity ' ...
        '(%d ch x %d x %d)'], L, H, W));
    saveas(gcf, fullfile(OUT_DIR, [FIG_PREF 'figA_render.png']));

    % --- Fig B: NoASC coefficients vs single-label reference images ---
    figure('Name','E14 Fig B: abundances vs reference images (run 1)', ...
        'Visible','on', 'Position',[30 30 620 1000], 'Color','w');
    for i = 1:N_DYE
        subplot(N_DYE, 2, 2*i-1);
        if HAVE_REF(i) && ~isnan(r1_perm(i))
            imagesc(reshape(r1_S(r1_perm(i), :), H, W));
            axis image off; colorbar;
            title(sprintf('PISCO %s, r = %.3f', REF_NAMES{i}, r1_pcc(i)));
        else
            axis off;
            text(0.5, 0.5, sprintf('%s: no match', REF_NAMES{i}), ...
                'HorizontalAlignment','center');
        end
        subplot(N_DYE, 2, 2*i);
        if HAVE_REF(i)
            imagesc(imresize(mat2gray(ref_img{i}), [H W]));
            axis image off; colorbar;
            title(sprintf('Reference %s', REF_NAMES{i}));
        else
            axis off;
            text(0.5, 0.5, sprintf('%s: file missing', REF_NAMES{i}), ...
                'HorizontalAlignment','center');
        end
    end
    sgtitle(sprintf(['E14 arm 1 (run 1): NoASC coefficients vs single-label ' ...
        'reference images (Pearson r per channel)']));
    saveas(gcf, fullfile(OUT_DIR, [FIG_PREF 'figB_abund_vs_ref.png']));

    % --- Fig C: ALL estimated endmember spectra (one panel per model EM) --
    % These panels use the original PISCO endmember order 1:p_used, NOT
    % the five-reference order. When SAD matched, the reference is overlaid.
    % Any additional estimated endmembers are still plotted as 'unmatched'.
    n_est = size(r1_M, 2);
    assert(size(r1_S,1) == n_est, ...
        'E14:badMS', 'M_est and S_est have inconsistent endmember counts.');
    n_col = min(n_est, min(5, max(3, ceil(n_est / 2))));
    n_row = ceil(n_est / n_col);
    spec_height = max(500, 320 * n_row);
    figure('Name',sprintf('E14 Fig C: all %d estimated NoASC spectra',n_est), ...
        'Visible','on', 'Position',[50 50 1500 spec_height], 'Color','w');
    for j = 1:n_est
        subplot(n_row, n_col, j);
        ep = r1_M(:,j);
        scale_ep = max(max(abs(ep)), eps);
        plot(ch_axis, ep / scale_ep, '-', 'LineWidth', 1.6, ...
            'Color', [0.65 0.12 0.18]);
        hold on;
        % Search the SAME SAD pairing r1_perm that is used for Fig B.
        matched_i = find(r1_perm == j, 1, 'first');
        if ~isempty(matched_i) && HAVE_REF(matched_i)
            rs = ref_spec(:,matched_i);
            scale_rs = max(max(abs(rs)), eps);
            plot(ch_axis, rs / scale_rs, 'k--', 'LineWidth', 1.4);
            title(sprintf('EM %d: %s (SAD %.2f deg)', ...
                j, REF_NAMES{matched_i}, r1_sad(matched_i)), ...
                'Interpreter','none');
            legend('PISCO', 'Single-stain ref.', 'Location','best', ...
                'FontSize',7);
        else
            title(sprintf('EM %d: unmatched (no dye label)',j), ...
                'Interpreter','none');
        end
        xlabel('Channel index');
        ylabel('Normalized intensity');
        xlim([1 L]);
        grid on;
    end
    sgtitle(sprintf(['E14 arm 1 (run 1): ALL %d PISCO NoASC spectra; ' ...
        'p_{used}=%d, HySime raw=%d'], n_est, p_hat, p_raw));
    saveas(gcf, fullfile(OUT_DIR, [FIG_PREF 'figC_spectra.png']));

    % --- Fig H (new): ALL NoASC coefficient maps, one-to-one with Fig C --
    % EM j in this figure is paired strictly with the EM j spectrum in
    % Fig C. The five single-stain comparison (Fig B) remains unchanged.
    % NoASC S_est is NOT a fraction: color limits show unnormalised coefficients.
    % Identical color limits allow direct comparison across all EM maps.
    s_lo = min(0, min(r1_S(:)));
    s_hi = max(1e-6, max(r1_S(:))); % no sum-one assumption
    map_height = max(500, 330 * n_row);
    figure('Name',sprintf('E14 Fig H: all %d PISCO abundance maps',n_est), ...
        'Visible','on', 'Position',[65 65 1500 map_height], 'Color','w');
    for j = 1:n_est
        subplot(n_row, n_col, j);
        imagesc(reshape(r1_S(j,:), H, W));
        axis image off;
        caxis([s_lo s_hi]);
        colorbar;
        matched_i = find(r1_perm == j, 1, 'first');
        if ~isempty(matched_i) && HAVE_REF(matched_i)
            title(sprintf('EM %d: %s', j, REF_NAMES{matched_i}), ...
                'Interpreter','none');
        else
            title(sprintf('EM %d: unmatched', j), ...
                'Interpreter','none');
        end
    end
    colormap(parula);
    sgtitle(sprintf(['E14 arm 1 (run 1): ALL %d NoASC coefficient maps; ' ...
        'EM index matches Fig C exactly (p_{used}=%d)'], n_est, p_hat));
    saveas(gcf, fullfile(OUT_DIR, [FIG_PREF 'figH_all_abundances.png']));
    fprintf('All %d endmember spectra (Fig C) and abundance maps (Fig H) saved.\n', n_est);

    % --- Fig D: residual analysis (residual RMS map + histogram) ------
    % per-pixel relative residual of the run-1 reconstruction; the
    % HySime p_hat itself is reported on the command line (section A.4)
    Yr = r1_M * r1_S;                       % L x N reconstruction
    rj = sqrt(sum((Y - Yr).^2, 1)) ./ max(sqrt(sum(Y.^2, 1)), eps);
    figure('Name','E14 Fig D: residual analysis (run 1)', ...
        'Visible','on', 'Position',[60 60 1000 420], 'Color','w');
    subplot(1,2,1);
    imagesc(reshape(rj, H, W)); axis image off; colorbar;
    title(sprintf('Residual RMS map (mean %.3f)', mean(rj)));
    subplot(1,2,2);
    histogram(rj, 40); grid on;
    xlabel('Per-pixel relative residual'); ylabel('Pixels');
    title('Residual distribution');
    sgtitle(sprintf(['E14 arm 1 (run 1): NoASC residual analysis, ' ...
        'p_{HySime} = %d (see command line)'], p_hat));
    saveas(gcf, fullfile(OUT_DIR, [FIG_PREF 'figD_residual.png']));
    % --- Fig I (new, Group B): Lyso reference, seeded initial & final ---
    if ~strcmp(LYSO_INIT_MODE, 'vca') && ~isempty(r1_M0_seed)
        ix = r1_init_diag.seed_col;
        rr = ref_spec(:, LYSO_REF_IDX); rr = rr/max(max(rr),eps);
        ini = r1_M0_seed(:,ix); ini = ini/max(max(ini),eps);
        fin = r1_M(:,ix); fin = fin/max(max(fin),eps);
        figure('Name','E14 Fig I: Lyso seeded column initial versus final', ...
            'Visible','on','Position',[80 80 820 510],'Color','w');
        plot(ch_axis,rr,'k--','LineWidth',2); hold on;
        plot(ch_axis,ini,'b-','LineWidth',1.5);
        plot(ch_axis,fin,'r-','LineWidth',1.5);
        xlabel('Channel index'); ylabel('Normalized spectral intensity'); grid on;
        legend('Lyso reference','Lyso seeded M0 (projected)', ...
            'Same column after training','Location','best');
        title(sprintf('EM %d: initial SAD %.2f deg -> final SAD %.2f deg', ...
            ix,r1_init_diag.proj_sad_deg, ...
            e14_safe_sad(ref_spec(:,LYSO_REF_IDX),r1_M(:,ix))));
        saveas(gcf, fullfile(OUT_DIR,[FIG_PREF 'figI_Lyso_seed_vs_final.png']));
    end
    % --- Fig J: standard versus guided Lyso projection (GROUP C ONLY) ---
    if strcmp(LYSO_INIT_MODE,'lyso_subspace')
        figure('Name','E14 Fig J: Lyso subspace representation', ...
            'Visible','on','Position',[90 90 860 500],'Color','w');
        rr = ref_spec(:,LYSO_REF_IDX);
        sc = max(abs(rr));
        plot(ch_axis,rr/sc,'k--','LineWidth',2); hold on;
        pr_b = r1_init_diag.standard_pca_projected_band;
        plot(ch_axis,pr_b / max(abs(pr_b)),'b-','LineWidth',1.4);
        pr_c = r1_init_diag.lyso_projected;
        plot(ch_axis,pr_c / max(abs(pr_c)),'g-','LineWidth',1.5);
        xlabel('Channel index'); ylabel('Normalized spectral intensity'); grid on;
        legend('Lyso single-stain reference','Standard PCA projection', ...
            'Lyso-guided projection','Location','best');
        title(sprintf('Ordinary PCA SAD %.2f deg -> guided SAD %.6f deg', ...
            r1_init_diag.base_proj_sad_deg, ...
            r1_init_diag.guided_proj_sad_deg));
        saveas(gcf,fullfile(OUT_DIR,[FIG_PREF 'figJ_PCA_guided_vs_standard.png']));
    end
    fprintf('Arm-1 figures for %s saved to %s\n', ARM1_TAG, OUT_DIR);
end

%% A.7 Arm 2 (optional): FocalCheck bead core-shell validation ----------
% p = 3 (core dye, nominal peak 512 nm; shell dye, nominal peak 525 nm;
% background/autofluorescence). The file format is not certified, so
% e14_read_bead tries several readers; failure -> prominent warning and
% the arm is skipped (CSV rows carry NaN).
BEAD_COMP = {'bead512', 'bead525', 'beadBG'};   % CSV endmember labels
SAD_b = NaN(N_RUNS, P_BEAD);        % SAD vs nominal dye spectra (BG: NaN)
T2_m  = NaN(N_RUNS, 1);             % wall-clock seconds per arm-2 training
bead_done = false;                  % run-1 products kept for Figs E-G
geom_pass = NaN;                    % core-shell geometry check (run 1)

if HAVE_BEAD
    fprintf('Reading FocalCheck bead file %s (multi-format probe) ...\n', F_BEAD);
    try
        t_read = tic;
        B_cube = e14_read_bead(F_BEAD);     % Lb x Hb x Wb double
        fprintf('  read %.1f s; cube %d x %d x %d (L x H x W)\n', ...
            toc(t_read), size(B_cube,1), size(B_cube,2), size(B_cube,3));
    catch ME
        fprintf(2, ['\n============================================================\n' ...
            '*** WARNING: could not read the bead file (%s).\n' ...
            '*** Arm 2 is SKIPPED; its CSV rows carry NaN metrics.\n' ...
            '*** Supported probes: LSM/TIFF via Tiff, multi-page TIFF via\n' ...
            '*** imread, .mat with a numeric 3-D variable. Convert the\n' ...
            '*** download (e.g. .czi via Bio-Formats/Fiji) to one of\n' ...
            '*** these and update F_BEAD in section A.0.\n' ...
            '============================================================\n\n'], ME.message);
        HAVE_BEAD = false;
    end
end

if HAVE_BEAD
    [Lb, Hb, Wb] = size(B_cube);
    if max(Hb, Wb) > BEAD_MAXDIM
        % centre-crop oversized bead frames (runtime bound; the bright
        % calibration beads sit near the frame centre in this dataset)
        h2 = min(Hb, BEAD_MAXDIM); w2 = min(Wb, BEAD_MAXDIM);
        r0 = floor(Hb/2) - floor(h2/2) + 1;
        c0 = floor(Wb/2) - floor(w2/2) + 1;
        B_cube = B_cube(:, r0:r0+h2-1, c0:c0+w2-1);
        [~, Hb, Wb] = size(B_cube);
        fprintf('  bead frame centre-cropped to %d x %d\n', Hb, Wb);
    end
    Nb = Hb * Wb;
    Yb = reshape(B_cube, Lb, []);   % raw counts (design v7: g = 1)

    % Nominal dye spectra on the (assumed) bead wavelength axis; the
    % spectral calibration of the file is NOT certified, so the SADs
    % below are for reference only (see section A.0 constants).
    wl_bead = BEAD_WL0 + (0:Lb-1) * BEAD_DWL;
    M_nom = NaN(Lb, 2);
    for j = 1:2
        M_nom(:, j) = exp(-0.5 * ((wl_bead - BEAD_PEAK_NM(j)) / BEAD_SIG).^2);
    end

    for k = 1:N_RUNS
        rng(SEEDS(k));      % trainer network init only; raster order kept
        base_args = {'spherize','yes', 'verbose',0, ...
            'MM_ITERS',MM_ITERS, 'WARM_UP',WARM_UP, 'LR',3e-4, ...
            'LAMBDA_VOL',0.008, 'LAMBDA_NONNEG',3, 'LAMBDA_EQ',100, ...
            'LAMBDA_ENCLOSE',10, ...
            'IMG_H',Hb, 'IMG_W',Wb, 'LAMBDA_SPATIAL',2, ...
            'NOISE_MODEL','poisson', 'ETA',0.1, ...
            'PHOTON_GAIN',1, 'PHOTON_FLOOR',1, 'READ_SIGMA',READ_SIG, ...
            'USE_GPU',USE_GPU, 'GPU_PRECISION',GPU_PRECISION, 'GPU_DEVICE',GPU_DEVICE};

        fprintf('arm 2, run %d/%d (seed %d): training PISCO on %d pixels, p = %d ...\n', ...
            k, N_RUNS, SEEDS(k), Nb, P_BEAD);
        t_run = tic;                                % paired handle
        [M_b, S_b] = deep_mvsa_invflow_poisson_explicit_Warmup2_NoASC_E14C(Yb, P_BEAD, base_args{:});
        time_s = toc(t_run);                        % paired toc
        T2_m(k) = time_s;
        fprintf('  training finished in %.1f s\n', time_s);

        % name the three components: greedy SAD match of the two nominal
        % dye spectra onto the three blind endmembers; the leftover
        % endmember is the background/autofluorescence component
        [pb, sad_b] = e14_match(M_nom, M_b, true(1, 2));
        idx_bg = setdiff(1:P_BEAD, pb);
        if numel(idx_bg) ~= 1 || any(isnan(pb))
            fprintf(2, ['  WARNING: bead component naming degenerate; ' ...
                'NaN metrics for this run.\n']);
            comp_ord = [NaN NaN NaN];
        else
            comp_ord = [pb(1) pb(2) idx_bg];    % [core512 shell525 BG]
            SAD_b(k, 1:2) = sad_b;              % SAD vs nominals (ref. only)
        end

        % per-component CSV rows (pearson_r undefined here -> NaN)
        for j = 1:P_BEAD
            fprintf(fid, 'arm2_beads,%d,%d,%d,%s,%g,%g,%.2f\n', ...
                k, SEEDS(k), P_BEAD, BEAD_COMP{j}, SAD_b(k,j), NaN, time_s);
            n_csv_rows = n_csv_rows + 1;
        end
        fprintf('  run %d: SAD vs nominal 512/525 spectra [%s] deg (reference only)\n', ...
            k, num2str(SAD_b(k,1:2), ' %.2f'));

        if k == 1 && ~any(isnan(comp_ord))
            b1_M = M_b; b1_S = S_b(comp_ord, :); b1_cube = B_cube;
            b1_ord = comp_ord;              % [core512 shell525 BG] columns
            bead_done = true;
        end
    end

    % --- core-shell geometry check (run-1 abundances) -----------------
    % Auto-locate the brightest bead: Otsu threshold on the total
    % intensity, largest connected component, intensity-weighted
    % centroid; then radial-mean abundance profiles of the core (512)
    % and shell (525) components. Geometry is verified when the shell
    % profile peaks OUTSIDE the core profile.
    if bead_done
        tot_b = squeeze(sum(b1_cube, 1));
        gb = mat2gray(tot_b);
        mask = imbinarize(gb, graythresh(gb));
        mask = bwareaopen(mask, 20);
        cc = bwconncomp(mask);
        if cc.NumObjects > 0
            sz = cellfun(@numel, cc.PixelIdxList);
            [~, ibig] = max(sz);
            pix = cc.PixelIdxList{ibig};
            [rr, ccv] = ind2sub([Hb Wb], pix);
            wgt = tot_b(pix);
            cx = sum(ccv .* wgt) / sum(wgt);
            cy = sum(rr  .* wgt) / sum(wgt);
            core_img = reshape(b1_S(1, :), Hb, Wb);
            shell_img = reshape(b1_S(2, :), Hb, Wb);
            rmax = ceil(sqrt(Hb^2 + Wb^2) / 2);
            [rad, prof_core]  = e14_radial(core_img,  cx, cy, rmax);
            [~,   prof_shell] = e14_radial(shell_img, cx, cy, rmax);
            [~, ipk_core]  = max(prof_core);
            [~, ipk_shell] = max(prof_shell);
            geom_pass = rad(ipk_shell) > rad(ipk_core);
            fprintf(['  core-shell geometry (run 1): core 512 peak at r = %d px, ' ...
                'shell 525 peak at r = %d px -> %s\n'], rad(ipk_core), ...
                rad(ipk_shell), mat2str(geom_pass));
            if geom_pass
                fprintf('  GEOMETRY CHECK PASSED: shell (525) peaks outside core (512).\n');
            else
                fprintf(2, ['  GEOMETRY CHECK FAILED: shell (525) does not ' ...
                    'peak outside core (512); inspect Fig F.\n']);
            end
        else
            fprintf(2, ['  WARNING: no bright bead found by Otsu ' ...
                'thresholding; geometry check skipped.\n']);
        end
    end
end

% ---- arm-2 rows when the arm is missing/unreadable (NaN placeholders) -
if ~HAVE_BEAD
    for k = 1:N_RUNS
        for j = 1:P_BEAD
            fprintf(fid, 'arm2_beads,%d,%d,%d,%s,%g,%g,%g\n', ...
                k, SEEDS(k), P_BEAD, BEAD_COMP{j}, NaN, NaN, NaN);
            n_csv_rows = n_csv_rows + 1;
        end
    end
end

% ---- arm-2 MEAN summary row -------------------------------------------
sad_mean2 = mean(reshape(SAD_b, [], 1), 'omitnan');
fprintf(fid, 'arm2_beads,%d,%d,%d,%s,%g,%g,%g\n', ...
    0, 0, P_BEAD, 'MEAN', sad_mean2, NaN, mean(T2_m, 'omitnan'));
n_csv_rows = n_csv_rows + 1;

%% A.8 Arm 2 figures (run 1; Suppl. Fig. 11e-g material) -----------------
if bead_done
    tot_b = squeeze(sum(b1_cube, 1));
    core_img  = reshape(b1_S(1, :), Hb, Wb);
    shell_img = reshape(b1_S(2, :), Hb, Wb);

    % --- Fig E: bead render + 512/525 two-component abundance maps ----
    figure('Name','E14 Fig E: bead render + component abundances (run 1)', ...
        'Visible','on', 'Position',[40 40 1100 380], 'Color','w');
    subplot(1,3,1);
    imagesc(tot_b); axis image off; colormap gray; colorbar;
    title('FocalCheck bead, total intensity');
    subplot(1,3,2);
    imagesc(core_img); axis image off; colorbar;
    title('Core component (nominal 512 nm)');
    subplot(1,3,3);
    imagesc(shell_img); axis image off; colorbar;
    title('Shell component (nominal 525 nm)');
    sgtitle('E14 arm 2 (run 1): bead render and blind two-dye separation');
    saveas(gcf, fullfile(OUT_DIR, 'pisco_E14_figE_bead.png'));

    % --- Fig F: core-shell radial abundance profiles -------------------
    if exist('prof_core', 'var') && ~isempty(prof_core)
        figure('Name','E14 Fig F: core-shell radial profiles (run 1)', ...
            'Visible','on', 'Position',[60 60 640 420], 'Color','w');
        pc_n = prof_core / max(prof_core);
        ps_n = prof_shell / max(prof_shell);
        plot(rad, pc_n, 'o-', 'LineWidth', 1.4, 'Color', [0.00 0.45 0.74]); hold on;
        plot(rad, ps_n, 's-', 'LineWidth', 1.4, 'Color', [0.85 0.33 0.10]);
        line([rad(ipk_core) rad(ipk_core)], ylim, 'LineStyle','--', ...
            'Color', [0.00 0.45 0.74]);
        line([rad(ipk_shell) rad(ipk_shell)], ylim, 'LineStyle','--', ...
            'Color', [0.85 0.33 0.10]);
        xlabel('Radius from bead centroid (px)');
        ylabel('Radial-mean abundance (normalised)');
        grid on;
        legend('Core (512 nm)', 'Shell (525 nm)', 'Location','best');
        if geom_pass
            verdict = 'PASS: shell peaks outside core';
        else
            verdict = 'FAIL: shell does not peak outside core';
        end
        title(sprintf('E14 arm 2: core-shell geometry, %s', verdict));
        saveas(gcf, fullfile(OUT_DIR, 'pisco_E14_figF_radial.png'));
    end

    % --- Fig G: bead component spectra vs nominal dye spectra ----------
    figure('Name','E14 Fig G: bead spectra vs nominals (run 1)', ...
        'Visible','on', 'Position',[70 70 900 400], 'Color','w');
    for j = 1:2
        subplot(1,2,j);
        nm = M_nom(:, j);
        plot(wl_bead, nm / max(nm), 'k-', 'LineWidth', 2); hold on;
        ep = b1_M(:, b1_ord(j));
        plot(wl_bead, ep / max(ep), '--', 'LineWidth', 1.2, ...
            'Color', [0.64 0.08 0.18]);
        xlabel('Wavelength (nm, assumed axis)'); ylabel('Normalised intensity');
        title(sprintf('%s component, SAD = %s deg (ref. only)', ...
            BEAD_COMP{j}, num2str(SAD_b(1,j), '%.2f')));
        grid on;
        if j == 1
            legend(sprintf('Nominal dye (%d nm)', BEAD_PEAK_NM(j)), ...
                'PISCO blind', 'Location','best');
        end
    end
    sgtitle(['E14 arm 2 (run 1): bead component spectra vs nominal dye ' ...
        'spectra (assumed wavelength axis, section A.0)']);
    saveas(gcf, fullfile(OUT_DIR, 'pisco_E14_figG_bead_spectra.png'));
    fprintf('Arm-2 figures saved (pisco_E14_figE-G_*.png) to %s\n', OUT_DIR);
end

%% A.9 Close CSV, read-back self-check, console summary -------------------
fclose(fid);
fclose(fd);
fprintf('Per-endmember results written to %s\n', OUT_CSV);
fprintf('Lyso seed diagnostics written to %s\n', DIAG_CSV);

% readmatrix read-back self-check: the text columns (arm, endmember)
% import as NaN; the six numeric columns must parse, the row count must
% match the number of rows written, and the seed column must contain
% only the configured seeds or 0 (MEAN rows).
Mc = readmatrix(OUT_CSV);
assert(size(Mc, 2) == 8, 'E14:csvBad', ...
    'CSV self-check failed: expected 8 columns, got %d', size(Mc, 2));
assert(size(Mc, 1) == n_csv_rows, 'E14:csvRows', ...
    'CSV self-check failed: wrote %d rows, read back %d', ...
    n_csv_rows, size(Mc, 1));
seeds_ok = all(ismember(Mc(:, 3), [SEEDS 0]));
assert(seeds_ok, 'E14:csvSeeds', 'CSV self-check failed: bad seed column');
n_sad_ok = sum(~isnan(Mc(:, 6)));
fprintf(['CSV self-check passed: %d rows x %d columns; %d rows carry a ' ...
    'numeric sad_deg (rest are NaN by design).\n'], ...
    size(Mc,1), size(Mc,2), n_sad_ok);

fprintf('\n===== E14 SUMMARY (PISCO only, public benchmark, semi GT) =====\n');
fprintf('arm 1 (five-label cells): p_raw = %d, p_used = %d\n', p_raw, p_hat);
fprintf('  per-dye SAD (deg), mean over runs:\n');
for i = 1:N_DYE
    fprintf('    %-9s SAD %6s deg | r %6s\n', REF_NAMES{i}, ...
        num2str(mean(SAD_m(:,i), 'omitnan'), '%.2f'), ...
        num2str(mean(PCC_m(:,i), 'omitnan'), '%.3f'));
end
fprintf('    MEAN      SAD %6s deg (target < 5) | r %6s (target > 0.9)\n', ...
    num2str(sad_mean1, '%.2f'), num2str(pcc_mean1, '%.3f'));
if HAVE_BEAD
    fprintf('arm 2 (FocalCheck beads): SAD vs nominal 512/525 spectra [%s] deg (ref. only)\n', ...
        num2str(mean(SAD_b(:,1:2), 1, 'omitnan'), ' %.2f'));
    fprintf('  core-shell geometry check: %s\n', mat2str(geom_pass));
else
    fprintf('arm 2 (FocalCheck beads): SKIPPED (file missing/unreadable), CSV rows are NaN\n');
end
fprintf('CSV: %s\nReferences: %s\nAll outputs folder: %s\n', OUT_CSV, REF_CSV, OUT_DIR);

function info = e14_update_noasc_diagnostics(info, Y, lyso_ref, M0_seed, Up_model, my_model)
% Re-evaluate PCA/projection diagnostic fields in the *actual* NoASC model.
% NoASC shape covariance uses Y - mean(Y)*relative_pixel_intensity.
[L,N]=size(Y);
p=size(M0_seed,2);
mu=double(my_model(:));
lyso_ref=double(lyso_ref(:));
intensity_ref=sum(mu);
scale=sum(Y,1)/intensity_ref;
Y_shape = Y - mu*scale;
shape_cov=Y_shape*Y_shape'/N;
[Ustd,Dstd]=svds(shape_cov,p-1);
seed_col=info.seed_col;
seed_band=M0_seed(:,seed_col);
seed_band=seed_band*(intensity_ref/max(sum(seed_band),eps));
proj_std=mu+Ustd*(Ustd'*(seed_band-mu));
Uguide=double(Up_model(:,1:p-1));
proj_guided=mu+Uguide*(Uguide'*(seed_band-mu));
info.raw_sad_deg=e14_safe_sad(seed_band,lyso_ref);
info.proj_sad_deg=e14_safe_sad(proj_guided,lyso_ref);
info.base_proj_sad_deg=e14_safe_sad(proj_std,lyso_ref);
info.guided_proj_sad_deg=info.proj_sad_deg;
info.base_proj_relerr=norm(proj_std-seed_band)/max(norm(seed_band),eps);
info.guided_proj_relerr=norm(proj_guided-seed_band)/max(norm(seed_band),eps);
info.standard_pca_projected_band=proj_std;
info.lyso_projected=proj_guided;
info.base_subspace_rre=norm(Y_shape-Ustd*(Ustd'*Y_shape),'fro')/max(norm(Y,'fro'),eps);
info.guided_subspace_rre=norm(Y_shape-Uguide*(Uguide'*Y_shape),'fro')/max(norm(Y,'fro'),eps);
info.original_last_variance=Dstd(end,end);
info.guided_axis_variance=Uguide(:,end)'*shape_cov*Uguide(:,end);
info.noasc_intensity_ref=intensity_ref;
info.noasc_seed_normalized_band=seed_band;
info.noasc_seed_projection_band=proj_guided;
info.noasc_seed_projection_sad_deg=info.proj_sad_deg;
end

%% ==================== local functions ================================
function info = e14_blank_seed_info()
%E14_BLANK_SEED_INFO Default diagnostics for blind VCA control.
info = struct('seed_col',NaN,'scale_factor',NaN,'raw_sad_deg',NaN, ...
    'proj_sad_deg',NaN,'rcond_m0',NaN,'vca_raw',[], ...
    'lyso_scaled',[],'lyso_projected',[], ...
    'base_proj_sad_deg',NaN,'guided_proj_sad_deg',NaN, ...
    'base_proj_relerr',NaN,'guided_proj_relerr',NaN, ...
    'base_subspace_rre',NaN,'guided_subspace_rre',NaN, ...
    'guided_axis_variance',NaN,'original_last_variance',NaN, ...
    'standard_pca_projected_band',[]);
end

function [M0_band, info] = e14_lyso_seed_m0(Y, p, lyso_ref, mode)
%E14_LYSO_SEED_M0 Matched Group B/C VCA initialization in 28-band units.
% In BOTH B and C, calibrate Lyso intensity from a *standard PCA/VCA*
% baseline. That holds the Lyso amplitude fixed between B and C.
% In C, replace PCA direction p-1 by the component of scaled Lyso that
% is orthogonal to the first p-2 PCA directions. The affine subspace then
% contains Lyso EXACTLY (up to floating-point error), keeping p-1 DOF.
% This is Lyso-guided SEMI-SUPERVISED diagnosis, NOT blind E14 evidence.
[L,N] = size(Y);
lyso_ref=double(lyso_ref(:));
assert(numel(lyso_ref)==L && all(isfinite(lyso_ref)) && ...
    all(lyso_ref>=0) && norm(lyso_ref)>0, ...
    'E14C:invalidLyso','Invalid Lyso L-by-1 reference spectrum.');
assert(p>=3 && p<=L, 'E14C:badP','Need 3 <= p <= number of bands.');
mu=mean(Y,2);
Yc=Y-mu;
Cov=Yc*Yc'/N;
[Ustd,Dstd]=svds(Cov,p-1);
lam=1e-10;

% Original PCA-then-VCA scale calibration, with a reproducible RNG state.
vca_rng_state=rng;
sc_std=sqrt(diag(Dstd + lam*eye(p-1)));
Ys_std=diag(1./sc_std)*Ustd'*Yc;
Ys_std(p,:)=1;
Ys_std=Ys_std/sqrt(p);
M0_vca_std_work=VCA(Ys_std, 'Endmembers',p,'verbose','off');
assert(isequal(size(M0_vca_std_work),[p,p]) && ...
    all(isfinite(M0_vca_std_work(:))), ...
    'E14C:vcaInvalid','Standard VCA initialization is invalid.');
M0_vca_std_band=mu+Ustd*bsxfun(@times,sc_std, ...
    sqrt(p)*M0_vca_std_work(1:p-1,:));
vca_totals=sum(max(M0_vca_std_band,0),1);
valid_totals=vca_totals(isfinite(vca_totals) & vca_totals>0);
assert(~isempty(valid_totals),'E14C:badScale', ...
    'VCA failed to provide positive reference intensity.');
target_total=median(valid_totals);
scale_factor=target_total/sum(lyso_ref);
lyso_scaled=lyso_ref*scale_factor;

% Standard affine PCA projection (B-group initial restriction).
standard_proj=mu+Ustd*(Ustd'*(lyso_scaled-mu));
standard_relerr=norm(standard_proj-lyso_scaled)/max(norm(lyso_scaled),eps);
standard_sad=e14_safe_sad(standard_proj,lyso_ref);
base_subspace_rre=norm(Yc-Ustd*(Ustd'*Yc),'fro')/max(norm(Y,'fro'),eps);

U=Ustd;
D=Dstd;
var_last=Dstd(p-1,p-1);
if strcmp(mode,'lyso_subspace')
    top=Ustd(:,1:p-2);
    dir=lyso_scaled-mu;
    missing=dir-top*(top'*dir);
    assert(norm(missing)>1e-11*max(norm(dir),1), ...
        'E14C:redundant','Lyso already represented by p-2 PCA axes.');
    guided_last=missing/norm(missing);
    var_last=guided_last'*Cov*guided_last;
    assert(isfinite(var_last) && var_last>1e-12, ...
        'E14C:weakAxis','Lyso-guided direction carries negligible data variance.');
    U=[top guided_last];
    D=diag([diag(Dstd(1:p-2,1:p-2));var_last]);
end

guided_proj=mu+U*(U'*(lyso_scaled-mu));
guided_relerr=norm(guided_proj-lyso_scaled)/max(norm(lyso_scaled),eps);
guided_sad=e14_safe_sad(guided_proj,lyso_ref);
guided_subspace_rre=norm(Yc-U*(U'*Yc),'fro')/max(norm(Y,'fro'),eps);
if strcmp(mode,'lyso_subspace')
    assert(guided_relerr < 1e-8, 'E14C:projectionFailed', ...
        'Lyso-guided subspace failed exact projection check.');
end

% For B: reuse the precomputed original VCA, exactly matching previous B.
% For C: use same VCA RNG draw but on guided subspace spectra.
if strcmp(mode,'lyso_subspace')
    rng(vca_rng_state);
    sd=sqrt(diag(D+lam*eye(p-1)));
    Ys=diag(1./sd)*U'*Yc;
    Ys(p,:)=1;
    Ys=Ys/sqrt(p);
    M0_vca_work=VCA(Ys,'Endmembers',p,'verbose','off');
    assert(isequal(size(M0_vca_work),[p,p]) && ...
        all(isfinite(M0_vca_work(:))), ...
        'E14C:vcaInvalid','Guided VCA initialization is invalid.');
    M0_vca_band=mu+U*bsxfun(@times,sd, ...
        sqrt(p)*M0_vca_work(1:p-1,:));
else
    M0_vca_work=M0_vca_std_work;
    M0_vca_band=M0_vca_std_band;
    sd=sc_std;
end

lyso_work=[(U'*(lyso_scaled-mu))./(sd*sqrt(p)); 1/sqrt(p)];
near=inf(p,p);
for a=1:p
    for b=a+1:p
        da=e14_safe_sad(M0_vca_band(:,a),M0_vca_band(:,b));
        near(a,b)=da; near(b,a)=da;
    end
end
[~,candidate_cols]=sort(min(near,[],2),'ascend');
seed_col=NaN; rc=NaN; M0_seed_work=[];
for z=1:p
    idx=candidate_cols(z);
    proposal=M0_vca_work;
    proposal(:,idx)=lyso_work;
    this_rc=rcond(proposal);
    if isfinite(this_rc) && this_rc>=1e-9
        M0_seed_work=proposal;
        seed_col=idx;
        rc=this_rc;
        break
    end
end
assert(~isempty(M0_seed_work),'E14C:singularSeed', ...
    'All candidate VCA replacements were singular/ill-conditioned.');
M0_band=mu+U*bsxfun(@times,sd, ...
    sqrt(p)*M0_seed_work(1:p-1,:));
assert(isequal(size(M0_band),[L,p]) && all(isfinite(M0_band(:))), ...
    'E14C:invalidM0','Bad seeded M0 after inverse whitening.');

info=e14_blank_seed_info();
info.seed_col=seed_col;
info.scale_factor=scale_factor;
info.raw_sad_deg=e14_safe_sad(lyso_scaled,lyso_ref);
info.proj_sad_deg=e14_safe_sad(M0_band(:,seed_col),lyso_ref);
info.rcond_m0=rc;
info.vca_raw=M0_vca_band;
info.lyso_scaled=lyso_scaled;
info.lyso_projected=guided_proj;
info.standard_pca_projected_band=standard_proj;
info.base_proj_sad_deg=standard_sad;
info.guided_proj_sad_deg=guided_sad;
info.base_proj_relerr=standard_relerr;
info.guided_proj_relerr=guided_relerr;
info.base_subspace_rre=base_subspace_rre;
info.guided_subspace_rre=guided_subspace_rre;
info.guided_axis_variance=var_last;
info.original_last_variance=Dstd(p-1,p-1);
end

function sad = e14_safe_sad(a,b)
%E14_SAFE_SAD Numeric-guarded spectral angle (degrees).
a=double(a(:)); b=double(b(:));
ok=isfinite(a)&isfinite(b);
a=a(ok); b=b(ok);
if isempty(a)||norm(a)<eps||norm(b)<eps
    sad=NaN; return;
end
sad = acosd(max(-1,min(1,(a'*b)/(norm(a)*norm(b)))));
end

function Y_cube = e14_read_lsm(fname)
%E14_READ_LSM Generic Zeiss LSM reader, whole spectral cube, one z/t.
%   Copied and adapted from e7_read_lsm_plane (demo_pisco_E7_downstream.
%   m, v1.1-E7). LSM is a little-endian TIFF variant; the private tag
%   34412 (LSMINFO, BYTE array) on directory 1 holds the dimensions at
%   byte offsets +8 i32 X, +12 i32 Y, +16 i32 Z, +20 i32 CH, +24 i32 T.
%   Adaptations for the PhasorPy 28-channel files:
%     - ALL sample planes are kept (no fixed 32-channel cap; the
%       PhasorPy five-label LSM carries 28 spectral channels and no
%       separate transmission page is assumed);
%     - the files may hold a SINGLE z plane and a SINGLE time point
%       (z = 1, t = 1): the reader is tolerant to that -- with
%       PlanarConfig = 2 and SamplesPerPixel > 1 one data page already
%       contains the whole L x H x W cube; with SamplesPerPixel = 1 the
%       data pages are stacked as the channel axis (pages = channels,
%       z = t = 1 assumed, a warning is printed if the page count looks
%       like more than one z/t series);
%     - if several full-frame pages exist with SamplesPerPixel > 1
%       (a z stack), the brightest-total-intensity page is used.
%   Fallback if the LSMINFO tag cannot be read: the pages with the
%   largest W x H product are taken as data pages.
%   Returns Y_cube as L x H x W double (photon counts).

t = Tiff(fname, 'r');
cleaner = onCleanup(@() t.close()); %#ok<NASGU> (keeps t open till return)

% --- LSMINFO private tag 34412 on directory 1 (byte offsets above) ---
have_info = false; Xi = 0; Yi = 0;
try
    tag = uint8(t.getTag(34412));       % BYTE array; Tiff.getTag accepts
    tag = tag(:);                       % a numeric tag id for unknown tags
    if numel(tag) >= 28
        Xi = double(typecast(tag(9:12),  'int32'));   % +8  i32 X
        Yi = double(typecast(tag(13:16), 'int32'));   % +12 i32 Y
        have_info = (Xi > 0) && (Yi > 0);
    end
catch
    have_info = false;
end

% --- walk all directories, record page sizes and samples-per-pixel ---
ws = []; hs = []; spps = [];
while true
    ws(end+1)    = t.getTag(Tiff.TagID.ImageWidth);     %#ok<AGROW>
    hs(end+1)    = t.getTag(Tiff.TagID.ImageLength);    %#ok<AGROW>
    try
        spps(end+1) = t.getTag(Tiff.TagID.SamplesPerPixel); %#ok<AGROW>
    catch
        spps(end+1) = 1;    % tag absent: TIFF default is 1 %#ok<AGROW>
    end
    if t.lastDirectory(), break; end
    t.nextDirectory();
end
if have_info
    is_data = (ws == Xi) & (hs == Yi);
else
    % fallback: largest pages are the data pages
    is_data = (ws .* hs) == max(ws .* hs);
end
datapages = find(is_data);
assert(~isempty(datapages), 'E14:lsmNoData', ...
    'No full-frame data pages found in %s', fname);
spp = spps(datapages(1));
Hf = hs(datapages(1)); Wf = ws(datapages(1));

if spp > 1
    % --- one page holds all channels (PlanarConfig separate/chunky) ---
    if numel(datapages) > 1
        % z stack (z = 1, t = 1 expected for the PhasorPy files, but be
        % tolerant): use the brightest-total-intensity page
        best = -Inf; z_use = 1;
        for z = 1:numel(datapages)
            t.setDirectory(datapages(z));
            A = t.read();
            s = sum(reshape(double(A), [], 1));
            if s > best, best = s; z_use = z; end
        end
        fprintf(['  e14_read_lsm: %d full-frame pages, using brightest ' ...
            '(page %d)\n'], numel(datapages), z_use);
    else
        z_use = 1;
    end
    t.setDirectory(datapages(z_use));
    A = t.read();
    assert(ndims(A) == 3, 'E14:lsmBadRead', ...
        'Expected H x W x SPP page, got %s in %s', mat2str(size(A)), fname);
    Y_cube = double(permute(A, [3 1 2]));       % SPP x H x W
else
    % --- one channel per page: stack the data pages as channels -------
    if numel(datapages) > 1
        fprintf(['  e14_read_lsm: SamplesPerPixel = 1, stacking %d ' ...
            'pages as channels (z = 1, t = 1 assumed)\n'], numel(datapages));
    end
    Y_cube = zeros(numel(datapages), Hf, Wf);
    for z = 1:numel(datapages)
        t.setDirectory(datapages(z));
        A = t.read();
        assert(ismatrix(A) && size(A,1) == Hf && size(A,2) == Wf, ...
            'E14:lsmBadRead', 'Unexpected page size %s in %s', ...
            mat2str(size(A)), fname);
        Y_cube(z, :, :) = double(A);
    end
end
end

function [spec, img, fg_frac] = e14_ref_from_lsm(fname)
%E14_REF_FROM_LSM Reference spectrum and image from a single-label LSM.
%   Protocol (SI Note 6): the reference spectrum is the mean spectrum
%   over the foreground (cell) mask, where the mask is the Otsu
%   threshold of the total-intensity image; the reference image is the
%   total-intensity image itself (sum over channels). fg_frac is the
%   foreground fraction (diagnostic). spec is L x 1.
cube = e14_read_lsm(fname);             % L x H x W
img = squeeze(sum(cube, 1));            % total-intensity image
g = mat2gray(img);
mask = imbinarize(g, graythresh(g));
mask = bwareaopen(mask, 20);            % drop specks < 20 px
mask = imclose(mask, strel('disk', 2));
[L, H, W] = size(cube);
m2 = reshape(mask, 1, []);
if sum(m2) < 10
    fprintf(2, ['WARNING: e14_ref_from_lsm: foreground mask nearly ' ...
        'empty in %s; using the full frame for the reference ' ...
        'spectrum.\n'], fname);
    m2 = true(1, H * W);
end
pix = reshape(cube, L, []);
spec = mean(pix(:, m2), 2);             % foreground mean spectrum
fg_frac = sum(m2) / numel(m2);
end

function B_cube = e14_read_bead(fname)
%E14_READ_BEAD Multi-format probe reader for the FocalCheck bead cube.
%   The download format is not certified (.lsm/.tif/.czi/.mat all
%   plausible), so three readers are tried in order:
%     probe 1: LSM/TIFF via e14_read_lsm (handles .lsm and most .tif);
%     probe 2: multi-page TIFF via imfinfo/imread (page = channel, or
%              samples-as-channels for a single multi-sample page);
%     probe 3: .mat file holding a numeric 3-D variable (the smallest
%              dimension is taken as the spectral axis);
%   .czi cannot be parsed without Bio-Formats: all probes then fail and
%   the caller's catch block skips arm 2 with a prominent warning.
%   Returns B_cube as L x H x W double.
try
    B_cube = e14_read_lsm(fname);       % probe 1
    return
catch
    % fall through to probe 2
end
try
    info = imfinfo(fname);              % probe 2: multi-page TIFF
    A1 = imread(fname, 1);
    if ndims(A1) == 3
        B_cube = double(permute(A1, [3 1 2]));   % samples as channels
        return
    end
    npg = numel(info);
    B_cube = zeros(npg, size(A1,1), size(A1,2));
    B_cube(1, :, :) = double(A1);
    for pg = 2:npg
        B_cube(pg, :, :) = double(imread(fname, pg));
    end
    return
catch
    % fall through to probe 3
end
S = load(fname);                        % probe 3: .mat (errors if not mat)
fn = fieldnames(S);
for i = 1:numel(fn)
    v = S.(fn{i});
    if isnumeric(v) && ndims(v) == 3
        [~, d] = min(size(v));          % smallest dim = spectral axis
        B_cube = double(permute(v, [d, setdiff(1:3, d)]));
        return
    end
end
error('E14:beadUnreadable', 'no readable 3-D numeric data found in %s', fname);
end

function p_hat = e14_hysime(Y_counts, IMG_H, IMG_W)
%E14_HYSIME HySime estimate of the endmember number (identical to the
%   E5 demo's e5_hysime; Bioucas-Dias & Nascimento, "Hyperspectral
%   Subspace Identification", IEEE TGRS 46(8):2435-2445, 2008, eqs.
%   (9)-(15), (22)-(24)). Verbatim port of the authors' hysime.m /
%   estNoise.m (GPL-2.0, http://www.lx.it.pt/~bioucas/code.htm) with
%   one documented adaptation: the criterion runs on BIN x BIN
%   superpixel-averaged data with the estNoise covariance scaled by
%   1/BIN^2 (spatial averaging divides the white-noise variance by the
%   bin area but preserves the signal subspace). See the E5 demo header
%   for the full rationale and the Python validation summary.
BIN = 4;                            % superpixel side (128 -> 32 x 32)
[L, N] = size(Y_counts);
Hb = IMG_H / BIN;  Wb = IMG_W / BIN;
if Hb ~= floor(Hb) || Wb ~= floor(Wb)
    error('e14_hysime: image size must be divisible by BIN = %d.', BIN);
end

% --- verbatim estNoise on the raw counts (see subfunction below) ---
Rn = e14_estnoise(Y_counts);        % diagonal noise correlation matrix

% --- superpixel averaging; column-major pixel order matches reshape ---
A  = reshape(Y_counts, L, BIN, Hb, BIN, Wb);
Yb = reshape(mean(mean(A, 2), 4), L, Hb * Wb);
Nb = Hb * Wb;
Rn = Rn / (BIN * BIN);              % white-noise variance / bin area

% --- verbatim HySime criterion on the binned data ---
Ry = Yb * Yb' / Nb;                 % sample correlation matrix
Rx = Ry - Rn;                       % eq. (13) literally: signal correl. est.
[E, D] = eig((Rx + Rx') / 2);       % NOTE: eig returns ASCENDING order
[~, ord] = sort(diag(D), 'descend');
E = E(:, ord);                      % descending, like [E,~] = svd(Rx)
Rn = Rn + sum(diag(Rx)) / L / 1e10 * eye(L);   % regularisation (verbatim)
Py = diag(E' * Ry * E);             % eq. (23)
Pn = diag(E' * Rn * E);             % eq. (24)
cost_F = -Py + 2 * Pn;              % eq. (22)
p_hat = sum(cost_F < 0);
p_hat = max(p_hat, 1);              % guard: a subspace of dim 0 is invalid
end

function Rn = e14_estnoise(y)
%E14_ESTNOISE Verbatim port of estAdditiveNoise (Bioucas-Dias &
%   Nascimento, 2008): additive-noise estimation by bandwise multiple
%   linear regression (paper eqs. (9)-(14)); returns the DIAGONAL noise
%   correlation matrix Rn = diag(diag(w*w'/N)), as in estNoise.m.
[L, N] = size(y);
small = 1e-6;
RR  = y * y';                       % eq. (11)
RRi = inv(RR + small * eye(L));     % eq. (11)
w = zeros(L, N);
for i = 1:L
    XX = RRi - (RRi(:,i) * RRi(i,:)) / RRi(i,i);   % eq. (14)
    RRa = RR(:,i); RRa(i) = 0;      % remove the effects of XX(:,i)
    beta = XX * RRa; beta(i) = 0;   % eq. (9); remove XX(i,:) effect
    w(i,:) = y(i,:) - beta' * y;    % eq. (10): noise estimate
end
Rn = diag(diag(w * w' / N));
end

function [perm, sad_v] = e14_match(M_ref, M_est, have_ref)
%E14_MATCH Greedy one-to-one SAD matching of references to endmembers.
%   E1 e1_match logic generalised to a rectangular problem: nref
%   reference spectra (some possibly missing, have_ref = false, or
%   partially NaN after channel truncation) vs pe estimated endmembers,
%   pe possibly ~= nref. Reference i is assigned endmember perm(i)
%   (NaN if missing or if no unused endmember remains); sad_v(i) is the
%   matching SAD in degrees. References are processed in fixed order,
%   each taking its best unused endmember (the E1 greedy rule). SADs
%   are computed on the common (non-NaN) channels only.
nref = size(M_ref, 2);
pe = size(M_est, 2);
perm = NaN(1, nref);
sad_v = NaN(1, nref);
valid = find(have_ref & ~all(isnan(M_ref), 1));
if isempty(valid) || pe == 0, return; end
C = NaN(nref, pe);
for i = valid
    for j = 1:pe
        a = M_ref(:, i);
        b = M_est(:, j);
        ok = ~isnan(a) & ~isnan(b);     % common channels only
        a = a(ok); b = b(ok);
        if isempty(a) || norm(a) == 0 || norm(b) == 0, continue; end
        C(i, j) = acosd(max(-1, min(1, (a' * b) / (norm(a) * norm(b)))));
    end
end
taken = false(1, pe);
for i = valid
    avail = find(~taken & ~isnan(C(i, :)));
    if isempty(avail), continue; end    % more references than endmembers
    [~, kk] = min(C(i, avail));
    jj = avail(kk);
    perm(i) = jj;
    sad_v(i) = C(i, jj);
    taken(jj) = true;
end
end

function r = e14_pearson(a, b)
%E14_PEARSON Pearson correlation between two images, NaN-safe.
a = a(:); b = b(:);
ok = isfinite(a) & isfinite(b);
a = a(ok); b = b(ok);
if numel(a) < 3 || std(a) == 0 || std(b) == 0
    r = NaN;
    return
end
a = a - mean(a);
b = b - mean(b);
r = (a' * b) / (norm(a) * norm(b));
r = max(-1, min(1, r));
end

function [rad, prof] = e14_radial(img, cx, cy, rmax)
%E14_RADIAL Radial-mean profile of img around centroid (cx, cy).
%   rad = (0:rmax).' bin centres (pixels); prof(r) = mean of img over
%   the unit-width annulus at radius r; empty bins are filled by
%   nearest-neighbour propagation so the profiles are NaN-free.
[H, W] = size(img);
[XX, YY] = meshgrid(1:W, 1:H);
R = sqrt((XX - cx).^2 + (YY - cy).^2);
rad = (0:rmax).';
prof = NaN(rmax + 1, 1);
for ri = 0:rmax
    m = R >= ri - 0.5 & R < ri + 0.5;
    if any(m(:))
        prof(ri + 1) = mean(img(m));
    end
end
ok = ~isnan(prof);
if any(ok)
    prof = interp1(rad(ok), prof(ok), rad, 'nearest', 'extrap');
end
end
