%% demo_pisco_E3_fivelabel_multiseed_CSV_GYL.m
% E-3: Five-label real-cell benchmark, TEN seeds (1001:1010).
% Based on the user's E14 Group-C Lyso-guided NoASC MATLAB demo.
% Training model is NOT modified: use the supplied
%   deep_mvsa_invflow_poisson_explicit_Warmup2_NoASC_E14C.m
% Same data, reference spectra, guided initialization, GPU and optimization
% hyperparameters for every seed. Only initialization RNG seed changes.
%
% Output: ONE CSV in a SEPARATE folder (ten numeric data rows, one per seed).
% No MAT/PNG/SVG/diagnostic CSV/extra logs are created by this driver.
% Completion checkpoint is the same CSV; successful seeds are skipped on rerun.
%
% ATTENTION:
% - Group C uses Lyso single-stain reference in the initialization;
%   this is REF-GUIDED (semi-supervised), not fully blind PISCO.
% - NoASC S_est contains unnormalised coefficients, not fractional abundances.
% - Single-stain reference images contain DIFFERENT cells; pixelwise
%   correlation with them is NOT a valid abundance ground-truth metric.
% - abundance_r_seed1001_* is the cross-SEED correlation of SAME-FOV
%   coefficient maps on a fixed intensity foreground mask, NOT accuracy.
%   Seed1001 is the anchor (its own correlation is NaN); n_valid <= 9.
% - Seed1001 anchor is only in RAM. On resume it may be retrained once;
%   this is unavoidable with strictly one small output CSV.
% - E14-C uses SIGMA_CAP=0.15, whereas v78 SI Table 1 says 0.03.
%   This driver preserves E14-C 0.15 to avoid silently changing the old
%   evaluation protocol. Resolve this mismatch before paper submission.
% - This script has not been executed with MATLAB/data in this environment.
%
% Required: VCA.m on MATLAB path, Image Processing Toolbox for masks,
%          an NVIDIA GPU + Parallel Computing Toolbox if USE_GPU=true.

clear; close all; clc;

%% 0. Configuration ------------------------------------------------------
QUICK = false;                 % MUST be false for paper: full mixed-cell FOV
RESUME = true;                 % rerun: skip completed seeds in the same CSV
SEEDS = 7001:7010;            % 10 independent training/initialization seeds
USE_GPU = true;               % false for CPU, if required
GPU_PRECISION = 'single';
GPU_DEVICE = 1;
MM_ITERS = 2500;              % 600 warm-up + 1900 joint, source convention
WARM_UP = 600;
READ_SIG = 1.0;
SIGMA_CAP_USED = 0.15;       % supplied E14-C default; v78 SI default is 0.03
P_FIXED = 6;                  % supplied E14-C uses p=6 (five dyes + background)
LYSO_INIT_MODE = 'lyso_subspace'; % fixed Group C, not Group A/B
CROP = 128;                   % QUICK smoke test only

script_dir = fileparts(mfilename('fullpath'));
if isempty(script_dir), script_dir = pwd; end
addpath(script_dir);
DATA_DIR = fullfile(script_dir, 'data_E14');
if ~isfolder(DATA_DIR) && isfolder(fullfile(pwd, 'data_E14'))
    DATA_DIR = fullfile(pwd, 'data_E14');
end
F_MIX = fullfile(DATA_DIR, ...
    '38_Hoechst_Golgi_Mito_Lyso_CellMAsk_404_488_561_633_SP.lsm');
REF_NAMES = {'Hoechst','Golgi','Mito','Lyso','CellMask'};
REF_FILES = {fullfile(DATA_DIR,'spectral hoehst.lsm'), ...
    fullfile(DATA_DIR,'spectral golgi.lsm'), ...
    fullfile(DATA_DIR,'spectral mito tracker.lsm'), ...
    fullfile(DATA_DIR,'spectral lyso tracker green.lsm'), ...
    fullfile(DATA_DIR,'spectral cell mask.lsm')};
N_DYE = numel(REF_NAMES);
LYSO_REF_IDX = find(strcmp(REF_NAMES,'Lyso'),1);

OUT_DIR = fullfile(script_dir, 'E3_fivelabel_multiseed_CSV_only_results');
if ~isfolder(OUT_DIR)
    [ok,msg] = mkdir(OUT_DIR);
    assert(ok, 'Cannot create output folder: %s', msg);
end
OUT_CSV = fullfile(OUT_DIR,'pisco_E3_fivelabel_multiseed_results.csv');

assert(exist('VCA','file')==2, 'Missing VCA.m on MATLAB path.');
assert(exist('deep_mvsa_invflow_poisson_explicit_Warmup2_NoASC_E14C','file')==2, ...
    'Missing deep_mvsa_invflow_poisson_explicit_Warmup2_NoASC_E14C.m');
assert(isfile(F_MIX), 'Missing mixed-cell LSM: %s', F_MIX);
for j=1:N_DYE
    assert(isfile(REF_FILES{j}), 'Missing %s single-stain LSM: %s', ...
        REF_NAMES{j}, REF_FILES{j});
end
assert(strcmp(LYSO_INIT_MODE,'lyso_subspace'), 'Must keep E14 Group-C mode.');

%% 1. Load only the five-label mixed field and its five references --------
fprintf('Reading mixed five-label image ...\n');
Y_cube = e14_read_lsm(F_MIX);   % L x H x W; original E14 LSM reader
[L,H,W] = size(Y_cube);
if QUICK
    assert(H>=CROP && W>=CROP,'QUICK crop exceeds source size.');
    r0=floor((H-CROP)/2)+1;
    c0=floor((W-CROP)/2)+1;
    Y_cube=Y_cube(:,r0:r0+CROP-1,c0:c0+CROP-1);
    [L,H,W]=size(Y_cube);
end
N=H*W;
Y=reshape(Y_cube,L,N);        % raster order; do NOT permute pixels
clear Y_cube;

ref_spec=nan(L,N_DYE);
for j=1:N_DYE
    [spec_j,~,~] = e14_ref_from_lsm(REF_FILES{j});
    assert(numel(spec_j)==L, ...
        'Reference channel mismatch for %s (%d rather than %d).', ...
        REF_NAMES{j}, numel(spec_j), L);
    ref_spec(:,j)=double(spec_j(:));
end
assert(all(isfinite(ref_spec(:))) && all(vecnorm(ref_spec)>0), ...
    'A single-stain reference spectrum is invalid.');

% FIXED mask used only for post-training residual and across-seed stability.
% The complete image Y (including background) enters every training run.
intensity = reshape(sum(Y,1),H,W);
intensity_norm = mat2gray(intensity);
fgmask = imbinarize(intensity_norm,graythresh(intensity_norm));
if nnz(fgmask)<max(64,round(1e-3*N))
    fgmask = intensity > 0;
end
mask_idx = find(fgmask(:));
assert(numel(mask_idx)>=64,'Insufficient non-background pixels.');
clear intensity intensity_norm fgmask;

% Same HySime estimate + p=6 clamp used by the supplied E14-C driver.
try
    p_raw=e14_hysime(Y,H,W);
catch ME
    warning('E3:HySime', 'HySime failed (%s); p_raw set to 5.',ME.message);
    p_raw=5;
end
p_hat=P_FIXED;
assert(p_hat==6 && L>=p_hat, 'Expected a six-component Group-C run.');

%% 2. One ten-row CSV for checkpoint AND paper statistics ----------------
% 10 rows, one per seed, NOT a summary table; another AI can compute
% mean +/- sample std and min/max directly. All columns are numeric.
% run_status: 1=success, 0=pending, -1=failed (eligible for retry).
COLS = { ...
    'seed','run','image_h','image_w','p_raw','p_used','sigma_cap', ...
    'SAD_Hoechst','SAD_Golgi','SAD_Mito','SAD_Lyso','SAD_CellMask', ...
    'SAD_mean_deg','reconstruction_RRE','masked_pixel_residual_mean', ...
    'abundance_r_seed1001_Hoechst', ...
    'abundance_r_seed1001_Golgi', ...
    'abundance_r_seed1001_Mito', ...
    'abundance_r_seed1001_Lyso', ...
    'abundance_r_seed1001_CellMask', ...
    'abundance_r_seed1001_mean', ...
    'time_s','run_status'};
nRuns=numel(SEEDS);
T=array2table(nan(nRuns,numel(COLS)), 'VariableNames', COLS);
T.seed=SEEDS(:);
T.run=(1:nRuns)';
T.image_h=repmat(H,nRuns,1);
T.image_w=repmat(W,nRuns,1);
T.p_raw=repmat(p_raw,nRuns,1);
T.p_used=repmat(p_hat,nRuns,1);
T.sigma_cap=repmat(SIGMA_CAP_USED,nRuns,1);
T.run_status=zeros(nRuns,1);

if RESUME && isfile(OUT_CSV)
    old=readtable(OUT_CSV);
    assert(isequal(old.Properties.VariableNames,COLS), ...
        'CSV header differs from this script. Move the old CSV before rerun.');
    assert(height(old)==nRuns && isequal(old.seed(:),SEEDS(:)) && ...
        isequal(old.run(:),(1:nRuns)') && ...
        all(old.image_h==H) && all(old.image_w==W) && ...
        all(old.p_used==p_hat) && all(old.p_raw==p_raw) && ...
        all(old.sigma_cap==SIGMA_CAP_USED), ...
        'CSV checkpoint belongs to another data shape/seed/protocol.');
    T=old;
else
    e3_write_one_csv(T,OUT_CSV);
end

fprintf('\nE-3 Group C: %dx%d, L=%d, p=%d, n=%d, seeds=%d..%d\n', ...
    H,W,L,p_hat,nRuns,SEEDS(1),SEEDS(end));
fprintf('Output (the ONLY result file): %s\n',OUT_CSV);
fprintf('Reference-guided Lyso initialization, not fully blind.\n');

% Strictly one CSV means we cannot persist a per-pixel seed1001 map.
% If a previous run finished seed1001 but stopped later, retrain it once
% in memory so that the SAME-FOV abundance correlations remain meaningful.
if all(T.run_status==1)
    fprintf('All ten successful seeds already recorded. No retraining.\n');
    e3_print_summary(T);
    return;
end
need_anchor = any(T.run_status(2:end)~=1);
anchor_abund = [];           % 5 x n_mask; RAM ONLY, never saved

%% 3. Run or resume the ten seeds -----------------------------------------
for k=1:nRuns
    if T.run_status(k)==1 && ~(k==1 && need_anchor)
        fprintf('Seed %d completed earlier; skipping.\n',SEEDS(k));
        continue;
    end
    anchor_rebuild = (k==1 && T.run_status(1)==1 && need_anchor);
    if anchor_rebuild
        fprintf('Recomputing seed1001 abundance anchor in memory for resume ...\n');
    else
        fprintf('Training seed=%d (%d/%d) ...\n',SEEDS(k),k,nRuns);
    end

    try
        rng(SEEDS(k),'twister');
        % EXACT E14 Group-C Lyso reference-guided VCA + shape subspace.
        % Restore RNG after building the seed, as in the supplied demo:
        % this keeps trainer initialization tied to the specified seed.
        state_before_seed=rng;
        [M0_seed_raw,init_diag] = e14_lyso_seed_m0( ...
            Y,p_hat,ref_spec(:,LYSO_REF_IDX),LYSO_INIT_MODE);
        rng(state_before_seed);
        args={'spherize','yes','verbose',0, ...
            'MM_ITERS',MM_ITERS,'WARM_UP',WARM_UP,'LR',3e-4, ...
            'LAMBDA_VOL',0.008,'LAMBDA_NONNEG',3,'LAMBDA_EQ',100, ...
            'LAMBDA_ENCLOSE',0.3, ...
            'IMG_H',H,'IMG_W',W,'LAMBDA_SPATIAL',2, ...
            'NOISE_MODEL','poisson','ETA',0.3,'SIGMA_CAP',SIGMA_CAP_USED, ...
            'PHOTON_GAIN',1,'PHOTON_FLOOR',1,'READ_SIGMA',READ_SIG, ...
            'USE_GPU',USE_GPU,'GPU_PRECISION',GPU_PRECISION, ...
            'GPU_DEVICE',GPU_DEVICE, ...
            'M0',M0_seed_raw,'SUBSPACE_ANCHOR',init_diag.lyso_scaled};
        tm=tic;
        [M_est,S_est] = deep_mvsa_invflow_poisson_explicit_Warmup2_NoASC_E14C( ...
            Y,p_hat,args{:});
        elapsed=toc(tm);      % trainer wall-time only (same as source E14)
        assert(isequal(size(M_est),[L,p_hat]) && ...
            isequal(size(S_est),[p_hat,N]), ...
            'Unexpected trainer M/S dimensions.');
        assert(all(isfinite(M_est(:))) && all(isfinite(S_est(:))), ...
            'Trainer M/S contains NaN/Inf.');

        % SAME greedy one-to-one matching as original E14 driver.
        [perm,sad_v]=e14_match(ref_spec,M_est,true(1,N_DYE));
        assert(all(isfinite(sad_v)) && all(isfinite(perm)), ...
            'Nonfinite SAD or unmatched reference.');
        S_on_mask = single(S_est(perm,mask_idx));

        if k==1
            anchor_abund=S_on_mask;  % store only in RAM
        elseif need_anchor
            assert(~isempty(anchor_abund),'Seed1001 anchor unavailable.');
        end

        if anchor_rebuild
            % Do NOT overwrite original seed1001 measured metrics.
            fprintf('Seed1001 anchor restored in RAM (time %.1f s).\n',elapsed);
            clear M0_seed_raw init_diag args M_est S_est S_on_mask;
            continue;
        end

        err=Y-M_est*S_est;
        rre=norm(err,'fro')/max(norm(Y,'fro'),eps);
        pix_num=sqrt(sum(err(:,mask_idx).^2,1));
        pix_den=max(sqrt(sum(Y(:,mask_idx).^2,1)),eps);
        mask_residual_mean=mean(pix_num./pix_den);
        assert(isfinite(rre) && isfinite(mask_residual_mean), ...
            'Nonfinite reconstruction metric.');

        T.SAD_Hoechst(k)=sad_v(1);
        T.SAD_Golgi(k)=sad_v(2);
        T.SAD_Mito(k)=sad_v(3);
        T.SAD_Lyso(k)=sad_v(4);
        T.SAD_CellMask(k)=sad_v(5);
        T.SAD_mean_deg(k)=mean(sad_v);
        T.reconstruction_RRE(k)=rre;
        T.masked_pixel_residual_mean(k)=mask_residual_mean;

        if k>1
            corrs=nan(1,N_DYE);
            for j=1:N_DYE
                corrs(j)=e14_pearson(double(anchor_abund(j,:)), ...
                    double(S_on_mask(j,:)));
            end
            % Individual degenerate (constant) channels may give NaN.
            T.abundance_r_seed1001_Hoechst(k)=corrs(1);
            T.abundance_r_seed1001_Golgi(k)=corrs(2);
            T.abundance_r_seed1001_Mito(k)=corrs(3);
            T.abundance_r_seed1001_Lyso(k)=corrs(4);
            T.abundance_r_seed1001_CellMask(k)=corrs(5);
            if any(isfinite(corrs))
                T.abundance_r_seed1001_mean(k)=mean(corrs(isfinite(corrs)));
            end
        end
        T.time_s(k)=elapsed;
        T.run_status(k)=1;
        e3_write_one_csv(T,OUT_CSV);  % checkpoint after EVERY success
        fprintf('Seed %d OK | SAD %.3f deg | RRE %.5f | elapsed %.1fs | %d/%d\n', ...
            SEEDS(k),T.SAD_mean_deg(k),rre,elapsed,nnz(T.run_status==1),nRuns);
        clear err M0_seed_raw init_diag args M_est S_est S_on_mask;

    catch ME
        if anchor_rebuild || k==1
            % Without seed1001, later cross-seed stability is undefined.
            rethrow(ME);
        end
        T.run_status(k)=-1;          % error; retry on next invocation
        e3_write_one_csv(T,OUT_CSV);
        warning('E3:SeedFailed', 'Seed %d FAILED: %s',SEEDS(k),ME.message);
    end
end

%% 4. Print paper statistics without creating any additional files -------
e3_print_summary(T);
fprintf('\nOnly CSV result: %s\n',OUT_CSV);

%% === Original E14 Group-C helper functions: preserved ===================

function e3_write_one_csv(T,filename)
% Single CSV is also the checkpoint; write a compact numeric table.
% Using the fixed filename deliberately avoids accumulating new outputs.
writetable(T,filename);
end

function e3_print_summary(T)
% No summary file; report mean, sample standard deviation and range.
ok=T.run_status==1;
n=nnz(ok);
fprintf('\n=== E-3 FIVE-LABEL MULTI-SEED (%d/%d successful) ===\n',n,height(T));
if n==0
    fprintf('No successful seed yet.\n'); return;
end
metrics={'SAD_mean_deg','reconstruction_RRE', ...
    'masked_pixel_residual_mean','abundance_r_seed1001_mean','time_s'};
for j=1:numel(metrics)
    x=T.(metrics{j})(ok);
    x=x(isfinite(x));
    if isempty(x)
        fprintf('%-29s : unavailable\n',metrics{j});
    else
        fprintf('%-29s : %.7g +/- %.7g; range %.7g .. %.7g (n=%d)\n', ...
            metrics{j},mean(x),std(x,0),min(x),max(x),numel(x));
    end
end
if n<height(T)
    fprintf('Incomplete/failed seed(s): %s\n', ...
        num2str(T.seed(T.run_status~=1).'));
end
fprintf(['NOTE: cross-seed abundance_r references seed1001; ' ...
         'self-correlation is NaN (n<=9). Not abundance accuracy.\n']);
end

function info = e14_blank_seed_info()
%E14_BLANK_SEED_INFO Default diagnostics for blind VCA control.
info = struct('seed_col',NaN,'scale_factor',NaN,'raw_sad_deg',NaN, ...
    'proj_sad_deg',NaN,'rcond_m0',NaN,'vca_raw',[], ...
    'lyso_scaled',[],'lyso_projected',[], ...
    'base_proj_sad_deg',NaN,'guided_proj_sad_deg',NaN, ...
    'base_proj_relerr',NaN,'guided_proj_relerr',NaN, ...
    'base_subspace_rre',NaN,'guided_subspace_rre',NaN, ...
    'guided_axis_variance',NaN,'original_last_variance',NaN, ...
    'standard_pca_projected_band',[]);
end

function [M0_band, info] = e14_lyso_seed_m0(Y, p, lyso_ref, mode)
%E14_LYSO_SEED_M0 Matched Group B/C VCA initialization in 28-band units.
% In BOTH B and C, calibrate Lyso intensity from a *standard PCA/VCA*
% baseline. That holds the Lyso amplitude fixed between B and C.
% In C, replace PCA direction p-1 by the component of scaled Lyso that
% is orthogonal to the first p-2 PCA directions. The affine subspace then
% contains Lyso EXACTLY (up to floating-point error), keeping p-1 DOF.
% This is Lyso-guided SEMI-SUPERVISED diagnosis, NOT blind E14 evidence.
[L,N] = size(Y);
lyso_ref=double(lyso_ref(:));
assert(numel(lyso_ref)==L && all(isfinite(lyso_ref)) && ...
    all(lyso_ref>=0) && norm(lyso_ref)>0, ...
    'E14C:invalidLyso','Invalid Lyso L-by-1 reference spectrum.');
assert(p>=3 && p<=L, 'E14C:badP','Need 3 <= p <= number of bands.');
mu=mean(Y,2);
Yc=Y-mu;
Cov=Yc*Yc'/N;
[Ustd,Dstd]=svds(Cov,p-1);
lam=1e-10;

% Original PCA-then-VCA scale calibration, with a reproducible RNG state.
vca_rng_state=rng;
sc_std=sqrt(diag(Dstd + lam*eye(p-1)));
Ys_std=diag(1./sc_std)*Ustd'*Yc;
Ys_std(p,:)=1;
Ys_std=Ys_std/sqrt(p);
M0_vca_std_work=VCA(Ys_std, 'Endmembers',p,'verbose','off');
assert(isequal(size(M0_vca_std_work),[p,p]) && ...
    all(isfinite(M0_vca_std_work(:))), ...
    'E14C:vcaInvalid','Standard VCA initialization is invalid.');
M0_vca_std_band=mu+Ustd*bsxfun(@times,sc_std, ...
    sqrt(p)*M0_vca_std_work(1:p-1,:));
vca_totals=sum(max(M0_vca_std_band,0),1);
valid_totals=vca_totals(isfinite(vca_totals) & vca_totals>0);
assert(~isempty(valid_totals),'E14C:badScale', ...
    'VCA failed to provide positive reference intensity.');
target_total=median(valid_totals);
scale_factor=target_total/sum(lyso_ref);
lyso_scaled=lyso_ref*scale_factor;

% Standard affine PCA projection (B-group initial restriction).
standard_proj=mu+Ustd*(Ustd'*(lyso_scaled-mu));
standard_relerr=norm(standard_proj-lyso_scaled)/max(norm(lyso_scaled),eps);
standard_sad=e14_safe_sad(standard_proj,lyso_ref);
base_subspace_rre=norm(Yc-Ustd*(Ustd'*Yc),'fro')/max(norm(Y,'fro'),eps);

U=Ustd;
D=Dstd;
var_last=Dstd(p-1,p-1);
if strcmp(mode,'lyso_subspace')
    top=Ustd(:,1:p-2);
    dir=lyso_scaled-mu;
    missing=dir-top*(top'*dir);
    assert(norm(missing)>1e-11*max(norm(dir),1), ...
        'E14C:redundant','Lyso already represented by p-2 PCA axes.');
    guided_last=missing/norm(missing);
    var_last=guided_last'*Cov*guided_last;
    assert(isfinite(var_last) && var_last>1e-12, ...
        'E14C:weakAxis','Lyso-guided direction carries negligible data variance.');
    U=[top guided_last];
    D=diag([diag(Dstd(1:p-2,1:p-2));var_last]);
end

guided_proj=mu+U*(U'*(lyso_scaled-mu));
guided_relerr=norm(guided_proj-lyso_scaled)/max(norm(lyso_scaled),eps);
guided_sad=e14_safe_sad(guided_proj,lyso_ref);
guided_subspace_rre=norm(Yc-U*(U'*Yc),'fro')/max(norm(Y,'fro'),eps);
if strcmp(mode,'lyso_subspace')
    assert(guided_relerr < 1e-8, 'E14C:projectionFailed', ...
        'Lyso-guided subspace failed exact projection check.');
end

% For B: reuse the precomputed original VCA, exactly matching previous B.
% For C: use same VCA RNG draw but on guided subspace spectra.
if strcmp(mode,'lyso_subspace')
    rng(vca_rng_state);
    sd=sqrt(diag(D+lam*eye(p-1)));
    Ys=diag(1./sd)*U'*Yc;
    Ys(p,:)=1;
    Ys=Ys/sqrt(p);
    M0_vca_work=VCA(Ys,'Endmembers',p,'verbose','off');
    assert(isequal(size(M0_vca_work),[p,p]) && ...
        all(isfinite(M0_vca_work(:))), ...
        'E14C:vcaInvalid','Guided VCA initialization is invalid.');
    M0_vca_band=mu+U*bsxfun(@times,sd, ...
        sqrt(p)*M0_vca_work(1:p-1,:));
else
    M0_vca_work=M0_vca_std_work;
    M0_vca_band=M0_vca_std_band;
    sd=sc_std;
end

lyso_work=[(U'*(lyso_scaled-mu))./(sd*sqrt(p)); 1/sqrt(p)];
near=inf(p,p);
for a=1:p
    for b=a+1:p
        da=e14_safe_sad(M0_vca_band(:,a),M0_vca_band(:,b));
        near(a,b)=da; near(b,a)=da;
    end
end
[~,candidate_cols]=sort(min(near,[],2),'ascend');
seed_col=NaN; rc=NaN; M0_seed_work=[];
for z=1:p
    idx=candidate_cols(z);
    proposal=M0_vca_work;
    proposal(:,idx)=lyso_work;
    this_rc=rcond(proposal);
    if isfinite(this_rc) && this_rc>=1e-9
        M0_seed_work=proposal;
        seed_col=idx;
        rc=this_rc;
        break
    end
end
assert(~isempty(M0_seed_work),'E14C:singularSeed', ...
    'All candidate VCA replacements were singular/ill-conditioned.');
M0_band=mu+U*bsxfun(@times,sd, ...
    sqrt(p)*M0_seed_work(1:p-1,:));
assert(isequal(size(M0_band),[L,p]) && all(isfinite(M0_band(:))), ...
    'E14C:invalidM0','Bad seeded M0 after inverse whitening.');

info=e14_blank_seed_info();
info.seed_col=seed_col;
info.scale_factor=scale_factor;
info.raw_sad_deg=e14_safe_sad(lyso_scaled,lyso_ref);
info.proj_sad_deg=e14_safe_sad(M0_band(:,seed_col),lyso_ref);
info.rcond_m0=rc;
info.vca_raw=M0_vca_band;
info.lyso_scaled=lyso_scaled;
info.lyso_projected=guided_proj;
info.standard_pca_projected_band=standard_proj;
info.base_proj_sad_deg=standard_sad;
info.guided_proj_sad_deg=guided_sad;
info.base_proj_relerr=standard_relerr;
info.guided_proj_relerr=guided_relerr;
info.base_subspace_rre=base_subspace_rre;
info.guided_subspace_rre=guided_subspace_rre;
info.guided_axis_variance=var_last;
info.original_last_variance=Dstd(p-1,p-1);
end

function sad = e14_safe_sad(a,b)
%E14_SAFE_SAD Numeric-guarded spectral angle (degrees).
a=double(a(:)); b=double(b(:));
ok=isfinite(a)&isfinite(b);
a=a(ok); b=b(ok);
if isempty(a)||norm(a)<eps||norm(b)<eps
    sad=NaN; return;
end
sad = acosd(max(-1,min(1,(a'*b)/(norm(a)*norm(b)))));
end

function Y_cube = e14_read_lsm(fname)
%E14_READ_LSM Generic Zeiss LSM reader, whole spectral cube, one z/t.
%   Copied and adapted from e7_read_lsm_plane (demo_pisco_E7_downstream.
%   m, v1.1-E7). LSM is a little-endian TIFF variant; the private tag
%   34412 (LSMINFO, BYTE array) on directory 1 holds the dimensions at
%   byte offsets +8 i32 X, +12 i32 Y, +16 i32 Z, +20 i32 CH, +24 i32 T.
%   Adaptations for the PhasorPy 28-channel files:
%     - ALL sample planes are kept (no fixed 32-channel cap; the
%       PhasorPy five-label LSM carries 28 spectral channels and no
%       separate transmission page is assumed);
%     - the files may hold a SINGLE z plane and a SINGLE time point
%       (z = 1, t = 1): the reader is tolerant to that -- with
%       PlanarConfig = 2 and SamplesPerPixel > 1 one data page already
%       contains the whole L x H x W cube; with SamplesPerPixel = 1 the
%       data pages are stacked as the channel axis (pages = channels,
%       z = t = 1 assumed, a warning is printed if the page count looks
%       like more than one z/t series);
%     - if several full-frame pages exist with SamplesPerPixel > 1
%       (a z stack), the brightest-total-intensity page is used.
%   Fallback if the LSMINFO tag cannot be read: the pages with the
%   largest W x H product are taken as data pages.
%   Returns Y_cube as L x H x W double (photon counts).

t = Tiff(fname, 'r');
cleaner = onCleanup(@() t.close()); %#ok<NASGU> (keeps t open till return)

% --- LSMINFO private tag 34412 on directory 1 (byte offsets above) ---
have_info = false; Xi = 0; Yi = 0;
try
    tag = uint8(t.getTag(34412));       % BYTE array; Tiff.getTag accepts
    tag = tag(:);                       % a numeric tag id for unknown tags
    if numel(tag) >= 28
        Xi = double(typecast(tag(9:12),  'int32'));   % +8  i32 X
        Yi = double(typecast(tag(13:16), 'int32'));   % +12 i32 Y
        have_info = (Xi > 0) && (Yi > 0);
    end
catch
    have_info = false;
end

% --- walk all directories, record page sizes and samples-per-pixel ---
ws = []; hs = []; spps = [];
while true
    ws(end+1)    = t.getTag(Tiff.TagID.ImageWidth);     %#ok<AGROW>
    hs(end+1)    = t.getTag(Tiff.TagID.ImageLength);    %#ok<AGROW>
    try
        spps(end+1) = t.getTag(Tiff.TagID.SamplesPerPixel); %#ok<AGROW>
    catch
        spps(end+1) = 1;    % tag absent: TIFF default is 1 %#ok<AGROW>
    end
    if t.lastDirectory(), break; end
    t.nextDirectory();
end
if have_info
    is_data = (ws == Xi) & (hs == Yi);
else
    % fallback: largest pages are the data pages
    is_data = (ws .* hs) == max(ws .* hs);
end
datapages = find(is_data);
assert(~isempty(datapages), 'E14:lsmNoData', ...
    'No full-frame data pages found in %s', fname);
spp = spps(datapages(1));
Hf = hs(datapages(1)); Wf = ws(datapages(1));

if spp > 1
    % --- one page holds all channels (PlanarConfig separate/chunky) ---
    if numel(datapages) > 1
        % z stack (z = 1, t = 1 expected for the PhasorPy files, but be
        % tolerant): use the brightest-total-intensity page
        best = -Inf; z_use = 1;
        for z = 1:numel(datapages)
            t.setDirectory(datapages(z));
            A = t.read();
            s = sum(reshape(double(A), [], 1));
            if s > best, best = s; z_use = z; end
        end
        fprintf(['  e14_read_lsm: %d full-frame pages, using brightest ' ...
            '(page %d)\n'], numel(datapages), z_use);
    else
        z_use = 1;
    end
    t.setDirectory(datapages(z_use));
    A = t.read();
    assert(ndims(A) == 3, 'E14:lsmBadRead', ...
        'Expected H x W x SPP page, got %s in %s', mat2str(size(A)), fname);
    Y_cube = double(permute(A, [3 1 2]));       % SPP x H x W
else
    % --- one channel per page: stack the data pages as channels -------
    if numel(datapages) > 1
        fprintf(['  e14_read_lsm: SamplesPerPixel = 1, stacking %d ' ...
            'pages as channels (z = 1, t = 1 assumed)\n'], numel(datapages));
    end
    Y_cube = zeros(numel(datapages), Hf, Wf);
    for z = 1:numel(datapages)
        t.setDirectory(datapages(z));
        A = t.read();
        assert(ismatrix(A) && size(A,1) == Hf && size(A,2) == Wf, ...
            'E14:lsmBadRead', 'Unexpected page size %s in %s', ...
            mat2str(size(A)), fname);
        Y_cube(z, :, :) = double(A);
    end
end
end

function [spec, img, fg_frac] = e14_ref_from_lsm(fname)
%E14_REF_FROM_LSM Reference spectrum and image from a single-label LSM.
%   Protocol (SI Note 6): the reference spectrum is the mean spectrum
%   over the foreground (cell) mask, where the mask is the Otsu
%   threshold of the total-intensity image; the reference image is the
%   total-intensity image itself (sum over channels). fg_frac is the
%   foreground fraction (diagnostic). spec is L x 1.
cube = e14_read_lsm(fname);             % L x H x W
img = squeeze(sum(cube, 1));            % total-intensity image
g = mat2gray(img);
mask = imbinarize(g, graythresh(g));
mask = bwareaopen(mask, 20);            % drop specks < 20 px
mask = imclose(mask, strel('disk', 2));
[L, H, W] = size(cube);
m2 = reshape(mask, 1, []);
if sum(m2) < 10
    fprintf(2, ['WARNING: e14_ref_from_lsm: foreground mask nearly ' ...
        'empty in %s; using the full frame for the reference ' ...
        'spectrum.\n'], fname);
    m2 = true(1, H * W);
end
pix = reshape(cube, L, []);
spec = mean(pix(:, m2), 2);             % foreground mean spectrum
fg_frac = sum(m2) / numel(m2);
end

function p_hat = e14_hysime(Y_counts, IMG_H, IMG_W)
%E14_HYSIME HySime estimate of the endmember number (identical to the
%   E5 demo's e5_hysime; Bioucas-Dias & Nascimento, "Hyperspectral
%   Subspace Identification", IEEE TGRS 46(8):2435-2445, 2008, eqs.
%   (9)-(15), (22)-(24)). Verbatim port of the authors' hysime.m /
%   estNoise.m (GPL-2.0, http://www.lx.it.pt/~bioucas/code.htm) with
%   one documented adaptation: the criterion runs on BIN x BIN
%   superpixel-averaged data with the estNoise covariance scaled by
%   1/BIN^2 (spatial averaging divides the white-noise variance by the
%   bin area but preserves the signal subspace). See the E5 demo header
%   for the full rationale and the Python validation summary.
BIN = 4;                            % superpixel side (128 -> 32 x 32)
[L, N] = size(Y_counts);
Hb = IMG_H / BIN;  Wb = IMG_W / BIN;
if Hb ~= floor(Hb) || Wb ~= floor(Wb)
    error('e14_hysime: image size must be divisible by BIN = %d.', BIN);
end

% --- verbatim estNoise on the raw counts (see subfunction below) ---
Rn = e14_estnoise(Y_counts);        % diagonal noise correlation matrix

% --- superpixel averaging; column-major pixel order matches reshape ---
A  = reshape(Y_counts, L, BIN, Hb, BIN, Wb);
Yb = reshape(mean(mean(A, 2), 4), L, Hb * Wb);
Nb = Hb * Wb;
Rn = Rn / (BIN * BIN);              % white-noise variance / bin area

% --- verbatim HySime criterion on the binned data ---
Ry = Yb * Yb' / Nb;                 % sample correlation matrix
Rx = Ry - Rn;                       % eq. (13) literally: signal correl. est.
[E, D] = eig((Rx + Rx') / 2);       % NOTE: eig returns ASCENDING order
[~, ord] = sort(diag(D), 'descend');
E = E(:, ord);                      % descending, like [E,~] = svd(Rx)
Rn = Rn + sum(diag(Rx)) / L / 1e10 * eye(L);   % regularisation (verbatim)
Py = diag(E' * Ry * E);             % eq. (23)
Pn = diag(E' * Rn * E);             % eq. (24)
cost_F = -Py + 2 * Pn;              % eq. (22)
p_hat = sum(cost_F < 0);
p_hat = max(p_hat, 1);              % guard: a subspace of dim 0 is invalid
end

function Rn = e14_estnoise(y)
%E14_ESTNOISE Verbatim port of estAdditiveNoise (Bioucas-Dias &
%   Nascimento, 2008): additive-noise estimation by bandwise multiple
%   linear regression (paper eqs. (9)-(14)); returns the DIAGONAL noise
%   correlation matrix Rn = diag(diag(w*w'/N)), as in estNoise.m.
[L, N] = size(y);
small = 1e-6;
RR  = y * y';                       % eq. (11)
RRi = inv(RR + small * eye(L));     % eq. (11)
w = zeros(L, N);
for i = 1:L
    XX = RRi - (RRi(:,i) * RRi(i,:)) / RRi(i,i);   % eq. (14)
    RRa = RR(:,i); RRa(i) = 0;      % remove the effects of XX(:,i)
    beta = XX * RRa; beta(i) = 0;   % eq. (9); remove XX(i,:) effect
    w(i,:) = y(i,:) - beta' * y;    % eq. (10): noise estimate
end
Rn = diag(diag(w * w' / N));
end

function [perm, sad_v] = e14_match(M_ref, M_est, have_ref)
%E14_MATCH Greedy one-to-one SAD matching of references to endmembers.
%   E1 e1_match logic generalised to a rectangular problem: nref
%   reference spectra (some possibly missing, have_ref = false, or
%   partially NaN after channel truncation) vs pe estimated endmembers,
%   pe possibly ~= nref. Reference i is assigned endmember perm(i)
%   (NaN if missing or if no unused endmember remains); sad_v(i) is the
%   matching SAD in degrees. References are processed in fixed order,
%   each taking its best unused endmember (the E1 greedy rule). SADs
%   are computed on the common (non-NaN) channels only.
nref = size(M_ref, 2);
pe = size(M_est, 2);
perm = NaN(1, nref);
sad_v = NaN(1, nref);
valid = find(have_ref & ~all(isnan(M_ref), 1));
if isempty(valid) || pe == 0, return; end
C = NaN(nref, pe);
for i = valid
    for j = 1:pe
        a = M_ref(:, i);
        b = M_est(:, j);
        ok = ~isnan(a) & ~isnan(b);     % common channels only
        a = a(ok); b = b(ok);
        if isempty(a) || norm(a) == 0 || norm(b) == 0, continue; end
        C(i, j) = acosd(max(-1, min(1, (a' * b) / (norm(a) * norm(b)))));
    end
end
taken = false(1, pe);
for i = valid
    avail = find(~taken & ~isnan(C(i, :)));
    if isempty(avail), continue; end    % more references than endmembers
    [~, kk] = min(C(i, avail));
    jj = avail(kk);
    perm(i) = jj;
    sad_v(i) = C(i, jj);
    taken(jj) = true;
end
end

function r = e14_pearson(a, b)
%E14_PEARSON Pearson correlation between two images, NaN-safe.
a = a(:); b = b(:);
ok = isfinite(a) & isfinite(b);
a = a(ok); b = b(ok);
if numel(a) < 3 || std(a) == 0 || std(b) == 0
    r = NaN;
    return
end
a = a - mean(a);
b = b - mean(b);
r = (a' * b) / (norm(a) * norm(b));
r = max(-1, min(1, r));
end
