%% demo_pisco_E3_FocalCheck_multiseed_CSV_GYL.m
% E-3: FocalCheck DoubleGreen REAL corrected TIFF, 10 independent RNG seeds.
% Adapted from demo_pisco_E14_beads_realTIFF_with_fullMAT_GYL_NoASC.m.
% ONLY ONE CSV in ONE fixed dedicated results folder; no MAT/figures/log CSV.
% Keeps the original measured single-dye references and the original
% globally optimal two-to-three SAD assignment, ring/core geometry scoring.
% Same NoASC PISCO trainer and loss/optimizer settings for every seed.
%
% Scientific interpretation:
%   Green1 = RING, Green2 = CORE (per original real-TIFF driver).
%   Single-dye TIFFs provide reference SPECTRA; no abundance ground truth.
%   Correlation of two estimated abundance maps from different seeds measures
%   run-to-run consistency, NOT pixel-wise abundance accuracy.
%   These corrected 8-bit TIFFs are NOT certified raw photon counts.
%   NoASC estimated S is non-normalized coefficients (not fractions).
%
% Important protocol caveat: supplied E14 bead driver uses MM_ITERS=550
% and WARM_UP=500 (only 50 joint iterations), NOT the 2500-iteration
% default described in PISCO SI. This E-3 repeat preserves that driver
% exactly. For a paper-wide uniform 2500-iteration protocol, a *new*
% comparison campaign with explicit protocol documentation is needed.
%
% Runtime requirements: MATLAB R2023a+, Image Processing Toolbox, VCA.m,
% supplied deep_mvsa_invflow_poisson_explicit_Warmup2_NoASC.m; supported GPU
% and Parallel Computing Toolbox if USE_GPU=true.
% Trainer is NOT modified. This driver was statically reviewed, not run in MATLAB.

clear; close all; clc;

%% 0. Configuration -------------------------------------------------------
QUICK           = false;           % MUST stay false for paper/full FOV
RESUME          = true;            % continue using existing CSV in fixed folder
SEEDS           = 1001:1010;       % exactly ten independent initialization seeds
P_BEAD          = 3;               % Green1 ring + Green2 core + background
MM_ITERS        = 550;             % preserve original bead driver setting
WARM_UP         = 500;
READ_SIG        = 1.0;
SIGMA_CAP_USED  = 0.15;            % explicit original NoASC trainer default
USE_GPU         = true;            % original trainer default
GPU_PRECISION   = 'single';
GPU_DEVICE      = 1;
CROP            = 384;             % only for QUICK=true smoke tests

script_dir = fileparts(mfilename('fullpath'));
if isempty(script_dir), script_dir = pwd; end
addpath(script_dir);
DATA_ROOT = fullfile(script_dir, 'data_E14', 'datasets');
if ~isfolder(DATA_ROOT)
    alt = fullfile(script_dir, 'datasets');
    if isfolder(alt), DATA_ROOT = alt; end
end
assert(isfolder(DATA_ROOT), 'Missing data_E14/datasets (or datasets) folder.');
DIR_REF1 = fullfile(DATA_ROOT, 'green1only_zoomed');
DIR_REF2 = fullfile(DATA_ROOT, 'green2only_zoomed');
DIR_MIX  = fullfile(DATA_ROOT, 'green1core_green2ring_zoomed');
assert(exist('VCA','file')==2, 'VCA.m not found on MATLAB path.');
assert(exist('deep_mvsa_invflow_poisson_explicit_Warmup2_NoASC','file')==2, ...
    'Trainer function file must be named deep_mvsa_invflow_poisson_explicit_Warmup2_NoASC.m');
assert(WARM_UP >= 0 && WARM_UP < MM_ITERS, 'Invalid warmup/total iterations.');

OUT_DIR = fullfile(script_dir, 'E3_FocalCheck_multiseed_CSV_only_results');
if ~isfolder(OUT_DIR)
    [made,msg] = mkdir(OUT_DIR);
    assert(made, 'Cannot create result folder: %s', msg);
end
OUT_CSV = fullfile(OUT_DIR, 'pisco_E3_FocalCheck_multiseed_results.csv');

%% 1. Read measured reference and mixed data ONCE ------------------------
C1 = e14_read_16tiff(DIR_REF1);
C2 = e14_read_16tiff(DIR_REF2);
B_cube = e14_read_16tiff(DIR_MIX);
assert(size(C1,1)==size(C2,1) && size(C1,1)==size(B_cube,1), ...
    'Reference/mixed spectral channel mismatch.');
L = size(B_cube,1);
assert(L==16, 'Expected 16 TIFF channels.');
[M_ref1,~,~] = e14_measured_ref(C1);
[M_ref2,~,~] = e14_measured_ref(C2);
M_ref = [M_ref1,M_ref2];
ref_pair_sad = e14_sad(M_ref1,M_ref2);
fprintf('Measured Green1/Green2 reference angle = %.3f degrees\n',ref_pair_sad);
clear C1 C2;

if QUICK
    [~,H0,W0] = size(B_cube);
    h=min(CROP,H0); w=min(CROP,W0);
    r1=floor((H0-h)/2)+1; c1=floor((W0-w)/2)+1;
    B_cube=B_cube(:,r1:r1+h-1,c1:c1+w-1);
end
[~,H,W] = size(B_cube);
N=H*W;
Yb=reshape(B_cube,L,N);  % IMPORTANT: keep original column-major raster order
assert(all(isfinite(Yb(:))) && all(Yb(:)>=0), 'Invalid mixed TIFF data.');

% Bead foreground mask is fixed across seeds and used ONLY for reporting.
[bead_mask,~,bead_R] = e14_bead_roi(B_cube);
assert(nnz(bead_mask)>=64 && isfinite(bead_R) && bead_R>=8, ...
    'Could not construct a stable mixed-bead mask.');
bead_idx=find(bead_mask(:));
clear bead_mask;

% Preserve original raw-data core/ring label audit (no extra output file).
[raw_core,raw_ring] = e14_raw_spatial_spectra(B_cube);
raw_sad = [e14_sad(raw_core,M_ref(:,1)),e14_sad(raw_core,M_ref(:,2)); ...
           e14_sad(raw_ring,M_ref(:,1)),e14_sad(raw_ring,M_ref(:,2))];
fprintf('Raw core SAD: Green1 %.2f, Green2 %.2f deg\n',raw_sad(1,1),raw_sad(1,2));
fprintf('Raw ring SAD: Green1 %.2f, Green2 %.2f deg\n',raw_sad(2,1),raw_sad(2,2));
if raw_sad(1,2)>=raw_sad(1,1) || raw_sad(2,1)>=raw_sad(2,2)
    warning('Raw mixed-bead spectra do not support core/ring identity unambiguously.');
end
clear raw_core raw_ring;

%% 2. ONE CSV: each seed has its own row -------------------------------
% CSV is also the only persistent checkpoint. 1=success, 0=pending, -1=failed.
% Anchor at SEEDS(1)=1001 is NOT stored as an image. When resuming, it may
% need to be recomputed in memory to compare pending seeds' abundance maps.
COLS = {'seed','run','image_h','image_w','p_used','total_iters', ...
    'warmup_iters','sigma_cap','SAD_Green1_ring_deg', ...
    'SAD_Green2_core_deg','SAD_mean_deg','reconstruction_RRE', ...
    'masked_pixel_residual_mean','abundance_r_seed1001_Green1_ring', ...
    'abundance_r_seed1001_Green2_core','abundance_r_seed1001_mean', ...
    'core_peak_r_px','ring_peak_r_px','geometry_pass', ...
    'time_s','run_status'};
nRuns=numel(SEEDS);
T=array2table(nan(nRuns,numel(COLS)),'VariableNames',COLS);
T.seed=SEEDS(:);
T.run=(1:nRuns)';
T.image_h=repmat(H,nRuns,1);
T.image_w=repmat(W,nRuns,1);
T.p_used=repmat(P_BEAD,nRuns,1);
T.total_iters=repmat(MM_ITERS,nRuns,1);
T.warmup_iters=repmat(WARM_UP,nRuns,1);
T.sigma_cap=repmat(SIGMA_CAP_USED,nRuns,1);
T.run_status=zeros(nRuns,1);

if RESUME && isfile(OUT_CSV)
    import_opts=detectImportOptions(OUT_CSV);
    import_opts=setvartype(import_opts,COLS,'double');
    old=readtable(OUT_CSV,import_opts);
    assert(isequal(old.Properties.VariableNames,COLS), ...
        'Existing CSV columns differ. Move old CSV before starting a new protocol.');
    assert(height(old)==nRuns && isequal(old.seed(:),SEEDS(:)) && ...
        isequal(old.run(:),(1:nRuns)') && ...
        all(old.image_h==H) && all(old.image_w==W) && ...
        all(old.p_used==P_BEAD) && all(old.total_iters==MM_ITERS) && ...
        all(old.warmup_iters==WARM_UP) && ...
        all(old.sigma_cap==SIGMA_CAP_USED), ...
        'Existing CSV checkpoint belongs to another experiment protocol.');
    T=old;
else
    e3_write_one_csv(T,OUT_CSV);
end

fprintf('\nFocalCheck E-3: %d x %d, %d channels, p=%d, seeds=%d..%d\n', ...
    H,W,L,P_BEAD,SEEDS(1),SEEDS(end));
fprintf('Total iterations=%d, warmup=%d (PRESERVED source settings)\n', ...
    MM_ITERS,WARM_UP);
fprintf('ONLY result file: %s\n',OUT_CSV);

if all(T.run_status==1)
    fprintf('All seeds already completed; no retraining.\n');
    e3_print_summary(T);
    return;
end

need_anchor=any(T.run_status(2:end)~=1);
anchor_coeff=[];              % 2 x n_bead; RAM ONLY

%% 3. Independent seed training ------------------------------------------
for k=1:nRuns
    if T.run_status(k)==1 && ~(k==1 && need_anchor)
        fprintf('Seed %d previously completed; skip.\n',SEEDS(k));
        continue;
    end
    anchor_rebuild = k==1 && T.run_status(1)==1 && need_anchor;
    if anchor_rebuild
        fprintf('Rebuilding seed=%d abundance anchor in memory (resume) ...\n',SEEDS(1));
    else
        fprintf('Training seed=%d (%d/%d) ...\n',SEEDS(k),k,nRuns);
    end

    try
        rng(SEEDS(k),'twister');
        args = {'spherize','yes', 'verbose',0, ...
            'MM_ITERS',MM_ITERS,'WARM_UP',WARM_UP,'LR',3e-4, ...
            'LAMBDA_VOL',0.008,'LAMBDA_NONNEG',3,'LAMBDA_EQ',100, ...
            'LAMBDA_SUMONE',0,'LAMBDA_ENCLOSE',10, ...
            'IMG_H',H,'IMG_W',W,'LAMBDA_SPATIAL',2, ...
            'NOISE_MODEL','poisson','ETA',0.3, ...
            'SIGMA_CAP',SIGMA_CAP_USED, ...
            'PHOTON_GAIN',1,'PHOTON_FLOOR',1,'READ_SIGMA',READ_SIG, ...
            'USE_GPU',USE_GPU,'GPU_PRECISION',GPU_PRECISION, ...
            'GPU_DEVICE',GPU_DEVICE};
        t0=tic;
        [M_b,S_b] = deep_mvsa_invflow_poisson_explicit_Warmup2_NoASC( ...
            Yb,P_BEAD,args{:});
        elapsed=toc(t0);
        assert(isequal(size(M_b),[L,P_BEAD]) && ...
            isequal(size(S_b),[P_BEAD,N]),'Unexpected M/S dimensions.');
        assert(all(isfinite(M_b(:))) && all(isfinite(S_b(:))), ...
            'Trainer returned non-finite M/S.');

        % EXACT reference-to-component matching from supplied E14 bead demo.
        [idx,sad2] = e14_pair_match(M_ref,M_b);
        idx_bg=setdiff(1:P_BEAD,idx);
        assert(numel(idx_bg)==1,'Unable to assign residual background component.');
        % Row 1=Green1 (ring), row 2=Green2 (core).
        coeff=single(S_b(idx,bead_idx));
        if k==1, anchor_coeff=coeff; end
        if anchor_rebuild
            fprintf('Seed %d anchor restored in RAM (%.1f s).\n',SEEDS(k),elapsed);
            clear args M_b S_b coeff;
            continue;
        end

        A_ring=reshape(S_b(idx(1),:),H,W);
        A_core=reshape(S_b(idx(2),:),H,W);
        [~,~,~,rc,rs,pass]=e14_geometry(B_cube,A_core,A_ring);
        % RRE is full-field relative Frobenius reconstruction error.
        E=Yb-M_b*S_b;
        rre=norm(E,'fro')/max(norm(Yb,'fro'),eps);
        pix_err=sqrt(sum(E(:,bead_idx).^2,1));
        pix_mag=max(sqrt(sum(Yb(:,bead_idx).^2,1)),eps);
        masked_mean=mean(pix_err./pix_mag);
        assert(all(isfinite([sad2,rre,masked_mean])), ...
            'Non-finite spectral/reconstruction evaluation.');

        T.SAD_Green1_ring_deg(k)=sad2(1);
        T.SAD_Green2_core_deg(k)=sad2(2);
        T.SAD_mean_deg(k)=mean(sad2);
        T.reconstruction_RRE(k)=rre;
        T.masked_pixel_residual_mean(k)=masked_mean;
        if k>1
            assert(~isempty(anchor_coeff),'Seed 1001 anchor is missing.');
            r1=e3_pearson(double(anchor_coeff(1,:)),double(coeff(1,:)));
            r2=e3_pearson(double(anchor_coeff(2,:)),double(coeff(2,:)));
            T.abundance_r_seed1001_Green1_ring(k)=r1;
            T.abundance_r_seed1001_Green2_core(k)=r2;
            vals=[r1,r2];
            vals=vals(isfinite(vals));
            if ~isempty(vals)
                T.abundance_r_seed1001_mean(k)=mean(vals);
            end
        end
        T.core_peak_r_px(k)=rc;
        T.ring_peak_r_px(k)=rs;
        T.geometry_pass(k)=pass;
        T.time_s(k)=elapsed;
        T.run_status(k)=1;
        e3_write_one_csv(T,OUT_CSV); % save each successful seed, no other files
        fprintf(['Seed %d OK | Green1 SAD %.3f, Green2 SAD %.3f, ' ...
            'Mean SAD %.3f deg | RRE %.5f | geom=%g | %.1fs | %d/%d\n'], ...
            SEEDS(k),sad2(1),sad2(2),mean(sad2),rre,pass, ...
            elapsed,nnz(T.run_status==1),nRuns);
        clear args M_b S_b coeff A_ring A_core E;
    catch ME
        if anchor_rebuild || k==1
            % Cannot compare any later abundance maps without seed-1001.
            rethrow(ME);
        end
        T.run_status(k)=-1;
        e3_write_one_csv(T,OUT_CSV);
        warning('Seed %d FAILED and can be retried: %s',SEEDS(k),ME.message);
    end
end

%% 4. Print summary, but write NO summary CSV or images -------------------
e3_print_summary(T);
fprintf('\nOnly saved output: %s\n',OUT_CSV);

%% Local helpers ----------------------------------------------------------
function e3_write_one_csv(T,fname)
% No cumulative run folders or separate checkpoint files.
writetable(T,fname);
end

function e3_print_summary(T)
ok=T.run_status==1;
fprintf('\nE-3 FocalCheck: %d/%d completed\n',nnz(ok),height(T));
if ~any(ok), return; end
names={'SAD_Green1_ring_deg','SAD_Green2_core_deg','SAD_mean_deg', ...
    'reconstruction_RRE','masked_pixel_residual_mean', ...
    'abundance_r_seed1001_mean','core_peak_r_px','ring_peak_r_px', ...
    'geometry_pass','time_s'};
for j=1:numel(names)
    v=T.(names{j})(ok);
    v=v(isfinite(v));
    if isempty(v)
        fprintf('%-34s: unavailable\n',names{j});
    else
        fprintf('%-34s: %.6g +/- %.6g, range %.6g..%.6g, n=%d\n', ...
            names{j},mean(v),std(v,0),min(v),max(v),numel(v));
    end
end
if nnz(~ok)>0
    fprintf('Pending/failed seeds: %s\n',num2str(T.seed(~ok).'));
end
fprintf(['NOTE: abundance correlation compares seed1001 on SAME FOV, ' ...
    'not true abundance accuracy; seed1001 self-correlation is NaN.\n']);
end

function r=e3_pearson(a,b)
a=double(a(:)); b=double(b(:));
ok=isfinite(a)&isfinite(b);
a=a(ok); b=b(ok);
r=NaN;
if numel(a)<3, return; end
a=a-mean(a); b=b-mean(b);
if norm(a)<=eps || norm(b)<=eps, return; end
r=max(-1,min(1,(a'*b)/(norm(a)*norm(b))));
end

% Original E14 bead methods: unchanged, apart from excluding plotting helper.
function cube = e14_read_16tiff(folder)
% Read corrected01zoomed.tif...corrected16zoomed.tif in numeric order.
assert(isfolder(folder),'E14:noTiffFolder','Folder not found: %s',folder);
first = fullfile(folder,'corrected01zoomed.tif');
assert(exist(first,'file')==2,'E14:noTiff','Missing %s',first);
img = imread(first);
assert(ismatrix(img),'E14:badTiff','Expected grayscale 2-D TIFF: %s',first);
[H,W]=size(img);
cube=zeros(16,H,W);
for i=1:16
    fname=fullfile(folder,sprintf('corrected%02dzoomed.tif',i));
    assert(exist(fname,'file')==2,'E14:noTiff','Missing channel TIFF: %s',fname);
    tmp=imread(fname);
    assert(isequal(size(tmp),[H W]),'E14:badTiff','Inconsistent TIFF size: %s',fname);
    cube(i,:,:)=double(tmp);
end
fprintf('Loaded 16 TIFF channels from %s\n',folder);
end

function [spec,fg,bg] = e14_measured_ref(cube)
% Otsu bead foreground; subtract per-channel median background.
[L,H,W]=size(cube);
intensity=squeeze(sum(cube,1));
normalized=mat2gray(intensity);
fg=imbinarize(normalized,graythresh(normalized));
fg=bwareaopen(fg,25);
cc=bwconncomp(fg);
assert(cc.NumObjects>0,'E14:emptyBead','No connected bead area in pure reference.');
sizes=cellfun(@numel,cc.PixelIdxList);
[~,largest]=max(sizes);
mask=false(H,W);
mask(cc.PixelIdxList{largest})=true;
fg=mask;
bg=~imdilate(fg,strel('disk',8));
if nnz(bg)<100, bg=~fg; end
assert(nnz(bg)>=100,'E14:badBackground','No background pixels detected.');
X=reshape(cube,L,[]);
mean_fg=mean(X(:,fg(:)),2);
med_bg=median(X(:,bg(:)),2);
spec=max(mean_fg-med_bg,0);
assert(norm(spec)>0,'E14:badRef','Background-subtracted spectrum is zero.');
end

function d=e14_sad(a,b)
a=a(:);b=b(:);
if norm(a)==0 || norm(b)==0 || any(~isfinite(a)) || any(~isfinite(b))
    d=NaN; return;
end
cosv=(a.'*b)/(norm(a)*norm(b));
d=acosd(max(-1,min(1,cosv)));
end

function [assign,sads,C]=e14_pair_match(R,M)
% Two measured refs -> three recovered endmembers, unique global assignment.
C=NaN(2,size(M,2));
for i=1:2
    for j=1:size(M,2), C(i,j)=e14_sad(R(:,i),M(:,j)); end
end
best=Inf;assign=[NaN NaN];
for j1=1:size(M,2)
    for j2=1:size(M,2)
        if j1==j2,continue;end
        objective=C(1,j1)+C(2,j2);
        if isfinite(objective) && objective<best
            best=objective; assign=[j1 j2];
        end
    end
end
assert(all(isfinite(assign)),'E14:noMatch', ...
    'No valid two-spectrum matching found; inspect recovered spectra.');
sads=[C(1,assign(1)),C(2,assign(2))];
end

function [r,pc,ps,rc,rs,pass,center]=e14_geometry(cube,A_core,A_ring)
% Evaluate radial peak order ONLY inside the segmented bead. This prevents
% high abundance in distant background (e.g. r=191 px) being scored as ring.
% Physical semantics: Green2=core, Green1=ring.
[mask,center,R] = e14_bead_roi(cube);
r=NaN;pc=NaN;ps=NaN;rc=NaN;rs=NaN;pass=NaN;
if ~isfinite(R) || R < 8, return; end
[~,H,W]=size(cube);
rmax=min(floor(R),floor(min(H,W)/2));
% Only allow annuli >=70% covered by bead pixels. Profile outside bead is
% NaN (not extrapolated). In the supplied 513x513 data this excludes the
% background region at ~191 px while preserving the true rim near 146 px.
[r,pc]=e14_radial_masked(max(A_core,0),center(1),center(2),rmax,mask);
[~,ps]=e14_radial_masked(max(A_ring,0),center(1),center(2),rmax,mask);
valid=isfinite(pc)&isfinite(ps);
if nnz(valid)<10, return; end
core_cmp=pc;ring_cmp=ps;
core_cmp(~valid)=-Inf;
ring_cmp(~valid)=-Inf;
[~,ic]=max(core_cmp); [~,ir]=max(ring_cmp);
rc=r(ic); rs=r(ir);
% The inequality checks spatial ordering. It is NOT proof of clean
% separation or spectral accuracy; SAD and the maps must also be checked.
pass=double(rs>rc);
end

function [mask,center,R]=e14_bead_roi(cube)
% Largest Otsu-foreground object, holes filled, weighted centroid.
[~,H,W]=size(cube);
intensity=squeeze(sum(cube,1));
img=mat2gray(intensity);
bw=imbinarize(img,graythresh(img));
bw=bwareaopen(bw,25);
cc=bwconncomp(bw);
mask=false(H,W);center=[NaN NaN];R=NaN;
if cc.NumObjects==0,return;end
sizes=cellfun(@numel,cc.PixelIdxList);
[~,i]=max(sizes);
mask(cc.PixelIdxList{i})=true;
mask=imfill(mask,'holes');
[y,x]=find(mask);
weights=max(double(intensity(mask)),0);
if sum(weights)<=0,return;end
center=[sum(x.*weights)/sum(weights),sum(y.*weights)/sum(weights)];
R=sqrt(nnz(mask)/pi);
end

function [r,profile]=e14_radial_masked(img,cx,cy,rmax,mask)
% Do NOT include outside-mask pixels or fill missing bins with extrapolation.
[H,W]=size(img);
[X,Y]=meshgrid(1:W,1:H);
radii=hypot(X-cx,Y-cy);
r=(0:rmax).';
profile=NaN(numel(r),1);
for k=0:rmax
    annulus=(radii>=k-0.5)&(radii<k+0.5);
    count_all=nnz(annulus);
    if count_all==0,continue;end
    valid_pix=annulus&mask;
    if nnz(valid_pix)/count_all < 0.70,continue;end
    profile(k+1)=mean(img(valid_pix));
end
end

function [core_spec,ring_spec,n_core,n_ring,mask,center,R] = e14_raw_spatial_spectra(cube)
% Compare measured core and ring spectra with the two SINGLE-dye references.
% This diagnostic does not enter either PISCO training or SAD matching.
[mask,center,R]=e14_bead_roi(cube);
assert(isfinite(R) && R>=8,'E14:badMixedMask', ...
    'Cannot identify a suitable mixed bead for the raw spectral audit.');
[~,H,W]=size(cube);
[X,Y]=meshgrid(1:W,1:H);
d=hypot(X-center(1),Y-center(2));
core_region=mask&(d<=0.45*R);
ring_region=mask&(d>=0.78*R)&(d<=0.96*R);
n_core=nnz(core_region);n_ring=nnz(ring_region);
assert(n_core>=20 && n_ring>=20,'E14:emptyRegion', ...
    'Raw spectral audit core/ring regions contain too few pixels.');
bg=~imdilate(mask,strel('disk',8));
if nnz(bg)<100,bg=~mask;end
assert(nnz(bg)>=100,'E14:missingBackground', ...
    'Too few background pixels for raw spectral audit.');
[L,~,~]=size(cube);
Xspec=reshape(cube,L,[]);
background=median(Xspec(:,bg(:)),2);
core_spec=max(mean(Xspec(:,core_region(:)),2)-background,0);
ring_spec=max(mean(Xspec(:,ring_region(:)),2)-background,0);
assert(norm(core_spec)>0 && norm(ring_spec)>0,'E14:emptySpectra', ...
    'Raw spatial spectra vanished after background subtraction.');
end
