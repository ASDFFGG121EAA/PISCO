%% demo_pisco_E14_beads_realTIFF_with_fullMAT_GYL_NoASC.m
% E14 Arm 2 ONLY -- REAL FocalCheck DoubleGreen TIFF datasets
% Dataset: Data.zip/datasets/{green1only_zoomed,green2only_zoomed,
%            green1core_green2ring_zoomed}/corrected01zoomed.tif ... corrected16zoomed.tif
%
% Scientific protocol:
%   1) Use ONLY the mixed core/ring cube to train PISCO (blind unmixing).
%   2) Independently extract measured Green1/Green2 reference spectra from
%      single-component bead cubes, for post-training SAD evaluation only.
%   3) Match two references to 3 estimated components by global minimum
%      total SAD; the third component is treated as background.
%   4) Check core-shell geometry for EACH seed by radial abundance profiles.
%
% IMPORTANT: These TIFFs are corrected, 8-bit images, NOT certified raw
% photon counts. Keeping the original Poisson trainer configuration is a
% MODELING CHOICE, not evidence that the values are raw photon counts.
% Spectral wavelength calibration is unknown; figures use channel 1..16.
% Physical role based on original FocalCheck description and spectral audit:
%   Green1 = ring (shorter-wavelength dye); Green2 = core (longer-wavelength dye).
% The original directory name 'green1core_green2ring_zoomed' is unchanged
% for compatibility; it must not be used to assign the physical labels.
% Channel names are indices 01..16, not verified wavelength calibration.
%
% MATLAB R2023a + Image Processing Toolbox.
% Required on MATLAB path: deep_mvsa_invflow_poisson_explicit_Warmup2_NoASC.m
% NoASC: estimated S contains non-normalized spectral coefficients (not
% sum-to-one abundance fractions). In background, S can be near zero.
% The geometric radius criterion, SAD matching, and plots are unchanged.
%
% Put the UNZIPPED Data.zip contents in:
%   <this_script_folder>/data_E14/datasets/green1only_zoomed/...
%   <this_script_folder>/data_E14/datasets/green2only_zoomed/...
%   <this_script_folder>/data_E14/datasets/green1core_green2ring_zoomed/...
% Also accepts <this_script_folder>/datasets/... directly.
%
% Outputs in a UNIQUE new folder for each execution:
%   E14_bead_outputs_NoASC_GYL_yyyymmdd_HHMMSS[/suffix]
% Previous corrected/ASC results and previous NoASC runs are never overwritten.
%   pisco_E14_beads_results.csv              (3*N_RUNS+1) rows x 11 columns
%       core_peak_r_px=Green2 core; shell_peak_r_px=Green1 ring;
%       geometry_pass=(ring peak radius > core peak radius), measured
%       only in annuli with >=70% segmented-bead pixel coverage
%   pisco_E14_bead_refspectra.csv             measured reference spectra
%   pisco_E14_figE_bead.png                  intensity and abundance maps
%   pisco_E14_figF_radial.png                radial profiles
%   pisco_E14_figG_bead_spectra.png          measured/estimated spectra
%   pisco_E14_beads_run1.mat                 self-contained Figs E/F/G data
%       includes full original corrected 16-channel mixed TIFF cube
%       (B_cube_full), actual training cube (B_cube), and Fig E total
%       intensity (mix_total); no extra diagnostic CSV files are written.
%
% QUICK=true : initial run, central 384x384 region (keep bead perimeter).
% QUICK=false: final run, full 513x513 mixed cube; original training
%              training settings and configured seeds are retained.

clear; close all; clc;

%% 0. Configuration
script_dir = fileparts(mfilename('fullpath'));
if isempty(script_dir), script_dir = pwd; end
DATA_ROOT = fullfile(script_dir, 'data_E14', 'datasets');
if ~isfolder(DATA_ROOT)
    alternate = fullfile(script_dir, 'datasets');
    if isfolder(alternate), DATA_ROOT = alternate; end
end
assert(isfolder(DATA_ROOT), 'E14:missingData', ...
    'Missing data folder: extract Data.zip so that data_E14/datasets exists beside this script.');

DIR_REF1 = fullfile(DATA_ROOT, 'green1only_zoomed');
DIR_REF2 = fullfile(DATA_ROOT, 'green2only_zoomed');
DIR_MIX  = fullfile(DATA_ROOT, 'green1core_green2ring_zoomed');

QUICK    = false;   % for final results, set false
CROP     = 384;    % first-test crop preserves bead core and ring better than 256
%SEEDS    = [1001, 2002];
SEEDS    = [1001];
N_RUNS   = 1;
P_BEAD   = 3;      % Green1 ring + Green2 core + residual background
MM_ITERS = 550;
WARM_UP  = 500;
READ_SIG = 1.0;    % original code's assumed noise floor (not calibrated)

assert(numel(SEEDS) >= N_RUNS, 'E14:seeds', ...
    'Add more seeds or decrease N_RUNS.');
assert(exist('deep_mvsa_invflow_poisson_explicit_Warmup2_NoASC','file') == 2, ...
    'E14:trainerMissing', ...
    'deep_mvsa_invflow_poisson_explicit_Warmup2_NoASC.m must be on the MATLAB path.');

%% Every execution gets its OWN output folder. Never overwrite old results.
% Includes a collision suffix if invoked more than once in the same second.
run_stamp = datestr(now,'yyyymmdd_HHMMSS');
base_out_name = ['E14_bead_outputs_NoASC_GYL_' run_stamp];
OUT_DIR = fullfile(script_dir, base_out_name);
suffix = 1;
while exist(OUT_DIR,'dir') == 7
    OUT_DIR = fullfile(script_dir, sprintf('%s_%02d',base_out_name,suffix));
    suffix = suffix + 1;
end
[ok,msg] = mkdir(OUT_DIR);
assert(ok, 'E14:outputFolder', 'Cannot create separate output folder: %s', msg);
fprintf('New NoASC output folder: %s\n',OUT_DIR);
OUT_CSV = fullfile(OUT_DIR, 'pisco_E14_beads_results.csv');
REF_CSV = fullfile(OUT_DIR, 'pisco_E14_bead_refspectra.csv');

fprintf('\nE14 -- FocalCheck DoubleGreen beads (Arm 2 ONLY)\n');
fprintf('data: %s\n', DATA_ROOT);
fprintf('QUICK=%d, p=%d, runs=%d, iterations=%d, warmup=%d\n', ...
    QUICK, P_BEAD, N_RUNS, MM_ITERS, WARM_UP);

%% 1. Read ALL TIFF channels numerically (01, 02, ... 16)
C1 = e14_read_16tiff(DIR_REF1);
C2 = e14_read_16tiff(DIR_REF2);
B_cube_full = e14_read_16tiff(DIR_MIX);

assert(size(C1,1)==size(C2,1) && size(C1,1)==size(B_cube_full,1), ...
    'E14:channelMismatch', 'Reference and mixed files have different numbers of channels.');
L = size(B_cube_full,1);
fprintf('Reference1 %s, reference2 %s, mixed %s (L x H x W)\n', ...
    mat2str(size(C1)), mat2str(size(C2)), mat2str(size(B_cube_full)));

%% 2. Measured references (never passed to the PISCO trainer)
% Otsu foreground mask = bead; outside-of-bead pixels = local background.
% A background-subtracted foreground mean is used as a SEMI-GT spectrum.
[M_ref1, mask1, bg1] = e14_measured_ref(C1);
[M_ref2, mask2, bg2] = e14_measured_ref(C2);
M_ref = [M_ref1, M_ref2];
ref_sad = e14_sad(M_ref1, M_ref2);
fprintf('Measured reference spectral angle Green1 vs Green2: %.3f deg\n', ref_sad);
fprintf('Reference bead foreground pixels: Green1 %d, Green2 %d\n', nnz(mask1), nnz(mask2));

fr = fopen(REF_CSV,'w');
assert(fr>0,'E14:refCsv','Cannot write reference CSV');
fprintf(fr, 'channel,Green1_ring,Green2_core\n');
for l = 1:L
    fprintf(fr,'%d,%.12g,%.12g\n', l, M_ref(l,1), M_ref(l,2));
end
fclose(fr);

%% 3. Mixed cube: cropped quick test or full data
B_cube = B_cube_full;
% Crop bounds (1-based, inclusive) are saved with the MAT file so the
% relationship between the full TIFF data and the training image is clear.
crop_rows = [1, size(B_cube_full,2)];
crop_cols = [1, size(B_cube_full,3)];
if QUICK
    [~, H0, W0] = size(B_cube);
    h = min(CROP,H0); w = min(CROP,W0);
    r1 = floor((H0-h)/2)+1; c1 = floor((W0-w)/2)+1;
    B_cube = B_cube(:,r1:r1+h-1,c1:c1+w-1);
    crop_rows = [r1, r1+h-1];
    crop_cols = [c1, c1+w-1];
    fprintf('QUICK crop: row %d..%d, col %d..%d\n',r1,r1+h-1,c1,c1+w-1);
end
[~, H, W] = size(B_cube);
% Fig E input, stored so it can be recreated without opening any TIFF.
% B_cube_full is the ORIGINAL full 16-channel corrected TIFF stack.
% B_cube is the stack actually passed into the trainer (possibly cropped).
mix_total = squeeze(sum(B_cube,1));
Yb = reshape(B_cube,L,[]);    % ordered in column-major raster order
assert(all(isfinite(Yb(:))) && all(Yb(:)>=0), 'E14:badData', ...
    'Mixed TIFF input must be finite and nonnegative.');

%% 3a. In-memory spatial/label check (NO diagnostic files saved)
% Uses the same largest-bead mask and intensity-weighted centroid as the
% geometry evaluation. Core: r <= 0.45 R; ring: 0.78 R <= r <= 0.96 R.
% For each zone, average the spectrum and subtract the per-channel median
% background. This check only prints a warning; it saves no diagnostic files.
[raw_core, raw_ring] = e14_raw_spatial_spectra(B_cube);
raw_sad = [e14_sad(raw_core, M_ref(:,1)), e14_sad(raw_core, M_ref(:,2)); ...
           e14_sad(raw_ring, M_ref(:,1)), e14_sad(raw_ring, M_ref(:,2))];
fprintf('Raw-data audit: core SAD [Green1 %.2f, Green2 %.2f] deg\n', ...
    raw_sad(1,1),raw_sad(1,2));
fprintf('Raw-data audit: ring SAD [Green1 %.2f, Green2 %.2f] deg\n', ...
    raw_sad(2,1),raw_sad(2,2));
if raw_sad(1,2) >= raw_sad(1,1) || raw_sad(2,1) >= raw_sad(2,2)
    warning('E14:labelAudit', ...
        'Raw mixed-bead spectra do not support Green2-core/Green1-ring consistently.');
end


% Only per-run results are written here. Ref spectra are independently saved.
fid = fopen(OUT_CSV,'w');
assert(fid>0,'E14:csvOpen','Cannot write results CSV');
fprintf(fid,['arm,run,seed,p_used,endmember,sad_deg,pearson_r,time_s,' ...
    'core_peak_r_px,shell_peak_r_px,geometry_pass\n']);
BEAD_COMP = {'Green1_ring','Green2_core','Background'};
SADs = NaN(N_RUNS,2);
TIMEs = NaN(N_RUNS,1);
RADII = NaN(N_RUNS,2);
PASS = NaN(N_RUNS,1);

%% 4. Blind PISCO training using Warmup2_NoASC
for k = 1:N_RUNS
    rng(SEEDS(k));
    base_args = {'spherize','yes', 'verbose',0, ...
        'MM_ITERS',MM_ITERS, 'WARM_UP',WARM_UP, 'LR',3e-4, ...
        'LAMBDA_VOL',0.008, 'LAMBDA_NONNEG',3, 'LAMBDA_EQ',100, ...
        'LAMBDA_SUMONE',0, 'LAMBDA_ENCLOSE',10, ...
        'IMG_H',H, 'IMG_W',W, 'LAMBDA_SPATIAL',2, ...
        'NOISE_MODEL','poisson', 'ETA',0.3, ...
        'PHOTON_GAIN',1, 'PHOTON_FLOOR',1, 'READ_SIGMA',READ_SIG};

    fprintf('\nArm 2 run %d/%d (seed=%d): %d x %d pixels, %d channels, p=%d\n', ...
        k, N_RUNS, SEEDS(k), H, W, L, P_BEAD);
    tt = tic;
    [M_b, S_b] = deep_mvsa_invflow_poisson_explicit_Warmup2_NoASC(Yb,P_BEAD,base_args{:});
    TIMEs(k) = toc(tt);
    assert(isequal(size(M_b),[L,P_BEAD]),'E14:badM', ...
        'Trainer must return M as L x p.');
    assert(isequal(size(S_b),[P_BEAD,H*W]),'E14:badS', ...
        'Trainer must return S as p x N.');

    % Global minimum two-reference assignment to 3 estimated endmembers.
    % Labels are assigned AFTER training, never during it.
    [idx,sad2] = e14_pair_match(M_ref,M_b);
    idx_bg = setdiff(1:P_BEAD,idx);
    assert(numel(idx_bg)==1,'E14:badMatch','Could not identify background.');
    full_idx = [idx(:).' idx_bg];
    SADs(k,:) = sad2(:).';

    % NoASC: S_b contains non-normalized coefficients, not fractions.
    A1 = reshape(S_b(full_idx(1),:), H, W);  % Green1 RING
    A2 = reshape(S_b(full_idx(2),:), H, W);  % Green2 CORE
    % e14_geometry accepts (core_abundance, ring_abundance).
    [rad,pc,ps,rc,rs,pass,center] = e14_geometry(B_cube,A2,A1);
    RADII(k,:) = [rc rs];
    PASS(k) = pass;
    fprintf('  %.1f s | Green1 SAD %.3f deg | Green2 SAD %.3f deg\n', ...
        TIMEs(k),SADs(k,1),SADs(k,2));
    fprintf('  core peak radius %.2f px, ring peak radius %.2f px, PASS=%g\n', ...
        rc,rs,pass);

    for j=1:P_BEAD
        v = NaN;
        if j<=2, v=SADs(k,j); end
        % Pearson is undefined for different-FOV single-component beads.
        fprintf(fid,'arm2_beads,%d,%d,%d,%s,%.9g,NaN,%.3f,%.9g,%.9g,%.9g\n', ...
            k, SEEDS(k), P_BEAD, BEAD_COMP{j}, v, TIMEs(k), rc, rs, pass);
    end

    if k == 1
        b1_M = M_b;
        b1_S = S_b;
        b1_order = full_idx;
        b1_A1 = A1; b1_A2 = A2;
        b1_rad = rad; b1_pc = pc; b1_ps = ps;
        b1_rc = rc; b1_rs = rs; b1_pass = pass;
        b1_center = center;
    end
end

% One global MEAN summary row: SAD across the two dyes and all repeats.
mean_sad = mean(SADs(:),'omitnan');
mean_t = mean(TIMEs,'omitnan');
mean_rc = mean(RADII(:,1),'omitnan');
mean_rs = mean(RADII(:,2),'omitnan');
mean_pass = mean(PASS,'omitnan');
fprintf(fid,'arm2_beads,0,0,%d,MEAN,%.9g,NaN,%.3f,%.9g,%.9g,%.9g\n', ...
    P_BEAD,mean_sad,mean_t,mean_rc,mean_rs,mean_pass);
fclose(fid);

%% 5. Figures: first run, using REAL reference spectra, no assumed nm axis
% Fig E: intensity image + abundance distributions.
fig=figure('Name','E14 Arm 2 Fig E: FocalCheck bead abundances','Color','w', ...
           'Position',[60 60 1230 380]);
subplot(1,3,1); imagesc(mix_total); axis image off;
colormap(gray); colorbar; title('Mixed bead: total intensity');
subplot(1,3,2); imagesc(b1_A1); axis image off; colorbar;
title('PISCO Green1 (ring) abundance');
subplot(1,3,3); imagesc(b1_A2); axis image off; colorbar;
title('PISCO Green2 (core) abundance');
sgtitle(sprintf('E14 Arm 2, run 1, 16 channels, %d x %d pixels', H,W));
saveas(fig,fullfile(OUT_DIR,'pisco_E14_figE_bead.png'));

% Fig F: radial abundance profiles.
fig=figure('Name','E14 Arm 2 Fig F: radial profiles','Color','w', ...
           'Position',[60 60 760 440]);
if any(isfinite(b1_pc)) && any(isfinite(b1_ps))
    plot(b1_rad,e14_norm(b1_pc),'-','LineWidth',2); hold on;
    plot(b1_rad,e14_norm(b1_ps),'--','LineWidth',2);
    xline(b1_rc,':','Core peak'); xline(b1_rs,':','Ring peak');
    legend('Green2: core','Green1: ring','Location','best');
    grid on; xlabel('Distance from bead center (pixels)');
    ylabel('Radial-mean abundance (normalised)');
    title(sprintf('Core %.1f px; ring %.1f px; geometry pass=%g', ...
        b1_rc,b1_rs,b1_pass));
else
    text(0.1,0.5,'Geometry not available: bead segmentation failed'); axis off;
end
saveas(fig,fullfile(OUT_DIR,'pisco_E14_figF_radial.png'));

% Fig G: estimated vs measured single-component spectra.
fig=figure('Name','E14 Arm 2 Fig G: measured references','Color','w', ...
           'Position',[60 60 1100 430]);
for j=1:2
    subplot(1,2,j);
    plot(1:L,e14_norm(M_ref(:,j)),'k-','LineWidth',2); hold on;
    plot(1:L,e14_norm(b1_M(:,b1_order(j))),'r--','LineWidth',1.6);
    xlabel('Channel index (not calibrated wavelength)');
    ylabel('Relative intensity'); grid on;
    title(sprintf('%s; SAD %.3f deg',BEAD_COMP{j},SADs(1,j)));
    legend('Measured single-bead reference','PISCO blind estimate', ...
        'Location','best');
end
sgtitle('E14 Arm 2: observed references and blind endmembers');
saveas(fig,fullfile(OUT_DIR,'pisco_E14_figG_bead_spectra.png'));

% Save EVERYTHING needed to redraw Figs E/F/G using this MAT only:
%   Fig E: mix_total, b1_A1 (Green1 ring), b1_A2 (Green2 core)
%   Fig F: b1_rad, b1_pc (Green2 core), b1_ps (Green1 ring), peak radii
%   Fig G: M_ref, b1_M, b1_order, SADs
%   Original mixed data: B_cube_full (16 x original height x original width)
%   Trainer input: B_cube (16 x H x W), identical to the array reshaped into Yb
%   NoASC coefficients: b1_S, b1_A1, b1_A2 (NOT fractional abundances)
% Both cubes store the *corrected TIFF grayscale values*, not raw photons.
% No diagnostic CSVs or separate data files are created.
TRAINER_NAME = 'deep_mvsa_invflow_poisson_explicit_Warmup2_NoASC';
ABUNDANCE_TYPE = 'non-normalized coefficients (NoASC)';
MAT_OUT = fullfile(OUT_DIR,'pisco_E14_beads_run1.mat');
save(MAT_OUT, ...
    'B_cube_full','B_cube','mix_total','crop_rows','crop_cols', ...
    'b1_M','b1_S','b1_order','M_ref','SADs','TIMEs','RADII','PASS', ...
    'b1_center','b1_A1','b1_A2', ...
    'b1_rad','b1_pc','b1_ps','b1_rc','b1_rs','b1_pass', ...
    'L','H','W','QUICK','CROP','SEEDS','P_BEAD','MM_ITERS','WARM_UP', ...
    'TRAINER_NAME','ABUNDANCE_TYPE');
fprintf('Complete Fig E/F/G and original 16-channel mixed cube saved: %s\n',MAT_OUT);

fprintf('\n========== E14 Arm 2 summary ==========\n');
fprintf('Mean Green1 SAD: %.3f deg\n',mean(SADs(:,1),'omitnan'));
fprintf('Mean Green2 SAD: %.3f deg\n',mean(SADs(:,2),'omitnan'));
fprintf('Physical roles: Green1 = ring, Green2 = core.\n');
fprintf('Mean SAD both dyes: %.3f deg\n',mean_sad);
fprintf('Core-shell pass rate: %.3f (over non-NaN runs)\n',mean_pass);
fprintf('Mean training time: %.2f s\n',mean_t);
fprintf('Trainer: %s\n',TRAINER_NAME);
fprintf('Results: %s\n',OUT_DIR);
fprintf('For FINAL experiment set QUICK=false and rerun.\n');

%% ========================== Local functions ============================
function cube = e14_read_16tiff(folder)
% Read corrected01zoomed.tif...corrected16zoomed.tif in numeric order.
assert(isfolder(folder),'E14:noTiffFolder','Folder not found: %s',folder);
first = fullfile(folder,'corrected01zoomed.tif');
assert(exist(first,'file')==2,'E14:noTiff','Missing %s',first);
img = imread(first);
assert(ismatrix(img),'E14:badTiff','Expected grayscale 2-D TIFF: %s',first);
[H,W]=size(img);
cube=zeros(16,H,W);
for i=1:16
    fname=fullfile(folder,sprintf('corrected%02dzoomed.tif',i));
    assert(exist(fname,'file')==2,'E14:noTiff','Missing channel TIFF: %s',fname);
    tmp=imread(fname);
    assert(isequal(size(tmp),[H W]),'E14:badTiff','Inconsistent TIFF size: %s',fname);
    cube(i,:,:)=double(tmp);
end
fprintf('Loaded 16 TIFF channels from %s\n',folder);
end

function [spec,fg,bg] = e14_measured_ref(cube)
% Otsu bead foreground; subtract per-channel median background.
[L,H,W]=size(cube);
intensity=squeeze(sum(cube,1));
normalized=mat2gray(intensity);
fg=imbinarize(normalized,graythresh(normalized));
fg=bwareaopen(fg,25);
cc=bwconncomp(fg);
assert(cc.NumObjects>0,'E14:emptyBead','No connected bead area in pure reference.');
sizes=cellfun(@numel,cc.PixelIdxList);
[~,largest]=max(sizes);
mask=false(H,W);
mask(cc.PixelIdxList{largest})=true;
fg=mask;
bg=~imdilate(fg,strel('disk',8));
if nnz(bg)<100, bg=~fg; end
assert(nnz(bg)>=100,'E14:badBackground','No background pixels detected.');
X=reshape(cube,L,[]);
mean_fg=mean(X(:,fg(:)),2);
med_bg=median(X(:,bg(:)),2);
spec=max(mean_fg-med_bg,0);
assert(norm(spec)>0,'E14:badRef','Background-subtracted spectrum is zero.');
end

function d=e14_sad(a,b)
a=a(:);b=b(:);
if norm(a)==0 || norm(b)==0 || any(~isfinite(a)) || any(~isfinite(b))
    d=NaN; return;
end
cosv=(a.'*b)/(norm(a)*norm(b));
d=acosd(max(-1,min(1,cosv)));
end

function [assign,sads,C]=e14_pair_match(R,M)
% Two measured refs -> three recovered endmembers, unique global assignment.
C=NaN(2,size(M,2));
for i=1:2
    for j=1:size(M,2), C(i,j)=e14_sad(R(:,i),M(:,j)); end
end
best=Inf;assign=[NaN NaN];
for j1=1:size(M,2)
    for j2=1:size(M,2)
        if j1==j2,continue;end
        objective=C(1,j1)+C(2,j2);
        if isfinite(objective) && objective<best
            best=objective; assign=[j1 j2];
        end
    end
end
assert(all(isfinite(assign)),'E14:noMatch', ...
    'No valid two-spectrum matching found; inspect recovered spectra.');
sads=[C(1,assign(1)),C(2,assign(2))];
end

function [r,pc,ps,rc,rs,pass,center]=e14_geometry(cube,A_core,A_ring)
% Evaluate radial peak order ONLY inside the segmented bead. This prevents
% high abundance in distant background (e.g. r=191 px) being scored as ring.
% Physical semantics: Green2=core, Green1=ring.
[mask,center,R] = e14_bead_roi(cube);
r=NaN;pc=NaN;ps=NaN;rc=NaN;rs=NaN;pass=NaN;
if ~isfinite(R) || R < 8, return; end
[~,H,W]=size(cube);
rmax=min(floor(R),floor(min(H,W)/2));
% Only allow annuli >=70% covered by bead pixels. Profile outside bead is
% NaN (not extrapolated). In the supplied 513x513 data this excludes the
% background region at ~191 px while preserving the true rim near 146 px.
[r,pc]=e14_radial_masked(max(A_core,0),center(1),center(2),rmax,mask);
[~,ps]=e14_radial_masked(max(A_ring,0),center(1),center(2),rmax,mask);
valid=isfinite(pc)&isfinite(ps);
if nnz(valid)<10, return; end
core_cmp=pc;ring_cmp=ps;
core_cmp(~valid)=-Inf;
ring_cmp(~valid)=-Inf;
[~,ic]=max(core_cmp); [~,ir]=max(ring_cmp);
rc=r(ic); rs=r(ir);
% The inequality checks spatial ordering. It is NOT proof of clean
% separation or spectral accuracy; SAD and the maps must also be checked.
pass=double(rs>rc);
end

function [mask,center,R]=e14_bead_roi(cube)
% Largest Otsu-foreground object, holes filled, weighted centroid.
[~,H,W]=size(cube);
intensity=squeeze(sum(cube,1));
img=mat2gray(intensity);
bw=imbinarize(img,graythresh(img));
bw=bwareaopen(bw,25);
cc=bwconncomp(bw);
mask=false(H,W);center=[NaN NaN];R=NaN;
if cc.NumObjects==0,return;end
sizes=cellfun(@numel,cc.PixelIdxList);
[~,i]=max(sizes);
mask(cc.PixelIdxList{i})=true;
mask=imfill(mask,'holes');
[y,x]=find(mask);
weights=max(double(intensity(mask)),0);
if sum(weights)<=0,return;end
center=[sum(x.*weights)/sum(weights),sum(y.*weights)/sum(weights)];
R=sqrt(nnz(mask)/pi);
end

function [r,profile]=e14_radial_masked(img,cx,cy,rmax,mask)
% Do NOT include outside-mask pixels or fill missing bins with extrapolation.
[H,W]=size(img);
[X,Y]=meshgrid(1:W,1:H);
radii=hypot(X-cx,Y-cy);
r=(0:rmax).';
profile=NaN(numel(r),1);
for k=0:rmax
    annulus=(radii>=k-0.5)&(radii<k+0.5);
    count_all=nnz(annulus);
    if count_all==0,continue;end
    valid_pix=annulus&mask;
    if nnz(valid_pix)/count_all < 0.70,continue;end
    profile(k+1)=mean(img(valid_pix));
end
end

function [core_spec,ring_spec,n_core,n_ring,mask,center,R] = e14_raw_spatial_spectra(cube)
% Compare measured core and ring spectra with the two SINGLE-dye references.
% This diagnostic does not enter either PISCO training or SAD matching.
[mask,center,R]=e14_bead_roi(cube);
assert(isfinite(R) && R>=8,'E14:badMixedMask', ...
    'Cannot identify a suitable mixed bead for the raw spectral audit.');
[~,H,W]=size(cube);
[X,Y]=meshgrid(1:W,1:H);
d=hypot(X-center(1),Y-center(2));
core_region=mask&(d<=0.45*R);
ring_region=mask&(d>=0.78*R)&(d<=0.96*R);
n_core=nnz(core_region);n_ring=nnz(ring_region);
assert(n_core>=20 && n_ring>=20,'E14:emptyRegion', ...
    'Raw spectral audit core/ring regions contain too few pixels.');
bg=~imdilate(mask,strel('disk',8));
if nnz(bg)<100,bg=~mask;end
assert(nnz(bg)>=100,'E14:missingBackground', ...
    'Too few background pixels for raw spectral audit.');
[L,~,~]=size(cube);
Xspec=reshape(cube,L,[]);
background=median(Xspec(:,bg(:)),2);
core_spec=max(mean(Xspec(:,core_region(:)),2)-background,0);
ring_spec=max(mean(Xspec(:,ring_region(:)),2)-background,0);
assert(norm(core_spec)>0 && norm(ring_spec)>0,'E14:emptySpectra', ...
    'Raw spatial spectra vanished after background subtraction.');
end

function out=e14_norm(v)
% Normalise valid entries without allowing masked NaNs to spoil the scale.
v=double(v);
finite_v=v(isfinite(v));
if isempty(finite_v),out=v;return;end
mx=max(finite_v);
if mx>0,out=v/mx;else,out=v;end
end
