%% demo_pisco_E12_dynamics.m
% E12: PISCO training dynamics on BIOLOGICAL-MASK simulated data.
% Data synthesis matches
% demo_pisco_E2_scalability_one_method_workspace_biomask_GYL.m:
%   1. load the original 32 x 4 FPbase/HyU spectrum matrix from MAT file;
%   2. cycle through use/<scene_name>/masks/*.png;
%   3. generate spatially correlated abundances with build_Strue_from_masks;
%   4. apply Poisson shot noise + Gaussian readout noise, with E2's
%      photon convention and independent deterministic random seeds.
% The model, objective weights, training schedule, per-iteration logs,
% statistics, figures and CSV layouts remain those of this E12 demo.
%
% Reference trainer: pisco_e12_train_log.m (explicit abundances and
% E3d fixed-Q warm-up, 6th output = losslog).
% Model training: 600 warm-up + 1900 joint = 2500 Adam iterations.
% Every iteration is logged, including all raw (unweighted) losses.
% Repeats: 10 by default (paper protocol: 30). One PISCO run per repeat.
%
% Required files on MATLAB path / beside this script:
%   build_Strue_from_masks.m, pisco_e12_train_log.m, VCA.m
%   PISCO_M_32x4_HyU_strict_quasar32.mat
%   use/<scene_name>/masks/*.png
% Requires Statistics and Machine Learning Toolbox (poissrnd).
%
% Outputs (unchanged):
%   pisco_E12_dynamics_losslog1.csv
%   pisco_E12_dynamics_summary1.csv
%   pisco_E12_fig1_curves1.png
%   pisco_E12_fig2_band1.png
%
% The loss-identity check compares total to the weighted raw components.
% During warm-up lambda_vol=0 and Q stays exactly frozen; during joint,
% Q is smoothly released as implemented inside pisco_e12_train_log.m.
% Logged losses correspond to pre-Adam-update states in the trainer.
%
clear all; close all; clc;

%% A.0 Protocol ---------------------------------------------------------
QUICK       = false;    % true = smoke test (2 repeats, 800 iters, 200 warm-up)
N_RUNS      = 30;      % Monte-Carlo repeats (demo; paper protocol: 30)
BASE_SEED   = 42;
SIZE        = 96;      % E1 standard scene: 96 x 96
PHOTONS     = 20;      % E2 convention: mean photons per CHANNEL
READ_SIG    = 1.0;     % Gaussian read-out noise, counts (design v5)
MM_ITERS    = 2500;    % total Adam iterations (SI Table 3 default)
WARM_UP     = 600;     % warm-up length (SI Table 3 default) -> 1900 joint

% E2 biological-mask simulation settings (data-generation only).
M_FILE          = 'PISCO_M_32x4_HyU_strict_quasar32.mat';
MASK_SIGMA      = 2.0;
MASK_BACKGROUND = 0.02;
MAX_PURITY      = 0.8;

% Resolve data next to this script, independent of the MATLAB working dir.
THIS_SCRIPT = mfilename('fullpath');
SCRIPT_DIR = fileparts(THIS_SCRIPT);
if isempty(SCRIPT_DIR)
    SCRIPT_DIR = pwd;
end
MASK_ROOT = fullfile(SCRIPT_DIR, 'use');
M_PATH    = fullfile(SCRIPT_DIR, M_FILE);
OUT_LOSSLOG = 'pisco_E12_dynamics_losslog2.csv';
OUT_SUMMARY = 'pisco_E12_dynamics_summary2.csv';
OUT_FIG1    = 'pisco_E12_fig1_curves2.png';
OUT_FIG2    = 'pisco_E12_fig2_band2.png';

if QUICK
    N_RUNS = 2; MM_ITERS = 800; WARM_UP = 200;
end

% E12 hyperparameters (unchanged from the supplied E12 demo).
% These weights are also used for the per-iteration loss-identity check:
LV   = 0.008;   % LAMBDA_VOL      (joint phase only; 0 during warm-up)
LNN  = 3;       % LAMBDA_NONNEG
LEQ  = 100;     % LAMBDA_EQ
LS1  = 2;       % LAMBDA_SUMONE
LENC = 10;      % LAMBDA_ENCLOSE
LSP  = 2;       % LAMBDA_SPATIAL
LMNN = 10;      % LAMBDA_MNONNEG  (trainer default, not overridden)
LSM  = 0.1;     % LAMBDA_SMOOTH   (trainer default, not overridden)

COMP = {'total','recon','vol','nonneg','eq','sumone','enclose', ...
        'spatial','mnonneg','smooth'};   % losslog fields, CSV order

%% A.1 E2 biomask scene discovery and FPbase spectral loading ------------
IMG_H = SIZE;
IMG_W = SIZE;
N = IMG_H * IMG_W;

% Discover valid scenes using the same ordered directory traversal as E2.
% Only masks/*.png are used. The images/ subdirectories are not needed.
if ~isfolder(MASK_ROOT)
    error(['Cannot find biological-mask root folder:\n  %s\n' ...
           'Expected use/<scene_name>/masks/*.png next to this script.'], ...
           MASK_ROOT);
end

Dscene = dir(MASK_ROOT);
Dscene = Dscene([Dscene.isdir]);
Dscene = Dscene(~ismember({Dscene.name},{'.','..'}));
scene_dirs = {};
for ii = 1:numel(Dscene)
    candidate = fullfile(MASK_ROOT,Dscene(ii).name);
    mask_dir = fullfile(candidate,'masks');
    if isfolder(mask_dir) && ~isempty(dir(fullfile(mask_dir,'*.png')))
        scene_dirs{end+1} = candidate; %#ok<SAGROW>
    end
end
if isempty(scene_dirs)
    error(['No usable biological scenes were found under:\n  %s\n' ...
           'Each scene must contain masks/*.png.'], MASK_ROOT);
end
[~,ord_scene] = sort(lower(string(scene_dirs)));
scene_dirs = scene_dirs(ord_scene);
nScenes = numel(scene_dirs);

% Same real fluorescence reference spectra as E2: NEVER hand-enter M_true.
if ~isfile(M_PATH)
    error(['Cannot find spectral MAT file:\n  %s\n' ...
           'Put the spectral MAT file next to this script.'], M_PATH);
end
Dspec = load(M_PATH);
if ~isfield(Dspec,'M')
    error('%s does not contain variable M.', M_FILE);
end
M_true = double(Dspec.M);
[L,p] = size(M_true);
if L ~= 32 || p ~= 4
    error('Expected M_true to be 32 x 4, got %d x %d.', L, p);
end
if any(~isfinite(M_true(:))) || any(M_true(:) < 0)
    error('M_true must contain finite nonnegative values.');
end
if isfield(Dspec,'channel_centers_nm')
    wl = double(Dspec.channel_centers_nm(:));
    if numel(wl) ~= L
        error('channel_centers_nm must contain %d values.', L);
    end
else
    wl = linspace(410.5,694.9,L)';
end
if isfield(Dspec,'endmember_names')
    endmember_names = Dspec.endmember_names; %#ok<NASGU>
else
    endmember_names = {'Citrine','tdTomato','mKO2','mRuby'}; %#ok<NASGU>
end
clear Dspec;

fprintf('Loaded FPbase spectra: %s (%d channels x %d endmembers)\n', ...
        M_FILE,L,p);
fprintf('Biomask scenes: %d in %s\n', nScenes, MASK_ROOT);
fprintf('Biomask synthesis: sigma=%.2f, background=%.3f, max purity=%.2f\n', ...
        MASK_SIGMA,MASK_BACKGROUND,MAX_PURITY);

%% A.2 Monte-Carlo repeats (PISCO only, per-iteration loss log) --------
% per-iteration storage: LG.<comp>(iter, run)
for c = 1:numel(COMP)
    LG.(COMP{c}) = zeros(MM_ITERS, N_RUNS);
end
SAD_v   = zeros(N_RUNS,1);      % endmember SAD (deg), E1 metric (sanity)
MAB_v   = zeros(N_RUNS,1);      % abundance MSE
T_v     = zeros(N_RUNS,1);      % wall-clock seconds
MAXERR  = zeros(N_RUNS,1);      % max loss-identity relative error
lam_vol_eff = [zeros(WARM_UP,1); LV*ones(MM_ITERS-WARM_UP,1)];

fprintf(['E12 demo (PISCO only): %d repeats, scene %dx%d, %d photons, ' ...
    '%d warm-up + %d joint iterations, every iteration logged\n'], ...
    N_RUNS, IMG_H, IMG_W, PHOTONS, WARM_UP, MM_ITERS-WARM_UP);

for r = 1:N_RUNS
    % --- E2 data synthesis: biological mask -> abundances -> noisy Y ---
    % Deterministic cycling across usable scenes; E2's same mask grouping
    % seed and hyperparameters. Each repeat gets a separately seeded mask.
    scene_idx = 1 + mod(r-1,nScenes);
    scene_dir = scene_dirs{scene_idx};
    [~,scene_name] = fileparts(scene_dir);
    %fprintf('run %d/%d: biological scene = %s\n',r,N_RUNS,scene_name);

    S_true = build_Strue_from_masks( ...
        scene_dir,IMG_H,IMG_W,p,MAX_PURITY, ...
        BASE_SEED + r,MASK_SIGMA,MASK_BACKGROUND);

    if ~isequal(size(S_true),[p,N]) || any(~isfinite(S_true(:)))
        error('build_Strue_from_masks returned an invalid %d x %d abundance matrix.',p,N);
    end
    Y_clean = M_true * S_true;

    % Independent E2 noise stream: keep mask sampling and noise independent.
    rng(BASE_SEED + 10000 + r,'twister');
    % PHOTONS denotes MEAN photons per channel, not per entire spectrum.
    g = PHOTONS * N / sum(Y_clean(:)) * L;
    Y_in = double( ...
        poissrnd(g*Y_clean) + ...
        READ_SIG*randn(L,N)) / g;

    % Separate E2 optimization stream, independent of mask and noise draws.
    rng(BASE_SEED + 100000 + r,'twister');

    % ---- PISCO (Poisson observation model, instrumented trainer) ----
    t_run = tic;                    % paired handle (robust tic/toc)
    [M_est, S_est, ~, ~, ~, losslog] = pisco_e12_train_log_explicit_Warmup(Y_in, p, ...
        'spherize','yes', 'verbose',0, ...
        'MM_ITERS',MM_ITERS, 'WARM_UP',WARM_UP, 'LR',3e-4, ...
        'LAMBDA_VOL',0.008, 'LAMBDA_NONNEG',3, 'LAMBDA_EQ',100, ...
        'LAMBDA_SUMONE',2, 'LAMBDA_ENCLOSE',10, ...
        'IMG_H',IMG_H, 'IMG_W',IMG_W, 'LAMBDA_SPATIAL',2, ...
        'NOISE_MODEL','poisson', 'ETA',0.3, ...
        'PHOTON_GAIN',g, 'PHOTON_FLOOR',1, 'READ_SIGMA',READ_SIG);
    T_v(r) = toc(t_run);

    % ---- store the per-iteration raw components ----
    for c = 1:numel(COMP)
        LG.(COMP{c})(:,r) = losslog.(COMP{c});
    end

    % ---- numerical-identity self-check (see header) ----
    rec = losslog.recon + lam_vol_eff.*losslog.vol + LNN*losslog.nonneg + ...
        LEQ*losslog.eq + LS1*losslog.sumone + LENC*losslog.enclose + ...
        LSP*losslog.spatial + LMNN*losslog.mnonneg + LSM*losslog.smooth;
    MAXERR(r) = max(abs(rec - losslog.total) ./ max(abs(losslog.total), 1e-30));
    if MAXERR(r) > 1e-6
        warning('E12:lossIdentity', ['run %d: loss-identity relative ' ...
            'error %.3e exceeds 1e-6 (recorded in MAXERR).'], r, MAXERR(r));
    end

    % ---- accuracy sanity check (E2-compatible metrics; 20 photons/channel) ----
    [perm, ~] = e1_match(M_true, M_est);
    [SAD_v(r), MAB_v(r), ~] = e1_metrics(M_true, S_true, Y_clean, ...
        M_est, S_est, perm);

    fprintf(['run %2d/%d | SAD %5.2f deg | MSE_ab %.3e | t %5.1fs | ' ...
        'final total %.6e | identity err %.2e\n'], r, N_RUNS, ...
        SAD_v(r), MAB_v(r), T_v(r), losslog.total(end), MAXERR(r));
end

%% A.3 CSV outputs ------------------------------------------------------
% (1) long loss-log table: one row per (run, iteration)
fid = fopen(OUT_LOSSLOG, 'w');
fprintf(fid, ['run,iter,phase,total,recon,vol,nonneg,eq,sumone,' ...
    'enclose,spatial,mnonneg,smooth\n']);
for r = 1:N_RUNS
    for k = 1:MM_ITERS
        if k <= WARM_UP, ph_str = 'warmup'; else, ph_str = 'joint'; end
        fprintf(fid, ['%d,%d,%s,%.10e,%.10e,%.10e,%.10e,%.10e,%.10e,' ...
            '%.10e,%.10e,%.10e,%.10e\n'], r, k, ph_str, ...
            LG.total(k,r), LG.recon(k,r), LG.vol(k,r), LG.nonneg(k,r), ...
            LG.eq(k,r), LG.sumone(k,r), LG.enclose(k,r), ...
            LG.spatial(k,r), LG.mnonneg(k,r), LG.smooth(k,r));
    end
end
fclose(fid);
fprintf('Per-iteration loss log written to %s (%d rows)\n', ...
    OUT_LOSSLOG, N_RUNS*MM_ITERS);

% (2) per-run summary
fid = fopen(OUT_SUMMARY, 'w');
fprintf(fid, 'run,photons,SAD_deg,MSE_ab,time_s\n');
for r = 1:N_RUNS
    fprintf(fid, '%d,%d,%.4f,%.6e,%.2f\n', r, PHOTONS, SAD_v(r), ...
        MAB_v(r), T_v(r));
end
fclose(fid);
fprintf('Per-run summary written to %s\n', OUT_SUMMARY);

%% A.4 Figures ----------------------------------------------------------
it   = (1:MM_ITERS).';
tiny = 1e-30;   % display floor: semilogy cannot draw exact zeros
plt  = @(x) max(x, tiny);

% --- Fig. 1 (SI Suppl. Fig. 2 counterpart): representative run 1 ------
% Total and every raw component on a log axis; the raw volume term
% vol = -sum(r_log) is SIGNED (<= 0 in practice), so it is drawn on a
% linear right-hand axis -- a log axis would silently drop it.
figure('Name','E12: training dynamics (run 1)', ...
    'Position',[50 50 980 560], 'Color','w');
cmap = lines(9);
yyaxis left
semilogy(it, plt(LG.total(:,1)),   'k-', 'LineWidth',2.2); hold on;
semilogy(it, plt(LG.recon(:,1)),   '-',  'LineWidth',1.4, 'Color',cmap(1,:));
semilogy(it, plt(LG.nonneg(:,1)),  '-',  'LineWidth',1.1, 'Color',cmap(2,:));
semilogy(it, plt(LG.eq(:,1)),      '-',  'LineWidth',1.1, 'Color',cmap(3,:));
semilogy(it, plt(LG.sumone(:,1)),  '-',  'LineWidth',1.1, 'Color',cmap(4,:));
semilogy(it, plt(LG.enclose(:,1)), '-',  'LineWidth',1.1, 'Color',cmap(5,:));
semilogy(it, plt(LG.spatial(:,1)), '-',  'LineWidth',1.1, 'Color',cmap(6,:));
semilogy(it, plt(LG.mnonneg(:,1)), '-',  'LineWidth',1.1, 'Color',cmap(7,:));
semilogy(it, plt(LG.smooth(:,1)),  '-',  'LineWidth',1.1, 'Color',cmap(8,:));
ylabel('raw loss component (log scale)');
yyaxis right
plot(it, LG.vol(:,1), '--', 'LineWidth',1.4, 'Color',cmap(9,:));
ylabel('vol = -sum(r\_log), signed (linear)');
xline(WARM_UP, ':', 'warm-up | joint', 'LineWidth',1.2, ...
    'LabelHorizontalAlignment','left');
xlabel('iteration'); grid on;
title(sprintf(['E12: PISCO training dynamics, run 1 ' ...
    '(%d photons, %d warm-up + %d joint)'], PHOTONS, WARM_UP, ...
    MM_ITERS-WARM_UP));
legend({'total','recon','nonneg','eq','sumone','enclose','spatial', ...
    'mnonneg','smooth','vol (right)'}, 'Location','northeast');
exportgraphics(gcf, OUT_FIG1, 'Resolution', 200);
fprintf('Figure written to %s\n', OUT_FIG1);

% --- Fig. 2: total and recon across repeats, mean +/- sd band --------
muT = mean(LG.total,2); sdT = std(LG.total,0,2);
muR = mean(LG.recon,2); sdR = std(LG.recon,0,2);
figure('Name','E12: dynamics across repeats', ...
    'Position',[50 50 900 520], 'Color','w');
% lower band edge floored at `tiny`: sd can exceed the mean on a log
% axis, and non-positive values cannot be drawn
fill([it; flipud(it)], [plt(muT-sdT); flipud(muT+sdT)], [0.75 0.75 0.75], ...
    'EdgeColor','none', 'FaceAlpha',0.5); hold on;
fill([it; flipud(it)], [plt(muR-sdR); flipud(muR+sdR)], [0.68 0.85 1.00], ...
    'EdgeColor','none', 'FaceAlpha',0.5);
semilogy(it, plt(muT), 'k-', 'LineWidth',2.2);
semilogy(it, plt(muR), '-',  'LineWidth',1.8, 'Color',[0.00 0.45 0.74]);
set(gca, 'YScale','log');
xline(WARM_UP, ':', 'warm-up | joint', 'LineWidth',1.2, ...
    'LabelHorizontalAlignment','left');
xlabel('iteration'); ylabel('loss (log scale)'); grid on;
title(sprintf('E12: total and recon over %d repeats (mean +/- sd)', N_RUNS));
legend({'total +/- sd','recon +/- sd','total mean','recon mean'}, ...
    'Location','northeast');
exportgraphics(gcf, OUT_FIG2, 'Resolution', 200);
fprintf('Figure written to %s\n', OUT_FIG2);

%% A.5 Console summary --------------------------------------------------
fprintf('\n===== E12 SUMMARY over %d repeats (PISCO only, %d photons) =====\n', ...
    N_RUNS, PHOTONS);
for r = 1:N_RUNS
    fprintf('run %2d | SAD %5.2f deg | time %5.1fs | final-iter total %.6e\n', ...
        r, SAD_v(r), T_v(r), LG.total(end,r));
end
fprintf('SAD %.2f +/- %.2f deg (mean +/- std) -- sanity: should sit ' , ...
    mean(SAD_v), std(SAD_v));
fprintf('near the comparable E1/E2 20-photon biomask runs.\n');
fprintf('MSE_ab %.3e +/- %.3e\n', mean(MAB_v), std(MAB_v));
fprintf(['Loss-identity self-check: max relative error over all runs ' ...
    'and iterations = %.3e (threshold 1e-6; violations warned above).\n'], ...
    max(MAXERR));

%% ==================== local functions ================================
function [perm, sad_v] = e1_match(M_true, M_est)
% Greedy permutation matching by spectral angle distance.
p = size(M_true, 2);
Cmat = zeros(p);
for i = 1:p
    for j = 1:p
        Cmat(i,j) = acosd(max(-1, min(1, ...
            (M_true(:,i)'*M_est(:,j)) / ...
            (norm(M_true(:,i))*norm(M_est(:,j))))));
    end
end
perm = zeros(1,p); taken = false(1,p);
for i = 1:p
    [~,jj] = min(Cmat(i,:) + taken*1e6); perm(i) = jj; taken(jj) = true;
end
sad_v = Cmat(sub2ind([p p], 1:p, perm));
end

function [sad, mse_ab, mse_rec] = e1_metrics(M_true, S_true, Y_clean, ...
    M_est, S_est, perm)
% Same metrics as demo_pisco_E1_accuracy.m; the reconstruction residual
% is vectorised with reshape(...) instead of expression indexing
% ((M_est*S_est)(:) is not valid MATLAB syntax), numerically identical.
[~, sad_v] = e1_match(M_true, M_est);
sad     = mean(sad_v);
mse_ab  = mean((S_true(:) - reshape(S_est(perm,:), [], 1)).^2);
mse_rec = mean((Y_clean(:) - reshape(M_est*S_est, [], 1)).^2);
end
