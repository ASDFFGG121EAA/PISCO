function [M_est, Sest, Up, my, theta, losslog] = pisco_e12_train_log(Y, p, varargin)
%% PISCO E12: explicit abundance + E3d fixed-Q warm-up + full training loss logging
%  + Spatial Smoothness + POISSON CHANCE CONSTRAINTS
%
% Q = L * Q0 * R, L: unit lower-tri, R: upper-tri with positive diagonal.
% E12 logging version of deep_mvsa_invflow_poisson_explicit_Warmup.m.
% Training arithmetic, gradients, Adam states, defaults and parameter schedule
% follow that reference implementation; logging only reads existing losses.
% Returns one raw (unweighted) objective-component value per iteration:
%   losslog.iter, phase (0=warm-up, 1=joint), total, recon, vol, nonneg,
%   eq, sumone, enclose, spatial, mnonneg, smooth.
% Losses are evaluated BEFORE the iteration's Adam update and logged AFTER
% that update; the logged losses therefore correspond to the pre-step state.
% 'vol' is signed: -sum(theta.r_log). Warm-up uses lambda_vol = 0.
% E12 caller can verify weighted-loss identity from these raw components.
%
% EXPLICIT ABUNDANCE VERSION:
%   E3d warm-up from pisco_e3_train_b1_15: freeze Q and its Adam moments,
%   pretrain the per-pixel abundances, then gradually release Q with a
%   separate Adam clock and an explicit Q learning-rate ramp.
%   The abundance matrix is optimized directly as theta.S_explicit (p x N),
%   initialized uniformly at 1/p. This follows the ABUNDANCE_MODE='explicit'
%   arm used in the PISCO E3 trainer: all reconstruction, non-negativity,
%   sum-to-one and spatial losses are unchanged; only the abundance
%   parameterization changes from the coordinate A-Net to per-pixel variables.
%
% NEW relative to deep_mvsa_invflow.m (Gaussian version):
%   NOISE_MODEL  : 'gaussian' (default, identical to original) or 'poisson'.
%   Under 'poisson', the noise variance is intensity-dependent. Y may be in
%   any intensity unit; PHOTON_GAIN converts it to counts:
%       counts = Y * PHOTON_GAIN,  Var_counts = counts
%       => Var(Y) = max(Y, PHOTON_FLOOR/PHOTON_GAIN) / PHOTON_GAIN
%   Propagated to the working space (B = whitening/projection operator):
%       Vpix      = (B.^2) * Var(Y)                p x N, per-pixel noise var
%       sigma2_ij = (Q.^2) * Vpix                  q_i' Cov_j q_i,  p x N
%   and the chance-constraint margin becomes pixel-adaptive:
%       margin_ij = Phi^{-1}(ETA) * min(sqrt(sigma2_ij), SIGMA_CAP)  <= 0
%   (stop-gradient).  Two terms change:
%     (1) reconstruction  -> heteroscedastic GLS:  diff^2 ./ Vpix, with the
%         weights normalized to mean 1 so the global loss balance (and all
%         lambda settings) matches the Gaussian model;
%     (2) enclosure       -> min(Q*Y - margin, 0)^2  (RMVSA-style noise-
%         tolerant data enclosure: noisy pixels may poke outside the
%         simplex, bright pixels may not).
%   NON-NEGATIVITY of the abundances stays STRICT (min(A_eff,0)^2):
%   abundances are truly non-negative, so relaxing this constraint by a
%   noise margin only injects bias -- the Poisson tolerance belongs to the
%   data terms, not to the abundance prior.
%   sigma2 is recomputed every iteration from the current Q and treated as
%   constant in the gradient (EM-style), so all gradients remain closed form.
%   ETA          : chance-constraint level (default 0.1; 0.5 = hard MVSA).
%   SIGMA_CAP    : cap on the per-pixel margin scale (default 0.1, in
%                  spherized working units). Prevents nearly-constraint-free
%                  behaviour at very low photon counts.
%   PHOTON_GAIN  : counts per unit of Y (default 1, i.e. Y is counts).
%                  Set it so both models can be compared on the SAME input
%                  scaling (see demo_pisco_vs_deeprmvsa.m).
%   PHOTON_FLOOR : variance floor in photon counts (default 1).
%
% v0.9 (2026-09-22):
%   - SPECTRAL SMOOTHNESS PRIOR (LAMBDA_SMOOTH, default 0.1; 0 = off):
%     2nd-difference Tikhonov penalty on the BAND-SPACE endmembers,
%     LAMBDA_SMOOTH*sum((M_band(3:end,:)-2*M_band(2:end-1,:)+M_band(1:end-2,:)).^2),
%     gradient chained through M = inv(Q) like LAMBDA_MNONNEG. Fluorescence
%     emission spectra are smooth on the ~9 nm channel grid, so this
%     suppresses the spurious narrow peaks/dips that shot noise imprints
%     on the recovered spectra without shifting the true (broad) peaks.
%     Also added to deep_mvsa_invflow.m (fair comparison).
%
% v0.8 (2026-09-21):
%   - MARGIN ANNEALING (ETA_END, default 0.5): the chance level eta is
%     linearly annealed from ETA to ETA_END over the joint phase, so the
%     enclosure margin Phi^{-1}(eta_t)*min(sigma,sigma_cap) decays to zero
%     at convergence. Rationale: in the capped regime the margin is a
%     CONSTANT inward relaxation of the enclosure (verified: sigma > cap
%     for 100% of pixels at all photon levels), which the volume term
%     exploits to pull the simplex inside the data cloud -- a systematic
%     bias that dominates once shot noise becomes small (high photon
%     budgets). Annealing removes the bias asymptotically while retaining
%     the noise tolerance during the critical simplex-formation phase.
%     Monte-Carlo verification (v0.9, self-contained Python package, 6
%     paired repeats, 96x96, real FP spectra): at 100 photons the annealed
%     margin beats the FIXED margin in 6/6 paired draws (mean SAD 7.25 vs
%     7.94 deg) and beats the Gaussian backbone in 6/6 paired draws (7.25
%     vs 7.71 deg, sign test p~0.03); neutral at 5-20 photons.
%     Set ETA_END = ETA to reproduce v0.7 behaviour.
%   - ENDMEMBER NON-NEGATIVITY (LAMBDA_MNONNEG, default 10): fluorescence
%     emission spectra are physically non-negative. Soft penalty
%     LAMBDA_MNONNEG*sum(min(M_band,0).^2) inside the objective (gradient
%     chained through M = inv(Q)), plus a final projection
%     M_est = max(M_est,0) on the returned endmembers. At 5 photons the
%     projection alone recovers ~2 deg SAD in bad-noise draws.
%   - Both mechanisms also added to deep_mvsa_invflow.m (fair comparison).
%
% v0.7 (2026-09-21):
%   - READ_SIGMA (default 0): Gaussian read-out noise in photon-count units,
%     added to the variance model Var(Y) = max(Y, floor/gain)/gain +
%     (READ_SIGMA/gain)^2, so the Poisson chance constraints remain
%     calibrated under the mixed Poisson + read-out noise of real detectors
%     (sCMOS/PMT analogue mode). Also honoured by NOISE_WEIGHT 'irls'.
%
% v0.6 (2026-09-21):
%   - SPATIAL TERM NORMALIZATION FIX (both algorithm files): the Laplacian
%     penalty was a SUM over ~2N neighbour pairs while reconstruction is a
%     MEAN, so the effective smoothing grew with N and compressed the
%     abundance range towards 1/p with over-smoothed maps. The penalty and
%     its gradient are now divided by N; use LAMBDA_SPATIAL ~ 20.
%   - NOISE_WEIGHT (default 'uniform'): after signal-covariance whitening,
%     the working-space noise is only weakly heteroscedastic, and uniform
%     weighting keeps the min-volume geometry anchored by all pixels; the
%     Poisson adaptation is carried by the (capped) enclosure margins.
%     'pearson' = v0.5 plug-in GLS; 'irls' = GLS with variances recomputed
%     from the current reconstruction every iteration (stop-grad), which
%     removes the Pearson plug-in noise feedback. Use 'pearson'/'irls' for
%     data with a large intensity dynamic range.
%   - SIGMA_CAP default tightened 0.1 -> 0.03: with a soft quadratic
%     enclosure penalty, noise excursions are already tolerated smoothly;
%     a wide extra margin double-counts the tolerance and lets the volume
%     term pull the simplex inside the data cloud (SAD degrades ~2 deg).
%   Verified (Python replica of the full pipeline, paired noise draws):
%   uniform+cap0.03 ties Deep RMVSA within ~0.1-0.8 deg SAD at matched MSE,
%   while every wider-margin or plug-in-weight variant trails by 1-2 deg.
%
% v0.5 (2026-09-21):
%   - FIX (critical): the affine working dimension carries no shot noise
%     (B(p,:) = 0), so Vpix(p,:) was exactly zero and its GLS weight
%     1/(0+eps) ~ 1e12 dominated the entire objective -- the network only
%     learned to fit the constant dimension, producing near-uniform
%     abundance maps with high-frequency stripe artifacts and oscillating
%     endmember spectra. The zero/too-small variances are now replaced by
%     the median variance (floor at 1e-3 x median).
%   - FIX: GLS weights normalized to mean 1 (keeps the loss scale, and
%     therefore every lambda, comparable to the Gaussian model; stops
%     dim-pixel noise from dominating the reconstruction).
%   - FIX: chance-constraint margin moved off the abundance non-negativity
%     (now strict, as in the Gaussian model) onto the data-enclosure term
%     only, and capped by SIGMA_CAP. Relaxing a physically exact
%     constraint (A >= 0) biased the solution; noise tolerance is only
%     statistically justified on the data enclosure.
%   Verified against a Python replica of the full pipeline: with these
%   fixes PISCO matches Deep RMVSA in endmember SAD and improves abundance
%   MSE at low photon budgets, and the stripe/oscillation artifacts vanish.
%
% v0.4 (2026-09-21):
%   - PHOTON_GAIN added (fixes the scale mismatch when comparing against
%     the Gaussian model on identically scaled inputs).
%   - FOURIER FEATURE encoding of coordinates (NeRF-style), new parameter
%     FF_K (default 6; 0 = off). Fixes INR spectral bias: plain (gx,gy)
%     inputs let the A-Net learn only smooth low-frequency abundance maps.
%   - Weight init scale raised 0.01 -> 0.05.
%
% Optional terms (unchanged):
%   LAMBDA_ENCLOSE : data-enclosure penalty (synthetic data: set 10).
%   LAMBDA_SPATIAL : 4-neighbour grid Laplacian on abundance maps.
%   IMG_H / IMG_W  : scene dimensions for 2-D coordinates and spatial term.

pStruct = inputParser;
addParameter(pStruct, 'MM_ITERS', 2500, @isnumeric);
addParameter(pStruct, 'WARM_UP', 600, ...
    @(x) isnumeric(x) && isscalar(x) && isfinite(x) && x >= 0 && mod(x,1) == 0);
% E3d warm-up transition controls (active only when WARM_UP > 0).
addParameter(pStruct, 'WARMUP_Q_RELEASE', 100, ...
    @(x) isnumeric(x) && isscalar(x) && isfinite(x) && x >= 0 && mod(x,1) == 0);
addParameter(pStruct, 'WARMUP_Q_MIN_LR_RATIO', 0.25, ...
    @(x) isnumeric(x) && isscalar(x) && isfinite(x) && x > 0 && x <= 1);
% Accepted for interface compatibility with pisco_e3_train_b1_15;
% no gate network exists in this explicit-abundance implementation.
addParameter(pStruct, 'WARMUP_GATE_RELEASE', 150, ...
    @(x) isnumeric(x) && isscalar(x) && isfinite(x) && x >= 0 && mod(x,1) == 0);
addParameter(pStruct, 'LR', 3e-4, @isnumeric);
addParameter(pStruct, 'LAMBDA_VOL', 0.005, @isnumeric);
addParameter(pStruct, 'LAMBDA_NONNEG', 3, @isnumeric);
addParameter(pStruct, 'LAMBDA_EQ', 80, @isnumeric);
addParameter(pStruct, 'LAMBDA_SUMONE', 2, @isnumeric);
addParameter(pStruct, 'LAMBDA_ENCLOSE', 0, @isnumeric);   % enclosure term (synthetic data)
addParameter(pStruct, 'LAMBDA_SPATIAL', 0, @isnumeric);   % spatial smoothness (image data)
addParameter(pStruct, 'IMG_H', [], @isnumeric);           % scene height  (rows)
addParameter(pStruct, 'IMG_W', [], @isnumeric);           % scene width   (cols)
addParameter(pStruct, 'M0', [], @isnumeric);
addParameter(pStruct, 'spherize', 'yes', @ischar);
addParameter(pStruct, 'verbose', 1, @isnumeric);
addParameter(pStruct, 'NOISE_MODEL', 'gaussian', @ischar);% 'gaussian' | 'poisson'
addParameter(pStruct, 'NOISE_WEIGHT', 'uniform', @ischar); % 'uniform' | 'pearson' | 'irls' <<< NEW v0.6
addParameter(pStruct, 'ETA', 0.3, @isnumeric);            % chance level
addParameter(pStruct, 'ETA_END', 0.3, @isnumeric);        % annealed chance level (0.5 = margin -> 0) <<< NEW v0.8
addParameter(pStruct, 'LAMBDA_MNONNEG', 10, @isnumeric);  % endmember non-negativity (band space) <<< NEW v0.8
addParameter(pStruct, 'LAMBDA_SMOOTH', 0.1, @isnumeric);  % spectral smoothness, 2nd-diff Tikhonov on M (0 = off) <<< NEW v0.9
addParameter(pStruct, 'SIGMA_CAP', 0.15, @isnumeric);      %0.03 margin cap (working units; 0.03 in v0.6)
addParameter(pStruct, 'PHOTON_GAIN', 1, @isnumeric);      % counts per unit of Y  <<< NEW v0.4
addParameter(pStruct, 'PHOTON_FLOOR', 1, @isnumeric);
addParameter(pStruct, 'READ_SIGMA', 0, @isnumeric);        % Gaussian read-out noise, in COUNTS (v0.7)     % count variance floor
addParameter(pStruct, 'FF_K', 6, @isnumeric);             % retained for API compatibility; unused in explicit mode
parse(pStruct, varargin{:});

[L, N] = size(Y);
if pStruct.Results.WARM_UP >= pStruct.Results.MM_ITERS && pStruct.Results.WARM_UP > 0
    error('WARM_UP must be strictly smaller than MM_ITERS.');
end

%% --------------------- Preprocessing ---------------------
my = mean(Y,2); Yc = Y - repmat(my,1,N);
[Up, D] = svds(Yc*Yc'/N, p-1);
Yp = Up*Up'*Yc + repmat(my,1,N);
my_ortho = my - Up*Up'*my;
Up = [Up, my_ortho/sqrt(sum(my_ortho.^2))];
Y_proj = Up'*Yp;

if strcmp(pStruct.Results.spherize, 'yes')
    lambda_reg = 1e-10;
    C = diag(1./sqrt(diag(D+lambda_reg*eye(p-1))));
    Ys = C*Up(:,1:p-1)'*(Yp-repmat(my,1,N));
    Ys(p,:) = 1; Ys = Ys/sqrt(p);
    Y_work = Ys;
else
    Y_work = Y_proj; lambda_reg = 0;
end

%% --------- v0.8: lift operator for band-space endmember non-negativity ----
lift_ctx = [];
if pStruct.Results.LAMBDA_MNONNEG > 0 || pStruct.Results.LAMBDA_SMOOTH > 0  % v0.9
    if strcmp(pStruct.Results.spherize, 'yes')
        lift_ctx.mode   = 'sph';
        lift_ctx.Up_sub = Up(:,1:p-1);
        lift_ctx.sD     = sqrt(diag(D+lambda_reg*eye(p-1)));
        lift_ctx.my     = my;
        lift_ctx.sqp    = sqrt(p);
    else
        lift_ctx.mode    = 'proj';
        lift_ctx.Up_full = Up;
    end
end

%% --------------------- Poisson noise propagation ---------------------
use_poisson = strcmpi(pStruct.Results.NOISE_MODEL, 'poisson');
irls_ctx = [];
if use_poisson
    if strcmp(pStruct.Results.spherize, 'yes')
        B = [C*Up(:,1:p-1)'; zeros(1,L)] / sqrt(p); % raw counts -> working space
    else
        B = Up';
    end
    B2   = B.^2;                                             % p x L
    gain = pStruct.Results.PHOTON_GAIN;
    VarY = max(Y, pStruct.Results.PHOTON_FLOOR/gain) / gain ...  % shot noise, units of Y
         + (pStruct.Results.READ_SIGMA/gain)^2;               % v0.7: Gaussian read-out noise
    Vpix = B2 * VarY;                                        % p x N
    % ---- v0.5: stabilize the heteroscedastic variances -----------------
    % (a) the affine working dimension carries no shot noise (B(p,:)=0);
    %     a zero variance would give it an infinite GLS weight and destroy
    %     the objective -> assign the median variance instead;
    % (b) floor all variances at 1e-3 x median so the per-pixel weight
    %     ratio cannot exceed 1e3 (Pearson plug-in weights are unstable
    %     at very low counts).
    med_v = median(Vpix(Vpix > 0));
    Vpix(Vpix <= 0) = med_v;
    Vpix = max(Vpix, 1e-3*med_v);
    phi_inv = -sqrt(2)*erfcinv(2*pStruct.Results.ETA);       % Phi^{-1}(eta) <= 0
    % ---- v0.6: IRLS context (model-based weights from the reconstruction)
    if strcmpi(pStruct.Results.NOISE_WEIGHT, 'irls')
        if strcmp(pStruct.Results.spherize, 'yes')
            irls_ctx.Up_sub = Up(:,1:p-1);
            irls_ctx.Cinv   = sqrt(diag(D+lambda_reg*eye(p-1)));
            irls_ctx.my     = my;
            irls_ctx.gain   = gain;
            irls_ctx.floor  = pStruct.Results.PHOTON_FLOOR;
            irls_ctx.rs2    = (pStruct.Results.READ_SIGMA/gain)^2;   % read-noise var (v0.7)
            irls_ctx.B2     = B2;
        else
            warning('NOISE_WEIGHT ''irls'' requires spherize ''yes''; using ''pearson''.');
            pStruct.Results.NOISE_WEIGHT = 'pearson';
        end
    end
    if pStruct.Results.verbose
        fprintf(['Poisson chance constraints: eta=%.2f, Phi^{-1}(eta)=%.3f, ' ...
                 'gain=%.3g\n'], pStruct.Results.ETA, phi_inv, gain);
    end
else
    Vpix = []; phi_inv = 0;
end

%% --------------------- Initialization ---------------------
if isempty(pStruct.Results.M0)
    M0 = VCA(Y_work, 'Endmembers', p, 'verbose', 'off');
else
    M0 = pStruct.Results.M0;
    if strcmp(pStruct.Results.spherize, 'yes')
        M0 = M0 - repmat(my,1,p);
        M0 = C*Up(:,1:p-1)'*M0;
        M0(p,:) = 1; M0 = M0/sqrt(p);
    else
        M0 = Up'*M0;
    end
end
Q0 = inv(M0);
qm = ones(1,N)*Y_work'*inv(Y_work*Y_work');

%% --------------------- Spatial dimensions ---------------------
% Explicit abundance does not use coordinate encoding or A-Net/S-Net.
% IMG_H / IMG_W are retained only for the spatial regularization term.
H_img = pStruct.Results.IMG_H;
W_img = pStruct.Results.IMG_W;
if isempty(H_img) || isempty(W_img)
    H_img = round(sqrt(N)); W_img = round(N/H_img);
end
use_spatial = (H_img * W_img == N);
if ~use_spatial
    if pStruct.Results.LAMBDA_SPATIAL > 0
        warning('IMG_H x IMG_W (%d x %d) ~= N (%d): spatial term disabled.', ...
            H_img, W_img, N);
    end
    H_img = 1; W_img = N;
end

%% --------------------- Explicit abundance parameters ---------------------
% Same explicit-abundance construction as the E3 ABUNDANCE_MODE='explicit' arm:
% optimize one free abundance vector per pixel under the existing losses.
% Near-uniform initialization avoids giving this representation an FCLS/data-
% informed initialization advantage.
theta.S_explicit = ones(p, N) / p;

%% --------------------- Invertible Q: Q = L * Q0 * R ---------------------
theta.L = zeros(p,p);       % strict lower triangular
theta.R = zeros(p,p);       % strict upper triangular
theta.r_log = zeros(p,1);   % R diagonal log

%% --------------------- Adam states ---------------------
m = init_adam(theta);
v = init_adam(theta);
lr = pStruct.Results.LR;
iter = 0;

%% --------------------- E12: preallocate full-iteration loss logs ------------
% All logged components are raw values; do not include lambda multipliers.
n_log = pStruct.Results.MM_ITERS;
losslog.iter    = (1:n_log).';
losslog.phase   = zeros(n_log, 1);  % 0 = warm-up; 1 = joint
losslog.total   = zeros(n_log, 1);
losslog.recon   = zeros(n_log, 1);
losslog.vol     = zeros(n_log, 1);
losslog.nonneg  = zeros(n_log, 1);
losslog.eq      = zeros(n_log, 1);
losslog.sumone  = zeros(n_log, 1);
losslog.enclose = zeros(n_log, 1);
losslog.spatial = zeros(n_log, 1);
losslog.mnonneg = zeros(n_log, 1);
losslog.smooth  = zeros(n_log, 1);

%% --------------------- Warm-up (explicit abundance; Q exactly frozen) ---------------------
% E3d from pisco_e3_train_b1_15: optimize S_explicit while keeping
% Q = Q0.  Do not update Q parameters OR their Adam moment estimates.
if pStruct.Results.verbose, fprintf('Warm-up (explicit abundance, Q exactly frozen)...\n'); end
for k = 1:pStruct.Results.WARM_UP
    [loss, grad, comp] = compute_gradients_invflow(theta, Y_work, Q0, qm, p, ...
        0, pStruct.Results.LAMBDA_NONNEG, pStruct.Results.LAMBDA_EQ, ...
        pStruct.Results.LAMBDA_SUMONE, pStruct.Results.LAMBDA_ENCLOSE, ...
        pStruct.Results.LAMBDA_SPATIAL, H_img, W_img, ...
        use_poisson, Vpix, phi_inv, pStruct.Results.SIGMA_CAP, ...
        pStruct.Results.NOISE_WEIGHT, irls_ctx, ...
        pStruct.Results.LAMBDA_MNONNEG, pStruct.Results.LAMBDA_SMOOTH, lift_ctx);
    [theta, m, v] = adam_update_struct(theta, grad, m, v, iter+1, lr, ...
        0, 0);  % Q frozen, Q Adam moments untouched; abundance Adam continues.
    iter = iter + 1;
    % E12: loss/comp were evaluated at the pre-update parameters.
    losslog.total(k)   = loss;
    losslog.recon(k)   = comp.recon;
    losslog.vol(k)     = comp.vol;
    losslog.nonneg(k)  = comp.nonneg;
    losslog.eq(k)      = comp.eq;
    losslog.sumone(k)  = comp.sumone;
    losslog.enclose(k) = comp.enclose;
    losslog.spatial(k) = comp.spatial;
    losslog.mnonneg(k) = comp.mnonneg;
    losslog.smooth(k)  = comp.smooth;
    if pStruct.Results.verbose && mod(k,100)==0
        fprintf('Warm-up %d/%d, loss=%.6f (Q exactly frozen)\n', ...
            k, pStruct.Results.WARM_UP, loss);
    end
end

if pStruct.Results.WARM_UP > 0
    q_drift = norm(theta.L,'fro') + norm(theta.R,'fro') + norm(theta.r_log);
    assert(q_drift == 0, 'E3d: Q changed during supposedly fixed-Q warm-up.');
    if pStruct.Results.verbose
        fprintf('Warm-up finished: Q parameter drift = %.3g (should be 0).\n', q_drift);
    end
end

%% --------------------- Joint training ---------------------
if pStruct.Results.verbose, fprintf('Joint training (invertible Q + explicit abundance)...\n'); end
n_joint = pStruct.Results.MM_ITERS - pStruct.Results.WARM_UP;
eta0 = pStruct.Results.ETA; eta1 = pStruct.Results.ETA_END;      % v0.8: anneal
for k = 1:n_joint
    % v0.8: anneal the chance level ETA -> ETA_END over the joint phase;
    % Phi^{-1}(0.5) = 0, so the enclosure margin decays to zero at
    % convergence (removes the systematic inward simplex bias at high SNR).
    if use_poisson
        prog  = (k-1)/max(1, n_joint-1);
        eta_t = min(max(eta0 + (eta1-eta0)*prog, 1e-6), 1-1e-6);
        phi_t = -sqrt(2)*erfcinv(2*eta_t);
    else
        phi_t = phi_inv;
    end
    % E3d: release Q smoothly after warm-up.  The smoothstep Q learning-
    % rate ramp is bypassed entirely for WARM_UP = 0.
    q_lr_scale = 1;
    if pStruct.Results.WARM_UP > 0 && pStruct.Results.WARMUP_Q_RELEASE > 0
        q_progress = min(1, k / pStruct.Results.WARMUP_Q_RELEASE);
        q_progress = q_progress^2 * (3 - 2*q_progress);
        q0_scale = pStruct.Results.WARMUP_Q_MIN_LR_RATIO;
        q_lr_scale = q0_scale + (1-q0_scale)*q_progress;
    end
    [loss, grad, comp] = compute_gradients_invflow(theta, Y_work, Q0, qm, p, ...
        pStruct.Results.LAMBDA_VOL, pStruct.Results.LAMBDA_NONNEG, ...
        pStruct.Results.LAMBDA_EQ, pStruct.Results.LAMBDA_SUMONE, ...
        pStruct.Results.LAMBDA_ENCLOSE, ...
        pStruct.Results.LAMBDA_SPATIAL, H_img, W_img, ...
        use_poisson, Vpix, phi_t, pStruct.Results.SIGMA_CAP, ...
        pStruct.Results.NOISE_WEIGHT, irls_ctx, ...
        pStruct.Results.LAMBDA_MNONNEG, pStruct.Results.LAMBDA_SMOOTH, lift_ctx);  % <<< v0.9 args
    % Q's bias-correction clock restarts at k=1 after being frozen,
    % whereas S_explicit keeps the full iteration count (iter+1).
    [theta, m, v] = adam_update_struct(theta, grad, m, v, iter+1, lr, ...
        q_lr_scale, k);
    iter = iter + 1;
    % E12: 1-based iteration index for joint stage.
    jj = pStruct.Results.WARM_UP + k;
    losslog.phase(jj)   = 1;
    losslog.total(jj)   = loss;
    losslog.recon(jj)   = comp.recon;
    losslog.vol(jj)     = comp.vol;
    losslog.nonneg(jj)  = comp.nonneg;
    losslog.eq(jj)      = comp.eq;
    losslog.sumone(jj)  = comp.sumone;
    losslog.enclose(jj) = comp.enclose;
    losslog.spatial(jj) = comp.spatial;
    losslog.mnonneg(jj) = comp.mnonneg;
    losslog.smooth(jj)  = comp.smooth;
    if pStruct.Results.verbose && mod(k,100)==0
        fprintf('Joint %d/%d, loss=%.6f, explicit abundance\n', k, n_joint, loss);
    end
end

%% --------------------- Recover endmembers ---------------------
A_eff = theta.S_explicit;
L_mat = eye(p) + tril(theta.L, -1);
R_mat = diag(exp(theta.r_log)) + triu(theta.R, 1);
Q = L_mat * Q0 * R_mat;
M_sub = inv(Q);
Sest = A_eff;
if strcmp(pStruct.Results.spherize, 'yes')
    M_sub = M_sub*sqrt(p);
    M_sub = M_sub(1:p-1,:);
    M_est = Up(:,1:p-1)*diag(sqrt(diag(D+lambda_reg*eye(p-1))))*M_sub + repmat(my,1,p);
else
    M_est = Up*M_sub;
end
M_est = max(M_est, 0);   % v0.8: fluorescence spectra are physically non-negative
end

%% ===================== Sub-functions =====================
function adam = init_adam(theta)
fields = fieldnames(theta);
adam = struct();
for i = 1:numel(fields)
    f = fields{i};
    adam.(f) = zeros(size(theta.(f)));
end
end

function [loss, grad, comp] = compute_gradients_invflow(theta, Y, Q0, qm, p, ...
    lambda_vol, lambda_nonneg, lambda_eq, lambda_sumone, lambda_enclose, ...
    lambda_spatial, H_img, W_img, use_poisson, Vpix, phi_inv, sigma_cap, ...
    noise_weight, irls_ctx, lambda_mnn, lambda_smooth, lift_ctx)     % <<< v0.9 args
L_mat = eye(p) + tril(theta.L, -1);
R_mat = diag(exp(theta.r_log)) + triu(theta.R, 1);
Q = L_mat * Q0 * R_mat;
M = inv(Q); % p is small, numerically safe

% Explicit per-pixel abundance variables (p x N).
A_eff = theta.S_explicit;

Y_hat = M * A_eff;
diff = Y_hat - Y;

% --- reconstruction weights (v0.6) ------------------------------------
% 'uniform' (default): after signal-covariance whitening the working-space
%   noise is only weakly heteroscedastic, and uniform weighting keeps the
%   min-volume geometry anchored by ALL pixels (bright vertices included);
%   the Poisson adaptation is carried by the enclosure margins below.
% 'pearson': heteroscedastic GLS with plug-in variances (v0.5 behaviour).
% 'irls'   : heteroscedastic GLS with variances recomputed from the
%   CURRENT RECONSTRUCTION every iteration (proper IRLS; removes the
%   Pearson plug-in feedback that lets the net fit its own weight noise).
eps_var = 1e-12;
use_w = use_poisson && ~strcmpi(noise_weight, 'uniform');
if use_poisson && strcmpi(noise_weight, 'irls')
    Yh_chan = irls_ctx.Up_sub * (irls_ctx.Cinv .* (sqrt(p)*Y_hat(1:p-1,:))) + irls_ctx.my;
    VarY = max(Yh_chan, irls_ctx.floor/irls_ctx.gain) / irls_ctx.gain + irls_ctx.rs2;
    Vpix = irls_ctx.B2 * VarY;                          % stop-grad
    med_i = median(Vpix(Vpix > 0)); Vpix(Vpix <= 0) = med_i;
end
if use_w
    W_rec = 1./(Vpix + eps_var);                        % stop-grad weights
    W_rec = W_rec / mean(W_rec(:));                     % mean weight 1
    loss_recon = mean(sum(diff.^2 .* W_rec, 1));
else
    loss_recon = mean(sum(diff.^2,1));
end

loss_vol = -sum(theta.r_log); % log|det(Q0)| omitted as constant

% --- pixel-adaptive chance-constraint margin (Poisson) ---              <<< NEW
% v0.5: the margin applies ONLY to the data-enclosure term (below), where
% noise tolerance is statistically justified (RMVSA heritage). Abundance
% non-negativity is physically exact and stays strict.
if use_poisson
    sigma2 = (Q.^2) * Vpix + eps_var;                  % q_i' Cov_j q_i, p x N
    margin = phi_inv * min(sqrt(sigma2), sigma_cap);   % <= 0, stop-grad, capped
else
    margin = 0;
end

penalty = min(A_eff, 0);                               % strict A >= 0 (v0.5)
loss_nonneg = sum(penalty.^2, 'all');

sum_A = sum(A_eff,1);
loss_sumone = sum((sum_A-1).^2, 'all');

col_sums = sum(Q,1);
loss_eq = sum((col_sums - qm).^2, 'all');

% --- optional data-enclosure penalty QY >= margin ---
QY = Q*Y;
pen_enclose = min(QY - margin, 0);
loss_enclose = sum(pen_enclose.^2, 'all');

% --- optional spatial smoothness of the abundance maps (4-neighbour
%     grid Laplacian):  sum_{adjacent (i,j)} ||a_i - a_j||^2  ---
loss_spatial = 0;
if lambda_spatial > 0 && H_img*W_img == size(Y,2)
    A3  = reshape(A_eff, p, H_img, W_img);
    Dh  = A3(:,2:end,:) - A3(:,1:end-1,:);   % vertical neighbour diffs
    Dw  = A3(:,:,2:end) - A3(:,:,1:end-1);   % horizontal neighbour diffs
    loss_spatial = (sum(Dh.^2,'all') + sum(Dw.^2,'all')) / size(Y,2);  % v0.6: mean over pixels
end

% E12: collect original objective terms without changing the objective.
comp.recon   = loss_recon;
comp.vol     = loss_vol;
comp.nonneg  = loss_nonneg;
comp.eq      = loss_eq;
comp.sumone  = loss_sumone;
comp.enclose = loss_enclose;
comp.spatial = loss_spatial;
comp.mnonneg = 0;
comp.smooth  = 0;

loss = loss_recon + lambda_vol*loss_vol + lambda_nonneg*loss_nonneg + ...
    lambda_sumone*loss_sumone + lambda_eq*loss_eq + ...
    lambda_enclose*loss_enclose + lambda_spatial*loss_spatial;

N = size(Y,2);
if use_w
    dY_hat = 2*diff.*W_rec/N;                          % GLS gradient     <<< NEW
else
    dY_hat = 2*diff/N;
end
dM = dY_hat * A_eff';

% --- v0.8/v0.9: band-space endmember priors (spectra >= 0; spectral smoothness)
if (lambda_mnn > 0 || lambda_smooth > 0) && ~isempty(lift_ctx)
    if strcmp(lift_ctx.mode, 'sph')
        M_band = lift_ctx.Up_sub * (lift_ctx.sD .* (lift_ctx.sqp*M(1:p-1,:))) ...
               + lift_ctx.my;                                   % L x p
    else
        M_band = lift_ctx.Up_full * M;
    end
    dM_band = zeros(size(M_band));
    if lambda_mnn > 0
        pen_M = min(M_band, 0);
        loss  = loss + lambda_mnn * sum(pen_M.^2, 'all');
        comp.mnonneg = sum(pen_M.^2, 'all');  % E12 raw band-space nonneg loss
        dM_band = dM_band + 2*lambda_mnn*pen_M;                 % L x p
    end
    if lambda_smooth > 0                                        % <<< NEW v0.9
        % 2nd-difference Tikhonov on the band-space endmembers: suppresses
        % spurious narrow peaks/dips that shot noise imprints on M.
        D2M = M_band(3:end,:) - 2*M_band(2:end-1,:) + M_band(1:end-2,:);
        loss = loss + lambda_smooth * sum(D2M.^2, 'all');
        comp.smooth = sum(D2M.^2, 'all');    % E12 raw spectral smoothness
        g2 = zeros(size(M_band));
        g2(3:end,:)   = g2(3:end,:)   + 2*lambda_smooth*D2M;
        g2(2:end-1,:) = g2(2:end-1,:) - 4*lambda_smooth*D2M;
        g2(1:end-2,:) = g2(1:end-2,:) + 2*lambda_smooth*D2M;
        dM_band = dM_band + g2;
    end
    if strcmp(lift_ctx.mode, 'sph')
        gmnn = zeros(p,p);
        gmnn(1:p-1,:) = lift_ctx.sqp * (lift_ctx.sD .* (lift_ctx.Up_sub' * dM_band));
    else
        gmnn = lift_ctx.Up_full' * dM_band;
    end
    dM = dM + gmnn;   % chain rule through M = inv(Q) handled below
end

grad_Q_recon = -M' * dM * M';
grad_Q_eq = 2 * repmat(col_sums - qm, p, 1);
grad_Q_enclose = 2 * pen_enclose * Y';
grad_Q_clean = grad_Q_recon + lambda_eq * grad_Q_eq + lambda_enclose * grad_Q_enclose;

% Map Q-gradients to triangular parameters
grad_L_mat = grad_Q_clean * R_mat' * Q0';
grad_R_mat = Q0' * L_mat' * grad_Q_clean;
grad.L = tril(grad_L_mat, -1);
grad.R = triu(grad_R_mat, 1);
grad.r_log = diag(grad_R_mat) .* exp(theta.r_log) - lambda_vol;

% Gradient with respect to explicit abundance variables (margin treated as constant)
dA_eff = M' * dY_hat + 2*lambda_nonneg*penalty + ...
    2*lambda_sumone*repmat(sum_A-1, p, 1);

% gradient of the spatial penalty: 2 * (grid Laplacian) * A
if lambda_spatial > 0 && H_img*W_img == N
    G3 = zeros(p, H_img, W_img);
    G3(:,1:end-1,:) = G3(:,1:end-1,:) - Dh;
    G3(:,2:end,:)   = G3(:,2:end,:)   + Dh;
    G3(:,:,1:end-1) = G3(:,:,1:end-1) - Dw;
    G3(:,:,2:end)   = G3(:,:,2:end)   + Dw;
    dA_eff = dA_eff + 2*lambda_spatial*reshape(G3, p, N)/N;   % v0.6: mean over pixels
end

% Direct per-pixel abundance optimization: all losses above are unchanged;
% only the abundance parameterization differs from the original implicit A-Net.
grad.S_explicit = dA_eff;
end

function [theta, m, v] = adam_update_struct(theta, grad, m, v, iter, lr, ...
    q_lr_scale, q_step)
% E3d: separate Adam bias-correction clocks for the Q group and S_explicit.
% A frozen Q group skips both the parameter step and its moment updates.
beta1 = 0.9; beta2 = 0.999; eps = 1e-8;
fields = fieldnames(theta);
for i = 1:numel(fields)
    f = fields{i};
    is_q = any(strcmp(f, {'L','R','r_log'}));
    if is_q
        if q_lr_scale <= 0, continue; end
        t = q_step;
        local_lr = lr*q_lr_scale;
    else
        t = iter;
        local_lr = lr;
    end
    m.(f) = beta1*m.(f) + (1-beta1)*grad.(f);
    v.(f) = beta2*v.(f) + (1-beta2)*grad.(f).^2;
    m_hat = m.(f) / (1 - beta1^t);
    v_hat = v.(f) / (1 - beta2^t);
    theta.(f) = theta.(f) - local_lr * m_hat ./ (sqrt(v_hat) + eps);
end
end
