%% demo_pisco_E11_structure_biomask_enclose_GYL.m
% E11: abundance-field structure control (PISCO only).
%
% Structured arm:
%   Identical biological-mask abundance generation as the supplied E1
%   benchmark: build_Strue_from_masks(scene_dir, H, W, p, MAX_PURITY,
%   BASE_SEED+r, MASK_SIGMA, MASK_BACKGROUND).
%   ./use/<scene>/masks/*.png -> p-by-N abundances, max purity <= 0.8.
%   LAMBDA_SPATIAL = 2; LAMBDA_ENCLOSE = 0.3 (PISCO v34).
%
% i.i.d. arm:
%   Per-pixel independent Dirichlet(1,1,1,1) draws, then the EXACT same
%   hard max-purity replacement as build_Strue_from_masks.m: when any
%   component exceeds 0.8, set it to 0.8 and the other p-1 to 0.2/(p-1).
%   This is NOT rejection sampling and is NOT an uncapped Dirichlet law;
%   the pixel-wise replacement preserves independence across pixels.
%   No biological masks are used. LAMBDA_SPATIAL = 0; LAMBDA_ENCLOSE = 10.
%
% Both arms share the exact FPbase 32-by-4 spectral matrix loaded from
% PISCO_M_32x4_HyU_strict_quasar32.mat and follow the same observation
% model and existing E11 PISCO/evaluation configuration. The arms differ
% in LAMBDA_SPATIAL (2 vs 0) and LAMBDA_ENCLOSE (0.3 vs 10), as specified
% in PISCO v34. Other trainer hyperparameters are unchanged.
%
% Required on MATLAB path or adjacent to script:
%   build_Strue_from_masks.m
%   deep_mvsa_invflow_poisson_explicit_Warmup.m and its dependencies
%   PISCO_M_32x4_HyU_strict_quasar32.mat
%   ./use/<scene_name>/masks/*.png
%   Statistics and Machine Learning Toolbox for poissrnd
%
% CSV (schema unchanged): pisco_E11_structure_results.csv
%   arm,run,photons,SAD_deg,MSE_ab,MSE_rec,time_s
% Figures (names unchanged):
%   pisco_E11_fig1_arms.png, pisco_E11_fig2_maps.png
% Here, photons = mean photons per SPECTRAL CHANNEL.
%
% Supplied E11 settings retained: QUICK=false, N_RUNS=10, SIZE=96,
% PHOTONS=20, READ_SIG=1, MM_ITERS=2500, WARM_UP=600.
% For paper-grade 30-repeat analysis set N_RUNS=30 (QUICK=false).

clear all; close all; clc;

%% E11.0 Protocol ---------------------------------------------------------
QUICK       = false;    % true = smoke test (2 repeats, 800 iters)
N_RUNS      = 30;      % paired Monte-Carlo repeats (demo; paper: 30)
BASE_SEED   = 42;
SIZE        = 96;      % E1 standard scene: 96 x 96 (both arms)
PHOTONS     = 20;      % fixed mean photons PER CHANNEL, both arms
READ_SIG    = 1.0;     % Gaussian read-out noise, counts (design v5)
MM_ITERS    = 2500;    % joint-phase length (SI Table 3 default)
WARM_UP     = 600;     % warm-up length (SI Table 3 default)
ARMS        = {'structured', 'iid'};
LAM_SPATIAL = [2, 0];    % structured / iid spatial penalty
LAM_ENCLOSE = [0.3, 10]; % structured / iid enclosure penalty
OUT_CSV     = 'pisco_E11_structure_results.csv';

% Exactly the biological-mask settings used in the supplied E1 script.
THIS_SCRIPT = mfilename('fullpath');
SCRIPT_DIR  = fileparts(THIS_SCRIPT);
if isempty(SCRIPT_DIR)
    SCRIPT_DIR = pwd;
end
MASK_ROOT       = fullfile(SCRIPT_DIR, 'use');
MASK_SIGMA      = 2.0;
MASK_BACKGROUND = 0.02;
MAX_PURITY      = 0.8;  % Applies to BOTH arms.

if QUICK
    N_RUNS = 2; MM_ITERS = 800; WARM_UP = 200;
end

%% E11.1 Ground-truth endmembers and biological-mask pool --------------
if exist('build_Strue_from_masks', 'file') ~= 2
    error('Cannot find build_Strue_from_masks.m on the MATLAB path.');
end
% Same MAT file, validation, folder layout, and scene-selection protocol
% as demo_E1_compare_PISCO_LU_SISAL_RMVSA_HyU_NMF_biomask_GYL.m.
M_FILE = fullfile(SCRIPT_DIR, 'PISCO_M_32x4_HyU_strict_quasar32.mat');
if ~isfile(M_FILE)
    error(['Cannot find spectral matrix file: %s\n' ...
           'Put PISCO_M_32x4_HyU_strict_quasar32.mat next to this script.'], ...
           M_FILE);
end
Dspec = load(M_FILE);
if ~isfield(Dspec, 'M')
    error('%s does not contain variable M.', M_FILE);
end
M_true = double(Dspec.M);
[L, p] = size(M_true);
if L ~= 32 || p ~= 4
    error('Expected M_true to be 32 x 4, got %d x %d.', L, p);
end
if any(~isfinite(M_true(:))) || any(M_true(:) < 0)
    error('M_true must contain finite nonnegative values.');
end
if isfield(Dspec, 'channel_centers_nm')
    wl = double(Dspec.channel_centers_nm(:)); %#ok<NASGU>
    if numel(wl) ~= L
        error('channel_centers_nm must contain %d values.', L);
    end
else
    wl = linspace(410.5, 694.9, L)'; %#ok<NASGU>
end
if isfield(Dspec, 'endmember_names')
    endmember_names = cellstr(string(Dspec.endmember_names));
else
    endmember_names = {'Citrine', 'tdTomato', 'mKO2', 'mRuby'};
end
endmember_names = endmember_names(:)';
if numel(endmember_names) ~= p
    error('endmember_names must have %d entries.', p);
end
clear Dspec;

IMG_H = SIZE; IMG_W = SIZE; N = IMG_H * IMG_W;
if ~isfolder(MASK_ROOT)
    error(['Cannot find biological-mask root folder:\n  %s\n' ...
           'Expected ./use/<scene_name>/masks/*.png next to this script.'], ...
           MASK_ROOT);
end
Dscene = dir(MASK_ROOT);
Dscene = Dscene([Dscene.isdir]);
Dscene = Dscene(~ismember({Dscene.name}, {'.', '..'}));
scene_dirs = {};
for ii = 1:numel(Dscene)
    candidate = fullfile(MASK_ROOT, Dscene(ii).name);
    mask_dir = fullfile(candidate, 'masks');
    if isfolder(mask_dir) && ~isempty(dir(fullfile(mask_dir, '*.png')))
        scene_dirs{end+1} = candidate; %#ok<SAGROW>
    end
end
if isempty(scene_dirs)
    error(['No usable biological scenes found under:\n  %s\n' ...
           'Each scene requires masks/*.png.'], MASK_ROOT);
end
[~, ord_scene] = sort(lower(string(scene_dirs)));
scene_dirs = scene_dirs(ord_scene);
nScenes = numel(scene_dirs);

fprintf('Loaded endmember file: %s\n', M_FILE);
fprintf('M_true = %d x %d, image = %d x %d (%d pixels)\n', ...
    L, p, IMG_H, IMG_W, N);
fprintf('Biological mask scenes = %d under %s\n', nScenes, MASK_ROOT);
fprintf('Both arms: maximum abundance purity = %.2f\n', MAX_PURITY);

%% E11.2 Trainer options (PISCO v34 E11 enclosure settings) -----------
% Structured: LAMBDA_SPATIAL=2, LAMBDA_ENCLOSE=0.3 (base_args).
% i.i.d.:     LAMBDA_SPATIAL=0, LAMBDA_ENCLOSE=10 (overrides below).
% The photon gain is recomputed for each scene and arm, as in E1.
base_args = {'spherize','yes', 'verbose',0, ...
    'MM_ITERS',MM_ITERS, 'WARM_UP',WARM_UP, 'LR',3e-4, ...
    'LAMBDA_VOL',0.008, 'LAMBDA_NONNEG',3, 'LAMBDA_EQ',100, ...
    'LAMBDA_SUMONE',2, 'LAMBDA_ENCLOSE',0.3, ...
    'IMG_H',IMG_H, 'IMG_W',IMG_W, 'LAMBDA_SPATIAL',2, ...
    'NOISE_MODEL','poisson', 'ETA',0.3, ...
    'PHOTON_GAIN',1, 'PHOTON_FLOOR',1, 'READ_SIGMA',READ_SIG};

%% E11.3 Paired Monte-Carlo two-arm comparison (PISCO only) ---------------
nA = numel(ARMS);
SAD_m = zeros(nA, N_RUNS);      % endmember SAD (deg)
MAB_m = zeros(nA, N_RUNS);      % abundance MSE
MRC_m = zeros(nA, N_RUNS);      % reconstruction MSE (vs noise-free)
T_m   = zeros(nA, N_RUNS);      % wall-clock seconds

fprintf(['E11 demo (PISCO only): %d paired repeats x %d arms, ' ...
    'scene %dx%d, %d photons, MM_ITERS=%d\n'], ...
    N_RUNS, nA, IMG_H, IMG_W, PHOTONS, MM_ITERS);
fprintf('Estimated runtime ~%.0f min\n', N_RUNS * nA * 20 / 60);

fid = fopen(OUT_CSV, 'w');
% 7 columns: arm,run,photons,SAD_deg,MSE_ab,MSE_rec,time_s
fprintf(fid, 'arm,run,photons,SAD_deg,MSE_ab,MSE_rec,time_s\n');

rep_done = false;
rep_S_true = cell(nA,1); rep_S_est = cell(nA,1); rep_perm = cell(nA,1);
for r = 1:N_RUNS
    % E1: deterministic cycle through the available biological mask scenes.
    scene_idx = 1 + mod(r-1, nScenes);
    scene_dir = scene_dirs{scene_idx};

    % --- arm 1: E1 biological-mask abundances, purity cap 0.8 ----------
    % Uses the EXACT E1 call signature and mask settings.
    S_str = build_Strue_from_masks( ...
        scene_dir, IMG_H, IMG_W, p, MAX_PURITY, ...
        BASE_SEED + r, MASK_SIGMA, MASK_BACKGROUND);
    S_str = double(S_str);
    assert(isequal(size(S_str), [p N]), ...
        'Structured abundance field must be p-by-N.');

    % --- arm 2: i.i.d. Dirichlet(1), E1-identical hard purity cap ---
    % Independent RNG stream: mask generation cannot affect i.i.d. draws.
    rng(BASE_SEED + 20000 + r, 'twister');
    S_iid = -log(rand(p, N));
    S_iid = S_iid ./ sum(S_iid, 1);

    % Copy the EXACT treatment from build_Strue_from_masks.m:
    % replace each pixel whose largest component exceeds MAX_PURITY.
    % No redraw/resampling and no neighbourhood processing.
    [Smax, Sidx] = max(S_iid, [], 1);
    idx_over = find(Smax > MAX_PURITY);
    if ~isempty(idx_over)
        other_value = (1-MAX_PURITY)/(p-1);
        for jj = idx_over
            S_iid(:,jj) = other_value * ones(p,1);
            S_iid(Sidx(jj),jj) = MAX_PURITY;
        end
    end

    % --- validity checks: both share the SAME purity upper bound -------
    assert(all(isfinite(S_str(:))) && all(S_str(:) >= -1e-12), ...
        'Structured abundances must be finite and nonnegative.');
    assert(all(isfinite(S_iid(:))) && all(S_iid(:) >= -1e-12), ...
        'i.i.d. abundances must be finite and nonnegative.');
    assert(max(abs(sum(S_str, 1) - 1)) < 1e-10, ...
        'Structured abundances must sum to 1 at each pixel.');
    assert(max(abs(sum(S_iid, 1) - 1)) < 1e-10, ...
        'i.i.d. abundances must sum to 1 at each pixel.');
    assert(max(S_str(:)) <= MAX_PURITY + 1e-10, ...
        'Structured abundances exceed MAX_PURITY.');
    assert(max(S_iid(:)) <= MAX_PURITY + 1e-10, ...
        'i.i.d. abundances exceed MAX_PURITY.');

    % --- per arm: photon scaling, independent noise draw, PISCO run ---
    for a = 1:nA
        if a == 1, S_true = S_str; else, S_true = S_iid; end
        Y_clean = M_true * S_true;                 % noise-free rates

        % scale so the mean spectrum carries PHOTONS photons per channel
        g = PHOTONS * N / sum(Y_clean(:)) * L;
        % Separate noise stream (as in E1); both arms have the same
        % mean photons per channel but independent measurement noise.
        rng(BASE_SEED + 10000 + 10*r + a, 'twister');
        Y_counts = poissrnd(g * Y_clean) + READ_SIG * randn(L, N);
        Y_in = double(Y_counts) / g;           % rate units

        % ---- per-arm trainer options (in-place parameter-pair edit) --
        args = base_args;                        % cell copy of E1 options
        args = e11_set_arg(args, 'PHOTON_GAIN', g);  % per-arm/run gain
        if strcmp(ARMS{a}, 'iid')
            % ========================================================
            % E11 i.i.d. arm (PISCO v34):
            %   LAMBDA_SPATIAL = 0 (no spatial correlation to exploit)
            %   LAMBDA_ENCLOSE = 10 (i.i.d. enclosure setting)
            % ========================================================
            args = e11_set_arg(args, 'LAMBDA_SPATIAL', 0);
            args = e11_set_arg(args, 'LAMBDA_ENCLOSE', 10);
        end
        % Check arm-specific hyperparameters before running PISCO.
        assert(e11_get_arg(args,'LAMBDA_SPATIAL') == LAM_SPATIAL(a), ...
            '%s arm: LAMBDA_SPATIAL must be %g', ARMS{a}, LAM_SPATIAL(a));
        assert(abs(e11_get_arg(args,'LAMBDA_ENCLOSE') - LAM_ENCLOSE(a)) < 1e-12, ...
            '%s arm: LAMBDA_ENCLOSE must be %g', ARMS{a}, LAM_ENCLOSE(a));

        % ---- PISCO (Poisson observation model) ----
        % Same PISCO initialization seed within a repeat, for a fairer
        % paired comparison between the two abundance-field regimes.
        rng(BASE_SEED + 100000 + 1000*r, 'twister');
        t_run = tic;
        [M_est, S_est] = deep_mvsa_invflow_poisson_explicit_Warmup(Y_in, p, args{:});
        T_m(a,r) = toc(t_run);

        % ---- metrics (identical to E1: e1_match / e1_metrics) ----
        [perm, ~] = e1_match(M_true, M_est);
        [SAD_m(a,r), MAB_m(a,r), MRC_m(a,r)] = ...
            e1_metrics(M_true, S_true, Y_clean, M_est, S_est, perm);

        fprintf(['run %2d/%d | %-10s | SAD %5.2f deg | MSE_ab %.3e | ' ...
            'MSE_rec %.3e | t %5.1fs\n'], r, N_RUNS, ARMS{a}, ...
            SAD_m(a,r), MAB_m(a,r), MRC_m(a,r), T_m(a,r));
        % CSV row: 7 fields matching the 7-column header above
        fprintf(fid, '%s,%d,%d,%.4f,%.6e,%.6e,%.2f\n', ARMS{a}, r, ...
            PHOTONS, SAD_m(a,r), MAB_m(a,r), MRC_m(a,r), T_m(a,r));

        % keep run 1 of each arm for the abundance-map figure
        if r == 1
            rep_S_true{a} = S_true; rep_S_est{a} = S_est;
            rep_perm{a} = perm;
            if a == nA, rep_done = true; end
        end
    end
end
fclose(fid);
fprintf('Per-run results written to %s (%d rows x 7 columns)\n', ...
    OUT_CSV, nA * N_RUNS);

%% E11.4 Summary (mean +/- std per arm) -----------------------------------
fprintf('\n===== E11 SUMMARY over %d paired repeats (PISCO only) =====\n', ...
    N_RUNS);
fprintf(['arm        | lambda_spatial | SAD (deg) mean+/-std | ' ...
    'MSE_ab mean+/-std | MSE_rec mean+/-std | time (s) mean+/-std\n']);
for a = 1:nA
    fprintf('%-10s | %14d | %6.2f +/- %5.2f      | %9.3e +/- %8.2e | %9.3e +/- %8.2e | %6.1f +/- %5.1f\n', ...
        ARMS{a}, LAM_SPATIAL(a), ...
        mean(SAD_m(a,:)), std(SAD_m(a,:)), ...
        mean(MAB_m(a,:)), std(MAB_m(a,:)), ...
        mean(MRC_m(a,:)), std(MRC_m(a,:)), ...
        mean(T_m(a,:)),   std(T_m(a,:)));
end
fprintf(['Reading: if PISCO remains accurate on the iid arm, the ' ...
    'spatial term is a gain, not a crutch (E11 goal 1); the structured-\n' ...
    'arm improvement over the iid arm (if any) is the reverse ' ...
    'validation of pillar P1 (E11 goal 2).\n']);

%% E11.5 Figures ----------------------------------------------------------
% (1) two-arm grouped comparison: SAD_deg and MSE_ab (1x2 subplots)
arm_cols = [0.55 0.27 0.07; 0.12 0.47 0.71];   % structured / iid
jit = linspace(-0.06, 0.06, N_RUNS);           % deterministic jitter
figure('Name','E11: structured vs iid arms', ...
    'Position',[50 50 950 400], 'Color','w');
subplot(1,2,1); hold on;
mb = mean(SAD_m,2); sb = std(SAD_m,0,2);
for a = 1:nA
    bar(a, mb(a), 0.55, 'FaceColor', arm_cols(a,:), ...
        'EdgeColor','k', 'FaceAlpha',0.55);
end
errorbar(1:nA, mb, sb, 'k.', 'LineWidth',1.2);
for a = 1:nA
    plot(a + jit, SAD_m(a,:), 'k.', 'MarkerSize',9);
end
set(gca,'XTick',1:nA,'XTickLabel',ARMS); ylabel('Endmember SAD (deg)');
title(sprintf('Spectral fidelity (n = %d paired runs)', N_RUNS));
grid on; xlim([0.4 nA+0.6]);
subplot(1,2,2); hold on;
mb = mean(MAB_m,2); sb = std(MAB_m,0,2);
for a = 1:nA
    bar(a, mb(a), 0.55, 'FaceColor', arm_cols(a,:), ...
        'EdgeColor','k', 'FaceAlpha',0.55);
end
errorbar(1:nA, mb, sb, 'k.', 'LineWidth',1.2);
for a = 1:nA
    plot(a + jit, MAB_m(a,:), 'k.', 'MarkerSize',9);
end
set(gca,'XTick',1:nA,'XTickLabel',ARMS); ylabel('Abundance MSE');
title('Abundance accuracy'); grid on; xlim([0.4 nA+0.6]);
sgtitle(sprintf(['E11: abundance-field structure control, ' ...
    '%d mean photons/channel (bar = mean, whisker = std)'], PHOTONS));
exportgraphics(gcf, 'pisco_E11_fig1_arms.png', 'Resolution',150);
fprintf('Figure written to pisco_E11_fig1_arms.png\n');

% (2) run-1 abundance maps: 4 rows (arm x {GT, estimate}) x 4 endmembers
if rep_done
    rowlab = {'structured GT', 'structured PISCO', ...
              'iid GT',        'iid PISCO'};
    figure('Name','E11: abundance maps (run 1)', ...
        'Position',[20 20 1250 800], 'Color','w');
    for a = 1:nA
        Sp = rep_S_est{a}(rep_perm{a},:);   % permuted to GT order
        for i = 1:p
            subplot(2*nA, p, (2*a-2)*p + i);
            imagesc(reshape(rep_S_true{a}(i,:),IMG_H,IMG_W));
            caxis([0 1]); axis image off; colorbar;
            title(sprintf('%s %s', rowlab{2*a-1}, endmember_names{i}));
            subplot(2*nA, p, (2*a-1)*p + i);
            imagesc(reshape(Sp(i,:),IMG_H,IMG_W));
            caxis([0 1]); axis image off; colorbar;
            title(sprintf('%s %s', rowlab{2*a}, endmember_names{i}));
        end
    end
    sgtitle(sprintf(['E11 abundance maps, run 1, %d mean photons/channel ' ...
        '(shared colour scale [0 1]; purity cap 0.8 in both arms)'], ...
        PHOTONS));
    exportgraphics(gcf, 'pisco_E11_fig2_maps.png', 'Resolution',150);
    fprintf('Figure written to pisco_E11_fig2_maps.png\n');
end

%% ==================== local functions ================================
function [perm, sad_v] = e1_match(M_true, M_est)
% Greedy permutation matching by spectral angle distance.
p = size(M_true, 2);
Cmat = zeros(p);
for i = 1:p
    for j = 1:p
        Cmat(i,j) = acosd(max(-1, min(1, ...
            (M_true(:,i)'*M_est(:,j)) / ...
            (norm(M_true(:,i))*norm(M_est(:,j))))));
    end
end
perm = zeros(1,p); taken = false(1,p);
for i = 1:p
    [~,jj] = min(Cmat(i,:) + taken*1e6); perm(i) = jj; taken(jj) = true;
end
sad_v = Cmat(sub2ind([p p], 1:p, perm));
end

function [sad, mse_ab, mse_rec] = e1_metrics(M_true, S_true, Y_clean, ...
    M_est, S_est, perm)
[~, sad_v] = e1_match(M_true, M_est);
sad     = mean(sad_v);
mse_ab  = mean((S_true(:) - reshape(S_est(perm,:), [], 1)).^2);
mse_rec = mean((Y_clean(:) - reshape(M_est*S_est, [], 1)).^2);
end

function args = e11_set_arg(args, name, value)
%E11_SET_ARG In-place value edit of a parameter/value-pair cell list.
% Parameter names sit at odd positions, values at even positions.
idx = find(strcmp(args(1:2:end), name), 1);
assert(~isempty(idx), 'e11_set_arg: parameter %s not found', name);
args{2*idx} = value;
end

function v = e11_get_arg(args, name)
%E11_GET_ARG Read a value from a parameter/value-pair cell list.
idx = find(strcmp(args(1:2:end), name), 1);
assert(~isempty(idx), 'e11_get_arg: parameter %s not found', name);
v = args{2*idx};
end
