function [M_est, S_est, info] = pisco_e2_train(Y, p, varargin)
%% PISCO_E2_TRAIN -- PISCO with tile-minibatch training for large fields
%  (E2 scalability experiment: Fig. 3a-c / SI Note 4 / Suppl. Table 6 /
%  Suppl. Fig. 7).
%
%  Identical model and hyperparameters as deep_mvsa_invflow_poisson.m v0.9
%  (Poisson chance constraints, margin annealing ETA->ETA_END, band-space
%  endmember non-negativity LAMBDA_MNONNEG, spectral smoothness
%  LAMBDA_SMOOTH, Fourier-feature A-Net, invertible Q = L*Q0*R), with two
%  scalability changes:
%
%    (1) TILE-MINIBATCH TRAINING. Each Adam iteration draws one random
%        TILE x TILE pixel patch (default 256 x 256). Pixel-sum penalties
%        (non-negativity, sum-to-one, enclosure) are rescaled by N/B
%        (B = TILE^2) so the objective matches the full-batch v0.9 scale;
%        the reconstruction term stays a per-pixel mean and the spatial
%        4-neighbour Laplacian is computed inside the tile (mean over B).
%        All working arrays per iteration are O(B) = independent of N,
%        which is exactly the mechanism behind the constant-memory claim
%        (SI Note 1.4: per-iteration activation memory O(B*p + p^2)).
%        Convergence validated against the full-batch implementation
%        (Python prototype, identical scene/noise/init): SAD equal within
%        ~1 deg at 64x64/tile 32; tile arm ~5x faster per iteration.
%        Set TILE >= min(IMG_H,IMG_W) to recover exact full-batch v0.9.
%
%    (2) CHUNKED PREPROCESSING / INFERENCE. The spherized working data Ys,
%        the propagated variance map Vpix and the final abundance render
%        are built in column chunks (CHUNK, default 1e5), so peak memory
%        stays base + O(N*p) data + O(B*hidden) activations. The raw cube
%        Y (L x N) is read once and never duplicated.
%
%  Inputs:
%    Y : L x N observation (rate units, as in demo_pisco_vs_deeprmvsa.m)
%    p : endmember number
%  Parameters (defaults = manuscript Table 1 / v0.9):
%    MM_ITERS 2500 | WARM_UP 600 | LR 3e-4 | LAMBDA_VOL 0.008 |
%    LAMBDA_NONNEG 3 | LAMBDA_EQ 100 | LAMBDA_SUMONE 2 | LAMBDA_ENCLOSE 10 |
%    LAMBDA_SPATIAL 2 | LAMBDA_MNONNEG 10 | LAMBDA_SMOOTH 0.1 |
%    ETA 0.1 | ETA_END 0.5 | SIGMA_CAP 0.03 | PHOTON_GAIN 1 |
%    PHOTON_FLOOR 1 | READ_SIGMA 0 | FF_K 6 | TILE 256 | CHUNK 1e5 |
%    IMG_H, IMG_W (required) | LOSS_EVERY 50 | verbose 1
%
%  Outputs:
%    M_est : L x p endmembers (band space, non-negative)
%    S_est : p x N abundances (full field, rendered in chunks)
%    info  : struct with per-phase wall times (t_pre/t_warm/t_joint/
%            t_infer, seconds), loss trace, TILE, B, N
%
%  Requires VCA.m on the path (same as previous demos).
%  MATLAB R2023a. Code version: v1.0-E2 (2026-09-22).

pStruct = inputParser;
addParameter(pStruct, 'MM_ITERS', 2500, @isnumeric);
addParameter(pStruct, 'WARM_UP', 600, @isnumeric);
addParameter(pStruct, 'LR', 3e-4, @isnumeric);
addParameter(pStruct, 'LAMBDA_VOL', 0.008, @isnumeric);
addParameter(pStruct, 'LAMBDA_NONNEG', 3, @isnumeric);
addParameter(pStruct, 'LAMBDA_EQ', 100, @isnumeric);
addParameter(pStruct, 'LAMBDA_SUMONE', 2, @isnumeric);
addParameter(pStruct, 'LAMBDA_ENCLOSE', 10, @isnumeric);
addParameter(pStruct, 'LAMBDA_SPATIAL', 2, @isnumeric);
addParameter(pStruct, 'LAMBDA_MNONNEG', 10, @isnumeric);
addParameter(pStruct, 'LAMBDA_SMOOTH', 0.1, @isnumeric);
addParameter(pStruct, 'ETA', 0.1, @isnumeric);
addParameter(pStruct, 'ETA_END', 0.5, @isnumeric);
addParameter(pStruct, 'SIGMA_CAP', 0.03, @isnumeric);
addParameter(pStruct, 'PHOTON_GAIN', 1, @isnumeric);
addParameter(pStruct, 'PHOTON_FLOOR', 1, @isnumeric);
addParameter(pStruct, 'READ_SIGMA', 0, @isnumeric);
addParameter(pStruct, 'FF_K', 6, @isnumeric);
addParameter(pStruct, 'TILE', 256, @isnumeric);
addParameter(pStruct, 'CHUNK', 1e5, @isnumeric);
addParameter(pStruct, 'IMG_H', [], @isnumeric);
addParameter(pStruct, 'IMG_W', [], @isnumeric);
addParameter(pStruct, 'LOSS_EVERY', 50, @isnumeric);
addParameter(pStruct, 'verbose', 1, @isnumeric);
parse(pStruct, varargin{:});
R = pStruct.Results;

[L, N] = size(Y);
H_img = R.IMG_H; W_img = R.IMG_W;
if isempty(H_img) || isempty(W_img) || H_img*W_img ~= N
    error('pisco_e2_train: IMG_H x IMG_W must equal N (%d).', N);
end
gain = R.PHOTON_GAIN;
rs2  = (R.READ_SIGMA/gain)^2;

T = min(R.TILE, min(H_img, W_img));
full_batch = (T >= min(H_img, W_img));
if full_batch, T = min(H_img, W_img); end
B = T*T;
nb_scale = N/B;                     % rescale pixel-sum penalties (v1.0-E2)

%% --------------------- Preprocessing (chunked) ---------------------
t0 = tic;
my = mean(Y, 2);
Cy = (Y*Y')/N - my*my';              % signal covariance, no Yc duplicate
[Up1, D] = svds(Cy, p-1);
lam = 1e-10;
Cm = diag(1./sqrt(diag(D + lam*eye(p-1))));

Ys = zeros(p, N);                    % spherized working data, p x N
ck = R.CHUNK;
for s = 1:ck:N
    ci = s:min(s+ck-1, N);
    Ys(1:p-1, ci) = Cm*(Up1'*(Y(:,ci) - my));
end
Ys(p,:) = 1; Ys = Ys/sqrt(p);

% Poisson variance propagation (mixed Poisson + read noise)
Bop = [Cm*Up1'; zeros(1,L)]/sqrt(p);
B2  = Bop.^2;
Vpix = zeros(p, N);
for s = 1:ck:N
    ci = s:min(s+ck-1, N);
    VarY = max(Y(:,ci), R.PHOTON_FLOOR/gain)/gain + rs2;
    Vpix(:,ci) = B2*VarY;
end
med_v = median(Vpix(Vpix > 0));
Vpix(Vpix <= 0) = med_v;
Vpix = max(Vpix, 1e-3*med_v);

% lift context for band-space endmember priors (spherized mode)
lift_ctx.Up_sub = Up1;
lift_ctx.sD     = sqrt(diag(D + lam*eye(p-1)));
lift_ctx.my     = my;
lift_ctx.sqp    = sqrt(p);

M0 = VCA(Ys, 'Endmembers', p, 'verbose', 'off');
Q0 = inv(M0);
qm = sum(Ys,2)'*inv(Ys*Ys');         % = ones(1,N)*Ys'*inv(Ys*Ys')

% 2-D coordinates (Fourier encoding computed per tile, on the fly)
[gx, gy] = meshgrid(linspace(-1,1,W_img), linspace(-1,1,H_img));
coords2 = [gx(:)'; gy(:)'];          % 2 x N
if R.FF_K > 0
    freqs = (2.^(0:R.FF_K-1)) * pi;  % 1 x K
else
    freqs = [];
end
info.t_pre = toc(t0);

%% --------------------- Parameters (as v0.9) ---------------------
hidden = 32;
cd_ = 2*(1 + 2*R.FF_K);              % FF-encoded coordinate dimension
theta.W1 = 0.05*randn(hidden, cd_);  theta.b1 = zeros(hidden,1);
theta.W2 = 0.05*randn(hidden, hidden); theta.b2 = zeros(hidden,1);
theta.W3 = 0.05*randn(p, hidden);    theta.b3 = zeros(p,1);
theta.Wg1 = 0.05*randn(hidden, cd_); theta.bg1 = zeros(hidden,1);
theta.Wg2 = 0.05*randn(p, hidden);   theta.bg2 = zeros(p,1);
theta.c = 0.05;
theta.L = zeros(p,p); theta.R = zeros(p,p); theta.r_log = zeros(p,1);

m_adam = init_adam_e2(theta);
v_adam = init_adam_e2(theta);
iter = 0;
loss_trace = zeros(ceil(R.MM_ITERS/max(R.LOSS_EVERY,1)), 2);
n_tr = 0;

if full_batch
    idx_full = (1:N)';
else
    idx_full = [];
end

%% --------------------- Warm-up (Q fixed at Q0) ---------------------
t0 = tic;
phi_const = -sqrt(2)*erfcinv(2*R.ETA);
for k = 1:R.WARM_UP
    idx = draw_tile(full_batch, idx_full, H_img, W_img, T);
    [loss, grad] = grad_tile(theta, Ys(:,idx), Vpix(:,idx), ...
        coords2(:,idx), freqs, Q0, qm, p, B, nb_scale, ...
        0, R.LAMBDA_NONNEG, R.LAMBDA_EQ, R.LAMBDA_SUMONE, ...
        R.LAMBDA_ENCLOSE, R.LAMBDA_SPATIAL, T, true, ...
        phi_const, R.SIGMA_CAP, R.LAMBDA_MNONNEG, R.LAMBDA_SMOOTH, lift_ctx);
    [theta, m_adam, v_adam] = adam_update_e2(theta, grad, m_adam, v_adam, iter+1, R.LR);
    iter = iter + 1;
    if R.LOSS_EVERY > 0 && mod(k, R.LOSS_EVERY) == 0
        n_tr = n_tr + 1; loss_trace(n_tr,:) = [iter, loss];
    end
    if R.verbose && mod(k,200)==0
        fprintf('  warm-up %d/%d, loss=%.5f\n', k, R.WARM_UP, loss);
    end
end
info.t_warm = toc(t0);

%% --------------------- Joint phase (margin annealing) ---------------------
t0 = tic;
n_joint = R.MM_ITERS - R.WARM_UP;
for k = 1:n_joint
    prog  = (k-1)/max(1, n_joint-1);
    eta_t = min(max(R.ETA + (R.ETA_END-R.ETA)*prog, 1e-6), 1-1e-6);
    phi_t = -sqrt(2)*erfcinv(2*eta_t);
    idx = draw_tile(full_batch, idx_full, H_img, W_img, T);
    [loss, grad] = grad_tile(theta, Ys(:,idx), Vpix(:,idx), ...
        coords2(:,idx), freqs, Q0, qm, p, B, nb_scale, ...
        R.LAMBDA_VOL, R.LAMBDA_NONNEG, R.LAMBDA_EQ, R.LAMBDA_SUMONE, ...
        R.LAMBDA_ENCLOSE, R.LAMBDA_SPATIAL, T, false, ...
        phi_t, R.SIGMA_CAP, R.LAMBDA_MNONNEG, R.LAMBDA_SMOOTH, lift_ctx);
    [theta, m_adam, v_adam] = adam_update_e2(theta, grad, m_adam, v_adam, iter+1, R.LR);
    iter = iter + 1;
    if R.LOSS_EVERY > 0 && mod(R.WARM_UP+k, R.LOSS_EVERY) == 0
        n_tr = n_tr + 1; loss_trace(n_tr,:) = [iter, loss];
    end
    if R.verbose && mod(k,500)==0
        fprintf('  joint %d/%d, loss=%.5f, c=%.4f\n', k, n_joint, loss, theta.c);
    end
end
info.t_joint = toc(t0);

%% --------------------- Recover endmembers + full-field render ---------------------
t0 = tic;
L_mat = eye(p) + tril(theta.L,-1);
R_mat = diag(exp(theta.r_log)) + triu(theta.R,1);
Q = L_mat*Q0*R_mat;
M_sub = inv(Q)*sqrt(p);
M_sub = M_sub(1:p-1,:);
M_est = Up1*diag(lift_ctx.sD)*M_sub + repmat(my,1,p);
M_est = max(M_est, 0);               % physical non-negativity projection

S_est = zeros(p, N);
for s = 1:ck:N
    ci = s:min(s+ck-1, N);
    enc = ff_encode(coords2(:,ci), freqs);
    S_est(:,ci) = anet_forward(theta, enc, false);
end
info.t_infer = toc(t0);

info.loss_trace = loss_trace(1:n_tr,:);
info.TILE = T; info.B = B; info.N = N; info.full_batch = full_batch;
end

%% ===================== sub-functions =====================
function idx = draw_tile(full_batch, idx_full, H, W, T)
if full_batch
    idx = idx_full;
else
    r0 = randi(H-T+1); c0 = randi(W-T+1);
    [cc, rr] = meshgrid(c0:c0+T-1, r0:r0+T-1);
    idx = (cc(:)-1)*H + rr(:);       % column-major, row index fastest
end
end

function enc = ff_encode(co2, freqs)
% [t, sin(2^k pi t), cos(2^k pi t)] per axis, as in v0.9
if isempty(freqs)
    enc = co2; return;
end
d0 = size(co2,1); K = numel(freqs); n = size(co2,2);
enc = zeros(d0*(1+2*K), n);
r = 1;
for d = 1:d0
    t = co2(d,:);
    enc(r,:) = t;                       r = r+1;
    enc(r:r+K-1,:) = sin(t'*freqs).';   r = r+K;
    enc(r:r+K-1,:) = cos(t'*freqs).';   r = r+K;
end
end

function [A_eff, cache] = anet_forward(theta, enc, warm_up)
Z1 = theta.W1*enc + theta.b1;  H1 = tanh(Z1);
Z2 = theta.W2*H1 + theta.b2;   H2 = tanh(Z2);
Z3 = theta.W3*H2 + theta.b3;
Z3 = Z3 - max(Z3,[],1); expZ = exp(Z3);
A_base = expZ ./ sum(expZ,1);
Zg1 = theta.Wg1*enc + theta.bg1; Hg1 = tanh(Zg1);
Zg2 = theta.Wg2*Hg1 + theta.bg2;
G = 1./(1+exp(-Zg2));
c = (1-double(warm_up))*theta.c;
A_eff = A_base + c*(G.*(A_base.^2));
cache.Z1=Z1; cache.H1=H1; cache.Z2=Z2; cache.H2=H2;
cache.expZ=expZ; cache.enc=enc;
cache.Zg1=Zg1; cache.Hg1=Hg1; cache.Zg2=Zg2; cache.G=G;
cache.A_base=A_base; cache.c=c; cache.warm_up=warm_up;
end

function grad = anet_backward(dA_eff, cache, theta)
A_base = cache.A_base; G = cache.G; c = cache.c;
dA_base = dA_eff + 2*c*G.*A_base.*dA_eff;
dG = c*(A_base.^2).*dA_eff;
if cache.warm_up
    grad.Wg1 = zeros(size(theta.Wg1)); grad.bg1 = zeros(size(theta.bg1));
    grad.Wg2 = zeros(size(theta.Wg2)); grad.bg2 = zeros(size(theta.bg2));
    grad.c = 0;
else
    dZg2 = dG.*(G.*(1-G));
    grad.Wg2 = dZg2*cache.Hg1'; grad.bg2 = sum(dZg2,2);
    dHg1 = theta.Wg2'*dZg2;
    dZg1 = dHg1.*(1-tanh(cache.Zg1).^2);
    grad.Wg1 = dZg1*cache.enc'; grad.bg1 = sum(dZg1,2);
    grad.c = sum(sum((G.*(A_base.^2)).*dA_eff));
end
A = cache.expZ ./ sum(cache.expZ,1);
dZ3 = A.*(dA_base - sum(A.*dA_base,1));
grad.W3 = dZ3*cache.H2'; grad.b3 = sum(dZ3,2);
dH2 = theta.W3'*dZ3;
dZ2 = dH2.*(1-tanh(cache.Z2).^2);
grad.W2 = dZ2*cache.H1'; grad.b2 = sum(dZ2,2);
dH1 = theta.W2'*dZ2;
dZ1 = dH1.*(1-tanh(cache.Z1).^2);
grad.W1 = dZ1*cache.enc'; grad.b1 = sum(dZ1,2);
end

function [loss, grad] = grad_tile(theta, Yt, Vt, co2, freqs, Q0, qm, p, ...
    B, nb_scale, lambda_vol, lambda_nonneg, lambda_eq, lambda_sumone, ...
    lambda_enclose, lambda_spatial, T, warm_up, phi_t, sigma_cap, ...
    lambda_mnn, lambda_smooth, lift_ctx)
% One Adam step's loss+gradient on a tile (B pixels). Pixel-sum penalties
% scaled by nb_scale = N/B to match the full-batch objective scale.
L_mat = eye(p) + tril(theta.L,-1);
R_mat = diag(exp(theta.r_log)) + triu(theta.R,1);
Q = L_mat*Q0*R_mat;
M = inv(Q);

enc = ff_encode(co2, freqs);
[A_eff, cache] = anet_forward(theta, enc, warm_up);

diff = M*A_eff - Yt;
loss_recon = mean(sum(diff.^2,1));

loss_vol = -sum(theta.r_log);

sigma2 = (Q.^2)*Vt + 1e-12;
margin = phi_t*min(sqrt(sigma2), sigma_cap);   % <= 0, stop-grad

pen = min(A_eff,0);
loss_nonneg = nb_scale*sum(pen.^2,'all');
sum_A = sum(A_eff,1);
loss_sumone = nb_scale*sum((sum_A-1).^2,'all');

col_sums = sum(Q,1);
loss_eq = sum((col_sums-qm).^2,'all');

QY = Q*Yt;
penc = min(QY-margin,0);
loss_enclose = nb_scale*sum(penc.^2,'all');

loss_spatial = 0;
if lambda_spatial > 0
    A3 = reshape(A_eff, p, T, T);
    Dh = A3(:,2:end,:) - A3(:,1:end-1,:);
    Dw = A3(:,:,2:end) - A3(:,:,1:end-1);
    loss_spatial = (sum(Dh.^2,'all') + sum(Dw.^2,'all'))/B;
end

loss = loss_recon + lambda_vol*loss_vol + lambda_nonneg*loss_nonneg + ...
    lambda_sumone*loss_sumone + lambda_eq*loss_eq + ...
    lambda_enclose*loss_enclose + lambda_spatial*loss_spatial;

dY_hat = 2*diff/B;
dM = dY_hat*A_eff';

% band-space endmember priors (global terms, exact gradient)
if (lambda_mnn > 0 || lambda_smooth > 0)
    M_band = lift_ctx.Up_sub*(lift_ctx.sD.*(lift_ctx.sqp*M(1:p-1,:))) + lift_ctx.my;
    dM_band = zeros(size(M_band));
    if lambda_mnn > 0
        pen_M = min(M_band,0);
        loss = loss + lambda_mnn*sum(pen_M.^2,'all');
        dM_band = dM_band + 2*lambda_mnn*pen_M;
    end
    if lambda_smooth > 0
        D2M = M_band(3:end,:) - 2*M_band(2:end-1,:) + M_band(1:end-2,:);
        loss = loss + lambda_smooth*sum(D2M.^2,'all');
        g2 = zeros(size(M_band));
        g2(3:end,:)   = g2(3:end,:)   + 2*lambda_smooth*D2M;
        g2(2:end-1,:) = g2(2:end-1,:) - 4*lambda_smooth*D2M;
        g2(1:end-2,:) = g2(1:end-2,:) + 2*lambda_smooth*D2M;
        dM_band = dM_band + g2;
    end
    gmnn = zeros(p,p);
    gmnn(1:p-1,:) = lift_ctx.sqp*(lift_ctx.sD.*(lift_ctx.Up_sub'*dM_band));
    dM = dM + gmnn;
end

grad_Q = -M'*dM*M' + lambda_eq*2*repmat(col_sums-qm,p,1) + ...
    lambda_enclose*nb_scale*2*(penc*Yt');
grad_L_mat = grad_Q*R_mat'*Q0';
grad_R_mat = Q0'*L_mat'*grad_Q;
grad.L = tril(grad_L_mat,-1);
grad.R = triu(grad_R_mat,1);
grad.r_log = diag(grad_R_mat).*exp(theta.r_log) - lambda_vol;

dA_eff = M'*dY_hat + 2*lambda_nonneg*nb_scale*pen + ...
    2*lambda_sumone*nb_scale*repmat(sum_A-1,p,1);
if lambda_spatial > 0
    G3 = zeros(p,T,T);
    G3(:,1:end-1,:) = G3(:,1:end-1,:) - Dh;
    G3(:,2:end,:)   = G3(:,2:end,:)   + Dh;
    G3(:,:,1:end-1) = G3(:,:,1:end-1) - Dw;
    G3(:,:,2:end)   = G3(:,:,2:end)   + Dw;
    dA_eff = dA_eff + 2*lambda_spatial*reshape(G3,p,B)/B;
end

grad_net = anet_backward(dA_eff, cache, theta);
grad.W1=grad_net.W1; grad.b1=grad_net.b1;
grad.W2=grad_net.W2; grad.b2=grad_net.b2;
grad.W3=grad_net.W3; grad.b3=grad_net.b3;
grad.Wg1=grad_net.Wg1; grad.bg1=grad_net.bg1;
grad.Wg2=grad_net.Wg2; grad.bg2=grad_net.bg2;
grad.c=grad_net.c;
end

function adam = init_adam_e2(theta)
fields = fieldnames(theta);
adam = struct();
for i = 1:numel(fields)
    adam.(fields{i}) = zeros(size(theta.(fields{i})));
end
end

function [theta, m, v] = adam_update_e2(theta, grad, m, v, iter, lr)
beta1 = 0.9; beta2 = 0.999; eps = 1e-8;
fields = fieldnames(theta);
for i = 1:numel(fields)
    f = fields{i};
    m.(f) = beta1*m.(f) + (1-beta1)*grad.(f);
    v.(f) = beta2*v.(f) + (1-beta2)*grad.(f).^2;
    m_hat = m.(f)/(1-beta1^iter);
    v_hat = v.(f)/(1-beta2^iter);
    theta.(f) = theta.(f) - lr*m_hat./(sqrt(v_hat)+eps);
end
end
