function [M,S,info] = nmf_lee_seung_euclidean(Y,p,varargin)
%NMF_LEE_SEUNG_EUCLIDEAN Standard Euclidean NMF with Lee-Seung updates.
%
%   [M,S,info] = nmf_lee_seung_euclidean(Y,p,...)
%
% Solves
%       min_{M>=0,S>=0} 0.5*||Y-M*S||_F^2
%
% Multiplicative updates:
%       S <- S .* (M'*Y) ./ (M'*M*S + eps)
%       M <- M .* (Y*S') ./ (M*S*S' + eps)
%
% References:
% Lee & Seung, Nature 401, 788-791 (1999).
% Lee & Seung, NIPS 13 (2001), Algorithms for NMF.
%
% This is STANDARD NMF:
%   no sparsity penalty, no spatial regularization, no sum-to-one
%   constraint, no minimum-volume regularization.
%
% Inputs:
%   Y : L x N nonnegative matrix
%   p : number of components
%
% Options:
%   'M0'         initial L x p nonnegative factor
%   'S0'         initial p x N nonnegative factor
%   'MaxIter'    default 2000
%   'MinIter'    default 100
%   'TolRelObj'  default 1e-7
%   'CheckEvery' default 20
%   'Floor'      default 1e-12
%   'NormalizeM' 'max' (default) or 'none'
%   'Verbose'    false (default)
%
% With NormalizeM='max', each column of M is peak-normalized and the
% inverse scale is transferred to S, so M*S is unchanged. This resolves
% NMF scale ambiguity consistently with the peak-normalized fluorescence
% spectra used in the current PISCO E1 experiment.
%
% The function intentionally does NOT force sum(S(:,j))=1.

ip = inputParser;
ip.FunctionName = 'nmf_lee_seung_euclidean';

addParameter(ip,'M0',[],@(x) isempty(x) || isnumeric(x));
addParameter(ip,'S0',[],@(x) isempty(x) || isnumeric(x));
addParameter(ip,'MaxIter',2000,@(x) isnumeric(x) && isscalar(x) && x>=1 && x==round(x));
addParameter(ip,'MinIter',100,@(x) isnumeric(x) && isscalar(x) && x>=0 && x==round(x));
addParameter(ip,'TolRelObj',1e-7,@(x) isnumeric(x) && isscalar(x) && x>=0);
addParameter(ip,'CheckEvery',20,@(x) isnumeric(x) && isscalar(x) && x>=1 && x==round(x));
addParameter(ip,'Floor',1e-12,@(x) isnumeric(x) && isscalar(x) && x>0);
addParameter(ip,'NormalizeM','max',@(x) ischar(x) || (isstring(x) && isscalar(x)));
addParameter(ip,'Verbose',false,@(x) islogical(x) && isscalar(x));

parse(ip,varargin{:});

M0 = ip.Results.M0;
S0 = ip.Results.S0;
max_iter = double(ip.Results.MaxIter);
min_iter = double(ip.Results.MinIter);
tol_rel_obj = double(ip.Results.TolRelObj);
check_every = double(ip.Results.CheckEvery);
floor_val = double(ip.Results.Floor);
normalize_m = lower(char(ip.Results.NormalizeM));
verbose = ip.Results.Verbose;

if ~ismember(normalize_m,{'max','none'})
    error('NormalizeM must be ''max'' or ''none''.');
end

if ~isnumeric(Y) || ~ismatrix(Y) || isempty(Y)
    error('Y must be a nonempty numeric L x N matrix.');
end

Y = double(Y);

if any(~isfinite(Y(:)))
    error('Y contains NaN or Inf.');
end

if any(Y(:) < 0)
    error(['Standard NMF requires nonnegative input. ' ...
           'For PISCO E1 mixed-noise data use Y_NMF = max(Y_in,0).']);
end

[L,N] = size(Y);

if ~isscalar(p) || p<1 || p>min(L,N) || p~=round(p)
    error('p must be an integer between 1 and min(L,N).');
end

if isempty(M0)
    M = rand(L,p) + 0.1;
else
    M = double(M0);
    if ~isequal(size(M),[L,p])
        error('M0 must have size %d x %d.',L,p);
    end
    if any(~isfinite(M(:))) || any(M(:)<0)
        error('M0 must contain finite nonnegative values.');
    end
    M = max(M,floor_val);
end

if isempty(S0)
    S = pinv(M) * Y;
    S = max(S,floor_val);
else
    S = double(S0);
    if ~isequal(size(S),[p,N])
        error('S0 must have size %d x %d.',p,N);
    end
    if any(~isfinite(S(:))) || any(S(:)<0)
        error('S0 must contain finite nonnegative values.');
    end
    S = max(S,floor_val);
end

if strcmp(normalize_m,'max')
    [M,S] = normalize_M_peak_preserve_product(M,S,floor_val);
end

Yhat = M*S;
obj_prev = 0.5 * sum((Y(:)-Yhat(:)).^2);

if ~isfinite(obj_prev)
    error('Initial NMF objective is not finite.');
end

n_checks = ceil(max_iter/check_every) + 2;
obj_hist = nan(n_checks,1);
iter_hist = nan(n_checks,1);

check_id = 1;
obj_hist(check_id) = obj_prev;
iter_hist(check_id) = 0;

converged = false;
rel_change = Inf;

for it = 1:max_iter

    numer_S = M' * Y;
    denom_S = (M' * M) * S;

    S = S .* (numer_S ./ max(denom_S,floor_val));
    S = max(S,floor_val);

    numer_M = Y * S';
    denom_M = M * (S * S');

    M = M .* (numer_M ./ max(denom_M,floor_val));
    M = max(M,floor_val);

    if strcmp(normalize_m,'max')
        [M,S] = normalize_M_peak_preserve_product(M,S,floor_val);
    end

    do_check = (mod(it,check_every)==0) || (it==max_iter);

    if do_check
        Yhat = M*S;
        obj = 0.5 * sum((Y(:)-Yhat(:)).^2);

        if ~isfinite(obj)
            error('NMF objective became nonfinite at iteration %d.',it);
        end

        rel_change = abs(obj_prev-obj) / max(abs(obj_prev),floor_val);

        check_id = check_id + 1;
        obj_hist(check_id) = obj;
        iter_hist(check_id) = it;

        if verbose
            fprintf('NMF iter %5d | objective %.8e | rel.change %.3e\n', ...
                it,obj,rel_change);
        end

        if it >= min_iter && rel_change <= tol_rel_obj
            converged = true;
            obj_prev = obj;
            break;
        end

        obj_prev = obj;
    end
end

Yhat = M*S;
final_obj = 0.5 * sum((Y(:)-Yhat(:)).^2);
sumS = sum(S,1);

info = struct();
info.method = 'Standard Lee-Seung Euclidean NMF';
info.loss = '0.5*||Y-M*S||_F^2';
info.algorithm = 'multiplicative updates';
info.sparsity_constraint = false;
info.sum_to_one_constraint = false;
info.spatial_regularization = false;
info.min_volume_regularization = false;

info.iterations = it;
info.converged = converged;
info.final_objective = final_obj;
info.relative_objective_change = rel_change;

info.objective_history = obj_hist(1:check_id);
info.check_iterations = iter_hist(1:check_id);

info.normalize_M = normalize_m;
info.min_M = min(M(:));
info.min_S = min(S(:));

info.sumone_mae = mean(abs(sumS-1));
info.sumone_max_abs = max(abs(sumS-1));

info.max_iter = max_iter;
info.min_iter = min_iter;
info.tol_rel_obj = tol_rel_obj;
info.check_every = check_every;
info.floor = floor_val;

if verbose
    fprintf(['NMF finished | iter=%d | converged=%d | final objective=%.8e | ' ...
             'sum-to-one MAE=%.4e\n'], ...
        info.iterations,info.converged,info.final_objective,info.sumone_mae);
end

end


function [M,S] = normalize_M_peak_preserve_product(M,S,floor_val)
scale = max(M,[],1);
scale = max(scale,floor_val);

M = M ./ scale;
S = S .* scale(:);

M = max(M,floor_val);
S = max(S,floor_val);
end
