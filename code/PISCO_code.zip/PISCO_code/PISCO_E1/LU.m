function [R, I_unmixed, info] = LU(Y, M_ref, varargin)
%LU_HYU Pixel-by-pixel linear unmixing following the LU method described
%in Chiang et al., "HyU: Hybrid Unmixing for longitudinal in vivo imaging
%of low signal-to-noise fluorescence", Nature Methods 20, 248-258 (2023).
%
%   [R, I_unmixed, info] = LU_HyU(Y, M_ref)
%
% INPUTS
%   Y       : L x N measured hyperspectral data.
%   M_ref   : L x p PROVIDED reference spectral fingerprints.
%
% NAME-VALUE OPTIONS
%   'ReferenceNormalization'
%       'require-unit-sum' (default): require each reference spectrum to
%       sum to 1 within tolerance. Recommended for PISCO_M_32x4.mat.
%       'normalize': normalize each reference spectrum by its channel sum.
%
%   'ReferenceSumTolerance' : default 1e-8.
%
%   'ZeroPhotonPolicy'
%       'nan' (default): R(:,n)=NaN for all-zero spectra.
%       'uniform'      : R(:,n)=1/p for all-zero spectra.
%       'zero'         : R(:,n)=0 for all-zero spectra.
%
% OUTPUTS
%   R         : p x N component-ratio matrix. For nonzero-intensity pixels,
%               sum(R(:,n))=1 up to numerical precision. No non-negativity
%               constraint is imposed.
%   I_unmixed : p x N unmixed component-intensity matrix,
%               I_unmixed(:,n)=R(:,n)*sum(Y(:,n)).
%   info      : diagnostics.
%
% PAPER-CONSISTENT MODEL
%   I(lambda) = sum_i W_i R_i fp_i(lambda) + N,   sum_i R_i = 1.
% The paper assumes identical W_i and solves R_i by Jacobian matrix
% inversion. The resulting ratio cube is multiplied by the integral of
% intensity over the spectral-channel dimension.
%
% With unit-sum fingerprints and T_n=sum_l Y(l,n), define z_n=Y(:,n)/T_n.
% Using the last fingerprint as the dependent component,
%
%   z_n - m_p = [m_1-m_p, ..., m_{p-1}-m_p] * [R_1;...;R_{p-1}],
%   R_p = 1 - sum_{i=1}^{p-1} R_i.
%
% For equal channel weights, the Jacobian normal equations are
%
%   (J'J)a = J'(z_n-m_p).
%
% This function solves those equations with MATLAB backslash.
%
% IMPORTANT
%   1) This is standard LU as described in the HyU Methods, not NNLS/FCLS.
%      No R>=0 constraint is added.
%   2) This follows the published mathematical/Methods description. It is
%      not claimed to be bit-for-bit identical to unreleased author code.
%
% EXAMPLE
%   [S_LU, I_LU, info] = LU_HyU(Y, M_true);
%   valid = info.valid_pixel_mask;
%   mse_valid = mean((S_LU(:,valid)-S_true(:,valid)).^2, 'all');
%
% Reference:
%   Chiang HJ et al. Nature Methods 20, 248-258 (2023).
%   DOI: 10.1038/s41592-022-01751-5

%% Parse options
pIn = inputParser;
pIn.FunctionName = 'LU_HyU';
addParameter(pIn, 'ReferenceNormalization', 'require-unit-sum', ...
    @(x) ischar(x) || (isstring(x) && isscalar(x)));
addParameter(pIn, 'ReferenceSumTolerance', 1e-8, ...
    @(x) isnumeric(x) && isscalar(x) && isfinite(x) && x > 0);
addParameter(pIn, 'ZeroPhotonPolicy', 'nan', ...
    @(x) ischar(x) || (isstring(x) && isscalar(x)));
parse(pIn, varargin{:});

reference_normalization = lower(char(pIn.Results.ReferenceNormalization));
reference_sum_tolerance = double(pIn.Results.ReferenceSumTolerance);
zero_photon_policy      = lower(char(pIn.Results.ZeroPhotonPolicy));

if ~ismember(reference_normalization, {'require-unit-sum','normalize'})
    error('LU_HyU:BadReferenceNormalization', ...
        'ReferenceNormalization must be ''require-unit-sum'' or ''normalize''.');
end
if ~ismember(zero_photon_policy, {'nan','uniform','zero'})
    error('LU_HyU:BadZeroPhotonPolicy', ...
        'ZeroPhotonPolicy must be ''nan'', ''uniform'', or ''zero''.');
end

%% Validate inputs
if ~isnumeric(Y) || ~ismatrix(Y) || isempty(Y)
    error('LU_HyU:BadY', 'Y must be a nonempty numeric L x N matrix.');
end
if ~isnumeric(M_ref) || ~ismatrix(M_ref) || isempty(M_ref)
    error('LU_HyU:BadM', 'M_ref must be a nonempty numeric L x p matrix.');
end

Y = double(Y);
M_ref = double(M_ref);

if any(~isfinite(Y(:)))
    error('LU_HyU:NonfiniteY', 'Y contains NaN or Inf.');
end
if any(~isfinite(M_ref(:)))
    error('LU_HyU:NonfiniteM', 'M_ref contains NaN or Inf.');
end
if any(Y(:) < 0)
    error('LU_HyU:NegativeY', ...
        'Y contains negative values. This LU implementation expects nonnegative intensities.');
end
if any(M_ref(:) < 0)
    error('LU_HyU:NegativeM', ...
        'M_ref contains negative values. Reference fluorescence spectra must be nonnegative.');
end

[L, N] = size(Y);
[Lm, p] = size(M_ref);
if Lm ~= L
    error('LU_HyU:DimensionMismatch', ...
        'Y has %d channels but M_ref has %d rows.', L, Lm);
end
if p < 2
    error('LU_HyU:TooFewReferences', 'At least two reference spectra are required.');
end
if p > L
    error('LU_HyU:Underdetermined', ...
        ['Number of reference spectra p=%d exceeds channels L=%d. ' ...
         'The HyU paper states that the number of spectra must not exceed the number of acquired channels.'], ...
         p, L);
end

%% Reference spectral fingerprints
reference_sums_before = sum(M_ref, 1);
if any(reference_sums_before <= 0)
    error('LU_HyU:ZeroReference', ...
        'Every reference spectrum must have a strictly positive channel sum.');
end

switch reference_normalization
    case 'require-unit-sum'
        max_ref_sum_error = max(abs(reference_sums_before - 1));
        if max_ref_sum_error > reference_sum_tolerance
            error('LU_HyU:ReferenceNotUnitSum', ...
                ['Reference spectra must sum to 1 for the default ratio formulation. ' ...
                 'Maximum |sum(M_ref)-1| = %.3e. Either provide unit-sum spectra or use ' ...
                 '''ReferenceNormalization'',''normalize''.'], max_ref_sum_error);
        end
        M = M_ref;
    case 'normalize'
        M = M_ref ./ reference_sums_before;
end
reference_sums_after = sum(M,1);

%% Pixel total intensity
total_intensity = sum(Y, 1);
valid_pixel_mask = total_intensity > 0;
zero_pixel_mask  = ~valid_pixel_mask;
R = nan(p, N);

%% Jacobian inversion
% Last spectral fingerprint is the dependent/reference component.
m_base = M(:,p);
J = M(:,1:p-1) - m_base;       % L x (p-1)
JTJ = J' * J;                  % (p-1) x (p-1)

jac_rank = rank(J);
if jac_rank < (p-1)
    error('LU_HyU:RankDeficientReferences', ...
        ['Reference spectra are not linearly independent under the sum-to-one parameterization. ' ...
         'Jacobian rank = %d, required rank = %d.'], jac_rank, p-1);
end

if any(valid_pixel_mask)
    Y_valid = Y(:,valid_pixel_mask);
    T_valid = total_intensity(valid_pixel_mask);

    % Remove the common per-pixel intensity weight and fit spectral shape.
    Z = Y_valid ./ T_valid;
    D = Z - m_base;             % implicit expansion
    rhs = J' * D;

    % Equal-weight Jacobian normal equations, corresponding to Eq. (6).
    A = JTJ \ rhs;

    R(1:p-1,valid_pixel_mask) = A;
    R(p,valid_pixel_mask) = 1 - sum(A,1);
end

%% Zero-total-intensity pixels
% The paper does not specify this edge case, so the policy is explicit.
if any(zero_pixel_mask)
    switch zero_photon_policy
        case 'nan'
            R(:,zero_pixel_mask) = NaN;
        case 'uniform'
            R(:,zero_pixel_mask) = 1 / p;
        case 'zero'
            R(:,zero_pixel_mask) = 0;
    end
end

%% Final unmixed component intensities
% Paper: multiply ratios by the integral of intensity over channels.
I_unmixed = R .* total_intensity;
if strcmp(zero_photon_policy, 'nan') && any(zero_pixel_mask)
    I_unmixed(:,zero_pixel_mask) = 0;
end

%% Diagnostics
sum_R = sum(R(:,valid_pixel_mask),1);
if isempty(sum_R)
    max_sum_to_one_error = NaN;
    negative_ratio_fraction = NaN;
else
    max_sum_to_one_error = max(abs(sum_R - 1));
    negative_ratio_fraction = nnz(R(:,valid_pixel_mask) < 0) / ...
        numel(R(:,valid_pixel_mask));
end

info = struct();
info.method = 'HyU paper-described pixel-by-pixel LU';
info.reference = ['Chiang et al., Nature Methods 20, 248-258 (2023), ' ...
                  'DOI 10.1038/s41592-022-01751-5'];
info.L = L;
info.p = p;
info.N = N;
info.reference_normalization = reference_normalization;
info.reference_sums_before = reference_sums_before;
info.reference_sums_after = reference_sums_after;
info.zero_photon_policy = zero_photon_policy;
info.total_intensity = total_intensity;
info.valid_pixel_mask = valid_pixel_mask;
info.zero_pixel_mask = zero_pixel_mask;
info.n_valid_pixels = nnz(valid_pixel_mask);
info.n_zero_pixels = nnz(zero_pixel_mask);
info.zero_pixel_fraction = nnz(zero_pixel_mask) / N;
info.jacobian_rank = jac_rank;
info.jacobian_condition_number = cond(J);
info.normal_matrix_condition_number = cond(JTJ);
info.max_sum_to_one_error_valid_pixels = max_sum_to_one_error;
info.negative_ratio_fraction_valid_pixels = negative_ratio_fraction;
info.nonnegative_constraint_applied = false;
info.notes = ['No non-negativity clipping or FCLS projection is applied. ' ...
              'All-zero-spectrum handling is not specified in the HyU paper ' ...
              'and is controlled by ZeroPhotonPolicy.'];

end
