function [R, I_unmixed, info] = HyU(Y, M_ref, varargin)
%HYU Paper-faithful HyU-filt0x implementation for 2D hyperspectral data.
%
%   [R, I_unmixed, info] = HyU(Y, M_ref)
%
% This function implements the HyU workflow described in:
%
%   Chiang HJ, Koo DES, Kitano M, et al.
%   "HyU: Hybrid Unmixing for longitudinal in vivo imaging of
%   low signal-to-noise fluorescence."
%   Nature Methods 20, 248-258 (2023).
%   DOI: 10.1038/s41592-022-01751-5
%
% IMPORTANT SCOPE
% -------------------------------------------------------------------------
% This is an independent implementation from the published equations,
% Methods text, and HyU pseudocode. It is NOT the unreleased author source
% code and is not claimed to be bit-for-bit identical to HySP/HyU.
%
% The implementation deliberately uses the HyU-filt0x variant:
%   - phasor encoding
%   - spectral averaging within each occupied phasor histogram bin
%   - paper-described Jacobian LU on each bin-average spectrum
%   - reverse phasor reference back to every original pixel
%
% No additional phasor median-filter pass is applied, because the paper
% reports 0-5 median-filter variants but does not fully specify all
% implementation details needed for exact reproduction of those filters.
%
% INPUTS
% -------------------------------------------------------------------------
% Y       : L x N nonnegative hyperspectral data.
%           L = number of spectral channels, N = number of pixels.
%
% M_ref   : L x p PROVIDED reference spectra.
%           HyU is supervised at the unmixing step and requires reference
%           spectra. Columns correspond to components/endmembers.
%
% NAME-VALUE OPTIONS
% -------------------------------------------------------------------------
% 'Harmonic'
%   Phasor harmonic n. Default = 2.
%   PAPER-SPECIFIED for fluorescent signals: n = 2.
%   The paper uses n = 1 for autofluorescence signals.
%
% 'NumBins'
%   Number of square phasor histogram bins per axis. Default = 100.
%   IMPLEMENTATION CHOICE: the paper specifies square 2D histogram bins
%   and illustrates roughly 10^4 phasor elements, but does not state the
%   exact official histogram resolution in the Methods.
%   NumBins=100 gives a 100 x 100 grid (=10^4 possible bins).
%
% 'ReferenceNormalization'
%   Passed to LU.m. Default = 'normalize'.
%   This is appropriate when M_ref contains peak-normalized fluorescence
%   spectra whose channel sums are not one.
%
% 'ZeroPhotonPolicy'
%   Handling of spectra with sum(Y(:,j)) == 0:
%       'uniform' (default) -> R(:,j)=1/p
%       'zero'              -> R(:,j)=0
%       'nan'               -> R(:,j)=NaN
%   The paper does not specify this edge case.
%
% 'Verbose'
%   true / false. Default = false.
%
% OUTPUTS
% -------------------------------------------------------------------------
% R
%   p x N HyU component-ratio matrix.
%   This is the ratio output in the paper's LU convention, not a blind
%   abundance estimate. For valid pixels, the ratios sum to one up to
%   numerical precision; negative ratios are not clipped because the
%   paper-described Jacobian LU is unconstrained.
%
% I_unmixed
%   p x N unmixed component intensities:
%       I_unmixed(:,j) = R(:,j) * sum(Y(:,j))
%   matching the paper's step of multiplying the ratio cube by the
%   integral of the original spectrum over channels.
%
% info
%   Diagnostics and phasor/bin metadata.
%
% ALGORITHM IMPLEMENTED
% -------------------------------------------------------------------------
% Paper pseudocode:
%
%   1) phasor_transform
%   2) histogram2d
%   3) phasor_average
%   4) LU on average spectrum of each occupied phasor bin
%   5) reverse_phasor_reference
%
% The phasor coordinates use the paper equations
%
%   G(n) = sum I(lambda) cos(n*omega*lambda) /
%          sum I(lambda)
%
%   S(n) = sum I(lambda) sin(n*omega*lambda) /
%          sum I(lambda)
%
%   omega = 2*pi/L
%
% For equally spaced channels, Delta-lambda cancels. Channel index
% lambda = 1,...,L is used in the discrete implementation.
%
% DEPENDENCY
% -------------------------------------------------------------------------
% LU.m must be on the MATLAB path.
%
% EXAMPLE
% -------------------------------------------------------------------------
%   Y_nonneg = max(Y,0);
%   [R_HyU, I_HyU, info] = HyU(Y_nonneg, M_true, ...
%       'Harmonic',2, 'NumBins',100, ...
%       'ReferenceNormalization','normalize', ...
%       'ZeroPhotonPolicy','uniform');
%
%   % If M_true is not unit-channel-sum and the synthetic coefficients were
%   % generated in the original M_true convention, map R_HyU back to that
%   % coefficient convention outside this function before abundance MSE.
%
% See also LU.

%% Parse options --------------------------------------------------------
ip = inputParser;
ip.FunctionName = 'HyU';

addParameter(ip, 'Harmonic', 2, ...
    @(x) isnumeric(x) && isscalar(x) && isfinite(x) && x >= 1 && x == round(x));

addParameter(ip, 'NumBins', 100, ...
    @(x) isnumeric(x) && isscalar(x) && isfinite(x) && x >= 2 && x == round(x));

addParameter(ip, 'ReferenceNormalization', 'normalize', ...
    @(x) ischar(x) || (isstring(x) && isscalar(x)));

addParameter(ip, 'ZeroPhotonPolicy', 'uniform', ...
    @(x) ischar(x) || (isstring(x) && isscalar(x)));

addParameter(ip, 'Verbose', false, ...
    @(x) islogical(x) && isscalar(x));

parse(ip, varargin{:});

harmonic = double(ip.Results.Harmonic);
num_bins = double(ip.Results.NumBins);
reference_normalization = char(ip.Results.ReferenceNormalization);
zero_policy = lower(char(ip.Results.ZeroPhotonPolicy));
verbose = ip.Results.Verbose;

if ~ismember(zero_policy, {'uniform','zero','nan'})
    error('HyU:BadZeroPhotonPolicy', ...
        'ZeroPhotonPolicy must be ''uniform'', ''zero'', or ''nan''.');
end

%% Validate inputs ------------------------------------------------------
if ~isnumeric(Y) || ~ismatrix(Y) || isempty(Y)
    error('HyU:BadY', 'Y must be a nonempty numeric L x N matrix.');
end

if ~isnumeric(M_ref) || ~ismatrix(M_ref) || isempty(M_ref)
    error('HyU:BadM', 'M_ref must be a nonempty numeric L x p matrix.');
end

Y = double(Y);
M_ref = double(M_ref);

if any(~isfinite(Y(:)))
    error('HyU:NonfiniteY', 'Y contains NaN or Inf.');
end

if any(~isfinite(M_ref(:)))
    error('HyU:NonfiniteM', 'M_ref contains NaN or Inf.');
end

if any(Y(:) < 0)
    error('HyU:NegativeY', ...
        ['Y contains negative values. HyU phasor intensities are defined ' ...
         'for nonnegative spectral intensities. For Poisson+read-noise data, ' ...
         'explicitly floor negative measured intensities before calling HyU, ' ...
         'for example Y_HyU = max(Y,0).']);
end

if any(M_ref(:) < 0)
    error('HyU:NegativeM', ...
        'M_ref contains negative values; fluorescence reference spectra must be nonnegative.');
end

[L, N] = size(Y);
[Lm, p] = size(M_ref);

if Lm ~= L
    error('HyU:DimensionMismatch', ...
        'Y has %d spectral channels but M_ref has %d rows.', L, Lm);
end

if p < 2
    error('HyU:TooFewReferences', ...
        'At least two reference spectra are required.');
end

if p > L
    error('HyU:Underdetermined', ...
        'Number of reference spectra p=%d exceeds number of channels L=%d.', p, L);
end

if exist('LU','file') ~= 2
    error('HyU:MissingLU', ...
        'LU.m must be on the MATLAB path because HyU uses the paper-described LU step.');
end

%% Step 1: paper phasor transform --------------------------------------
% Eq. (1)-(3) in the paper.
%
% For uniformly spaced channels, Delta-lambda is common to numerator and
% denominator and therefore cancels.
lambda_idx = (1:L)';
omega = 2*pi/L;

cvec = cos(harmonic * omega * lambda_idx);
svec = sin(harmonic * omega * lambda_idx);

total_intensity = sum(Y,1);
valid = total_intensity > 0;
zero_mask = ~valid;

G = nan(1,N);
S = nan(1,N);

if any(valid)
    denom = total_intensity(valid);
    G(valid) = (cvec' * Y(:,valid)) ./ denom;
    S(valid) = (svec' * Y(:,valid)) ./ denom;
end

% Round-off can place a point infinitesimally outside the unit square.
G(valid) = min(max(G(valid), -1), 1);
S(valid) = min(max(S(valid), -1), 1);

%% Step 2: 2D square phasor histogram ----------------------------------
edges = linspace(-1, 1, num_bins+1);

g_bin = nan(1,N);
s_bin = nan(1,N);

if any(valid)
    g_bin(valid) = discretize(G(valid), edges);
    s_bin(valid) = discretize(S(valid), edges);
end

% Numerical safety for valid points exactly on/near a boundary.
bad_bin = valid & (isnan(g_bin) | isnan(s_bin));
if any(bad_bin)
    % Re-map with explicit clipping to the interior of the final edge.
    tiny = 10*eps;
    G2 = min(max(G(bad_bin), -1+tiny), 1-tiny);
    S2 = min(max(S(bad_bin), -1+tiny), 1-tiny);
    g_bin(bad_bin) = discretize(G2, edges);
    s_bin(bad_bin) = discretize(S2, edges);
end

if any(valid & (isnan(g_bin) | isnan(s_bin)))
    error('HyU:HistogramAssignmentFailed', ...
        'Some valid phasor points could not be assigned to a histogram bin.');
end

n_all_bins = num_bins * num_bins;
global_bin_id = zeros(1,N);

if any(valid)
    global_bin_id(valid) = sub2ind( ...
        [num_bins, num_bins], ...
        s_bin(valid), g_bin(valid));
end

occupied_bin_ids = unique(global_bin_id(valid));
n_occupied = numel(occupied_bin_ids);

if n_occupied == 0
    error('HyU:NoOccupiedBins', 'No valid phasor histogram bins were occupied.');
end

%% Step 3: average spectra inside each occupied phasor bin --------------
% Build a compact occupied-bin index 1..n_occupied.
bin_to_compact = zeros(n_all_bins,1);
bin_to_compact(occupied_bin_ids) = 1:n_occupied;

compact_pixel_bin = zeros(1,N);
compact_pixel_bin(valid) = bin_to_compact(global_bin_id(valid));

bin_counts = accumarray( ...
    compact_pixel_bin(valid)', ...
    1, ...
    [n_occupied 1], ...
    @sum, 0);

I_H = zeros(L, n_occupied);

for ell = 1:L
    channel_sums = accumarray( ...
        compact_pixel_bin(valid)', ...
        Y(ell,valid)', ...
        [n_occupied 1], ...
        @sum, 0);

    I_H(ell,:) = (channel_sums ./ bin_counts)';
end

%% Step 4: LU on each bin-average spectrum ------------------------------
% Paper: Jacobian matrix inversion on average spectrum of each phasor bin.
[R_bin, ~, lu_info] = LU(I_H, M_ref, ...
    'ReferenceNormalization', reference_normalization, ...
    'ZeroPhotonPolicy', 'uniform');

%% Step 5: reverse phasor reference ------------------------------------
R = nan(p,N);

if any(valid)
    R(:,valid) = R_bin(:, compact_pixel_bin(valid));
end

if any(zero_mask)
    switch zero_policy
        case 'uniform'
            R(:,zero_mask) = 1/p;
        case 'zero'
            R(:,zero_mask) = 0;
        case 'nan'
            R(:,zero_mask) = NaN;
    end
end

%% Final unmixed component intensity -----------------------------------
% Paper: multiply component ratios by integral intensity of original pixel.
I_unmixed = R .* total_intensity;

if strcmp(zero_policy,'nan') && any(zero_mask)
    I_unmixed(:,zero_mask) = 0;
end

%% Diagnostics ----------------------------------------------------------
hist_counts = zeros(num_bins,num_bins);
hist_counts(occupied_bin_ids) = bin_counts;

if any(valid)
    ratios_valid = R(:,valid);
    sum_to_one_error = max(abs(sum(ratios_valid,1)-1));
    negative_ratio_fraction = nnz(ratios_valid < 0) / numel(ratios_valid);
else
    sum_to_one_error = NaN;
    negative_ratio_fraction = NaN;
end

info = struct();
info.method = 'HyU-filt0x independent paper-faithful implementation';
info.reference = ['Chiang et al., Nature Methods 20, 248-258 (2023), ' ...
                  'DOI 10.1038/s41592-022-01751-5'];

% Paper-specified / source-derived choices.
info.harmonic = harmonic;
info.paper_fluorescence_harmonic = 2;
info.phasor_omega = omega;
info.phasor_G = G;
info.phasor_S = S;
info.variant = 'HyU-filt0x';
info.denoising_filter_iterations = 0;

% Implementation choices not numerically specified in the paper.
info.num_bins_per_axis = num_bins;
info.total_possible_bins = n_all_bins;
info.histogram_edges = edges;

% Compression / bin information.
info.N = N;
info.L = L;
info.p = p;
info.valid_pixel_mask = valid;
info.zero_pixel_mask = zero_mask;
info.n_valid_pixels = nnz(valid);
info.n_zero_pixels = nnz(zero_mask);
info.global_bin_id = global_bin_id;
info.g_bin = g_bin;
info.s_bin = s_bin;
info.occupied_bin_ids = occupied_bin_ids;
info.n_occupied_bins = n_occupied;
info.bin_counts = bin_counts;
info.histogram_counts = hist_counts;
info.bin_mean_spectra = I_H;
info.mean_pixels_per_occupied_bin = nnz(valid) / n_occupied;
info.compression_ratio_valid_pixels_to_bins = nnz(valid) / n_occupied;

% LU diagnostics.
info.LU = lu_info;
info.reference_normalization = reference_normalization;
info.zero_photon_policy = zero_policy;
info.max_sum_to_one_error_valid_pixels = sum_to_one_error;
info.negative_ratio_fraction_valid_pixels = negative_ratio_fraction;

info.notes = { ...
    'Implements published HyU phasor encoding -> bin averaging -> LU -> reverse mapping.', ...
    'Uses HyU-filt0x: no extra phasor median-filter pass.', ...
    ['NumBins is configurable because the paper states square histogram bins ' ...
     'but does not provide the exact official histogram resolution in Methods.'], ...
    ['This implementation follows the paper description but is not the unreleased ' ...
     'official HySP/HyU source code.']};

if verbose
    fprintf(['HyU-filt0x | harmonic=%d | grid=%dx%d | valid pixels=%d | ' ...
             'occupied bins=%d | mean %.2f pixels/bin | compression %.2fx\n'], ...
        harmonic, num_bins, num_bins, nnz(valid), n_occupied, ...
        info.mean_pixels_per_occupied_bin, ...
        info.compression_ratio_valid_pixels_to_bins);
end

end
