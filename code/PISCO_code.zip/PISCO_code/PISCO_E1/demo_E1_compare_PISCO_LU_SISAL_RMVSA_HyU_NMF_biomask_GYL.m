%% demo_E1_compare_PISCO_LU_SISAL_RMVSA_HyU_NMF.m
% Unified E1 benchmark:
%   PISCO + LU + SISAL + RMVSA + HyU + NMF
%
% All six methods are evaluated on the SAME simulated scene and the SAME
% noisy Y_in for each Monte-Carlo repeat / photon level.
%
% FIGURES
% -------------------------------------------------------------------------
%   (1) SAD vs photon:
%         PISCO + SISAL + RMVSA + NMF
%       LU and HyU are supervised with M_true, so no endmember SAD is used.
%
%   (2) Abundance MSE vs photon:
%         PISCO + LU + SISAL + RMVSA + HyU + NMF
%
%   (3) Per-pixel residual boxplots:
%         one separate figure for each method,
%         at BOX_LEVELS = [5 10 20] photons
%
%   (4) Representative abundance maps at REP_PHOTON, run 1:
%         row 1: GT
%         row 2: PISCO
%         row 3: LU
%         row 4: SISAL
%         row 5: RMVSA
%         row 6: HyU
%         row 7: NMF
%       columns: Citrine / tdTomato / mKO2 / mRuby
%
% SAVED DATA FOR LATER FIGURE REPRODUCTION
% -------------------------------------------------------------------------
%   (A) compare_E1_PISCO_LU_SISAL_RMVSA_HyU_NMF_accuracy_results.csv
%       method,photons,run,SAD_deg,MSE_ab,MSE_rec,residual_mean,time_s
%
%   (B) compare_E1_PISCO_LU_SISAL_RMVSA_HyU_NMF_per_pixel_residuals.csv
%       method,photons,run,pixel_id,residual_pixel
%
%   (C) compare_E1_PISCO_LU_SISAL_RMVSA_HyU_NMF_abundance_maps_20photons_run1.csv
%       pixel_id,row,col,
%       GT_*, PISCO_*, LU_*, SISAL_*, RMVSA_*, HyU_*, NMF_*
%
%   (D) compare_E1_PISCO_LU_SISAL_RMVSA_HyU_NMF_plotdata.mat
%       all arrays used to draw the figures, including RMVSA/HyU/NMF settings.
%
% REQUIRED FILES ON MATLAB PATH
% -------------------------------------------------------------------------
%   deep_mvsa_invflow_poisson.m
%   LU.m
%   sisal.m
%   rmvsa_LiAlex22.m
%   estNoise.m
%   quadProg.m
%   computeAtransYinvLA.m
%   VCA.m
%   hinge.m
%   soft_neg.m
%   HyU.m
%   nmf_lee_seung_euclidean.m
%   build_Strue_from_masks.m
%   PISCO_M_32x4_HyU_strict_quasar32.mat
%
% IMPORTANT RMVSA NOTE
% -------------------------------------------------------------------------
% RMVSA uses the five supplied files as one complete implementation:
%   rmvsa_LiAlex22.m + estNoise.m + VCA.m + quadProg.m +
%   computeAtransYinvLA.m.
%
% The invocation follows Rmvsa_demo_Cuprite1026:
%   estimate Rn from the current input, then call rmvsa_LiAlex22 with
%   spherize=yes. The supplied demo passes alpha=0.001 directly, so the
%   benchmark keeps RMVSA_ALPHA=0.001 rather than reinterpreting it as eta.
%
% For a fair abundance comparison with SISAL, RMVSA endmembers are followed
% by the same exact FCLS abundance recovery used for SISAL. The internal
% Sest returned by rmvsa_LiAlex22 is therefore not used for E1 MSE/residuals.
%
% IMPORTANT HyU NOTE
% -------------------------------------------------------------------------
% HyU.m is an independent implementation following the published equations,
% Methods, and pseudocode of Chiang et al., Nature Methods 20, 248-258
% (2023). It is not claimed to be the unreleased official HySP source.
%
% This benchmark uses HyU-filt0x:
%   phasor encoding -> bin-average spectra -> paper-described LU ->
%   reverse mapping to pixels.
%
% Paper-specified for fluorescent signals:
%   HYU_HARMONIC = 2.
%
% Implementation choice because the paper does not state the exact official
% histogram resolution in Methods:
%   HYU_NBINS = 100 per phasor axis.
%
% IMPORTANT NMF NOTE
% -------------------------------------------------------------------------
% NMF is the standard Lee-Seung Euclidean/Frobenius NMF baseline:
%       min_{M>=0,S>=0} 0.5*||Y-M*S||_F^2
% with multiplicative updates, no sparsity penalty, no spatial term, no
% sum-to-one constraint, and no minimum-volume term. Because mixed read
% noise can make Y_in negative, NMF uses Y_nonneg = max(Y_in,0).
% VCA initializes M; M columns are peak-normalized while S is inversely
% rescaled so M*S is unchanged.
%
% Biological-mask E1 protocol:
% abundance fields are derived from instance masks under ./use/<scene>/masks,
% then smoothed, normalized to sum-to-one, and capped at max purity 0.8.
% Poisson + Gaussian read noise, photon grid [2 5 10 20 50 100],
% 32 channels, 4 proteins. The original images under ./use/<scene>/images
% are NOT used in the numerical simulation.

clear all; close all; clc;

%% A.0 Protocol ---------------------------------------------------------
QUICK       = false;
N_RUNS      = 30;
BASE_SEED   = 52;

SIZE        = 96;
PHOTON_GRID = [2, 5, 10, 20, 50, 100];
BOX_LEVELS  = [5, 10, 20];
READ_SIG    = 1.0;
REP_PHOTON  = 20;

% Biological-mask abundance settings.
% Expected folder layout:
%   <this script>/use/<scene_name>/masks/*.png
%   <this script>/use/<scene_name>/images/*    (not used numerically)
THIS_SCRIPT = mfilename('fullpath');
SCRIPT_DIR = fileparts(THIS_SCRIPT);
if isempty(SCRIPT_DIR)
    SCRIPT_DIR = pwd;
end
MASK_ROOT       = fullfile(SCRIPT_DIR,'use');
MASK_SIGMA      = 2.0;    % Gaussian smoothing sigma, in target-image pixels.
MASK_BACKGROUND = 0.02;   % Positive floor before sum-to-one normalization.
MAX_PURITY      = 0.8;

% PISCO parameters: same as the current E1 PISCO script.
MM_ITERS = 2500;
WARM_UP  = 0;

% SISAL parameters: same as the current SISAL E1 baseline.
SISAL_MM_ITERS = 10;
SISAL_TAU      = 40;

% RMVSA parameters: follow the supplied Cuprite demo call.
RMVSA_ALPHA    = 0.00001;
RMVSA_MM_ITERS = 10;      % actual default in rmvsa_LiAlex22.m
RMVSA_NOISE    = 'additive';

% HyU parameters.
HYU_HARMONIC = 2;      % PAPER-SPECIFIED for fluorescent signals.
HYU_NBINS    = 100;    % IMPLEMENTATION CHOICE; configurable.
HYU_VARIANT  = 'filt0x';

% NMF parameters: same standard Lee-Seung baseline as demo_NMF_E1_accuracy.m.
NMF_MAX_ITER    = 2000;
NMF_MIN_ITER    = 100;
NMF_TOL_REL_OBJ = 1e-7;
NMF_CHECK_EVERY = 20;
NMF_FLOOR       = 1e-12;

OUT_ACC_CSV = ...
    '10compare_E1_PISCO_LU_SISAL_RMVSA_HyU_NMF_accuracy_results.csv';

OUT_RES_CSV = ...
    '10compare_E1_PISCO_LU_SISAL_RMVSA_HyU_NMF_per_pixel_residuals.csv';

OUT_ABUND_CSV = ...
    '10compare_E1_PISCO_LU_SISAL_RMVSA_HyU_NMF_abundance_maps_20photons_run1.csv';

OUT_MAT = ...
    '10compare_E1_PISCO_LU_SISAL_RMVSA_HyU_NMF_plotdata.mat';

if QUICK
    N_RUNS = 2;
    PHOTON_GRID = 20;
    BOX_LEVELS = [];
    MM_ITERS = 800;
    WARM_UP = 200;
    NMF_MAX_ITER = 500;
    NMF_MIN_ITER = 50;
    NMF_CHECK_EVERY = 10;
    RMVSA_MM_ITERS = 4;
    REP_PHOTON = 20;
end

%% A.1 Ground-truth endmembers -----------------------------------------
M_FILE = 'PISCO_M_32x4_HyU_strict_quasar32.mat';

if ~isfile(M_FILE)
    error(['Cannot find %s.\n' ...
           'Put the MAT file in the same folder as this script or set M_FILE.'], ...
           M_FILE);
end

Dspec = load(M_FILE);

if ~isfield(Dspec,'M')
    error('%s does not contain variable M.', M_FILE);
end

M_true = double(Dspec.M);
[L,p] = size(M_true);

if L ~= 32 || p ~= 4
    error('Expected M_true to be 32 x 4, got %d x %d.', L, p);
end

if any(~isfinite(M_true(:))) || any(M_true(:) < 0)
    error('M_true must contain finite nonnegative values.');
end

if isfield(Dspec,'channel_centers_nm')
    wl = double(Dspec.channel_centers_nm(:));
    if numel(wl) ~= L
        error('channel_centers_nm must contain %d values.', L);
    end
else
    wl = linspace(410.5,694.9,L)';
end

if isfield(Dspec,'endmember_names')
    endmember_names = Dspec.endmember_names;
else
    endmember_names = {'Citrine','tdTomato','mKO2','mRuby'};
end

clear Dspec;

IMG_H = SIZE;
IMG_W = SIZE;
N = IMG_H * IMG_W;

% Discover biological scenes. Only the masks folders are used.
if ~isfolder(MASK_ROOT)
    error(['Cannot find biological-mask root folder:\n  %s\n' ...
           'Expected ./use/<scene_name>/masks/*.png next to this script.'], ...
           MASK_ROOT);
end

Dscene = dir(MASK_ROOT);
Dscene = Dscene([Dscene.isdir]);
Dscene = Dscene(~ismember({Dscene.name},{'.','..'}));

scene_dirs = {};
for ii = 1:numel(Dscene)
    candidate = fullfile(MASK_ROOT,Dscene(ii).name);
    mask_dir = fullfile(candidate,'masks');
    if isfolder(mask_dir) && ~isempty(dir(fullfile(mask_dir,'*.png')))
        scene_dirs{end+1} = candidate; %#ok<SAGROW>
    end
end

if isempty(scene_dirs)
    error(['No usable biological scenes were found under:\n  %s\n' ...
           'Each scene must contain masks/*.png.'],MASK_ROOT);
end

% Sort for deterministic run-to-scene cycling. Scene identities are NOT
% stored in the output MAT file, per the experiment requirement.
[~,ord_scene] = sort(lower(string(scene_dirs)));
scene_dirs = scene_dirs(ord_scene);
nScenes = numel(scene_dirs);

% LU/HyU internally normalize reference spectra to unit channel-sum.
% These sums map returned component ratios back to the coefficient
% convention of the original peak-normalized M_true used in Y_clean.
M_colsum = sum(M_true,1);

if any(M_colsum <= 0)
    error('Each M_true column must have positive channel sum.');
end

fprintf('Loaded %s\n', M_FILE);
fprintf('M_true: %d channels x %d endmembers\n', L, p);
fprintf('Scene: %d x %d = %d pixels\n', IMG_H, IMG_W, N);
fprintf('Biological mask pool: %d usable scenes under %s\n',nScenes,MASK_ROOT);
fprintf('HyU variant: %s, harmonic=%d, phasor grid=%dx%d\n', ...
    HYU_VARIANT, HYU_HARMONIC, HYU_NBINS, HYU_NBINS);
fprintf('NMF: Lee-Seung Euclidean, MaxIter=%d, TolRelObj=%.1e\n', ...
    NMF_MAX_ITER, NMF_TOL_REL_OBJ);

%% A.2 Method bookkeeping ----------------------------------------------
METHODS = {'PISCO','LU','SISAL','RMVSA','HyU','NMF'};

miP = 1;
miL = 2;
miS = 3;
miR = 4;
miH = 5;
miN = 6;

nM = numel(METHODS);
nL = numel(PHOTON_GRID);

SAD_m = nan(nM,nL,N_RUNS);   % LU/HyU remain NaN.
MAB_m = nan(nM,nL,N_RUNS);
MRC_m = nan(nM,nL,N_RUNS);
RES_m = nan(nM,nL,N_RUNS);
T_m   = nan(nM,nL,N_RUNS);

% HyU diagnostics useful for interpretation / reproducibility.
HYU_OCC_BINS = nan(nL,N_RUNS);
HYU_COMPRESS = nan(nL,N_RUNS);
HYU_PIX_PER_BIN = nan(nL,N_RUNS);

% NMF convergence / constraint diagnostics.
NMF_ITER = nan(nL,N_RUNS);
NMF_CONV = false(nL,N_RUNS);
NMF_SUMONE_MAE = nan(nL,N_RUNS);
NMF_FINAL_OBJ = nan(nL,N_RUNS);
NMF_REL_OBJ_CHANGE = nan(nL,N_RUNS);

% Boxplot raw data.
res_pix = cell(nM,nL);
for m = 1:nM
    for k = 1:nL
        res_pix{m,k} = [];
    end
end

% Representative abundance-map data.
rep_done = false;
rep_S_true = [];
rep_PISCO = [];
rep_LU = [];
rep_SISAL = [];
rep_RMVSA = [];
rep_HyU = [];
rep_NMF = [];

rep_M_PISCO = [];
rep_M_SISAL = [];
rep_M_RMVSA = [];
rep_M_NMF = [];

rep_HyU_info = [];
rep_NMF_info = [];

%% A.3 Open output CSV files -------------------------------------------
fid_acc = fopen(OUT_ACC_CSV,'w');

if fid_acc < 0
    error('Cannot open %s for writing.', OUT_ACC_CSV);
end

fprintf(fid_acc, ...
    'method,photons,run,SAD_deg,MSE_ab,MSE_rec,residual_mean,time_s\n');

fid_res = fopen(OUT_RES_CSV,'w');

if fid_res < 0
    fclose(fid_acc);
    error('Cannot open %s for writing.', OUT_RES_CSV);
end

fprintf(fid_res, ...
    'method,photons,run,pixel_id,residual_pixel\n');

%% A.4 Monte-Carlo experiment ------------------------------------------
fprintf('\nUnified E1: %d repeats x %d photon levels\n', ...
    N_RUNS, nL);

for r = 1:N_RUNS

    %% ---- Generate one shared biological scene for this repeat --------
    % Cycle deterministically through all usable folders under ./use.
    % If N_RUNS > nScenes, the scene pool is reused on the next cycle.
    % The selected scene identity is intentionally NOT saved in plotdata.
    scene_idx = 1 + mod(r-1,nScenes);
    scene_dir = scene_dirs{scene_idx};

    % Build a p x N ground-truth abundance matrix from the instance masks.
    % Inside build_Strue_from_masks:
    %   1) all masks are resized to IMG_H x IMG_W by nearest-neighbor;
    %   2) mask instances are randomly but evenly assigned to p groups;
    %   3) masks are unioned within each group;
    %   4) each group is Gaussian-smoothed;
    %   5) a small positive floor is added and abundances sum to one;
    %   6) the exact E1 max-purity cap is imposed.
    S_true = build_Strue_from_masks( ...
        scene_dir,IMG_H,IMG_W,p,MAX_PURITY, ...
        BASE_SEED + r,MASK_SIGMA,MASK_BACKGROUND);

    Y_clean = M_true * S_true;

    %% ---- Generate ALL noisy datasets before running any method -------
    % Use a separate deterministic RNG stream for measurement noise so
    % mask grouping does not alter the Poisson/Gaussian noise realization.
    rng(BASE_SEED + 10000 + r, 'twister');

    % This prevents stochastic PISCO/SISAL initialization from changing
    % the noise realization used at later photon levels.
    Y_inputs = cell(1,nL);
    GAIN_GRID = zeros(1,nL);

    for k = 1:nL
        ph = PHOTON_GRID(k);

        % Keep the exact photon scaling used in the existing PISCO E1 code.
        g = ph * N / sum(Y_clean(:)) * L;
        GAIN_GRID(k) = g;

        Y_counts = poissrnd(g * Y_clean) + ...
                   READ_SIG * randn(L,N);

        Y_inputs{k} = double(Y_counts) / g;
    end

    %% ---- Evaluate every method on exactly the same Y_in --------------
    for k = 1:nL

        ph = PHOTON_GRID(k);
        g  = GAIN_GRID(k);
        Y_in = Y_inputs{k};

        % Physical nonnegative version used only by supervised LU/HyU,
        % matching the existing LU E1 baseline treatment of read-noise
        % values below zero.
        Y_nonneg = max(Y_in,0);

        %% ==============================================================
        % 1) PISCO
        % ===============================================================
        rng(BASE_SEED + 100000 + 1000*r + k, 'twister');

        t_run = tic;

        [M_est_P,S_est_P] = deep_mvsa_invflow_poisson_explicit_Warmup(Y_in,p, ...
            'spherize','yes', ...
            'verbose',0, ...
            'MM_ITERS',MM_ITERS, ...
            'WARM_UP',WARM_UP, ...
            'LR',3e-4, ...
            'LAMBDA_VOL',0.008, ...
            'LAMBDA_NONNEG',10, ...
            'LAMBDA_EQ',80, ...
            'LAMBDA_SUMONE',2, ...
            'LAMBDA_ENCLOSE',3, ...
            'IMG_H',IMG_H, ...
            'IMG_W',IMG_W, ...
            'LAMBDA_SPATIAL',1, ...
            'ETA',0.1, ...
            'PHOTON_GAIN',g, ...
            'PHOTON_FLOOR',1, ...
            'READ_SIGMA',READ_SIG);

        T_m(miP,k,r) = toc(t_run);

        [permP,~] = e1_match(M_true,M_est_P);

        [SAD_m(miP,k,r), ...
         MAB_m(miP,k,r), ...
         MRC_m(miP,k,r)] = ...
            e1_metrics( ...
                M_true,S_true,Y_clean, ...
                M_est_P,S_est_P,permP);

        Yhat_P = M_est_P * S_est_P;

        rj_P = e1_relative_residual(Y_in,Yhat_P);

        RES_m(miP,k,r) = mean(rj_P);

        if ismember(ph,BOX_LEVELS)
            res_pix{miP,k} = [res_pix{miP,k}, rj_P];

            for j = 1:N
                fprintf(fid_res, ...
                    '%s,%d,%d,%d,%.10g\n', ...
                    METHODS{miP},ph,r,j,rj_P(j));
            end
        end

        fprintf(fid_acc, ...
            '%s,%d,%d,%.8g,%.10e,%.10e,%.10g,%.10g\n', ...
            METHODS{miP},ph,r, ...
            SAD_m(miP,k,r), ...
            MAB_m(miP,k,r), ...
            MRC_m(miP,k,r), ...
            RES_m(miP,k,r), ...
            T_m(miP,k,r));

        %% ==============================================================
        % 2) LU
        % ===============================================================
        t_run = tic;

        [R_LU,~,info_LU] = LU( ...
            Y_nonneg,M_true, ...
            'ReferenceNormalization','normalize', ...
            'ZeroPhotonPolicy','uniform');

        T_m(miL,k,r) = toc(t_run);

        S_est_L = ratio_to_original_coeff( ...
            R_LU,M_colsum,p);

        Yhat_L = M_true * S_est_L;

        MAB_m(miL,k,r) = ...
            mean((S_true(:)-S_est_L(:)).^2);

        MRC_m(miL,k,r) = ...
            mean((Y_clean(:)-Yhat_L(:)).^2);

        rj_L = e1_relative_residual(Y_in,Yhat_L);

        RES_m(miL,k,r) = mean(rj_L);

        if ismember(ph,BOX_LEVELS)
            res_pix{miL,k} = [res_pix{miL,k}, rj_L];

            for j = 1:N
                fprintf(fid_res, ...
                    '%s,%d,%d,%d,%.10g\n', ...
                    METHODS{miL},ph,r,j,rj_L(j));
            end
        end

        fprintf(fid_acc, ...
            '%s,%d,%d,%.8g,%.10e,%.10e,%.10g,%.10g\n', ...
            METHODS{miL},ph,r, ...
            NaN, ...
            MAB_m(miL,k,r), ...
            MRC_m(miL,k,r), ...
            RES_m(miL,k,r), ...
            T_m(miL,k,r));

        %% ==============================================================
        % 3) SISAL + exact FCLS abundance recovery
        % ===============================================================
        rng(BASE_SEED + 200000 + 1000*r + k, 'twister');

        t_run = tic;

        A_est = sisal(Y_in,p, ...
            'spherize','no', ...
            'MM_ITERS',SISAL_MM_ITERS, ...
            'TAU',SISAL_TAU, ...
            'verbose',0);

        M_est_S = double(A_est);

        S_est_S = e1_fcls_exact(M_est_S,Y_in);

        T_m(miS,k,r) = toc(t_run);

        [permS,~] = e1_match(M_true,M_est_S);

        [SAD_m(miS,k,r), ...
         MAB_m(miS,k,r), ...
         MRC_m(miS,k,r)] = ...
            e1_metrics( ...
                M_true,S_true,Y_clean, ...
                M_est_S,S_est_S,permS);

        Yhat_S = M_est_S * S_est_S;

        rj_S = e1_relative_residual(Y_in,Yhat_S);

        RES_m(miS,k,r) = mean(rj_S);

        if ismember(ph,BOX_LEVELS)
            res_pix{miS,k} = [res_pix{miS,k}, rj_S];

            for j = 1:N
                fprintf(fid_res, ...
                    '%s,%d,%d,%d,%.10g\n', ...
                    METHODS{miS},ph,r,j,rj_S(j));
            end
        end

        fprintf(fid_acc, ...
            '%s,%d,%d,%.8g,%.10e,%.10e,%.10g,%.10g\n', ...
            METHODS{miS},ph,r, ...
            SAD_m(miS,k,r), ...
            MAB_m(miS,k,r), ...
            MRC_m(miS,k,r), ...
            RES_m(miS,k,r), ...
            T_m(miS,k,r));

        %% ==============================================================
        % 4) RMVSA + exact FCLS abundance recovery
        % ===============================================================
        % The supplied Cuprite demo estimates a noise covariance and then
        % calls rmvsa_LiAlex22(...,'spherize','yes'). Here p is already
        % known (=4), so Cuprite-specific HySime/affine/VCA-regularization
        % preprocessing is intentionally not imported into the E1 protocol.
        rng(BASE_SEED + 400000 + 1000*r + k, 'twister');

        t_run = tic;

        % estNoise defaults to additive noise; specify it explicitly and
        % silence its progress messages for the Monte-Carlo benchmark.
        [~,Rn_R] = estNoise(Y_in,RMVSA_NOISE,'off');

        % rmvsa_LiAlex22 internally initializes with the supplied VCA.m and
        % solves its QP subproblems through quadProg.m ->
        % computeAtransYinvLA.m.
        warn_state_rmvsa = warning;
        [M_est_R,~] = rmvsa_LiAlex22( ...
            Y_in,p,RMVSA_ALPHA,Rn_R, ...
            'spherize','yes', ...
            'MM_ITERS',RMVSA_MM_ITERS, ...
            'verbose',0);
        warning(warn_state_rmvsa);

        M_est_R = double(M_est_R);

        % Use the same exact FCLS recovery as SISAL so abundance MSE and
        % reconstruction metrics compare endmember estimators consistently.
        S_est_R = e1_fcls_exact(M_est_R,Y_in);

        T_m(miR,k,r) = toc(t_run);

        [permR,~] = e1_match(M_true,M_est_R);

        [SAD_m(miR,k,r), ...
         MAB_m(miR,k,r), ...
         MRC_m(miR,k,r)] = ...
            e1_metrics( ...
                M_true,S_true,Y_clean, ...
                M_est_R,S_est_R,permR);

        Yhat_R = M_est_R * S_est_R;

        rj_R = e1_relative_residual(Y_in,Yhat_R);

        RES_m(miR,k,r) = mean(rj_R);

        if ismember(ph,BOX_LEVELS)
            res_pix{miR,k} = [res_pix{miR,k}, rj_R];

            for j = 1:N
                fprintf(fid_res, ...
                    '%s,%d,%d,%d,%.10g\n', ...
                    METHODS{miR},ph,r,j,rj_R(j));
            end
        end

        fprintf(fid_acc, ...
            '%s,%d,%d,%.8g,%.10e,%.10e,%.10g,%.10g\n', ...
            METHODS{miR},ph,r, ...
            SAD_m(miR,k,r), ...
            MAB_m(miR,k,r), ...
            MRC_m(miR,k,r), ...
            RES_m(miR,k,r), ...
            T_m(miR,k,r));

        %% ==============================================================
        % 5) HyU-filt0x
        % ===============================================================
        t_run = tic;

        [R_HyU,~,info_HyU] = HyU( ...
            Y_nonneg,M_true, ...
            'Harmonic',HYU_HARMONIC, ...
            'NumBins',HYU_NBINS, ...
            'ReferenceNormalization','normalize', ...
            'ZeroPhotonPolicy','uniform', ...
            'Verbose',false);

        T_m(miH,k,r) = toc(t_run);

        % HyU returns paper LU ratios. Convert them to the coefficient
        % convention of the original peak-normalized M_true before
        % abundance-MSE and M_true*S reconstruction, exactly as for LU.
        S_est_H = ratio_to_original_coeff( ...
            R_HyU,M_colsum,p);

        Yhat_H = M_true * S_est_H;

        MAB_m(miH,k,r) = ...
            mean((S_true(:)-S_est_H(:)).^2);

        MRC_m(miH,k,r) = ...
            mean((Y_clean(:)-Yhat_H(:)).^2);

        rj_H = e1_relative_residual(Y_in,Yhat_H);

        RES_m(miH,k,r) = mean(rj_H);

        HYU_OCC_BINS(k,r) = ...
            info_HyU.n_occupied_bins;

        HYU_COMPRESS(k,r) = ...
            info_HyU.compression_ratio_valid_pixels_to_bins;

        HYU_PIX_PER_BIN(k,r) = ...
            info_HyU.mean_pixels_per_occupied_bin;

        if ismember(ph,BOX_LEVELS)
            res_pix{miH,k} = [res_pix{miH,k}, rj_H];

            for j = 1:N
                fprintf(fid_res, ...
                    '%s,%d,%d,%d,%.10g\n', ...
                    METHODS{miH},ph,r,j,rj_H(j));
            end
        end

        fprintf(fid_acc, ...
            '%s,%d,%d,%.8g,%.10e,%.10e,%.10g,%.10g\n', ...
            METHODS{miH},ph,r, ...
            NaN, ...
            MAB_m(miH,k,r), ...
            MRC_m(miH,k,r), ...
            RES_m(miH,k,r), ...
            T_m(miH,k,r));

        %% ==============================================================
        % 6) Standard Lee-Seung Euclidean NMF
        % ===============================================================
        % NMF requires nonnegative data. Use the same Y_nonneg realization
        % already used by LU/HyU, without changing the shared noise draw.
        Y_NMF = Y_nonneg;

        % Independent, reproducible blind initialization seed for NMF.
        rng(BASE_SEED + 300000 + 1000*r + k, 'twister');

        % Time the complete NMF baseline, including VCA initialization.
        t_run = tic;

        [M0_NMF,~,~] = VCA( ...
            Y_NMF, ...
            'Endmembers',p, ...
            'verbose','off');

        M0_NMF = double(M0_NMF);
        M0_NMF = max(M0_NMF,NMF_FLOOR);

        % Peak-normalize initial endmembers. This matches the peak-normalized
        % fluorescence convention used by M_true.
        scl0 = max(M0_NMF,[],1);

        for q = 1:p
            if ~isfinite(scl0(q)) || scl0(q) <= NMF_FLOOR
                M0_NMF(:,q) = rand(L,1) + 0.1;
                scl0(q) = max(M0_NMF(:,q));
            end
        end

        M0_NMF = M0_NMF ./ scl0;

        % Nonnegative coefficient warm start.
        S0_NMF = pinv(M0_NMF) * Y_NMF;
        S0_NMF = max(S0_NMF,NMF_FLOOR);

        [M_est_N,S_est_N,info_NMF] = ...
            nmf_lee_seung_euclidean( ...
                Y_NMF,p, ...
                'M0',M0_NMF, ...
                'S0',S0_NMF, ...
                'MaxIter',NMF_MAX_ITER, ...
                'MinIter',NMF_MIN_ITER, ...
                'TolRelObj',NMF_TOL_REL_OBJ, ...
                'CheckEvery',NMF_CHECK_EVERY, ...
                'Floor',NMF_FLOOR, ...
                'NormalizeM','max', ...
                'Verbose',false);

        T_m(miN,k,r) = toc(t_run);

        % Use the SAME matching/evaluation routine as the other blind
        % methods in this unified benchmark.
        [permN,~] = e1_match(M_true,M_est_N);

        [SAD_m(miN,k,r), ...
         MAB_m(miN,k,r), ...
         MRC_m(miN,k,r)] = ...
            e1_metrics( ...
                M_true,S_true,Y_clean, ...
                M_est_N,S_est_N,permN);

        Yhat_N = M_est_N * S_est_N;

        % Measured-data residual uses the original Y_in, exactly as for the
        % other methods; NMF fitting itself uses nonnegative Y_NMF.
        rj_N = e1_relative_residual(Y_in,Yhat_N);

        RES_m(miN,k,r) = mean(rj_N);

        NMF_ITER(k,r) = info_NMF.iterations;
        NMF_CONV(k,r) = info_NMF.converged;
        NMF_SUMONE_MAE(k,r) = info_NMF.sumone_mae;
        NMF_FINAL_OBJ(k,r) = info_NMF.final_objective;
        NMF_REL_OBJ_CHANGE(k,r) = info_NMF.relative_objective_change;

        if ismember(ph,BOX_LEVELS)
            res_pix{miN,k} = [res_pix{miN,k}, rj_N];

            for j = 1:N
                fprintf(fid_res, ...
                    '%s,%d,%d,%d,%.10g\n', ...
                    METHODS{miN},ph,r,j,rj_N(j));
            end
        end

        fprintf(fid_acc, ...
            '%s,%d,%d,%.8g,%.10e,%.10e,%.10g,%.10g\n', ...
            METHODS{miN},ph,r, ...
            SAD_m(miN,k,r), ...
            MAB_m(miN,k,r), ...
            MRC_m(miN,k,r), ...
            RES_m(miN,k,r), ...
            T_m(miN,k,r));

        %% ---- Representative run --------------------------------------
        if r == 1 && ph == REP_PHOTON && ~rep_done

            rep_S_true = S_true;

            % Align blind methods to GT protein order.
            rep_PISCO = S_est_P(permP,:);
            rep_SISAL = S_est_S(permS,:);
            rep_RMVSA = S_est_R(permR,:);
            rep_NMF = S_est_N(permN,:);

            % Supervised methods already correspond to M_true order.
            rep_LU  = S_est_L;
            rep_HyU = S_est_H;

            rep_M_PISCO = M_est_P(:,permP);
            rep_M_SISAL = M_est_S(:,permS);
            rep_M_RMVSA = M_est_R(:,permR);
            rep_M_NMF = M_est_N(:,permN);

            rep_HyU_info = info_HyU;
            rep_NMF_info = info_NMF;

            rep_done = true;
        end

        %% ---- Console progress ----------------------------------------
        fprintf([ ...
            'run %2d/%d | ph=%3d | ' ...
            'PISCO SAD=%6.2f MSE=%8.3e | ' ...
            'LU MSE=%8.3e | ' ...
            'SISAL SAD=%6.2f MSE=%8.3e | ' ...
            'RMVSA SAD=%6.2f MSE=%8.3e | ' ...
            'HyU MSE=%8.3e bins=%4d comp=%.2fx | ' ...
            'NMF SAD=%6.2f MSE=%8.3e iter=%4d conv=%d\n'], ...
            r,N_RUNS,ph, ...
            SAD_m(miP,k,r), ...
            MAB_m(miP,k,r), ...
            MAB_m(miL,k,r), ...
            SAD_m(miS,k,r), ...
            MAB_m(miS,k,r), ...
            SAD_m(miR,k,r), ...
            MAB_m(miR,k,r), ...
            MAB_m(miH,k,r), ...
            info_HyU.n_occupied_bins, ...
            info_HyU.compression_ratio_valid_pixels_to_bins, ...
            SAD_m(miN,k,r), ...
            MAB_m(miN,k,r), ...
            info_NMF.iterations, ...
            info_NMF.converged);

    end
end

fclose(fid_acc);
fclose(fid_res);

fprintf('\nSaved per-run accuracy results:\n  %s\n',OUT_ACC_CSV);
fprintf('Saved per-pixel residuals:\n  %s\n',OUT_RES_CSV);

%% A.5 Save representative abundance CSV -------------------------------
if ~rep_done
    warning('Representative abundance result was not captured.');
else
    [row_id,col_id] = ...
        ind2sub([IMG_H,IMG_W],(1:N)');

    T_ab = table( ...
        (1:N)', row_id, col_id, ...
        rep_S_true(1,:)', rep_S_true(2,:)', ...
        rep_S_true(3,:)', rep_S_true(4,:)', ...
        rep_PISCO(1,:)', rep_PISCO(2,:)', ...
        rep_PISCO(3,:)', rep_PISCO(4,:)', ...
        rep_LU(1,:)', rep_LU(2,:)', ...
        rep_LU(3,:)', rep_LU(4,:)', ...
        rep_SISAL(1,:)', rep_SISAL(2,:)', ...
        rep_SISAL(3,:)', rep_SISAL(4,:)', ...
        rep_RMVSA(1,:)', rep_RMVSA(2,:)', ...
        rep_RMVSA(3,:)', rep_RMVSA(4,:)', ...
        rep_HyU(1,:)', rep_HyU(2,:)', ...
        rep_HyU(3,:)', rep_HyU(4,:)', ...
        rep_NMF(1,:)', rep_NMF(2,:)', ...
        rep_NMF(3,:)', rep_NMF(4,:)', ...
        'VariableNames',{ ...
        'pixel_id','row','col', ...
        'GT_Citrine','GT_tdTomato','GT_mKO2','GT_mRuby', ...
        'PISCO_Citrine','PISCO_tdTomato','PISCO_mKO2','PISCO_mRuby', ...
        'LU_Citrine','LU_tdTomato','LU_mKO2','LU_mRuby', ...
        'SISAL_Citrine','SISAL_tdTomato','SISAL_mKO2','SISAL_mRuby', ...
        'RMVSA_Citrine','RMVSA_tdTomato','RMVSA_mKO2','RMVSA_mRuby', ...
        'HyU_Citrine','HyU_tdTomato','HyU_mKO2','HyU_mRuby', ...
        'NMF_Citrine','NMF_tdTomato','NMF_mKO2','NMF_mRuby'});

    writetable(T_ab,OUT_ABUND_CSV);

    fprintf('Saved representative abundance data:\n  %s\n', ...
        OUT_ABUND_CSV);
end

%% A.6 Console summary -------------------------------------------------
fprintf('\n============================================================\n');
fprintf('E1 SUMMARY over %d repeats\n',N_RUNS);
fprintf('============================================================\n');

for m = 1:nM

    fprintf('\n[%s]\n',METHODS{m});

    for k = 1:nL

        mse_vec = squeeze(MAB_m(m,k,:));
        res_vec = squeeze(RES_m(m,k,:));
        tim_vec = squeeze(T_m(m,k,:));

        ci_mse = ci95(mse_vec);

        if m == miP || m == miS || m == miR || m == miN

            sad_vec = squeeze(SAD_m(m,k,:));
            ci_sad = ci95(sad_vec);

            fprintf([ ...
                'ph=%3d | SAD %.4f +/- %.4f [95%% CI +/- %.4f] | ' ...
                'MSE %.4e +/- %.4e [95%% CI +/- %.4e] | ' ...
                'res %.4f +/- %.4f | t %.4f +/- %.4f s\n'], ...
                PHOTON_GRID(k), ...
                mean_finite(sad_vec),std_finite(sad_vec),ci_sad, ...
                mean_finite(mse_vec),std_finite(mse_vec),ci_mse, ...
                mean_finite(res_vec),std_finite(res_vec), ...
                mean_finite(tim_vec),std_finite(tim_vec));

        else

            fprintf([ ...
                'ph=%3d | SAD N/A | ' ...
                'MSE %.4e +/- %.4e [95%% CI +/- %.4e] | ' ...
                'res %.4f +/- %.4f | t %.4f +/- %.4f s\n'], ...
                PHOTON_GRID(k), ...
                mean_finite(mse_vec),std_finite(mse_vec),ci_mse, ...
                mean_finite(res_vec),std_finite(res_vec), ...
                mean_finite(tim_vec),std_finite(tim_vec));
        end
    end
end

fprintf('\n[HyU compression diagnostics]\n');

for k = 1:nL
    fprintf([ ...
        'ph=%3d | occupied bins %.1f +/- %.1f | ' ...
        'compression %.3fx +/- %.3f | ' ...
        'pixels/occupied-bin %.3f +/- %.3f\n'], ...
        PHOTON_GRID(k), ...
        mean_finite(HYU_OCC_BINS(k,:)), ...
        std_finite(HYU_OCC_BINS(k,:)), ...
        mean_finite(HYU_COMPRESS(k,:)), ...
        std_finite(HYU_COMPRESS(k,:)), ...
        mean_finite(HYU_PIX_PER_BIN(k,:)), ...
        std_finite(HYU_PIX_PER_BIN(k,:)));
end

fprintf('\n[NMF convergence diagnostics]\n');

for k = 1:nL
    fprintf([ ...
        'ph=%3d | converged %d/%d | iter %.1f +/- %.1f | ' ...
        'sum1-MAE %.4e +/- %.4e | rel.obj.change %.3e +/- %.3e\n'], ...
        PHOTON_GRID(k), ...
        nnz(NMF_CONV(k,:)),N_RUNS, ...
        mean_finite(NMF_ITER(k,:)),std_finite(NMF_ITER(k,:)), ...
        mean_finite(NMF_SUMONE_MAE(k,:)),std_finite(NMF_SUMONE_MAE(k,:)), ...
        mean_finite(NMF_REL_OBJ_CHANGE(k,:)),std_finite(NMF_REL_OBJ_CHANGE(k,:)));
end

%% A.7 Figure 1: SAD vs photon -----------------------------------------
% Blind endmember-estimation methods: PISCO, SISAL, RMVSA and NMF.

clrP = [0.85 0.33 0.10];
clrL = [0.00 0.45 0.74];
clrS = [0.47 0.67 0.19];
clrR = [0.64 0.08 0.18];
clrH = [0.49 0.18 0.56];
clrN = [0.30 0.75 0.93];

figure( ...
    'Name','E1: SAD PISCO vs SISAL vs RMVSA vs NMF', ...
    'Position',[80 80 780 420], ...
    'Color','w');

hold on;

% PISCO.
X = squeeze(SAD_m(miP,:,:));
[mu,ci] = row_mean_ci95(X);

fill( ...
    [PHOTON_GRID,fliplr(PHOTON_GRID)], ...
    [(mu-ci)',fliplr((mu+ci)')], ...
    clrP, ...
    'FaceAlpha',0.18, ...
    'EdgeColor','none');

plot( ...
    PHOTON_GRID,mu,'o-', ...
    'LineWidth',1.5, ...
    'MarkerSize',6, ...
    'Color',clrP);

% SISAL.
X = squeeze(SAD_m(miS,:,:));
[mu,ci] = row_mean_ci95(X);

fill( ...
    [PHOTON_GRID,fliplr(PHOTON_GRID)], ...
    [(mu-ci)',fliplr((mu+ci)')], ...
    clrS, ...
    'FaceAlpha',0.18, ...
    'EdgeColor','none');

plot( ...
    PHOTON_GRID,mu,'s-', ...
    'LineWidth',1.5, ...
    'MarkerSize',6, ...
    'Color',clrS);

% RMVSA.
X = squeeze(SAD_m(miR,:,:));
[mu,ci] = row_mean_ci95(X);

fill( ...
    [PHOTON_GRID,fliplr(PHOTON_GRID)], ...
    [(mu-ci)',fliplr((mu+ci)')], ...
    clrR, ...
    'FaceAlpha',0.18, ...
    'EdgeColor','none');

plot( ...
    PHOTON_GRID,mu,'d-', ...
    'LineWidth',1.5, ...
    'MarkerSize',6, ...
    'Color',clrR);

% NMF.
X = squeeze(SAD_m(miN,:,:));
[mu,ci] = row_mean_ci95(X);

fill( ...
    [PHOTON_GRID,fliplr(PHOTON_GRID)], ...
    [(mu-ci)',fliplr((mu+ci)')], ...
    clrN, ...
    'FaceAlpha',0.18, ...
    'EdgeColor','none');

plot( ...
    PHOTON_GRID,mu,'v-', ...
    'LineWidth',1.5, ...
    'MarkerSize',6, ...
    'Color',clrN);

set(gca,'XScale','log');

xlabel('Photons per spectrum');
ylabel('Endmember SAD (deg)');
title(sprintf('SAD comparison (n = %d, 95%% CI)',N_RUNS));
legend({'PISCO 95% CI','PISCO', ...
        'SISAL 95% CI','SISAL', ...
        'RMVSA 95% CI','RMVSA', ...
        'NMF 95% CI','NMF'}, ...
    'Location','best');
grid on;

%% A.8 Figure 2: Abundance MSE vs photon -------------------------------
figure( ...
    'Name','E1: Abundance MSE comparison', ...
    'Position',[100 100 820 450], ...
    'Color','w');

hold on;

plot_method_ci( ...
    PHOTON_GRID, ...
    squeeze(MAB_m(miP,:,:)), ...
    clrP,'o','PISCO',N_RUNS);

plot_method_ci( ...
    PHOTON_GRID, ...
    squeeze(MAB_m(miL,:,:)), ...
    clrL,'^','LU',N_RUNS);

plot_method_ci( ...
    PHOTON_GRID, ...
    squeeze(MAB_m(miS,:,:)), ...
    clrS,'s','SISAL',N_RUNS);

plot_method_ci( ...
    PHOTON_GRID, ...
    squeeze(MAB_m(miR,:,:)), ...
    clrR,'d','RMVSA',N_RUNS);

plot_method_ci( ...
    PHOTON_GRID, ...
    squeeze(MAB_m(miH,:,:)), ...
    clrH,'d','HyU',N_RUNS);

plot_method_ci( ...
    PHOTON_GRID, ...
    squeeze(MAB_m(miN,:,:)), ...
    clrN,'v','NMF',N_RUNS);

set(gca,'XScale','log','YScale','log');

xlabel('Photons per spectrum');
ylabel('Abundance MSE');
title(sprintf('Abundance MSE comparison (n = %d, 95%% CI)',N_RUNS));

% Only show line handles in the legend.
hline = findobj(gca,'Type','Line');
legend(flipud(hline), ...
    {'PISCO','LU','SISAL','RMVSA','HyU','NMF'}, ...
    'Location','best');

grid on;

%% A.9 Figures 3-8: separate residual boxplots -------------------------
for m = 1:nM

    figure( ...
        'Name',sprintf('E1: %s residual boxplot',METHODS{m}), ...
        'Position',[140 140 560 430], ...
        'Color','w');

    bx = [];
    bg = [];
    labels = {};
    group_id = 0;

    for k = 1:nL

        ph = PHOTON_GRID(k);

        if ismember(ph,BOX_LEVELS) && ~isempty(res_pix{m,k})

            group_id = group_id + 1;

            vals = res_pix{m,k};

            bx = [bx,vals]; %#ok<AGROW>
            bg = [bg,group_id*ones(size(vals))]; %#ok<AGROW>

            labels{end+1} = num2str(ph); %#ok<AGROW>
        end
    end

    if isempty(bx)
        axis off;
        text(0.5,0.5, ...
            '(no saved residual boxplot levels)', ...
            'HorizontalAlignment','center');
    else
        boxplot(bx,bg,'Labels',labels);

        xlabel('Photons per spectrum');
        ylabel('Relative residual');

        title(sprintf('%s per-pixel residual',METHODS{m}));

        grid on;
    end
end

%% A.10 Representative abundance maps: 7 x 4 ---------------------------
if rep_done

    figure( ...
        'Name',sprintf( ...
            'E1 abundance maps at %d photons, run 1', ...
            REP_PHOTON), ...
        'Position',[20 20 1150 1150], ...
        'Color','w');

    row_names = { ...
        'GT', ...
        'PISCO', ...
        'LU', ...
        'SISAL', ...
        'RMVSA', ...
        'HyU', ...
        'NMF'};

    map_rows = { ...
        rep_S_true, ...
        rep_PISCO, ...
        rep_LU, ...
        rep_SISAL, ...
        rep_RMVSA, ...
        rep_HyU, ...
        rep_NMF};

    for rr = 1:7

        A = map_rows{rr};

        for i = 1:p

            subplot(7,p,(rr-1)*p+i);

            imagesc( ...
                reshape(A(i,:),IMG_H,IMG_W));

            caxis([0 0.8]);

            axis image off;
            colorbar;

            title(sprintf( ...
                '%s %s', ...
                row_names{rr}, ...
                char(endmember_names{i})));
        end
    end

    sgtitle(sprintf([ ...
        'Representative abundances at %d photons/spectrum, run 1 ' ...
        '(shared color scale [0, 0.8])'], ...
        REP_PHOTON));
end

%% A.11 Save complete MAT for later plotting ---------------------------
plotdata = struct();

plotdata.METHODS = METHODS;
plotdata.PHOTON_GRID = PHOTON_GRID;
plotdata.BOX_LEVELS = BOX_LEVELS;
plotdata.N_RUNS = N_RUNS;

plotdata.IMG_H = IMG_H;
plotdata.IMG_W = IMG_W;
plotdata.REP_PHOTON = REP_PHOTON;

plotdata.endmember_names = endmember_names;
plotdata.wl = wl;

plotdata.SAD_m = SAD_m;
plotdata.MAB_m = MAB_m;
plotdata.MRC_m = MRC_m;
plotdata.RES_m = RES_m;
plotdata.T_m = T_m;

plotdata.res_pix = res_pix;

plotdata.RMVSA_ALPHA = RMVSA_ALPHA;
plotdata.RMVSA_MM_ITERS = RMVSA_MM_ITERS;
plotdata.RMVSA_NOISE = RMVSA_NOISE;

plotdata.HYU_HARMONIC = HYU_HARMONIC;
plotdata.HYU_NBINS = HYU_NBINS;
plotdata.HYU_VARIANT = HYU_VARIANT;

plotdata.HYU_OCC_BINS = HYU_OCC_BINS;
plotdata.HYU_COMPRESS = HYU_COMPRESS;
plotdata.HYU_PIX_PER_BIN = HYU_PIX_PER_BIN;

plotdata.NMF_MAX_ITER = NMF_MAX_ITER;
plotdata.NMF_MIN_ITER = NMF_MIN_ITER;
plotdata.NMF_TOL_REL_OBJ = NMF_TOL_REL_OBJ;
plotdata.NMF_CHECK_EVERY = NMF_CHECK_EVERY;
plotdata.NMF_ITER = NMF_ITER;
plotdata.NMF_CONV = NMF_CONV;
plotdata.NMF_SUMONE_MAE = NMF_SUMONE_MAE;
plotdata.NMF_FINAL_OBJ = NMF_FINAL_OBJ;
plotdata.NMF_REL_OBJ_CHANGE = NMF_REL_OBJ_CHANGE;

plotdata.rep_done = rep_done;

plotdata.rep_S_true = rep_S_true;
plotdata.rep_PISCO = rep_PISCO;
plotdata.rep_LU = rep_LU;
plotdata.rep_SISAL = rep_SISAL;
plotdata.rep_RMVSA = rep_RMVSA;
plotdata.rep_HyU = rep_HyU;
plotdata.rep_NMF = rep_NMF;

plotdata.rep_M_PISCO = rep_M_PISCO;
plotdata.rep_M_SISAL = rep_M_SISAL;
plotdata.rep_M_RMVSA = rep_M_RMVSA;
plotdata.rep_M_NMF = rep_M_NMF;
plotdata.rep_HyU_info = rep_HyU_info;
plotdata.rep_NMF_info = rep_NMF_info;

plotdata.OUT_ACC_CSV = OUT_ACC_CSV;
plotdata.OUT_RES_CSV = OUT_RES_CSV;
plotdata.OUT_ABUND_CSV = OUT_ABUND_CSV;

save(OUT_MAT,'plotdata','-v7.3');

fprintf('\nSaved complete plotting MAT:\n  %s\n',OUT_MAT);

%% ==================== Local functions ================================

function [perm,sad_v] = e1_match(M_true,M_est)
% Greedy endmember matching by spectral angle distance.

p = size(M_true,2);

Cmat = zeros(p,p);

for i = 1:p
    for j = 1:p

        den = norm(M_true(:,i)) * ...
              norm(M_est(:,j));

        if den <= eps
            Cmat(i,j) = 180;
        else
            cc = (M_true(:,i)'*M_est(:,j)) / den;
            cc = max(-1,min(1,cc));
            Cmat(i,j) = acosd(cc);
        end
    end
end

perm = zeros(1,p);
taken = false(1,p);

for i = 1:p

    tmp = Cmat(i,:) + ...
          1e6*double(taken);

    [~,jj] = min(tmp);

    perm(i) = jj;
    taken(jj) = true;
end

sad_v = Cmat( ...
    sub2ind([p p],1:p,perm));

end


function [sad,mse_ab,mse_rec] = ...
    e1_metrics( ...
        M_true,S_true,Y_clean, ...
        M_est,S_est,perm)

% SAD after matching.
sad_v = zeros(1,numel(perm));

for i = 1:numel(perm)

    den = norm(M_true(:,i)) * ...
          norm(M_est(:,perm(i)));

    if den <= eps
        sad_v(i) = 180;
    else
        cc = (M_true(:,i)'*M_est(:,perm(i))) / den;
        cc = max(-1,min(1,cc));
        sad_v(i) = acosd(cc);
    end
end

sad = mean(sad_v);

% Abundance MSE after matching.
S_aligned = S_est(perm,:);

mse_ab = ...
    mean((S_true(:)-S_aligned(:)).^2);

% Noise-free reconstruction MSE.
Yhat = M_est * S_est;

mse_rec = ...
    mean((Y_clean(:)-Yhat(:)).^2);

end


function rj = e1_relative_residual(Y,Yhat)
% Per-pixel measured-data relative residual.

num = sqrt(sum((Y-Yhat).^2,1));
den = max(sqrt(sum(Y.^2,1)),eps);

rj = num ./ den;

end


function S = ratio_to_original_coeff(R,M_colsum,p)
% Convert LU/HyU ratios obtained using unit-sum spectral fingerprints
% back to the coefficient convention of the original peak-normalized
% M_true used to synthesize Y_clean.

S = R ./ M_colsum(:);

denom = sum(S,1);

good = isfinite(denom) & ...
       abs(denom) > eps;

S(:,good) = ...
    S(:,good) ./ denom(good);

S(:,~good) = 1/p;

end


function S = e1_fcls_exact(M,Y)
% Exact FCLS for small p by active-set support enumeration.

[~,p] = size(M);
N = size(Y,2);

S = zeros(p,N);
best_err = inf(1,N);

tol = 1e-10;

for mask = 1:(2^p-1)

    idx = find(bitget(mask,1:p));
    q = numel(idx);

    Ma = M(:,idx);

    K = [ ...
        Ma'*Ma, ones(q,1); ...
        ones(1,q), 0];

    RHS = [ ...
        Ma'*Y; ...
        ones(1,N)];

    if rcond(K) > 1e-12
        sol = K \ RHS;
    else
        sol = pinv(K) * RHS;
    end

    Sa = sol(1:q,:);

    feasible = all(Sa >= -tol,1);

    Sa(abs(Sa) < tol) = 0;

    Sa_pos = max(Sa,0);

    denom = sum(Sa_pos,1);

    valid = feasible & ...
            denom > eps;

    if ~any(valid)
        continue;
    end

    Sa_pos(:,valid) = ...
        Sa_pos(:,valid) ./ denom(valid);

    Yhat = Ma * Sa_pos;

    err = sum((Y-Yhat).^2,1);

    update = valid & ...
             err < best_err;

    if any(update)

        S(:,update) = 0;

        S(idx,update) = ...
            Sa_pos(:,update);

        best_err(update) = ...
            err(update);
    end
end

bad = ~isfinite(best_err);

if any(bad)
    S(:,bad) = 1/p;
end

end


function [mu,ci] = row_mean_ci95(X)
% Row-wise mean and approximate 95% CI ignoring nonfinite entries.

nrow = size(X,1);

mu = nan(nrow,1);
ci = nan(nrow,1);

for i = 1:nrow

    x = X(i,:);
    x = x(isfinite(x));

    if isempty(x)
        continue;
    end

    mu(i) = mean(x);

    if numel(x) == 1
        ci(i) = 0;
    else
        ci(i) = ...
            1.96*std(x,0) / ...
            sqrt(numel(x));
    end
end

end


function plot_method_ci( ...
    xgrid,X,clr,marker,label_text,N_RUNS)
% Plot mean +/- approximate 95% CI for one method.

[mu,ci] = row_mean_ci95(X);

lowb = max(mu-ci,realmin);
highb = mu+ci;

fill( ...
    [xgrid,fliplr(xgrid)], ...
    [lowb',fliplr(highb')], ...
    clr, ...
    'FaceAlpha',0.18, ...
    'EdgeColor','none', ...
    'HandleVisibility','off');

plot( ...
    xgrid,mu, ...
    [marker '-'], ...
    'LineWidth',1.5, ...
    'MarkerSize',6, ...
    'Color',clr, ...
    'DisplayName',label_text);

% Keep parameter explicit in signature because the plotted CI depends on
% the number of runs represented by X.
if N_RUNS < 1
    error('N_RUNS must be positive.');
end

end


function y = mean_finite(x)

x = x(isfinite(x));

if isempty(x)
    y = NaN;
else
    y = mean(x);
end

end


function y = std_finite(x)

x = x(isfinite(x));

if numel(x) <= 1
    y = 0;
else
    y = std(x,0);
end

end


function y = ci95(x)

x = x(isfinite(x));

if isempty(x)
    y = NaN;
elseif numel(x) == 1
    y = 0;
else
    y = 1.96*std(x,0) / ...
        sqrt(numel(x));
end

end
