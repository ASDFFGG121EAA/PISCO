%% demo_pisco_E2_scalability_one_method_workspace.m
% E2 scalability benchmark: run ONE method per MATLAB execution.
%
% Manual method selection:
%   RUN_METHOD = 'PISCO';
%   RUN_METHOD = 'SISAL';
%   RUN_METHOD = 'RMVSA';
%
% IMPORTANT:
%   This script intentionally does NOT run PISCO and SISAL sequentially.
%   The selected method is the only model executed in the Monte-Carlo loop.
%
% MEMORY-MEASUREMENT NOTE:
%   peak_workspace_MB records local optimization workspace arrays.
%   It measures tile-level activation/workspace memory during optimization,
%   not the MATLAB process RSS. This corresponds to the tile-memory claim
%   O(B*p+p^2), independent of total pixel number N.
%
% The model calls, simulation protocol, metrics and memory definition are
% otherwise kept the same as demo_pisco_E2_scalability_with_SISAL.m.
%
% Required on MATLAB path:
%   pisco_e2_train_workspace.m
%   sisal.m
%   rmvsa_LiAlex22_workspace.m
%   build_Strue_from_masks.m
%   estNoise.m
%   VCA.m / hinge.m / soft_neg.m if required by SISAL/RMVSA
%   PISCO_M_32x4_HyU_strict_quasar32.mat
%
% MATLAB R2023a or later recommended.

clear all; close all; clc;

%% E2.0 Protocol ---------------------------------------------------------
QUICK     = false;
N_RUNS    = 30;
BASE_SEED = 42;

% ========================================================================
% MANUALLY SELECT EXACTLY ONE MODEL HERE
% Options:
%   'PISCO'
%   'SISAL'
%   'RMVSA'
% ========================================================================
RUN_METHOD = 'PISCO';

% Select ONE E2 scale here. For the full E2 table, rerun at each requested
% SIZE in a FRESH MATLAB process when measuring process peak memory.
SIZE      = 2000;      % SIZE x SIZE pixels; e.g. 1000 -> N = 1e6
PHOTONS   = 20;       % mean photons per channel
READ_SIG  = 1.0;      % Gaussian readout noise in counts

% PISCO settings.
TILE      = 256;
MM_ITERS  = 2500;
WARM_UP   = 600;

% SISAL settings copied from the E1 unified comparison.
SISAL_MM_ITERS = 40;
SISAL_TAU      = 1;

% RMVSA settings.
% RMVSA_ALPHA controls the chance-constraint margin in rmvsa_LiAlex22_workspace.
% Keep this value identical across all E2 scales/runs.
RMVSA_MM_ITERS = 10;
RMVSA_ALPHA    = 1;

% Same FPbase / Quasar-32 spectral file used by E1.
M_FILE = 'PISCO_M_32x4_HyU_strict_quasar32.mat';

% Biological-mask abundance settings: same protocol as the E1 biomask demo.
% Expected folder layout:
%   <this script>/use/<scene_name>/masks/*.png
%   <this script>/use/<scene_name>/images/*    (not used numerically)
THIS_SCRIPT = mfilename('fullpath');
SCRIPT_DIR = fileparts(THIS_SCRIPT);
if isempty(SCRIPT_DIR)
    SCRIPT_DIR = pwd;
end
MASK_ROOT       = fullfile(SCRIPT_DIR,'use');
MASK_SIGMA      = 2.0;    % Gaussian smoothing sigma in target-image pixels
MASK_BACKGROUND = 0.02;   % positive floor before sum-to-one normalization
MAX_PURITY      = 0.8;

if QUICK
    SIZE = 128;
    N_RUNS = 2;
    TILE = 64;
    MM_ITERS = 800;
    WARM_UP = 200;
end

RUN_METHOD = upper(strtrim(char(RUN_METHOD)));

if ~ismember(RUN_METHOD, {'PISCO','SISAL','RMVSA'})
    error('RUN_METHOD must be ''PISCO'', ''SISAL'', or ''RMVSA''.');
end

IMG_H = SIZE;
IMG_W = SIZE;
N = IMG_H * IMG_W;

% Discover usable biological scenes. Only masks/*.png are used.
if ~isfolder(MASK_ROOT)
    error(['Cannot find biological-mask root folder:\n  %s\n' ...
           'Expected ./use/<scene_name>/masks/*.png next to this script.'], ...
          MASK_ROOT);
end

Dscene = dir(MASK_ROOT);
Dscene = Dscene([Dscene.isdir]);
Dscene = Dscene(~ismember({Dscene.name},{'.','..'}));

scene_dirs = {};
for ii = 1:numel(Dscene)
    candidate = fullfile(MASK_ROOT,Dscene(ii).name);
    mask_dir = fullfile(candidate,'masks');
    if isfolder(mask_dir) && ~isempty(dir(fullfile(mask_dir,'*.png')))
        scene_dirs{end+1} = candidate; %#ok<SAGROW>
    end
end

if isempty(scene_dirs)
    error(['No usable biological scenes were found under:\n  %s\n' ...
           'Each scene must contain masks/*.png.'],MASK_ROOT);
end

[~,ord_scene] = sort(lower(string(scene_dirs)));
scene_dirs = scene_dirs(ord_scene);
nScenes = numel(scene_dirs);

if QUICK
    OUT_CSV = sprintf('E_E2_%s_quick_N%d_results.csv',RUN_METHOD,N);
else
    OUT_CSV = sprintf('E_E2_%s_N%d_results.csv',RUN_METHOD,N);
end

%% E2.1 Load real FPbase endmember spectra ------------------------------
if ~isfile(M_FILE)
    error(['Cannot find %s.\n' ...
           'Put the MAT file in the same folder as this script or set M_FILE.'], ...
          M_FILE);
end

Dspec = load(M_FILE);

if ~isfield(Dspec,'M')
    error('%s does not contain variable M.',M_FILE);
end

M_true = double(Dspec.M);
[L,p] = size(M_true);

if L ~= 32 || p ~= 4
    error('Expected M_true to be 32 x 4, got %d x %d.',L,p);
end

if any(~isfinite(M_true(:))) || any(M_true(:) < 0)
    error('M_true must contain finite nonnegative values.');
end

if isfield(Dspec,'channel_centers_nm')
    wl = double(Dspec.channel_centers_nm(:));
    if numel(wl) ~= L
        error('channel_centers_nm must contain %d values.',L);
    end
else
    wl = linspace(410.5,694.9,L)';
end

if isfield(Dspec,'endmember_names')
    endmember_names = Dspec.endmember_names; %#ok<NASGU>
else
    endmember_names = {'Citrine','tdTomato','mKO2','mRuby'}; %#ok<NASGU>
end

clear Dspec;

fprintf('============================================================\n');
fprintf('E2 scalability benchmark: ONE METHOD PER EXECUTION\n');
fprintf('============================================================\n');
fprintf('Selected method: %s\n',RUN_METHOD);
fprintf('Loaded spectral file: %s\n',M_FILE);
fprintf('M_true: %d channels x %d endmembers\n',L,p);
fprintf('N = %d x %d = %d pixels | photons/channel = %g | repeats = %d\n', ...
    IMG_H,IMG_W,N,PHOTONS,N_RUNS);
fprintf('Estimated raw cube size: %.1f MB (L x N doubles)\n',L*N*8/1e6);
fprintf('Biological mask pool: %d usable scenes under %s\n',nScenes,MASK_ROOT);
fprintf('Biomask abundance: sigma=%.2f | background=%.3f | max purity=%.2f\n', ...
    MASK_SIGMA,MASK_BACKGROUND,MAX_PURITY);

switch RUN_METHOD
    case 'PISCO'
        fprintf('PISCO: tile = %d x %d | MM_ITERS = %d | WARM_UP = %d\n', ...
            TILE,TILE,MM_ITERS,WARM_UP);
    case 'SISAL'
        fprintf('SISAL: MM_ITERS = %d | TAU = %g\n', ...
            SISAL_MM_ITERS,SISAL_TAU);
    case 'RMVSA'
        fprintf('RMVSA: MM_ITERS = %d | ALPHA = %g | noise covariance = estNoise(...,''poisson'')\n', ...
            RMVSA_MM_ITERS,RMVSA_ALPHA);
end

fprintf('Output CSV: %s\n',OUT_CSV);
fprintf(['IMPORTANT: restart MATLAB before switching RUN_METHOD if peak RSS ' ...
         'will be compared.\n']);
fprintf('============================================================\n\n');

%% E2.2 Allocate results -------------------------------------------------
SAD_m = nan(1,N_RUNS);
MAB_m = nan(1,N_RUNS);
MRC_m = nan(1,N_RUNS);
MEM_ws = nan(1,N_RUNS);
T_tot  = nan(1,N_RUNS);

% PISCO-specific phase times. They remain NaN for SISAL.
T_pre = nan(1,N_RUNS);
T_wrm = nan(1,N_RUNS);
T_jnt = nan(1,N_RUNS);
T_inf = nan(1,N_RUNS);

% First-repeat results for inspection of the selected model only.
r1_M = [];
r1_S = [];
r1_perm = [];
r1_loss = [];
r1_S_true = [];

%% E2.3 Open method-specific CSV ----------------------------------------
fid = fopen(OUT_CSV,'w');

if fid < 0
    error('Cannot open %s for writing.',OUT_CSV);
end

fprintf(fid,[ ...
    'method,run,N,img_h,img_w,tile,photons,read_sigma,' ...
    'peak_workspace_MB,' ...
    't_pre_s,t_warm_s,t_joint_s,t_infer_s,t_total_s,' ...
    'SAD_deg,MSE_ab,MSE_rec,status\n']);

%% E2.4 Monte-Carlo loop -------------------------------------------------
for r = 1:N_RUNS

    %% ---- Biological-mask scene + noise -------------------------------
    % Same biological-mask generation protocol as the E1 biomask benchmark:
    % cycle deterministically through ./use/<scene>/masks, resize all instance
    % masks to the current E2 SIZE, randomly/evenly assign instances to p
    % groups, union within each group, smooth, add a positive background,
    % normalize to sum-to-one, then impose max purity <= 0.8.
    scene_idx = 1 + mod(r-1,nScenes);
    scene_dir = scene_dirs{scene_idx};

    S_true = build_Strue_from_masks( ...
        scene_dir,IMG_H,IMG_W,p,MAX_PURITY, ...
        BASE_SEED + r,MASK_SIGMA,MASK_BACKGROUND);

    Y_clean = M_true * S_true;

    % Use a separate deterministic RNG stream for measurement noise so mask
    % grouping never changes the Poisson/Gaussian realization for this run.
    rng(BASE_SEED + 10000 + r,'twister');

    % Same photon convention as E1:
    % PHOTONS = mean photons per channel.
    g = PHOTONS * N / sum(Y_clean(:)) * L;

    Y_in = double( ...
        poissrnd(g*Y_clean) + ...
        READ_SIG*randn(L,N)) / g;

    %% ---- Run exactly ONE selected model ------------------------------
    switch RUN_METHOD

        case 'PISCO'
            % Same PISCO initialization seed as the original combined file.
            rng(BASE_SEED + 100000 + r,'twister');

            status = 'OK';

            try
                t_run = tic;

                [M_est,S_est,info_P] = pisco_e2_train_workspace_full_weightedaccum_adam_3(Y_in,p, ...
                    'IMG_H',IMG_H,'IMG_W',IMG_W,'TILE',TILE, ...
                    'MM_ITERS',MM_ITERS,'WARM_UP',WARM_UP,'LR',3e-4, ...
                    'LAMBDA_VOL',0.008, ...
                    'LAMBDA_NONNEG',3, ...
                    'LAMBDA_EQ',100, ...
                    'LAMBDA_SUMONE',2, ...
                    'LAMBDA_ENCLOSE',10, ...
                    'LAMBDA_SPATIAL',2, ...
                    'LAMBDA_MNONNEG',10, ...
                    'LAMBDA_SMOOTH',0.1, ...
                    'ETA',0.4, ...
                    'ETA_END',0.4, ...
                    ... % SIGMA_CAP intentionally NOT overridden: trainer default = 0.1
                    'PHOTON_GAIN',g, ...
                    'PHOTON_FLOOR',1, ...
                    'READ_SIGMA',READ_SIG, ...
                    'verbose',0, ...
                    'LOSS_EVERY',100);

                T_tot(r) = toc(t_run);
                MEM_ws(r) = info_P.peak_workspace_MB;

                [SAD_m(r),MAB_m(r),MRC_m(r)] = e2_metrics( ...
                    M_true,S_true,Y_clean,M_est,S_est);

                T_pre(r) = info_P.t_pre;
                T_wrm(r) = info_P.t_warm;
                T_jnt(r) = info_P.t_joint;
                T_inf(r) = info_P.t_infer;

                if r == 1
                    r1_M = M_est;
                    r1_S = S_est;
                    r1_perm = e2_match(M_true,M_est);
                    r1_loss = info_P.loss_trace;
                    r1_S_true = S_true;
                end

                fprintf([ ...
                    'run %2d/%d | PISCO | workspace %.3f MB | ' ...
                    't %.2fs | SAD %.3f | MSE_ab %.3e | MSE_rec %.3e\n'], ...
                    r,N_RUNS, ...
                    MEM_ws(r), ...
                    T_tot(r),SAD_m(r),MAB_m(r),MRC_m(r));

            catch ME
                if is_memory_error(ME)
                    status = 'OOM';
                    warning('PISCO OOM at run %d, N=%d: %s',r,N,ME.message);
                else
                    status = sprintf('ERROR:%s',sanitize_csv_text(ME.identifier));
                    warning('PISCO failed at run %d: %s',r,ME.message);
                end
            end

            fprintf(fid,['PISCO,%d,%d,%d,%d,%d,%.10g,%.10g,' ...
                '%.10g,%.10g,%.10g,%.10g,%.10g,%.10g,' ...
                '%.10g,%.10e,%.10e,%s\n'], ...
                r,N,IMG_H,IMG_W,TILE,PHOTONS,READ_SIG, ...
                MEM_ws(r), ...
                T_pre(r),T_wrm(r),T_jnt(r),T_inf(r),T_tot(r), ...
                SAD_m(r),MAB_m(r),MRC_m(r),status);

            clear M_est S_est info_P

        case 'RMVSA'
            % Same RMVSA initialization seed on every E2 scale/repeat.
            rng(BASE_SEED + 300000 + r,'twister');

            status = 'OK';

            try
                t_run = tic;

                % Estimate the noise covariance directly from the noisy cube.
                % estNoise returns w (LxN) and Rwww (LxL); RMVSA uses Rwww.
                % Included in RMVSA total wall time because it is a required input.
                [~,Rwww] = estNoise(Y_in,'poisson','off');

                [M_est,S_est,~,~,~,info_R] = rmvsa_LiAlex22_workspace( ...
                    Y_in,p,RMVSA_ALPHA,Rwww, ...
                    'MM_ITERS',RMVSA_MM_ITERS, ...
                    'spherize','yes', ...
                    'verbose',0);

                T_tot(r) = toc(t_run);
                MEM_ws(r) = info_R.peak_workspace_MB;

                [SAD_m(r),MAB_m(r),MRC_m(r)] = e2_metrics( ...
                    M_true,S_true,Y_clean,M_est,S_est);

                if r == 1
                    r1_M = M_est;
                    r1_S = S_est;
                    r1_perm = e2_match(M_true,M_est);
                    r1_S_true = S_true;
                end

                fprintf([ ...
                    'run %2d/%d | RMVSA | workspace %.3f MB | ' ...
                    't %.2fs | SAD %.3f | MSE_ab %.3e | MSE_rec %.3e\n'], ...
                    r,N_RUNS, ...
                    MEM_ws(r), ...
                    T_tot(r),SAD_m(r),MAB_m(r),MRC_m(r));

            catch ME
                if is_memory_error(ME)
                    status = 'OOM';
                    warning('RMVSA OOM at run %d, N=%d: %s',r,N,ME.message);
                else
                    status = sprintf('ERROR:%s',sanitize_csv_text(ME.identifier));
                    warning('RMVSA failed at run %d: %s',r,ME.message);
                end
            end

            % RMVSA has no PISCO-like phase timings.
            fprintf(fid,['RMVSA,%d,%d,%d,%d,%d,%.10g,%.10g,' ...
                '%.10g,NaN,NaN,NaN,NaN,%.10g,' ...
                '%.10g,%.10e,%.10e,%s\n'], ...
                r,N,IMG_H,IMG_W,TILE,PHOTONS,READ_SIG, ...
                MEM_ws(r), ...
                T_tot(r),SAD_m(r),MAB_m(r),MRC_m(r),status);

            clear M_est S_est info_R Rwww

        case 'SISAL'
            % Same SISAL initialization seed as the original combined file.
            rng(BASE_SEED + 200000 + r,'twister');

            status = 'OK';

            try
                t_run = tic;

               % A_est = sisal(Y_in,p, ...
                %    'spherize','yes', ...
                 %   'MM_ITERS',SISAL_MM_ITERS, ...
                 %   'TAU',SISAL_TAU, ...
                 %   'verbose',0);
                [A_est,~,~,~,info_S] = sisal_workspace(Y_in,p, ...
                     'spherize','yes', ...
                     'MM_ITERS',SISAL_MM_ITERS, ...
                      'TAU',SISAL_TAU, ...
                      'verbose',0);

                M_est = double(A_est);

                % Exact FCLS is part of SISAL's total wall time, matching E1.
                S_est = e2_fcls_exact(M_est,Y_in);

                T_tot(r) = toc(t_run);
                MEM_ws(r) = info_S.peak_workspace_MB;

                [SAD_m(r),MAB_m(r),MRC_m(r)] = e2_metrics( ...
                    M_true,S_true,Y_clean,M_est,S_est);

                if r == 1
                    r1_M = M_est;
                    r1_S = S_est;
                    r1_perm = e2_match(M_true,M_est);
                    r1_S_true = S_true;
                end

                fprintf([ ...
                    'run %2d/%d | SISAL | workspace %.3f MB | ' ...
                    't %.2fs | SAD %.3f | MSE_ab %.3e | MSE_rec %.3e\n'], ...
                    r,N_RUNS, ...
                    MEM_ws(r), ...
                    T_tot(r),SAD_m(r),MAB_m(r),MRC_m(r));

            catch ME
                if is_memory_error(ME)
                    status = 'OOM';
                    warning('SISAL OOM at run %d, N=%d: %s',r,N,ME.message);
                else
                    status = sprintf('ERROR:%s',sanitize_csv_text(ME.identifier));
                    warning('SISAL failed at run %d: %s',r,ME.message);
                end
            end

            % SISAL has no PISCO-like phase timings.
            fprintf(fid,['SISAL,%d,%d,%d,%d,%d,%.10g,%.10g,' ...
                '%.10g,NaN,NaN,NaN,NaN,%.10g,' ...
                '%.10g,%.10e,%.10e,%s\n'], ...
                r,N,IMG_H,IMG_W,TILE,PHOTONS,READ_SIG, ...
                MEM_ws(r), ...
                T_tot(r),SAD_m(r),MAB_m(r),MRC_m(r),status);

            clear A_est M_est S_est
    end

    % Release large per-repeat arrays before generating the next repeat.
    clear Y_in Y_clean S_true
end

fclose(fid);

%% E2.5 Summary for selected method -------------------------------------
fprintf('\n============================================================\n');
fprintf('E2 SUMMARY | %s | N = %d | %d repeats | mean +/- std\n', ...
    RUN_METHOD,N,N_RUNS);
fprintf('============================================================\n');

fprintf('Peak local workspace (MB): %.4f +/- %.4f\n', ...
    mean_finite(MEM_ws),std_finite(MEM_ws));

fprintf('Wall time (s)    : %.3f +/- %.3f\n', ...
    mean_finite(T_tot),std_finite(T_tot));

fprintf('SAD (deg)        : %.4f +/- %.4f\n', ...
    mean_finite(SAD_m),std_finite(SAD_m));

fprintf('MSE_abundance    : %.6e +/- %.6e\n', ...
    mean_finite(MAB_m),std_finite(MAB_m));

fprintf('MSE_recon        : %.6e +/- %.6e\n', ...
    mean_finite(MRC_m),std_finite(MRC_m));

if strcmp(RUN_METHOD,'PISCO')
    fprintf('\n[PISCO phase times]\n');
    fprintf('pre   : %.3f +/- %.3f s\n', ...
        mean_finite(T_pre),std_finite(T_pre));
    fprintf('warm  : %.3f +/- %.3f s\n', ...
        mean_finite(T_wrm),std_finite(T_wrm));
    fprintf('joint : %.3f +/- %.3f s\n', ...
        mean_finite(T_jnt),std_finite(T_jnt));
    fprintf('infer : %.3f +/- %.3f s\n', ...
        mean_finite(T_inf),std_finite(T_inf));
end

fprintf('\nCSV written to: %s\n',OUT_CSV);

%% E2.6 First-repeat inspection for selected method ---------------------
if ~isempty(r1_S_true)

    if strcmp(RUN_METHOD,'PISCO')
        figure('Name','E2 first-repeat PISCO', ...
               'Position',[40 40 1200 650]);

        subplot(2,4,1);
        if ~isempty(r1_loss) && size(r1_loss,1) > 1
            plot(r1_loss(:,1),r1_loss(:,2),'LineWidth',1.2);
        end
        xlabel('Iteration');
        ylabel('Objective');
        grid on;
        title('PISCO training curve');

        subplot(2,4,2);
        hold on;

        for i = 1:p
            plot(wl,M_true(:,i)/max(M_true(:,i)), ...
                 '-','LineWidth',1.5);

            e = r1_M(:,r1_perm(i));
            plot(wl,e/max(e),'--','LineWidth',1.0);
        end

        xlabel('Wavelength (nm)');
        ylabel('Normalised');
        grid on;
        title('PISCO: GT solid / estimate dashed');

        for i = 1:min(4,p)
            subplot(2,4,4+i);

            imagesc(reshape( ...
                r1_S(r1_perm(i),:), ...
                IMG_H,IMG_W));

            caxis([0 0.8]);
            axis image off;
            colorbar;
            title(sprintf('PISCO abundance %d',i));
        end

        sgtitle(sprintf( ...
            'E2 PISCO first repeat, N = %d, photons/channel = %g', ...
            N,PHOTONS));

    else
        figure('Name',sprintf('E2 first-repeat %s',RUN_METHOD), ...
               'Position',[40 40 1200 650]);

        subplot(2,4,1);
        axis off;
        text(0.5,0.5,sprintf('%s has no PISCO-style loss trace',RUN_METHOD), ...
            'HorizontalAlignment','center');

        subplot(2,4,2);
        hold on;

        for i = 1:p
            plot(wl,M_true(:,i)/max(M_true(:,i)), ...
                 '-','LineWidth',1.5);

            e = r1_M(:,r1_perm(i));
            plot(wl,e/max(e),'--','LineWidth',1.0);
        end

        xlabel('Wavelength (nm)');
        ylabel('Normalised');
        grid on;
        title(sprintf('%s: GT solid / estimate dashed',RUN_METHOD));

        for i = 1:min(4,p)
            subplot(2,4,4+i);

            imagesc(reshape( ...
                r1_S(r1_perm(i),:), ...
                IMG_H,IMG_W));

            caxis([0 0.8]);
            axis image off;
            colorbar;
            title(sprintf('%s: %s',RUN_METHOD,endmember_names{i}));
        end

        sgtitle(sprintf( ...
            'E2 %s first repeat, N = %d, photons/channel = %g', ...
            RUN_METHOD,N,PHOTONS));
    end
end


%% E2.7 First-repeat abundance comparison (GT vs estimated) ----------------
if ~isempty(r1_S_true) && ~isempty(r1_S)
    figure('Name',sprintf('E2 abundance comparison %s',RUN_METHOD), ...
           'Position',[60 60 1200 520]);

    for i = 1:min(4,p)
        subplot(2,4,i);
        imagesc(reshape(r1_S_true(i,:),IMG_H,IMG_W));
        caxis([0 0.8]);
        axis image off;
        colorbar;
        title(sprintf('GT: %s',endmember_names{i}));

        subplot(2,4,4+i);
        imagesc(reshape(r1_S(r1_perm(i),:),IMG_H,IMG_W));
        caxis([0 0.8]);
        axis image off;
        colorbar;
        title(sprintf('%s: %s',RUN_METHOD,endmember_names{i}));
    end

    sgtitle(sprintf('Ground-truth vs estimated abundance maps (%s), N = %d, photons/channel = %g', ...
        RUN_METHOD,N,PHOTONS));
end


%% ===================== Local functions ================================

function perm = e2_match(M_true,M_est)
% Greedy SAD matching, consistent with the original E2 demo and E1 script.
p = size(M_true,2);
Cmat = zeros(p,p);

for i = 1:p
    for j = 1:p
        den = norm(M_true(:,i))*norm(M_est(:,j));
        if den <= eps
            Cmat(i,j) = 180;
        else
            cc = (M_true(:,i)'*M_est(:,j))/den;
            cc = max(-1,min(1,cc));
            Cmat(i,j) = acosd(cc);
        end
    end
end

perm = zeros(1,p);
taken = false(1,p);

for i = 1:p
    tmp = Cmat(i,:) + 1e6*double(taken);
    [~,jj] = min(tmp);
    perm(i) = jj;
    taken(jj) = true;
end
end


function [sad,mab,mrc] = e2_metrics(M_true,S_true,Y_clean,M_est,S_est)
% Same metric definitions for PISCO and SISAL.
p = size(M_true,2);
perm = e2_match(M_true,M_est);

Cmat = zeros(p,p);
for i = 1:p
    for j = 1:p
        den = norm(M_true(:,i))*norm(M_est(:,j));
        if den <= eps
            Cmat(i,j) = 180;
        else
            cc = (M_true(:,i)'*M_est(:,j))/den;
            cc = max(-1,min(1,cc));
            Cmat(i,j) = acosd(cc);
        end
    end
end

sad = mean(Cmat(sub2ind([p p],1:p,perm)));

S_aligned = S_est(perm,:);
mab = mean((S_true(:)-S_aligned(:)).^2);

Yhat = M_est*S_est;
mrc = mean((Y_clean(:)-Yhat(:)).^2);
end


function S = e2_fcls_exact(M,Y)
% Exact FCLS for small p by active-set support enumeration.
% Copied structurally from the E1 unified comparison so SISAL abundance
% recovery is identical between E1 and E2.
[~,p] = size(M);
N = size(Y,2);

S = zeros(p,N);
best_err = inf(1,N);
tol = 1e-10;

for mask = 1:(2^p-1)
    idx = find(bitget(mask,1:p));
    q = numel(idx);
    Ma = M(:,idx);

    K = [Ma'*Ma, ones(q,1); ones(1,q), 0];
    RHS = [Ma'*Y; ones(1,N)];

    if rcond(K) > 1e-12
        sol = K \ RHS;
    else
        sol = pinv(K)*RHS;
    end

    Sa = sol(1:q,:);
    feasible = all(Sa >= -tol,1);
    Sa(abs(Sa) < tol) = 0;
    Sa_pos = max(Sa,0);
    denom = sum(Sa_pos,1);
    valid = feasible & denom > eps;

    if ~any(valid)
        continue;
    end

    Sa_pos(:,valid) = Sa_pos(:,valid)./denom(valid);
    Yhat = Ma*Sa_pos;
    err = sum((Y-Yhat).^2,1);
    update = valid & err < best_err;

    if any(update)
        S(:,update) = 0;
        S(idx,update) = Sa_pos(:,update);
        best_err(update) = err(update);
    end
end

bad = ~isfinite(best_err);
if any(bad)
    S(:,bad) = 1/p;
end
end


function tf = is_memory_error(ME)
% Conservative MATLAB OOM detector for logging E2 baseline termination.
msg = lower(ME.message);
id  = lower(ME.identifier);
tf = contains(msg,'out of memory') || ...
     contains(msg,'insufficient memory') || ...
     contains(msg,'maximum array size') || ...
     contains(msg,'requested array exceeds') || ...
     contains(id,'nomem') || ...
     contains(id,'outofmemory');
end


function s = sanitize_csv_text(s)
if isempty(s)
    s = 'unknown';
end
s = strrep(s,',',';');
s = strrep(s,newline,' ');
end


function m = mean_finite(x)
x = x(isfinite(x));
if isempty(x)
    m = NaN;
else
    m = mean(x);
end
end


function s = std_finite(x)
x = x(isfinite(x));
if numel(x) <= 1
    s = NaN;
else
    s = std(x);
end
end
