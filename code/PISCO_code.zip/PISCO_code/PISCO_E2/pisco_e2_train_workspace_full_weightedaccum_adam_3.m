function [M_est, S_est, info] = pisco_e2_train_workspace_full_weightedaccum_adam_2(Y, p, varargin)
% Aligned E2 explicit-abundance trainer, with adam_2 full-image Adam update.
% REFERENCE: pisco_e2_train_workspace_full_weightedaccum_E3explicit_1.m
% Apart from whole-image (TILE unused) execution and the Adam implementation,
% the objective, gradients, spatial smoothing, nearest-neighbor scope,
% Poisson chance margins, parameters, warm-up schedule and preprocessing
% follow E3explicit_1.
%
% TILE is retained as an accepted, compatibility-only parameter.
% peak_workspace_MB follows E3explicit_1 exactly: selected local arrays
% {Yt,Vt,co2,A_eff,diff,Q,M,penc,dA_eff}; it excludes model parameters,
% optimizer states and full-process RSS. It is a selected-array estimate,
% NOT a measurement of the actual peak allocated memory.

pStruct = inputParser;
addParameter(pStruct, 'MM_ITERS', 2500, @isnumeric);
addParameter(pStruct, 'WARM_UP', 600, @(x) isnumeric(x) && isscalar(x) && isfinite(x) && x>=0 && mod(x,1)==0);
% E3 warm-up transition: Q is exactly frozen during warm-up, then released gradually.
addParameter(pStruct, 'WARMUP_Q_RELEASE', 100, ...
    @(x) isnumeric(x) && isscalar(x) && isfinite(x) && x>=0 && mod(x,1)==0);
addParameter(pStruct, 'WARMUP_Q_MIN_LR_RATIO', 0.25, ...
    @(x) isnumeric(x) && isscalar(x) && isfinite(x) && x>0 && x<=1);
addParameter(pStruct, 'LR', 3e-4, @isnumeric);
addParameter(pStruct, 'LAMBDA_VOL', 0.008, @isnumeric);
addParameter(pStruct, 'LAMBDA_NONNEG', 3, @isnumeric);
addParameter(pStruct, 'LAMBDA_EQ', 100, @isnumeric);
addParameter(pStruct, 'LAMBDA_SUMONE', 2, @isnumeric);
addParameter(pStruct, 'LAMBDA_ENCLOSE', 10, @isnumeric);
addParameter(pStruct, 'LAMBDA_SPATIAL', 2, @isnumeric);
addParameter(pStruct, 'LAMBDA_MNONNEG', 10, @isnumeric);
addParameter(pStruct, 'LAMBDA_SMOOTH', 0.1, @isnumeric);
addParameter(pStruct, 'ETA', 0.1, @isnumeric);
addParameter(pStruct, 'ETA_END', 0.5, @isnumeric);
addParameter(pStruct, 'SIGMA_CAP', 0.03, @isnumeric);
addParameter(pStruct, 'PHOTON_GAIN', 1, @isnumeric);
addParameter(pStruct, 'PHOTON_FLOOR', 1, @isnumeric);
addParameter(pStruct, 'READ_SIGMA', 0, @isnumeric);
addParameter(pStruct, 'FF_K', 6, @isnumeric);
addParameter(pStruct, 'TILE', 256, @isnumeric);
addParameter(pStruct, 'CHUNK', 1e5, @isnumeric);
addParameter(pStruct, 'IMG_H', [], @isnumeric);
addParameter(pStruct, 'IMG_W', [], @isnumeric);
addParameter(pStruct, 'LOSS_EVERY', 50, @isnumeric);
addParameter(pStruct, 'verbose', 1, @isnumeric);
% Historical adam_2 API: accept these options, but the aligned reference
% specifically uses the E3explicit_1 Poisson / explicit / coupled-Q model.
addParameter(pStruct, 'ABUNDANCE_MODE', 'explicit', @ischar);
addParameter(pStruct, 'NOISE_MODEL', 'poisson', @ischar);
addParameter(pStruct, 'NOISE_WEIGHT', 'uniform', @ischar);
addParameter(pStruct, 'QPARAM', 'coupled', @ischar);
addParameter(pStruct, 'COORDS', '2d', @ischar);
addParameter(pStruct, 'GATED', true, @islogical);
addParameter(pStruct, 'WARMUP_GATE_RELEASE', 150, @isnumeric);
addParameter(pStruct, 'M0', [], @isnumeric);
addParameter(pStruct, 'spherize', 'yes', @ischar);
% Preserve the original adam_2's E3a name/value arguments for API
% compatibility. They are unused because spatial loss is now exactly
% E3explicit_1's nearest-neighbor quadratic smoothness.
addParameter(pStruct, 'SPATIAL_DELTA', 0.08, @isnumeric);
addParameter(pStruct, 'SPATIAL_GUIDE_MODE', 'noise_adaptive', @ischar);
addParameter(pStruct, 'SPATIAL_GUIDE_SIGMA', 1.0, @isnumeric);
addParameter(pStruct, 'SPATIAL_GUIDE_TAU', 2.0, @isnumeric);
addParameter(pStruct, 'SPATIAL_GUIDE_MIN_WEIGHT', 0.05, @isnumeric);
addParameter(pStruct, 'SPATIAL_GUIDE_NORMALIZE', true, @islogical);
addParameter(pStruct, 'NOISE_GUIDE_THRESHOLD', 1.5, @isnumeric);
addParameter(pStruct, 'NOISE_GUIDE_TAU', 0.6, @isnumeric);
addParameter(pStruct, 'NOISE_GUIDE_UNCERT_POWER', 0.5, @isnumeric);
addParameter(pStruct, 'NOISE_GUIDE_MAX_BOOST', 2.0, @isnumeric);
addParameter(pStruct, 'SPATIAL_MS_ENABLE', true, @islogical);
addParameter(pStruct, 'SPATIAL_MS_OFFSETS', [1 2 4], @isnumeric);
addParameter(pStruct, 'SPATIAL_MS_WEIGHTS', [0.55 0.30 0.15], @isnumeric);
addParameter(pStruct, 'SPATIAL_GRAD_BALANCE', true, @islogical);
addParameter(pStruct, 'SPATIAL_TARGET_HEAD_RATIO', 0.40, @isnumeric);
addParameter(pStruct, 'SPATIAL_GAIN_MIN', 0.50, @isnumeric);
addParameter(pStruct, 'SPATIAL_GAIN_MAX', 12.0, @isnumeric);
addParameter(pStruct, 'SPATIAL_SCHEDULE', 'constant', @ischar);
addParameter(pStruct, 'SPATIAL_DECAY_START', 0.40, @isnumeric);
addParameter(pStruct, 'SPATIAL_FINAL_RATIO', 0.20, @isnumeric);
parse(pStruct, varargin{:});
R = pStruct.Results;
ignored_spatial_args = {'SPATIAL_DELTA','SPATIAL_GUIDE_MODE', ...
    'SPATIAL_GUIDE_SIGMA','SPATIAL_GUIDE_TAU', ...
    'SPATIAL_GUIDE_MIN_WEIGHT','SPATIAL_GUIDE_NORMALIZE', ...
    'NOISE_GUIDE_THRESHOLD','NOISE_GUIDE_TAU', ...
    'NOISE_GUIDE_UNCERT_POWER','NOISE_GUIDE_MAX_BOOST', ...
    'SPATIAL_MS_ENABLE','SPATIAL_MS_OFFSETS','SPATIAL_MS_WEIGHTS', ...
    'SPATIAL_GRAD_BALANCE','SPATIAL_TARGET_HEAD_RATIO', ...
    'SPATIAL_GAIN_MIN','SPATIAL_GAIN_MAX','SPATIAL_SCHEDULE', ...
    'SPATIAL_DECAY_START','SPATIAL_FINAL_RATIO'};
explicitly_given = setdiff(ignored_spatial_args, pStruct.UsingDefaults);
if ~isempty(explicitly_given)
    warning('E3explicit_1 alignment: spatial guidance/multiscale options are accepted but unused: %s', ...
        strjoin(explicitly_given, ', '));
end
if ~strcmpi(R.ABUNDANCE_MODE,'explicit') || ~strcmpi(R.NOISE_MODEL,'poisson') || ...
        ~strcmpi(R.NOISE_WEIGHT,'uniform') || ~strcmpi(R.QPARAM,'coupled') || ...
        ~strcmpi(R.COORDS,'2d') || ~strcmpi(R.spherize,'yes') || ~isempty(R.M0)
    error(['This E3explicit_1-aligned implementation requires explicit ' ...
        'abundance, Poisson/uniform noise, coupled Q, 2-D coordinates, ' ...
        'spherize=yes, and VCA initialization.']);
end

[L, N] = size(Y);
if R.WARM_UP >= R.MM_ITERS && R.WARM_UP > 0
    error('WARM_UP must be strictly smaller than MM_ITERS.');
end
H_img = R.IMG_H; W_img = R.IMG_W;
if isempty(H_img) || isempty(W_img) || H_img*W_img ~= N
    error('pisco_e2_train: IMG_H x IMG_W must equal N (%d).', N);
end
gain = R.PHOTON_GAIN;
rs2  = (R.READ_SIGMA/gain)^2;

% adam_2 uses the full image for every gradient step; TILE is ignored.
B = N;
full_batch = true;
n_tile_rows = 1; n_tile_cols = 1; n_tiles = 1;
idx = 1:N;

%% --------------------- Preprocessing (chunked) ---------------------
t0 = tic;
my = mean(Y, 2);
Cy = (Y*Y')/N - my*my';              % signal covariance, no Yc duplicate
[Up1, D] = svds(Cy, p-1);
lam = 1e-10;
Cm = diag(1./sqrt(diag(D + lam*eye(p-1))));

Ys = zeros(p, N);                    % spherized working data, p x N
ck = R.CHUNK;
for s = 1:ck:N
    ci = s:min(s+ck-1, N);
    Ys(1:p-1, ci) = Cm*(Up1'*(Y(:,ci) - my));
end
Ys(p,:) = 1; Ys = Ys/sqrt(p);

% Poisson variance propagation (mixed Poisson + read noise)
Bop = [Cm*Up1'; zeros(1,L)]/sqrt(p);
B2  = Bop.^2;
Vpix = zeros(p, N);
for s = 1:ck:N
    ci = s:min(s+ck-1, N);
    VarY = max(Y(:,ci), R.PHOTON_FLOOR/gain)/gain + rs2;
    Vpix(:,ci) = B2*VarY;
end
med_v = median(Vpix(Vpix > 0));
Vpix(Vpix <= 0) = med_v;
Vpix = max(Vpix, 1e-3*med_v);

% lift context for band-space endmember priors (spherized mode)
lift_ctx.Up_sub = Up1;
lift_ctx.sD     = sqrt(diag(D + lam*eye(p-1)));
lift_ctx.my     = my;
lift_ctx.sqp    = sqrt(p);

M0 = VCA(Ys, 'Endmembers', p, 'verbose', 'off');
Q0 = inv(M0);
qm = sum(Ys,2)'*inv(Ys*Ys');         % = ones(1,N)*Ys'*inv(Ys*Ys')

% 2-D coordinates: retained for exact E3explicit_1 selected-array accounting
[gx, gy] = meshgrid(linspace(-1,1,W_img), linspace(-1,1,H_img));
coords2 = [gx(:)'; gy(:)'];          % 2 x N
if R.FF_K > 0
    freqs = (2.^(0:R.FF_K-1)) * pi;  % 1 x K
else
    freqs = [];
end
info.t_pre = toc(t0);

%% --------------------- Parameters (E3 explicit abundance) ---------------------
% Imported from pisco_e3_train_b1_15 explicit mode:
% optimize a free p x N abundance matrix directly, initialized near-uniform.
theta.S_explicit = ones(p, N) / p;
theta.L = zeros(p,p); theta.R = zeros(p,p); theta.r_log = zeros(p,1);

m_adam = init_adam(theta);
v_adam = init_adam(theta);
iter = 0;
loss_trace = zeros(ceil(R.MM_ITERS/max(R.LOSS_EVERY,1))+2, 2);
n_tr = 0;

% Same E3explicit_1 selected-array workspace accounting (not process RSS).
peak_workspace_bytes = 0;


%% --------------------- Warm-up (Q fixed at Q0) ---------------------
t0 = tic;
phi_const = -sqrt(2)*erfcinv(2*R.ETA);
for epoch = 1:R.WARM_UP
    [loss_epoch, grad, ws_bytes] = grad_tile_epoch_mean(theta, idx, Ys, Vpix, ...
        coords2, freqs, Q0, qm, p, N, ...
        0, R.LAMBDA_NONNEG, R.LAMBDA_EQ, R.LAMBDA_SUMONE, ...
        R.LAMBDA_ENCLOSE, R.LAMBDA_SPATIAL, H_img, W_img, true, ...
        phi_const, R.SIGMA_CAP, R.LAMBDA_MNONNEG, R.LAMBDA_SMOOTH, lift_ctx);

    % Preserve adam_2's Adam update code and E3 fixed-Q warm-up semantics.
    [theta, m_adam, v_adam] = adam_update_struct(theta, grad, m_adam, v_adam, ...
        iter+1, R.LR, 0, 0, 0, false);
    iter = iter + 1;
    peak_workspace_bytes = max(peak_workspace_bytes, ws_bytes);

    if R.LOSS_EVERY > 0 && mod(iter, R.LOSS_EVERY) == 0
        n_tr = n_tr + 1; loss_trace(n_tr,:) = [iter, loss_epoch];
    end
    if R.verbose && mod(epoch,20)==0
        fprintf('  warm-up epoch %d/%d | full-image Adam update=%d | loss=%.5f\n', ...
            epoch, R.WARM_UP, iter, loss_epoch);
    end
end
info.t_warm = toc(t0);

%% --------------------- Joint phase (margin annealing) ---------------------
t0 = tic;
n_joint = R.MM_ITERS - R.WARM_UP;
for epoch = 1:n_joint
    prog  = (epoch-1)/max(1, n_joint-1);
    eta_t = min(max(R.ETA + (R.ETA_END-R.ETA)*prog, 1e-6), 1-1e-6);
    phi_t = -sqrt(2)*erfcinv(2*eta_t);

    [loss_epoch, grad, ws_bytes] = grad_tile_epoch_mean(theta, idx, Ys, Vpix, ...
        coords2, freqs, Q0, qm, p, N, ...
        R.LAMBDA_VOL, R.LAMBDA_NONNEG, R.LAMBDA_EQ, R.LAMBDA_SUMONE, ...
        R.LAMBDA_ENCLOSE, R.LAMBDA_SPATIAL, H_img, W_img, false, ...
        phi_t, R.SIGMA_CAP, R.LAMBDA_MNONNEG, R.LAMBDA_SMOOTH, lift_ctx);

    % Identical Q-release schedule; retain adam_2's Adam update function.
    q_lr_scale = 1;
    if R.WARM_UP > 0 && R.WARMUP_Q_RELEASE > 0
        q_progress = min(1, epoch / R.WARMUP_Q_RELEASE);
        q_progress = q_progress^2 * (3 - 2*q_progress);
        q_lr_scale = R.WARMUP_Q_MIN_LR_RATIO + ...
            (1 - R.WARMUP_Q_MIN_LR_RATIO) * q_progress;
    end
    [theta, m_adam, v_adam] = adam_update_struct(theta, grad, m_adam, v_adam, ...
        iter+1, R.LR, q_lr_scale, epoch, epoch, false);
    iter = iter + 1;
    peak_workspace_bytes = max(peak_workspace_bytes, ws_bytes);

    if R.LOSS_EVERY > 0 && mod(iter, R.LOSS_EVERY) == 0
        n_tr = n_tr + 1; loss_trace(n_tr,:) = [iter, loss_epoch];
    end
    if R.verbose && mod(epoch,20)==0
        fprintf('  joint epoch %d/%d | full-image Adam update=%d | loss=%.5f | explicit abundance\n', ...
            epoch, n_joint, iter, loss_epoch);
    end
end
info.t_joint = toc(t0);

%% --------------------- Recover endmembers + full-field render ---------------------
t0 = tic;
L_mat = eye(p) + tril(theta.L,-1);
R_mat = diag(exp(theta.r_log)) + triu(theta.R,1);
Q = L_mat*Q0*R_mat;
M_sub = inv(Q)*sqrt(p);
M_sub = M_sub(1:p-1,:);
M_est = Up1*diag(lift_ctx.sD)*M_sub + repmat(my,1,p);
M_est = max(M_est, 0);               % physical non-negativity projection

% E3 explicit abundance representation: the optimized p x N matrix is returned directly.
S_est = theta.S_explicit;
info.t_infer = toc(t0);

info.loss_trace = loss_trace(1:n_tr,:);
info.TILE = R.TILE; info.B = B; info.N = N; info.full_batch = full_batch; % TILE accepted, UNUSED
info.n_tile_rows = n_tile_rows; info.n_tile_cols = n_tile_cols; info.n_tiles = n_tiles;
info.full_data_per_epoch = true;
info.tilewise_adam = false;
info.cross_tile_spatial_edges = true; % full-image nearest neighbors included
info.total_updates = iter;
info.gradient_accumulation = 'none: full-image explicit gradient; one adam_2 Adam update per iteration';
info.SIGMA_CAP = R.SIGMA_CAP;
info.peak_workspace_MB = peak_workspace_bytes / 1024^2;
info.workspace_memory_definition = ['E3explicit_1 selected local arrays only: ' ...
    '{Yt,Vt,co2,A_eff,diff,Q,M,penc,dA_eff}. ' ...
    'Excludes theta, Adam states, accumulated gradients and process RSS.'];
end

%% ===================== sub-functions =====================
function [loss, grad, ws_bytes] = grad_tile_epoch_mean(theta, idx, Yt, Vt, co2, freqs, Q0, qm, p, ...
    Bt, lambda_vol, lambda_nonneg, lambda_eq, lambda_sumone, ...
    lambda_enclose, lambda_spatial, th, tw, warm_up, phi_t, sigma_cap, ...
    lambda_mnn, lambda_smooth, lift_ctx)
% Per-tile MEAN objective/gradient. Pixel-wise terms are normalized by Bt.
% The caller later weights this tile gradient by Bt/N before full-image accumulation.
L_mat = eye(p) + tril(theta.L,-1);
R_mat = diag(exp(theta.r_log)) + triu(theta.R,1);
Q = L_mat*Q0*R_mat;
M = inv(Q);

% E3 explicit abundance: directly select the p x Bt trainable abundance block.
A_eff = theta.S_explicit(:,idx);

diff = M*A_eff - Yt;
loss_recon = mean(sum(diff.^2,1));
loss_vol = -sum(theta.r_log);

sigma2 = (Q.^2)*Vt + 1e-12;
margin = phi_t*min(sqrt(sigma2), sigma_cap);

pen = min(A_eff,0);
loss_nonneg = sum(pen.^2,'all')/Bt;
sum_A = sum(A_eff,1);
loss_sumone = sum((sum_A-1).^2,'all')/Bt;

col_sums = sum(Q,1);
loss_eq = sum((col_sums-qm).^2,'all');

QY = Q*Yt;
penc = min(QY-margin,0);
loss_enclose = sum(penc.^2,'all')/Bt;

loss_spatial = 0;
if lambda_spatial > 0
    A3 = reshape(A_eff,p,th,tw);
    if th > 1
        Dh = A3(:,2:end,:) - A3(:,1:end-1,:);
    else
        Dh = zeros(p,0,tw);
    end
    if tw > 1
        Dw = A3(:,:,2:end) - A3(:,:,1:end-1);
    else
        Dw = zeros(p,th,0);
    end
    loss_spatial = (sum(Dh.^2,'all') + sum(Dw.^2,'all'))/Bt;
else
    Dh = []; Dw = [];
end

loss = loss_recon + lambda_vol*loss_vol + lambda_nonneg*loss_nonneg + ...
    lambda_sumone*loss_sumone + lambda_eq*loss_eq + ...
    lambda_enclose*loss_enclose + lambda_spatial*loss_spatial;

dY_hat = 2*diff/Bt;
dM = dY_hat*A_eff';

if (lambda_mnn > 0 || lambda_smooth > 0)
    M_band = lift_ctx.Up_sub*(lift_ctx.sD.*(lift_ctx.sqp*M(1:p-1,:))) + lift_ctx.my;
    dM_band = zeros(size(M_band));
    if lambda_mnn > 0
        pen_M = min(M_band,0);
        loss = loss + lambda_mnn*sum(pen_M.^2,'all');
        dM_band = dM_band + 2*lambda_mnn*pen_M;
    end
    if lambda_smooth > 0
        D2M = M_band(3:end,:) - 2*M_band(2:end-1,:) + M_band(1:end-2,:);
        loss = loss + lambda_smooth*sum(D2M.^2,'all');
        g2 = zeros(size(M_band));
        g2(3:end,:)   = g2(3:end,:)   + 2*lambda_smooth*D2M;
        g2(2:end-1,:) = g2(2:end-1,:) - 4*lambda_smooth*D2M;
        g2(1:end-2,:) = g2(1:end-2,:) + 2*lambda_smooth*D2M;
        dM_band = dM_band + g2;
    end
    gmnn = zeros(p,p);
    gmnn(1:p-1,:) = lift_ctx.sqp*(lift_ctx.sD.*(lift_ctx.Up_sub'*dM_band));
    dM = dM + gmnn;
end

grad_Q = -M'*dM*M' + lambda_eq*2*repmat(col_sums-qm,p,1) + ...
    lambda_enclose*(2/Bt)*(penc*Yt');
grad_L_mat = grad_Q*R_mat'*Q0';
grad_R_mat = Q0'*L_mat'*grad_Q;

grad.L = tril(grad_L_mat,-1);
grad.R = triu(grad_R_mat,1);
grad.r_log = diag(grad_R_mat).*exp(theta.r_log) - lambda_vol;

dA_eff = M'*dY_hat + (2*lambda_nonneg/Bt)*pen + ...
    (2*lambda_sumone/Bt)*repmat(sum_A-1,p,1);
if lambda_spatial > 0
    G3 = zeros(p,th,tw);
    if th > 1
        G3(:,1:end-1,:) = G3(:,1:end-1,:) - Dh;
        G3(:,2:end,:)   = G3(:,2:end,:)   + Dh;
    end
    if tw > 1
        G3(:,:,1:end-1) = G3(:,:,1:end-1) - Dw;
        G3(:,:,2:end)   = G3(:,:,2:end)   + Dw;
    end
    dA_eff = dA_eff + 2*lambda_spatial*reshape(G3,p,Bt)/Bt;
end

% E3 explicit abundance: abundance gradient is the direct gradient w.r.t. S_explicit(:,idx).
grad.S_explicit = dA_eff;

vars = {Yt,Vt,co2,A_eff,diff,Q,M,penc,dA_eff};
ws_bytes = selected_bytes(vars);
end

function n = selected_bytes(vars)
n=0;
for i=1:numel(vars)
    if isnumeric(vars{i}), n=n+numel(vars{i})*8; end
end
end

function adam = init_adam(theta)
fields = fieldnames(theta);
adam = struct();
for i = 1:numel(fields)
    adam.(fields{i}) = zeros(size(theta.(fields{i})));
end
end

function [theta, m, v] = adam_update_struct(theta, grad, m, v, iter, lr, ...
    q_lr_scale, q_step, gate_step, gate_active)
% Separate Adam bias-correction clocks for Q / nonlinear gate, since these
% groups remain frozen during warm-up. Shared S-Net params use 'iter'.
% Skipping an inactive group also leaves its Adam moment vectors at zero.
beta1 = 0.9; beta2 = 0.999; eps = 1e-8;
fields = fieldnames(theta);
for i = 1:numel(fields)
    f = fields{i};
    is_q = any(strcmp(f, {'L','R','r_log','Delta'}));
    is_gate = any(strcmp(f, {'Wg1','bg1','Wg2','bg2','c'}));
    if is_q
        if q_lr_scale <= 0, continue; end
        t = q_step;
        local_lr = lr*q_lr_scale;
    elseif is_gate
        if ~gate_active, continue; end
        t = gate_step;
        local_lr = lr;
    else
        t = iter;
        local_lr = lr;
    end
    m.(f) = beta1*m.(f) + (1-beta1)*grad.(f);
    v.(f) = beta2*v.(f) + (1-beta2)*grad.(f).^2;
    m_hat = m.(f) / (1 - beta1^t);
    v_hat = v.(f) / (1 - beta2^t);
    theta.(f) = theta.(f) - local_lr * m_hat ./ (sqrt(v_hat) + eps);
end
end
