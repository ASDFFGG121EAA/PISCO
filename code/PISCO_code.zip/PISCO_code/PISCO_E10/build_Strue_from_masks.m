function S_true = build_Strue_from_masks( ...
    scene_dir,H,W,p,max_purity,seed,sigma_px,background_floor)
%BUILD_STRUE_FROM_MASKS Build biological-mask-derived abundance ground truth.
%
% S_true = build_Strue_from_masks(scene_dir,H,W,p,max_purity,seed,...
%                                 sigma_px,background_floor)
%
% Expected scene layout:
%   scene_dir/
%       images/        % optional; NOT used here
%       masks/
%           *.png      % one binary instance mask per biological object
%
% The function uses ONLY masks/*.png. It does not read the original image.
%
% Construction:
%   1) read all instance masks;
%   2) resize every mask to H x W with nearest-neighbor interpolation;
%   3) randomly permute the instances using the supplied seed;
%   4) distribute instances as evenly as possible across p components;
%   5) union masks within each component;
%   6) Gaussian-smooth each component;
%   7) add a small positive floor and normalize every pixel to sum to one;
%   8) impose the same hard max-purity rule used by the original E1 code.
%
% Output:
%   S_true : p x (H*W), column order compatible with reshape(S_true(k,:),H,W)
%
% No scene identity or mask filename is saved by this function.

if nargin < 8 || isempty(background_floor)
    background_floor = 0.02;
end
if nargin < 7 || isempty(sigma_px)
    sigma_px = 2.0;
end
if nargin < 6 || isempty(seed)
    seed = 1;
end
if nargin < 5 || isempty(max_purity)
    max_purity = 0.8;
end

validateattributes(H,{'numeric'},{'scalar','integer','positive'});
validateattributes(W,{'numeric'},{'scalar','integer','positive'});
validateattributes(p,{'numeric'},{'scalar','integer','>=',2});
validateattributes(max_purity,{'numeric'},{'scalar','>',0,'<=',1});
validateattributes(sigma_px,{'numeric'},{'scalar','>=',0});
validateattributes(background_floor,{'numeric'},{'scalar','nonnegative'});

mask_dir = fullfile(scene_dir,'masks');
if ~isfolder(mask_dir)
    error('Mask folder does not exist: %s',mask_dir);
end

files = dir(fullfile(mask_dir,'*.png'));
if isempty(files)
    error('No PNG masks found in: %s',mask_dir);
end

% Sort filenames before seeded randomization for cross-run reproducibility.
[~,ord] = sort(lower(string({files.name})));
files = files(ord);

nMasks = numel(files);
if nMasks < p
    error(['Scene %s contains only %d masks, but p=%d. ' ...
           'At least p instance masks are required.'],scene_dir,nMasks,p);
end

% Balanced random assignment of instance masks to the p abundance channels.
rng(seed,'twister');
perm = randperm(nMasks);

B = zeros(H,W,p);

for tt = 1:nMasks
    idx = perm(tt);
    group_id = 1 + mod(tt-1,p);

    M = imread(fullfile(files(idx).folder,files(idx).name));

    if ndims(M) == 3
        M = any(M > 0,3);
    else
        M = M > 0;
    end

    M = double(M);
    [h0,w0] = size(M);

    if h0 == H && w0 == W
        Mr = M;
    else
        % Nearest-neighbor resize using interp2 so no Image Processing
        % Toolbox dependency is required.
        xq = linspace(1,w0,W);
        yq = linspace(1,h0,H)';
        [Xq,Yq] = meshgrid(xq,yq);
        Mr = interp2(1:w0,(1:h0)',M,Xq,Yq,'nearest',0);
        Mr = double(Mr > 0.5);
    end

    % Union all biological instances assigned to the same component.
    B(:,:,group_id) = max(B(:,:,group_id),Mr);
end

% Gaussian smoothing with a self-contained convolution kernel.
A = zeros(H,W,p);
if sigma_px > 0
    radius = max(1,ceil(3*sigma_px));
    [gx,gy] = meshgrid(-radius:radius,-radius:radius);
    G = exp(-(gx.^2 + gy.^2)/(2*sigma_px^2));
    G = G / sum(G(:));

    for k = 1:p
        A(:,:,k) = conv2(B(:,:,k),G,'same');
    end
else
    A = B;
end

% Positive floor avoids undefined all-zero background pixels.
A = A + background_floor;

% Sum-to-one at every pixel.
den = sum(A,3);
if any(~isfinite(den(:))) || any(den(:) <= 0)
    error('Invalid abundance normalization denominator was produced.');
end
A = A ./ den;

% Convert H x W x p -> p x N in MATLAB image column-major pixel order.
S_true = reshape(permute(A,[3 1 2]),p,[]);

% Same hard purity cap as the original E1 implementation.
[Smax,Sidx] = max(S_true,[],1);
idx_over = find(Smax > max_purity);

if ~isempty(idx_over)
    other_value = (1-max_purity)/(p-1);
    for jj = idx_over
        S_true(:,jj) = other_value * ones(p,1);
        S_true(Sidx(jj),jj) = max_purity;
    end
end

% Final numerical checks.
if any(~isfinite(S_true(:))) || any(S_true(:) < -1e-12)
    error('S_true contains invalid values.');
end

sum_err = max(abs(sum(S_true,1)-1));
if sum_err > 1e-10
    error('S_true violates sum-to-one: max error = %.3e',sum_err);
end

if max(S_true(:)) > max_purity + 1e-12
    error('S_true violates max purity %.6g.',max_purity);
end

end
