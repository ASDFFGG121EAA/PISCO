%% demo_pisco_E10_channels_biomask_RMVSA.m
% E10: Spectral resolution 32/64/128 channels, PISCO versus RMVSA.
%
% DATA PROTOCOL (same biological-mask synthesis as E1):
%  - Use four true FPbase-derived endmembers: Citrine, tdTomato, mKO2, mRuby.
%  - Load each channel's ORIGINAL, separately generated MAT spectrum.
%    No upsampling/interpolation from M32 happens in this driver.
%  - One build_Strue_from_masks() call per run; same true abundances for
%    the 32-, 64-, and 128-channel configurations.
%  - Per-arm gain calibrated to mean PHOTONS Poisson counts PER CHANNEL.
%  - Read noise is Gaussian N(0,READ_SIG^2) in count units.
%  - All noisy observations are generated before either solver executes.
%
% FAIR COMPARISON:
%  - On a given run and channel, PISCO and RMVSA receive identical Y_in.
%  - RMVSA reproduces the active E1 driver: estNoise(additive), then
%    rmvsa_LiAlex22(spherize=yes, alpha=1e-5, MM_ITERS=10), then exact FCLS.
%  - PISCO function and hyperparameters are preserved from the provided
%    demo_pisco_E10_channels_biomask(1).m (including ETA=0.3).
%  - Endmember matching and metrics follow the original E1 helper methods.
%
% OUTPUT (one row per method x channel x run):
%  pisco_E10_PISCO_RMVSA_results.csv
%      method,channels,run,photons,SAD_deg,MSE_ab,MSE_rec,time_s
%  pisco_E10_PISCO_RMVSA_summary.csv
%      method,channels,n_runs,photons,SAD_mean_deg,SAD_std_deg,
%      MSE_ab_mean,MSE_ab_std,MSE_rec_mean,MSE_rec_std,time_mean_s,time_std_s
%  pisco_E10_PISCO_RMVSA_fig1_accuracy.png
%  pisco_E10_PISCO_RMVSA_fig2_spectra.png
%
% REQUIREMENTS: build_Strue_from_masks.m, ./use/<scene>/masks/*.png;
%  PISCO three spectra MAT files; deep_mvsa_invflow_poisson_explicit_Warmup;
%  RMVSA: rmvsa_LiAlex22, estNoise, VCA, quadProg,
%          computeAtransYinvLA; Statistics Toolbox for poissrnd.
%
% Set N_RUNS=30, QUICK=false for the n=30 SI Table 3 campaign.
% MATLAB R2023a-compatible script with local functions.

clear all; close all; clc;

%% B.0 Protocol ---------------------------------------------------------
QUICK      = false;     % true = smoke test (2 repeats, all 3 arms)
N_RUNS     = 30;       % E10 original repeat count; use 30 for SI formal table
BASE_SEED  = 52;       % same biological-mask seed base as E1
SIZE       = 96;       % E1 standard scene: 96 x 96
L_ARMS     = [32, 64, 128];       % channel-count arms (SI Suppl. Table 3)
PHOTONS    = 20;                  % fixed photon budget per channel
READ_SIG   = 1.0;      % Gaussian read-out noise, counts (design v5)
MM_ITERS   = 2500;     % joint-phase length (SI Table 3 default)
WARM_UP    = 600;      % warm-up length (SI Table 3 default)
% The wavelength range and wavelength centers will be read from MAT metadata.
% Biological-mask settings: identical to E1.
THIS_SCRIPT = mfilename('fullpath');
SCRIPT_DIR = fileparts(THIS_SCRIPT);
if isempty(SCRIPT_DIR)
    SCRIPT_DIR = pwd;
end
MASK_ROOT       = fullfile(SCRIPT_DIR,'use');
MASK_SIGMA      = 2.0;
MASK_BACKGROUND = 0.02;
MAX_PURITY      = 0.8;
OUT_CSV         = 'pisco_E10_PISCO_RMVSA_results.csv';
OUT_SUMMARY_CSV = 'pisco_E10_PISCO_RMVSA_summary.csv';
FIG1_PNG        = 'pisco_E10_PISCO_RMVSA_fig1_accuracy.png';
FIG2_PNG        = 'pisco_E10_PISCO_RMVSA_fig2_spectra.png';

% RMVSA settings: copied from the ACTIVE E1 comparison driver.
RMVSA_ALPHA    = 0.00001;
RMVSA_MM_ITERS = 10;
RMVSA_NOISE    = 'additive';

if QUICK
    N_RUNS = 2; L_ARMS = [32, 64, 128]; MM_ITERS = 800; WARM_UP = 200;
    RMVSA_MM_ITERS = 4;
end

%% B.1 Load real four-protein endmembers for EVERY arm ---------------
% Same input convention as E1, without the hard-coded 32-channel matrix.
% Each MAT file contains M, endmember_names, channel_centers_nm, etc.
p = 4;
IMG_H = SIZE; IMG_W = SIZE; N = IMG_H * IMG_W;
nA = numel(L_ARMS);
M_arm  = cell(nA,1);
wl_arm = cell(nA,1);
expected_names = ["Citrine"; "tdTomato"; "mKO2"; "mRuby"];

for a = 1:nA
    La = L_ARMS(a);
    if ~ismember(La,[32 64 128])
        error('E10:unsupportedChannels', 'Unsupported L=%d.', La);
    end

    M_FILE = sprintf('PISCO_M_%dx4_HyU_strict_quasar%d.mat',La,La);
    M_PATH = fullfile(SCRIPT_DIR,M_FILE);
    if ~isfile(M_PATH)
        % Allow files on the MATLAB current working directory as in E1.
        M_PATH = M_FILE;
    end
    if ~isfile(M_PATH)
        error('E10:missingSpectra', ['Cannot locate %s.\n' ...
            'Place it next to this E10 script, or in the current folder.'],M_FILE);
    end

    Dspec = load(M_PATH);
    if ~isfield(Dspec,'M') || ~isfield(Dspec,'channel_centers_nm') || ...
            ~isfield(Dspec,'endmember_names') || ...
            ~isfield(Dspec,'spectral_range_nm')
        error('E10:badSpectra', '%s lacks required E1-format fields.',M_FILE);
    end

    Ma = double(Dspec.M);
    if ~isequal(size(Ma),[La p]) || any(~isfinite(Ma(:))) || ...
            any(Ma(:) < 0)
        error('E10:badSpectra', '%s needs a finite nonnegative %dx%d M.', ...
            M_FILE,La,p);
    end
    if any(abs(max(Ma,[],1)-1) > 1e-6)
        error('E10:badSpectra', '%s: M columns must be peak-normalized.',M_FILE);
    end

    names_here = string(Dspec.endmember_names(:));
    if ~isequal(names_here,expected_names)
        error('E10:proteinOrder', ...
            '%s: expected Citrine/tdTomato/mKO2/mRuby column order.', M_FILE);
    end

    wl_here = double(Dspec.channel_centers_nm(:));
    range_here = double(Dspec.spectral_range_nm(:));
    if numel(wl_here) ~= La || any(~isfinite(wl_here)) || ...
            any(diff(wl_here) <= 0) || numel(range_here) ~= 2
        error('E10:badWavelengths','Invalid wavelength data in %s.',M_FILE);
    end
    if a == 1
        WL0 = range_here(1);
        WL1 = range_here(2);
    elseif any(abs(range_here - [WL0; WL1]) > 1e-6)
        error('E10:rangeMismatch', ...
            'All three channel arms must have the same wavelength range.');
    end

    M_arm{a}  = Ma;
    wl_arm{a} = wl_here;
    fprintf('Loaded %-47s : M=%dx%d, %.3f nm/channel\n', ...
        M_FILE,La,p,(WL1-WL0)/La);
end
clear Dspec Ma M_FILE M_PATH names_here wl_here range_here;

%% B.2 Discover mask-derived biological scenes (identical to E1) --------
if exist('build_Strue_from_masks','file') ~= 2
    error('E10:missingMasksFunction', ...
        'Put build_Strue_from_masks.m on the MATLAB path.');
end
if ~isfolder(MASK_ROOT)
    error('E10:missingMaskRoot', ...
        'Missing folder %s. Expected use/<scene_name>/masks/*.png.',MASK_ROOT);
end
Dscene = dir(MASK_ROOT);
Dscene = Dscene([Dscene.isdir]);
Dscene = Dscene(~ismember({Dscene.name},{'.','..'}));
scene_dirs = {};
for ii = 1:numel(Dscene)
    candidate = fullfile(MASK_ROOT,Dscene(ii).name);
    mask_dir = fullfile(candidate,'masks');
    if isfolder(mask_dir) && ~isempty(dir(fullfile(mask_dir,'*.png')))
        scene_dirs{end+1} = candidate; %#ok<SAGROW>
    end
end
if isempty(scene_dirs)
    error('E10:emptyScenes', ...
        'No usable mask folders under %s (need */masks/*.png).',MASK_ROOT);
end
[~,ord_scene] = sort(lower(string(scene_dirs)));
scene_dirs = scene_dirs(ord_scene);
nScenes = numel(scene_dirs);
fprintf('E10 biological-mask pool: %d scenes under %s\n',nScenes,MASK_ROOT);
fprintf('All arms share the same 4-protein S_true in each repeat.\n');


%% B.2b Validate external solvers on MATLAB path -------------------------
required_functions = { ...
    'deep_mvsa_invflow_poisson_explicit_Warmup', ...
    'estNoise', 'rmvsa_LiAlex22', 'VCA', ...
    'quadProg', 'computeAtransYinvLA'};
for ii = 1:numel(required_functions)
    if exist(required_functions{ii},'file') == 0
        error('E10:missingSolver', ...
            'Missing MATLAB dependency: %s', required_functions{ii});
    end
end
clear required_functions ii;

%% B.3 Monte-Carlo channel sweep: paired PISCO vs RMVSA ----------------
METHODS = {'PISCO','RMVSA'};
miP = 1; miR = 2;
nM = numel(METHODS);
SAD_m = nan(nM,nA,N_RUNS);    % spectral angle distance (degrees)
MAB_m = nan(nM,nA,N_RUNS);    % abundance MSE
MRC_m = nan(nM,nA,N_RUNS);    % noise-free reconstruction MSE
T_m   = nan(nM,nA,N_RUNS);    % wall-clock runtime (seconds)

fprintf(['E10 PISCO vs RMVSA: %d repeats x %d channels x %d methods; ' ...
    'scene %dx%d, %d photons/channel\n'], ...
    N_RUNS,nA,nM,IMG_H,IMG_W,PHOTONS);
fprintf('Channel arms: %s\n',mat2str(L_ARMS));

fid = fopen(OUT_CSV,'w');
if fid < 0
    error('E10:csvOpen','Cannot open %s for writing.',OUT_CSV);
end
fprintf(fid,'method,channels,run,photons,SAD_deg,MSE_ab,MSE_rec,time_s\n');

rep_M = cell(nM,nA);       % representative run 1 spectrum per method/arm
rep_perm = cell(nM,nA);    % representative run 1 matching

for r = 1:N_RUNS
    % E1 biological-mask protocol: cycle deterministically over mask scenes.
    scene_idx = 1 + mod(r-1,nScenes);
    scene_dir = scene_dirs{scene_idx};
    S_true = build_Strue_from_masks( ...
        scene_dir,IMG_H,IMG_W,p,MAX_PURITY, ...
        BASE_SEED + r,MASK_SIGMA,MASK_BACKGROUND);
    if ~isequal(size(S_true),[p N]) || any(~isfinite(S_true(:))) || ...
            any(S_true(:) < -1e-10) || ...
            any(abs(sum(S_true,1)-1) > 1e-6) || ...
            any(max(S_true,[],1) > MAX_PURITY + 1e-6)
        error('E10:badAbundances', ...
            'build_Strue_from_masks returned invalid S_true in run %d.',r);
    end

    % One fixed noise stream; generate ALL L-arm observations beforehand,
    % unaffected by random draws made during either optimization.
    rng(BASE_SEED + 10000 + r,'twister');
    Y_clean_arms = cell(nA,1);
    Y_inputs = cell(nA,1);
    GAIN_ARMS = zeros(nA,1);
    for a = 1:nA
        La = L_ARMS(a);
        Y_clean_arm = M_arm{a} * S_true;
        g_arm = PHOTONS * N / sum(Y_clean_arm(:)) * La;
        Y_counts = poissrnd(g_arm * Y_clean_arm) + ...
                   READ_SIG * randn(La,N);
        Y_clean_arms{a} = Y_clean_arm;
        Y_inputs{a} = double(Y_counts) / g_arm;
        GAIN_ARMS(a) = g_arm;
    end

    for a = 1:nA
        La = L_ARMS(a);
        Ma = M_arm{a};
        Y_clean = Y_clean_arms{a};
        Y_in = Y_inputs{a};
        g = GAIN_ARMS(a);

        %% PISCO: original E10 trainer and original hyperparameters -----
        rng(BASE_SEED + 100000 + 1000*r + a,'twister');
        t_run = tic;
        [M_est_P,S_est_P] = deep_mvsa_invflow_poisson_explicit_Warmup(Y_in,p, ...
            'spherize','yes', 'verbose',0, ...
            'MM_ITERS',MM_ITERS, 'WARM_UP',WARM_UP, 'LR',3e-4, ...
            'LAMBDA_VOL',0.008, 'LAMBDA_NONNEG',3, 'LAMBDA_EQ',100, ...
            'LAMBDA_SUMONE',2, 'LAMBDA_ENCLOSE',10, ...
            'IMG_H',IMG_H, 'IMG_W',IMG_W, 'LAMBDA_SPATIAL',2, ...
            'NOISE_MODEL','poisson', 'ETA',0.3, ...
            'PHOTON_GAIN',g, 'PHOTON_FLOOR',1, 'READ_SIGMA',READ_SIG);
        T_m(miP,a,r) = toc(t_run);

        [permP,~] = e1_match(Ma,M_est_P);
        [SAD_m(miP,a,r),MAB_m(miP,a,r),MRC_m(miP,a,r)] = ...
            e1_metrics(Ma,S_true,Y_clean,M_est_P,S_est_P,permP);
        fprintf(fid,'%s,%d,%d,%d,%.8g,%.10e,%.10e,%.10g\n', ...
            METHODS{miP},La,r,PHOTONS,SAD_m(miP,a,r), ...
            MAB_m(miP,a,r),MRC_m(miP,a,r),T_m(miP,a,r));
        if r == 1
            rep_M{miP,a} = M_est_P;
            rep_perm{miP,a} = permP;
        end

        %% RMVSA: exact same E1 comparison procedure and parameters ------
        rng(BASE_SEED + 400000 + 1000*r + a,'twister');
        t_run = tic;
        [~,Rn_R] = estNoise(Y_in,RMVSA_NOISE,'off');
        warn_state_rmvsa = warning;
        % The supplied E1 comparison driver uses the same signature.
        [M_est_R,~] = rmvsa_LiAlex22( ...
            Y_in,p,RMVSA_ALPHA,Rn_R, ...
            'spherize','yes', ...
            'MM_ITERS',RMVSA_MM_ITERS, ...
            'verbose',0);
        warning(warn_state_rmvsa);
        M_est_R = double(M_est_R);
        % RMVSA abundance is recovered with the E1 exact FCLS helper,
        % NOT with the second output of rmvsa_LiAlex22.
        S_est_R = e1_fcls_exact(M_est_R,Y_in);
        T_m(miR,a,r) = toc(t_run);

        [permR,~] = e1_match(Ma,M_est_R);
        [SAD_m(miR,a,r),MAB_m(miR,a,r),MRC_m(miR,a,r)] = ...
            e1_metrics(Ma,S_true,Y_clean,M_est_R,S_est_R,permR);
        fprintf(fid,'%s,%d,%d,%d,%.8g,%.10e,%.10e,%.10g\n', ...
            METHODS{miR},La,r,PHOTONS,SAD_m(miR,a,r), ...
            MAB_m(miR,a,r),MRC_m(miR,a,r),T_m(miR,a,r));
        if r == 1
            rep_M{miR,a} = M_est_R;
            rep_perm{miR,a} = permR;
        end

        fprintf(['run %2d/%2d | L=%3d | ' ...
            'PISCO: SAD %.3f MSE_ab %.3e t %.2fs | ' ...
            'RMVSA: SAD %.3f MSE_ab %.3e t %.2fs\n'], ...
            r,N_RUNS,La,SAD_m(miP,a,r),MAB_m(miP,a,r),T_m(miP,a,r), ...
            SAD_m(miR,a,r),MAB_m(miR,a,r),T_m(miR,a,r));
    end
end
fclose(fid);
fprintf('Detailed per-run results written to %s\n',OUT_CSV);

%% B.4 Summary: 6 rows (2 methods x 3 channel counts) --------------------
fid_sum = fopen(OUT_SUMMARY_CSV,'w');
if fid_sum < 0
    error('E10:csvOpen','Cannot open %s for writing.',OUT_SUMMARY_CSV);
end
fprintf(fid_sum, ['method,channels,n_runs,photons,' ...
    'SAD_mean_deg,SAD_std_deg,MSE_ab_mean,MSE_ab_std,' ...
    'MSE_rec_mean,MSE_rec_std,time_mean_s,time_std_s\n']);
fprintf('\n========== E10 PISCO / RMVSA SUMMARY (mean +/- sd) ==========\n');
fprintf(['method channels | SAD (deg) | MSE_ab | MSE_rec | ' ...
    'runtime (seconds)\n']);
for a = 1:nA
    for m = 1:nM
        vSAD = reshape(SAD_m(m,a,:),1,[]);
        vMAB = reshape(MAB_m(m,a,:),1,[]);
        vMRC = reshape(MRC_m(m,a,:),1,[]);
        vT = reshape(T_m(m,a,:),1,[]);
        fprintf(fid_sum, ...
            '%s,%d,%d,%d,%.10g,%.10g,%.10e,%.10e,%.10e,%.10e,%.10g,%.10g\n', ...
            METHODS{m},L_ARMS(a),N_RUNS,PHOTONS, ...
            mean(vSAD),std(vSAD),mean(vMAB),std(vMAB), ...
            mean(vMRC),std(vMRC),mean(vT),std(vT));
        fprintf(['%-5s %3d | %.3f +/- %.3f | %.3e +/- %.2e | ' ...
            '%.3e +/- %.2e | %.2f +/- %.2f\n'], ...
            METHODS{m},L_ARMS(a),mean(vSAD),std(vSAD), ...
            mean(vMAB),std(vMAB),mean(vMRC),std(vMRC), ...
            mean(vT),std(vT));
    end
end
fclose(fid_sum);
fprintf('Summary written to %s\n',OUT_SUMMARY_CSV);

%% B.5 Figure 1: SAD and abundance MSE vs channel count ------------------
figure('Name','E10 PISCO vs RMVSA across channels', ...
    'Position',[50 50 990 430],'Color','w');
styles = {'o-','s--'};
colors = [0.10 0.45 0.72; 0.85 0.35 0.12];

subplot(1,2,1); hold on;
for m = 1:nM
    V = reshape(SAD_m(m,:,:),nA,N_RUNS);
    errorbar(L_ARMS,mean(V,2),std(V,0,2),styles{m}, ...
        'LineWidth',1.5,'MarkerSize',6,'Color',colors(m,:));
end
xlabel('Number of spectral channels L');
ylabel('Endmember SAD (deg)');
set(gca,'XTick',L_ARMS); grid on;
legend(METHODS,'Location','best');
title('Endmember spectral accuracy (mean +/- SD)');

subplot(1,2,2); hold on;
for m = 1:nM
    V = reshape(MAB_m(m,:,:),nA,N_RUNS);
    errorbar(L_ARMS,mean(V,2),std(V,0,2),styles{m}, ...
        'LineWidth',1.5,'MarkerSize',6,'Color',colors(m,:));
end
xlabel('Number of spectral channels L');
ylabel('Abundance MSE');
set(gca,'XTick',L_ARMS,'YScale','log'); grid on;
legend(METHODS,'Location','best');
title('Abundance accuracy (mean +/- SD)');
sgtitle(sprintf('E10: %d photons/channel, n=%d runs',PHOTONS,N_RUNS));
print(gcf,FIG1_PNG,'-dpng','-r150');
fprintf('Figure written to %s\n',FIG1_PNG);

%% B.6 Figure 2: representative run 1 true vs estimated spectra ---------
figure('Name','E10 spectral signatures: GT vs PISCO vs RMVSA', ...
    'Position',[30 30 325*nA 225*p],'Color','w');
for i = 1:p
    for a = 1:nA
        subplot(p,nA,(i-1)*nA+a);
        plot(wl_arm{a},M_arm{a}(:,i),'k-','LineWidth',1.8);
        hold on;
        for m = 1:nM
            ep = rep_M{m,a}(:,rep_perm{m,a}(i));
            peak = max(abs(ep));
            if peak > eps
                ep = ep/peak;
            end
            curve_style = '-';
            if m == miR, curve_style = '--'; end
            plot(wl_arm{a},ep,curve_style,'LineWidth',1.2, ...
                'Color',colors(m,:));
        end
        xlim([WL0 WL1]); grid on;
        if i == 1
            title(sprintf('L=%d (%.4g nm/bin)',L_ARMS(a), ...
                (WL1-WL0)/L_ARMS(a)));
            legend([{'GT'},METHODS],'Location','best');
        end
        if i == p, xlabel('Wavelength (nm)'); end
        if a == 1, ylabel(char(expected_names(i))); end
    end
end
sgtitle(sprintf('E10: true vs recovered spectra (run 1, %d photons/channel)',PHOTONS));
print(gcf,FIG2_PNG,'-dpng','-r150');
fprintf('Figure written to %s\n',FIG2_PNG);

%% ==================== Local helpers: identical to E1 ==================
function [perm,sad_v] = e1_match(M_true,M_est)
% Greedy endmember matching by spectral angle distance.

p = size(M_true,2);

Cmat = zeros(p,p);

for i = 1:p
    for j = 1:p

        den = norm(M_true(:,i)) * ...
              norm(M_est(:,j));

        if den <= eps
            Cmat(i,j) = 180;
        else
            cc = (M_true(:,i)'*M_est(:,j)) / den;
            cc = max(-1,min(1,cc));
            Cmat(i,j) = acosd(cc);
        end
    end
end

perm = zeros(1,p);
taken = false(1,p);

for i = 1:p

    tmp = Cmat(i,:) + ...
          1e6*double(taken);

    [~,jj] = min(tmp);

    perm(i) = jj;
    taken(jj) = true;
end

sad_v = Cmat( ...
    sub2ind([p p],1:p,perm));

end


function [sad,mse_ab,mse_rec] = ...
    e1_metrics( ...
        M_true,S_true,Y_clean, ...
        M_est,S_est,perm)

% SAD after matching.
sad_v = zeros(1,numel(perm));

for i = 1:numel(perm)

    den = norm(M_true(:,i)) * ...
          norm(M_est(:,perm(i)));

    if den <= eps
        sad_v(i) = 180;
    else
        cc = (M_true(:,i)'*M_est(:,perm(i))) / den;
        cc = max(-1,min(1,cc));
        sad_v(i) = acosd(cc);
    end
end

sad = mean(sad_v);

% Abundance MSE after matching.
S_aligned = S_est(perm,:);

mse_ab = ...
    mean((S_true(:)-S_aligned(:)).^2);

% Noise-free reconstruction MSE.
Yhat = M_est * S_est;

mse_rec = ...
    mean((Y_clean(:)-Yhat(:)).^2);

end



function S = e1_fcls_exact(M,Y)
% Exact FCLS for small p by active-set support enumeration.

[~,p] = size(M);
N = size(Y,2);

S = zeros(p,N);
best_err = inf(1,N);

tol = 1e-10;

for mask = 1:(2^p-1)

    idx = find(bitget(mask,1:p));
    q = numel(idx);

    Ma = M(:,idx);

    K = [ ...
        Ma'*Ma, ones(q,1); ...
        ones(1,q), 0];

    RHS = [ ...
        Ma'*Y; ...
        ones(1,N)];

    if rcond(K) > 1e-12
        sol = K \ RHS;
    else
        sol = pinv(K) * RHS;
    end

    Sa = sol(1:q,:);

    feasible = all(Sa >= -tol,1);

    Sa(abs(Sa) < tol) = 0;

    Sa_pos = max(Sa,0);

    denom = sum(Sa_pos,1);

    valid = feasible & ...
            denom > eps;

    if ~any(valid)
        continue;
    end

    Sa_pos(:,valid) = ...
        Sa_pos(:,valid) ./ denom(valid);

    Yhat = Ma * Sa_pos;

    err = sum((Y-Yhat).^2,1);

    update = valid & ...
             err < best_err;

    if any(update)

        S(:,update) = 0;

        S(idx,update) = ...
            Sa_pos(:,update);

        best_err(update) = ...
            err(update);
    end
end

bad = ~isfinite(best_err);

if any(bad)
    S(:,bad) = 1/p;
end

end


