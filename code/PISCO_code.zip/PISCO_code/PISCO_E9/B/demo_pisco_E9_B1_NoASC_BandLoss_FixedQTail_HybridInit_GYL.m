% E9-B1 NoASC BandLoss + fixed-Q tail -- FINAL ABUNDANCES ONLY.
% Only the S_est (AFTER fixed-Q refinement) abundance figure is displayed/saved.
% S_joint is retained in MAT exclusively for numerical diagnostics (NO joint maps).
% Joint-versus-tail residual diagnostics remain intact.
% New model term only: normalized ORIGINAL 32-band reconstruction error.
% No NNLS, no postprocessing spatial smoothing. Original experiments unchanged.
% Baseline reproduction: set OPT.LAMBDA_BAND=0 and use same seed/config.
% Distinguish PRE-CLIP and POST-CLIP residuals with the same S_est.
% E9-B1 MINIMAL NO-ASC BRANCH.
% Data loading, p, training hyperparameters (except ASC), GPU selection,
% saved MAT keys, CSV headers and all figure routines match the uploaded driver.
% Free nonnegative S_est coefficients: sum(S_est(:,j)) is NOT 1 by design.
% The geometry uses the per-pixel observed integrated intensity coordinate.
% DO NOT compare old/new abundance color scales as if both were proportions.
% Older published ASC runs are unaffected: the original trainer is untouched.
% Hybrid variant: VCA-6 + reference-initialized mKO2/mRuby; both remain trainable.
%
%% demo_pisco_E9_B1_real_twophoton.m
% E9-B1 | INDEPENDENT REAL-DATA PISCO EXPERIMENT
% Based on scenario B in demo_pisco_E9_invivo(5).m; NO E9-A/SHy-Cam arm.
%
% Dataset (metadata already checked by user):
% fig5_e_01-fish1-four-hinbrain_eye-autofl.lsm
% X=2560, Y=2048, Z=27, C=32, T=1. 740-nm two-photon HyU Fig.5e.
% B1: one/multiple Z planes -> blind endmembers, abundance maps, residual
% diagnostics, optional *exploratory* NADH map, per-run .mat + .csv + PNG.
%
% HOW TO USE:
%   Put the LSM file alongside this script or in data_E9/.
%   Put the companion HybridInit trainer (provided with this script) on the path.
%   Use QUICK=true for 256 x 256 center crop; QUICK=false for full 2048 x 2560 Z plane.
%   Begin with QUICK=true, Z_PLANES=12; view other Z planes first.
%   To test a different plane use Z_PLANES=[2 14 23], not all 27 by default.
%
% IMPORTANT SCIENTIFIC GUARDS:
% - Original HyU Fig.5e/g describes EIGHT spectra; older E9 code used ten.
%   P_FIXED=8 is a *prespecified comparison*, NOT evidence that p_true=8.
%   P_METHOD='hysime' is optional and needs external hysime.m + approximate
%   local noise estimate; document p selection in paper.
% - Plot labels report initialization provenance (VCA or reference-init);
%   they do NOT establish final biological identities such as NADH or retinoids.
% - Hybrid mode initializes columns 1..6 with VCA and columns 7..8 with
%   the MAT mKO2/mRuby spectra; all eight columns remain trainable.
% - Optional NADH ratio is DISABLED until two indices are independently
%   validated and fluorescence-scaling issues resolved.
% - For NoASC, ONLY the linear M*S residual represents the forward model.
%   The old affine residual is still stored for CSV schema compatibility
%   but is NOT a valid alternative NoASC physical prediction.
% - A uint16 LSM digital level is not automatically a calibrated photon.
%
% Outputs (created under OUT_BASE_DIR_<init_mode>/<parameter_profile>/):
%   pisco_E9_B1_results.csv / pisco_E9_B1_summary.csv
%   pisco_E9_B1_Z##_run##_full.mat (Y, M, S, stats, config, ROI...)
%   pisco_E9_B1_Z##_run##_abundances.png / _spectra.png / _residual.png
%   pisco_E9_B1_Z##_run##_initial_M0_spectra.png (initialization audit)
%   Only ONE abundance figure per run: ..._abundances.png (TAIL-optimized S_est).
%   NO joint/baseline abundance figure and NO matched abundance comparison.
%   Per-run exploratory abundance-composition proxy (NOT crosstalk GT)
%   Optional ..._NADH_exploratory.png
% Figures are displayed directly in MATLAB and ALSO saved to PNG.
% Abundance figure uses a white canvas with black-inside RGB fluorescence panels,
% consistent with E9-A MAT replot Figure A4; p endmembers + RGB overlay.
% All figure windows stay open for inspection; no SHOW_FIGURES switch.
%
% No claim of ground-truth SAD or quantitative metabolic redox ratio.
clear;close all;clc;

%% ---------------------------- CONFIGURATION ---------------------------
DATA_FILE='fig5_e_01-fish1-four-hinbrain_eye-autofl.lsm';
DATA_DIR='data_E9';
OUT_BASE_DIR='E9_B1_NoASC_BandLoss_FixedQTail_HybridInit_output'; % prevent older plots from remaining in results
Z_PLANES=12;                   % one or more explicit Z numbers, 1..27
QUICK=false;                    % true: quick 256x256 center ROI; false: full Z image
if QUICK
    CROP_HW=[256 256];         % QUICK=true: 256x256 center ROI
    MAX_PIXELS=256*256;
else
    CROP_HW=[0 0];             % QUICK=false: entire 2048x2560 Z plane
    MAX_PIXELS=2048*2560;
end
% WARNING: QUICK=false only lifts the pixel-count guard. The current trainer
% is NOT a streaming full-frame solver and may run out of CPU/GPU memory.
P_METHOD='fixed';             % fixed | hysime (external hysime required)
P_FIXED=8;                    % change to 10 as a separate model-order arm
SEEDS=[1001];
TRAINER='deep_mvsa_invflow_poisson_explicit_Warmup2_HybridInit'; % companion trainer supplied with this driver
INIT_MODE='hybrid_vca6_ref2'; % 'hybrid_vca6_ref2' or 'vca8'
VCA_INIT_COUNT=6;             % hybrid mode: six data-driven VCA components
REF_MAT_FILE='PISCO_M_32x4_HyU_strict_quasar32.mat'; % four-protein reference library
RECON_MODE='linear';          % NoASC forward model is exactly M*S; keep linear
SIGNAL_PERCENTILE=25;        % same ROI rule can be copied to B2
RECON_BLOCK=20000;
% Conditional NADH map. Only enable after external physical identification.
NADH_FREE_INDEX=[];
NADH_BOUND_INDEX=[];
NADH_SCALE_VALIDATED=false;
% Model settings: spatial regularization + spectral priors + noise model.
% Spatial: LAMBDA_SPATIAL is the 4-neighbour abundance-map penalty;
%          IMG_H/IMG_W are passed automatically using the loaded image size.
% Spectral: LAMBDA_SMOOTH is a spectral (band-axis), NOT spatial, penalty.
% Noise: NOISE_MODEL / NOISE_WEIGHT / PHOTON_GAIN / PHOTON_FLOOR /
%        READ_SIGMA / ETA / ETA_END / SIGMA_CAP control the noise treatment.
% Values below retain the existing run's effective parameters (including
% Warmup2 defaults that were previously implicit in this driver).
OPT=struct('MM_ITERS',2500,'WARM_UP',600, ...
    'LAMBDA_BAND',5, ...  % Retain exact latest uploaded setting
    'LAMBDA_ENCLOSE',10, ...
    'LAMBDA_SPATIAL',2, ...
    'LAMBDA_SMOOTH',0.1,'LAMBDA_MNONNEG',10, ...
    'NOISE_MODEL','poisson','NOISE_WEIGHT','uniform', ...
    'PHOTON_GAIN',0.1,'PHOTON_FLOOR',1,'READ_SIGMA',1, ...
    'ETA',0.4,'ETA_END',0.4, ...
    'SIGMA_CAP',0.15,'PASS_SIGMA_CAP',true, ...
    'P_METHOD',P_METHOD,'P_FIXED',P_FIXED, ...
    'TAIL_ITERS',400,'TAIL_LR',3e-4, ...
    'TAIL_REPORT_EVERY',100,'TAIL_ROLLBACK_IF_WORSE',true);
%% ---------------------------------------------------------------------
% Every initialization arm has a separate destination: never overwrite another arm.
OUT_DIR=fullfile([OUT_BASE_DIR '_' lower(INIT_MODE)], ...
    sprintf('band_%g_sp_%g_enc_%g_tail_%d_lr_%g', ...
    OPT.LAMBDA_BAND,OPT.LAMBDA_SPATIAL,OPT.LAMBDA_ENCLOSE, ...
    OPT.TAIL_ITERS,OPT.TAIL_LR)); % isolate VCA-8 and hybrid outputs
fprintf('[BandLoss] lambda=%.4g | init=%s | new output: %s\n',OPT.LAMBDA_BAND,INIT_MODE,OUT_DIR);
if QUICK
    fprintf('E9-B1 QUICK=true: center %d x %d, limit %d pixels.\n', ...
        CROP_HW(1),CROP_HW(2),MAX_PIXELS);
else
    fprintf(2,'E9-B1 QUICK=false: FULL 2048 x 2560 Z plane (%d pixels).\n', ...
        MAX_PIXELS);
    fprintf(2,['WARNING: The explicit-abundance PISCO trainer may run out ' ...
        'of RAM or GPU VRAM on a full plane.\n']);
end

scriptdir=fileparts(mfilename('fullpath'));
if isempty(scriptdir),scriptdir=pwd;end
addpath(scriptdir);
assert(exist('VCA','file')==2,'E9B1:VCA', ...
    'VCA.m is required for the six-component (or eight-component) data-driven initialization.');
assert(exist(TRAINER,'file')==2,'E9B1:Trainer', ...
    'Cannot find %s. Keep the companion HybridInit trainer beside this driver or add it to MATLAB path.',TRAINER);

% ---------------- Hybrid initialization reference library --------------
M0_reference_spectra=zeros(32,0);
init_reference_names={};
init_reference_file='';
wl=410.5+(0:31)*8.9; % fallback axis for the VCA-only baseline
switch lower(INIT_MODE)
    case 'hybrid_vca6_ref2'
        assert(P_FIXED==8 && strcmpi(P_METHOD,'fixed'), ...
            'E9B1:HybridP','Hybrid VCA-6 + two references requires P_METHOD=fixed and P_FIXED=8.');
        ref_candidates={fullfile(scriptdir,REF_MAT_FILE),REF_MAT_FILE};
        for ir=1:numel(ref_candidates)
            if exist(ref_candidates{ir},'file')==2
                init_reference_file=ref_candidates{ir};
                break;
            end
        end
        if isempty(init_reference_file)
            ref_listing=dir(fullfile(scriptdir,'PISCO_M_32x4_HyU_strict_quasar32*.mat'));
            ref_listing_dir=scriptdir;
            if isempty(ref_listing)
                ref_listing=dir('PISCO_M_32x4_HyU_strict_quasar32*.mat');
                ref_listing_dir=pwd;
            end
            if isempty(ref_listing)
                error('E9B1:MissingReference', ...
                    'Cannot find %s beside this script or in the current folder.',REF_MAT_FILE);
            end
            [~,ir_latest]=max([ref_listing.datenum]);
            init_reference_file=fullfile(ref_listing_dir,ref_listing(ir_latest).name);
        end
        Rref=load(init_reference_file);
        assert(isfield(Rref,'M') && isfield(Rref,'endmember_names') && ...
            isfield(Rref,'channel_centers_nm'), 'E9B1:ReferenceFields', ...
            'Reference MAT must contain M, endmember_names and channel_centers_nm.');
        M_reference_all=double(Rref.M);
        assert(isequal(size(M_reference_all),[32 4]) && ...
            all(isfinite(M_reference_all(:))) && all(M_reference_all(:)>=0) && ...
            all(sum(M_reference_all,1)>0), 'E9B1:ReferenceMatrix', ...
            'Reference M must be finite, nonnegative 32x4 with positive column sums.');
        if iscell(Rref.endmember_names)
            ref_names=cellfun(@char,Rref.endmember_names(:).','UniformOutput',false);
        elseif isstring(Rref.endmember_names) || ischar(Rref.endmember_names)
            ref_names=reshape(cellstr(Rref.endmember_names),1,[]);
        else
            error('E9B1:ReferenceNames','Unsupported endmember_names format.');
        end
        ref_names=cellfun(@strtrim,ref_names,'UniformOutput',false);
        idx_mko2=find(strcmpi(ref_names,'mKO2'),1);
        idx_mruby=find(strcmpi(ref_names,'mRuby'),1);
        assert(~isempty(idx_mko2) && ~isempty(idx_mruby) && idx_mko2~=idx_mruby, ...
            'E9B1:ReferenceNames','Could not uniquely locate mKO2 and mRuby in the MAT file.');
        M0_reference_spectra=M_reference_all(:,[idx_mko2 idx_mruby]);
        init_reference_names={'mKO2','mRuby'};
        wl=double(Rref.channel_centers_nm(:).');
        assert(numel(wl)==32 && all(isfinite(wl)) && all(diff(wl)>0), ...
            'E9B1:ReferenceWavelengths','Expected 32 increasing channel centers.');
        if isfield(Rref,'channel_edges_nm')
            ref_edges=double(Rref.channel_edges_nm(:));
            assert(numel(ref_edges)==33 && all(diff(ref_edges)>0) && ...
                abs(ref_edges(1)-410.5)<0.5 && abs(ref_edges(end)-694.9)<0.5, ...
                'E9B1:ReferenceGrid','Reference spectral bins do not match the HyU 410.5-694.9 nm range.');
        end
        fprintf('[HybridInit] MAT: %s\n',init_reference_file);
        fprintf('[HybridInit] Reference columns: mKO2=%d, mRuby=%d; VCA=%d; total p=8.\n', ...
            idx_mko2,idx_mruby,VCA_INIT_COUNT);
        clear Rref M_reference_all ref_names ref_edges;
    case 'vca8'
        fprintf('[Init] Original VCA initialization for all %d components.\n',P_FIXED);
    otherwise
        error('E9B1:InitMode','INIT_MODE must be hybrid_vca6_ref2 or vca8.');
end
component_labels={};
if strcmpi(INIT_MODE,'hybrid_vca6_ref2')
    component_labels=[arrayfun(@(k)sprintf('VCA-%02d',k),1:VCA_INIT_COUNT, ...
        'UniformOutput',false),{'Ref-init mKO2','Ref-init mRuby'}];
else
    component_labels=arrayfun(@(k)sprintf('VCA-%02d',k),1:P_FIXED, ...
        'UniformOutput',false);
end

candidates={DATA_FILE,fullfile(DATA_DIR,DATA_FILE), ...
    fullfile(scriptdir,DATA_FILE),fullfile(scriptdir,DATA_DIR,DATA_FILE)};
fname='';
for ii=1:numel(candidates)
    if exist(candidates{ii},'file')==2,fname=candidates{ii};break;end
end
assert(~isempty(fname),'E9B1:NoLSM','Missing LSM file: %s',DATA_FILE);
if ~exist(OUT_DIR,'dir'),mkdir(OUT_DIR);end
results_path=fullfile(OUT_DIR,'pisco_E9_B1_results.csv');
fid=fopen(results_path,'w');
assert(fid>0,'E9B1:CSV','Cannot write CSV: %s',results_path);
fprintf(fid,['z,run,seed,p,p_source,init_mode,vca_init_count,reference_init_count,' ...
    'init_M0_rcond,init_M0_condition,H,W,n_pixels,train_time_s,' ...
    'signal_pixels,rel_frob_linear,rel_frob_affine,' ...
    'pearson_per_count,poisson_deviance_per_count,recon_mode,' ...
    'lambda_band,raw_frob_preclip,clip_relative,' ...
    'tail_iters,tail_lr,tail_joint_frob,tail_sse_change_pct,tail_rolled_back,' ...
    'intensity_joint_median,intensity_tail_median\n']);
fclose(fid);
summary_path=fullfile(OUT_DIR,'pisco_E9_B1_summary.csv');
fid=fopen(summary_path,'w');
assert(fid>0,'E9B1:Summary','Cannot write summary CSV.');
fprintf(fid,['z,p,n_runs,linear_mean,linear_std,affine_mean,affine_std,' ...
    'pearson_mean,pearson_std,deviance_mean,deviance_std\n']);
fclose(fid);
% Wavelength axis is the reference MAT channel-center grid in hybrid mode.
fprintf('\n=== E9-B1 real two-photon experiment ===\nFile: %s\n',fname);
fprintf('MATLAB figures: display ON; also saving PNG/MAT/CSV.\n');

for iz=1:numel(Z_PLANES)
    z=Z_PLANES(iz);
    [Y,roi_info]=e9b_read_lsm_roi(fname,z,CROP_HW,MAX_PIXELS);
    H=roi_info.H;W=roi_info.W;
    mask=e9b_signal_mask(Y,SIGNAL_PERCENTILE);
    [p,p_source]=e9b_select_p(Y,OPT);
    b1_linear=NaN(1,numel(SEEDS));b1_affine=b1_linear;
    b1_pearson=b1_linear;b1_deviance=b1_linear;
    for run=1:numel(SEEDS)
        seed=SEEDS(run);
        rng(seed,'twister');
        args=e9b_train_options(H,W,OPT);
        if strcmpi(INIT_MODE,'hybrid_vca6_ref2')
            args=[args,{'M0_VCA_COUNT',VCA_INIT_COUNT, ...
                'M0_REFERENCE',M0_reference_spectra}];
        end
        fprintf('\nB1 | Z=%d | run=%d | seed=%d | p=%d | init=%s ...\n', ...
            z,run,seed,p,INIT_MODE);
        ticTrain=tic;
        % Request optional theta solely to audit the model's final endmember clipping.
        [M_est,S_est,~,~,theta_audit]=feval(TRAINER,Y,p,args{:});
        M_preclip=theta_audit.M_before_clip_bandloss_audit;
        S_joint=theta_audit.S_before_tail;
        tail_info=theta_audit.tail_info;
        band_clip_relative=theta_audit.endmember_clip_relative;
        M0_initial_band=theta_audit.M0_initial_band;
        M0_initial_work=theta_audit.M0_initial_work;
        init_M0_rcond=theta_audit.M0_initial_rcond;
        init_M0_condition=theta_audit.M0_initial_condition;
        init_vca_count=theta_audit.M0_vca_count;
        init_reference_count=theta_audit.M0_reference_count;
        clear theta_audit;
        fprintf(['[Init audit] VCA=%d + reference=%d | M0 rcond=%.4g | ' ...
            'M0 cond=%.4g\n'],init_vca_count,init_reference_count, ...
            init_M0_rcond,init_M0_condition);
        train_time_s=toc(ticTrain);
        stats=e9b_residual_metrics(Y,M_est,S_est,mask,H,W,RECON_MODE,RECON_BLOCK);
        % Diagnostic only: same S_est, before vs after output nonnegative clip.
        r_preclip=e9b_frob_only(Y,M_preclip,S_est,mask,RECON_BLOCK);
        r_joint_preclip=e9b_frob_only(Y,M_preclip,S_joint,mask,RECON_BLOCK);
        r_joint_postclip=e9b_frob_only(Y,M_est,S_joint,mask,RECON_BLOCK);
        fprintf(['[FixedQ-tail] Same ROI, fixed M: joint PRECLIP %.9f, ' ...
            'joint POSTCLIP %.9f | tail PRECLIP %.9f, ' ...
            'tail POSTCLIP %.9f\n'], ...
            r_joint_preclip,r_joint_postclip,r_preclip,stats.linear_frob);
        fprintf('[FixedQ-tail] Joint -> tail ROI SSE change = %+.4f%%\n', ...
            100*(stats.linear_frob^2/max(r_joint_postclip^2,eps)-1));
        [intensity_joint_median,intensity_tail_median] = ...
            e9b_tail_median_intensity_ratio(Y,M_est,S_joint,S_est,mask);
        fprintf('[FixedQ-tail] Pred/obs integral median (same sampled ROI): %.6f -> %.6f\n', ...
            intensity_joint_median,intensity_tail_median);
        fprintf(['[BandLoss] lambda=%.4g | raw ROI PRE-CLIP=%.9f | ' ...
            'POST-CLIP=%.9f | endmember clip rel=%.5g\n'], ...
            OPT.LAMBDA_BAND,r_preclip,stats.linear_frob,band_clip_relative);
        bandloss_diagnostic=struct('lambda_band',OPT.LAMBDA_BAND, ...
            'raw_roi_frob_before_clip',r_preclip, ...
            'raw_roi_frob_after_clip',stats.linear_frob, ...
            'clip_relative',band_clip_relative, ...
            'note','TRAIN uses preclip M; returned M_est=max(preclip M,0)');
        clear M_preclip;
        tag=sprintf('pisco_E9_B1_Z%02d_run%02d',z,run);
        roi_mask=reshape(mask,H,W);
        config=struct('trainer',TRAINER,'trainer_path',which(TRAINER), ...
            'input_file',fname,'p',p,'p_source',p_source, ...
            'seed',seed,'z',z,'QUICK',QUICK,'crop_hw',CROP_HW, ...
             'max_pixels',MAX_PIXELS,'recon_mode',RECON_MODE, ...
             'signal_percentile',SIGNAL_PERCENTILE,'options',OPT, ...
             'initialization_mode',INIT_MODE, ...
             'vca_initialization_count',init_vca_count, ...
             'reference_initialization_count',init_reference_count, ...
             'reference_initialization_names',{init_reference_names}, ...
             'reference_initialization_file',init_reference_file, ...
             'reference_spectra_fixed_during_training',false, ...
             'initial_M0_rcond',init_M0_rcond, ...
             'initial_M0_condition',init_M0_condition, ...
             'initialization_note','mKO2/mRuby are reference-informed initial values only; all 8 endmembers remain trainable; 740-nm-specific spectral equivalence is not established', ...
             'abundance_interpretation','unnormalized coefficients; soft nonnegativity; no ASC', ...
             'relative_intensity_reference','mean 32-band observed integral', ...
             'affine_metric_note','legacy diagnostic only; linear is the NoASC forward model', ...
            'wavelengths_nm',wl,'input_is_calibrated_photons',false);
        % Exploratory compositional overlap: NOT a ground-truth crosstalk rate.
        coefficient_sum = sum(S_est,1);  % NoASC: free, varying with brightness
        observed_relative_intensity = sum(Y,1)/mean(sum(Y,1));
        composition_proxy=e9b_abundance_composition(S_est,mask);
        e9b_plot_composition(composition_proxy, ...
            fullfile(OUT_DIR,[tag '_composition_proxy.png']), ...
            sprintf('E9-B1 Z=%d exploratory abundance composition',z));
        % Preserve matrix order exactly: M_est and S_est are NOT renamed.
        % Store the original observed 32-band region and reconstructed image.
        original_cube_32HW=reshape(single(Y),32,H,W);
        reconstructed_cube_32HW=reshape(stats.yhat_selected,32,H,W);
        residual_linear=stats.residual_linear;
        residual_affine=stats.residual_affine;
        save(fullfile(OUT_DIR,[tag '_full.mat']), ...
            'Y','original_cube_32HW','reconstructed_cube_32HW', ...
            'M_est','S_est','mask','roi_mask','roi_info','wl','config', ...
            'M0_initial_band','M0_initial_work','M0_reference_spectra', ...
            'init_reference_names','init_reference_file','init_vca_count', ...
            'init_reference_count','init_M0_rcond','init_M0_condition', ...
            'stats','composition_proxy','coefficient_sum','observed_relative_intensity', ...
            'residual_linear','residual_affine','train_time_s','bandloss_diagnostic', ...
            'S_joint','tail_info','r_joint_preclip','r_joint_postclip', ...
            'intensity_joint_median','intensity_tail_median', ...
            '-v7.3');
        fprintf('NoASC | sum(A) median=%.4g | observed rel intensity median=%.4g\n', ...
            median(coefficient_sum),median(observed_relative_intensity));
        % Only plot FINAL optimized abundance maps (S_est AFTER fixed-Q tail).
        % Baseline S_joint remains in MAT for numeric comparison, never plotted.
        e9b_plot_abundances(S_est,H,W,fullfile(OUT_DIR,[tag '_abundances.png']), ...
            sprintf('E9-B1 Fixed-Q TAIL optimized | Z=%d, p=%d, run=%d',z,p,run), ...
            component_labels);
        % Keep numerical residual comparison, but no baseline abundance figure.
        e9b_plot_terminal_residuals(Y,M_est,S_joint,S_est,mask,H,W,RECON_BLOCK, ...
            fullfile(OUT_DIR,[tag '_FixedQTail_residual_comparison.png']), ...
            r_joint_postclip,stats.linear_frob);
        e9b_plot_spectra(wl,M0_initial_band,sprintf('E9-B1 initial M0 (VCA/reference provenance), Z=%d',z), ...
            fullfile(OUT_DIR,[tag '_initial_M0_spectra.png']),component_labels);
        e9b_plot_spectra(wl,M_est,sprintf('E9-B1 spectra (initialization labels only), Z=%d',z), ...
            fullfile(OUT_DIR,[tag '_spectra.png']),component_labels);
        e9b_plot_residual(Y,mask,stats,H,W, ...
            fullfile(OUT_DIR,[tag '_residual.png']), ...
            sprintf('E9-B1 Z=%d; same ROI for both residual definitions',z));
        % A ratio can only be explored AFTER independent identity/scaling checks.
        if ~isempty(NADH_FREE_INDEX) && ~isempty(NADH_BOUND_INDEX)
            assert(NADH_SCALE_VALIDATED, 'E9B1:NADHScaling', ...
                'Set NADH_SCALE_VALIDATED=true ONLY after confirming calibration.');
            assert(all([NADH_FREE_INDEX,NADH_BOUND_INDEX]>=1) && ...
                all([NADH_FREE_INDEX,NADH_BOUND_INDEX]<=p) && ...
                NADH_FREE_INDEX~=NADH_BOUND_INDEX,'E9B1:NADHIndex', ...
                'NADH indices must be two distinct endmember columns.');
            Sf=max(S_est(NADH_FREE_INDEX,:),0);
            Sb=max(S_est(NADH_BOUND_INDEX,:),0);
            ratio=reshape(Sf./max(Sf+Sb,eps),H,W);
            ratio(~roi_mask)=NaN;
            f=figure('Visible','on','Color','w');
            imagesc(ratio,[0 1]);axis image off;colorbar;
            title('Exploratory abundance ratio; NOT validated metabolic redox');
            exportgraphics(f,fullfile(OUT_DIR,[tag '_NADH_exploratory.png']), ...
                'Resolution',150);drawnow;
            save(fullfile(OUT_DIR,[tag '_NADH_exploratory.mat']),'ratio', ...
                'NADH_FREE_INDEX','NADH_BOUND_INDEX','-v7.3');
        end
        fid=fopen(results_path,'a');
        fprintf(fid,['%d,%d,%d,%d,%s,%s,%d,%d,%.9g,%.9g,%d,%d,%d,%.6f,%d,' ...
            '%.9g,%.9g,%.9g,%.9g,%s,%.9g,%.9g,%.9g,%d,%.9g,%.9g,%.9g,%d,' ...
            '%.9g,%.9g\n'], ...
            z,run,seed,p,p_source,INIT_MODE,init_vca_count,init_reference_count, ...
            init_M0_rcond,init_M0_condition,H,W,H*W,train_time_s,nnz(mask), ...
            stats.linear_frob,stats.affine_frob, ...
            stats.pearson_per_count,stats.poisson_deviance_per_count,RECON_MODE, ...
            OPT.LAMBDA_BAND,r_preclip,band_clip_relative, ...
            tail_info.iterations_done,tail_info.lr,r_joint_postclip, ...
            100*(stats.linear_frob^2/max(r_joint_postclip^2,eps)-1), ...
            tail_info.rolled_back,intensity_joint_median,intensity_tail_median);
        fclose(fid);
        b1_linear(run)=stats.linear_frob;
        b1_affine(run)=stats.affine_frob;
        b1_pearson(run)=stats.pearson_per_count;
        b1_deviance(run)=stats.poisson_deviance_per_count;
        fprintf('Saved: %s | train %.1f sec\n',tag,train_time_s);
    end
    fid=fopen(summary_path,'a');
    fprintf(fid,'%d,%d,%d,%.9g,%.9g,%.9g,%.9g,%.9g,%.9g,%.9g,%.9g\n', ...
        z,p,numel(SEEDS),mean(b1_linear),std(b1_linear), ...
        mean(b1_affine),std(b1_affine), ...
        mean(b1_pearson),std(b1_pearson), ...
        mean(b1_deviance),std(b1_deviance));
    fclose(fid);
end
fprintf('\nE9-B1 complete. See %s\n',OUT_DIR);


%% ========================================================================
% Local utilities. Duplicated deliberately so this .m is self contained.
% No E9-A script or additional project helper file is required.
% ========================================================================
function e9b_plot_terminal_residuals(Y,M,S0,S1,mask,H,W,block,filename,r0,r1)
% Original 32-band, same P25 ROI; per-pixel relative L2 residual.
N=size(Y,2); a=nan(1,N,'single');b=a;
for idx=1:block:N
    j=idx:min(idx+block-1,N);
    if ~any(mask(j)),continue;end
    obs=double(Y(:,j));den=max(sqrt(sum(obs.^2,1)),1);
    e0=obs-double(M)*double(S0(:,j));
    e1=obs-double(M)*double(S1(:,j));
    aa=sqrt(sum(e0.^2,1))./den;
    bb=sqrt(sum(e1.^2,1))./den;
    aa(~mask(j))=nan;bb(~mask(j))=nan;
    a(j)=single(aa);b(j)=single(bb);
end
im0=fliplr(reshape(a,H,W));im1=fliplr(reshape(b,H,W));
f=figure('Color','w','Visible','on','Position',[30 30 1500 540]);
tiledlayout(f,1,3,'TileSpacing','compact','Padding','compact');
nexttile;imagesc(im0,[0 1.5]);axis image off;colorbar;
title(sprintf('JOINT: R=%.6f',r0));
nexttile;imagesc(im1,[0 1.5]);axis image off;colorbar;
title(sprintf('Fixed-Q tail: R=%.6f',r1));
nexttile;imagesc(im0-im1,[-0.5 0.5]);axis image off;colorbar;
title('Relative pixel L2: JOINT - TAIL');
sgtitle('Same M after clipping, same original Y / ROI','Interpreter','none');
exportgraphics(f,filename,'Resolution',140);drawnow;
end

function [r_joint,r_tail] = e9b_tail_median_intensity_ratio(Y,M,S0,S1,mask)
% Deterministic ROI sampling to avoid another full 32*N reconstruction.
idx=find(mask);
stride=max(1,ceil(numel(idx)/150000));
idx=idx(1:stride:end);
obs=sum(double(Y(:,idx)),1);
valid=obs>0;
idx=idx(valid);
obs=obs(valid);
if isempty(idx),r_joint=NaN;r_tail=NaN;return;end
pred0=sum(double(M)*double(S0(:,idx)),1);
pred1=sum(double(M)*double(S1(:,idx)),1);
r_joint=median(pred0./obs);
r_tail=median(pred1./obs);
end

function r=e9b_frob_only(Y,M,S,mask,block)
% Blocked ROI-only relative Frobenius; no 32xN output cube allocated.
    acc=0;den=0;N=size(Y,2);
    for k=1:block:N
        j=k:min(k+block-1,N);
        msk=logical(mask(j));
        if ~any(msk),continue;end
        obs=double(Y(:,j(msk)));
        pred=double(M)*double(S(:,j(msk)));
        d=obs-pred;
        acc=acc+sum(d(:).^2);
        den=den+sum(obs(:).^2);
    end
    r=sqrt(acc/max(den,eps));
end

function [Y, roi_info] = e9b_read_lsm_roi(fname, z, cropHW, max_pixels)
% Reads ONLY one Z (32 spectral bands). Native Tiff first, Bio-Formats fallback.
% Note: native Tiff.read decodes one full-resolution uint16 Z page in RAM;
% ROI is cropped before conversion to double. No full volume is loaded.
    originalH = 2048; originalW = 2560; expectedZ = 27; C = 32;
    assert(isscalar(z) && z == round(z) && z >= 1 && z <= expectedZ, ...
        'E9B:Z','Z must be an integer from 1 to %d.',expectedZ);
    assert(numel(cropHW)==2 && all(cropHW >= 0),'E9B:Crop','Bad crop size.');
    if all(cropHW == 0)
        rr = 1:originalH; cc = 1:originalW;
    else
        h = cropHW(1); w = cropHW(2);
        assert(h<=originalH && w<=originalW && h>=1 && w>=1 && ...
            h==round(h) && w==round(w),'E9B:Crop','Invalid crop size.');
        r1 = floor((originalH - h)/2) + 1;
        c1 = floor((originalW - w)/2) + 1;
        rr = r1:(r1+h-1); cc = c1:(c1+w-1);
    end
    H = numel(rr); W = numel(cc);
    assert(H*W <= max_pixels,'E9B:MemoryGuard', ...
        ['Requested %d pixels exceeds MAX_PIXELS=%d. The original trainer' ...
         ' is NOT a verified full-frame streaming solver. Increase the' ...
         ' limit only after reviewing available RAM and trainer behavior.'], ...
        H*W,max_pixels);
    roi_info = struct('z',z,'H',H,'W',W,'rows',[rr(1),rr(end)], ...
        'cols',[cc(1),cc(end)],'fullH',originalH,'fullW',originalW, ...
        'channels',C,'pixel_count',H*W,'method','');
    Y = [];
    native_error = '';
    try
        tif = Tiff(fname,'r');
        tif_close = onCleanup(@() tif.close()); %#ok<NASGU>
        dirs = e9b_fullres_dirs(tif,originalW,originalH);
        assert(numel(dirs)>=expectedZ,'E9B:Directories', ...
            'Only %d full-resolution TIFF pages; expected at least %d.', ...
            numel(dirs),expectedZ);
        tif.setDirectory(dirs(z));
        A = tif.read();
        assert(size(A,1)==originalH && size(A,2)==originalW && ...
            size(A,3)>=C,'E9B:TiffShape', ...
            'Tiff.read returned %s, expected H x W x >=32.',mat2str(size(A)));
        Y = zeros(C,H*W,'double');
        for c=1:C
            tmp = A(rr,cc,c);
            Y(c,:) = reshape(double(tmp),1,[]);
        end
        clear A;
        roi_info.method = 'MATLAB Tiff';
    catch ME
        native_error = ME.message;
        Y = [];
    end
    if isempty(Y)
        if exist('bfGetReader','file') ~= 2 || exist('bfGetPlane','file') ~= 2
            error('E9B:Reader',[...
                'Native TIFF reader failed: %s\n' ...
                'Install the MATLAB Bio-Formats package (bfGetReader and' ...
                ' bfGetPlane) or inspect this >4GB LSM image encoding.'], ...
                native_error);
        end
        fprintf(2,'Native TIFF read unavailable: %s\nTrying Bio-Formats...\n',native_error);
        br = bfGetReader(fname);
        br_close = onCleanup(@() br.close()); %#ok<NASGU>
        br.setSeries(0);
        assert(double(br.getSizeX())==originalW && double(br.getSizeY())==originalH && ...
            double(br.getSizeZ())>=expectedZ && double(br.getSizeC())>=C, ...
            'E9B:BFShape','Unexpected Bio-Formats series dimensions.');
        Y = zeros(C,H*W,'double');
        for c=1:C
            plane_id = double(br.getIndex(z-1,c-1,0))+1;
            A = bfGetPlane(br,plane_id);
            tmp = A(rr,cc);
            Y(c,:) = reshape(double(tmp),1,[]);
        end
        roi_info.method = 'Bio-Formats';
    end
    assert(isequal(size(Y),[C H*W]) && all(isfinite(Y(:))) && ...
        all(Y(:)>=0),'E9B:BadY','Invalid intensity values in imported cube.');
    fprintf('Read Z=%d by %s | %d x %d | 32 bands | count range %.5g..%.5g\n', ...
        z,roi_info.method,H,W,min(Y(:)),max(Y(:)));
end

function dirs=e9b_fullres_dirs(tif,X,Y)
% Use dimensions, never assume alternating thumbnails, never read pixels.
    dirs=[]; tif.setDirectory(1); idx=1;
    while true
        x=double(tif.getTag(Tiff.TagID.ImageWidth));
        y=double(tif.getTag(Tiff.TagID.ImageLength));
        if x==X && y==Y
            dirs(end+1)=idx; %#ok<AGROW>
        end
        if tif.lastDirectory(), break; end
        tif.nextDirectory(); idx=idx+1;
        assert(idx<10000,'E9B:IFD','Too many TIFF directories.');
    end
end

function mask=e9b_signal_mask(Y,percentile)
% Fixed ROI from ORIGINAL data, not from each thinned observation.
    brightness = sum(Y,1);
    v = sort(brightness(isfinite(brightness)));
    assert(~isempty(v),'E9B:EmptyData','All pixel intensities are invalid.');
    rank=max(1,min(numel(v),round(1+(numel(v)-1)*percentile/100)));
    threshold=v(rank);
    mask=brightness>max(0,threshold);
    if nnz(mask)<max(100,ceil(.03*numel(mask)))
        mask=brightness>0;
    end
    assert(nnz(mask)>0,'E9B:Mask','There are no illuminated pixels.');
end

function args=e9b_train_options(H,W,opt)
% Pass all spatial/spectral/noise settings from OPT to Warmup2 explicitly.
% H and W always come from the actually loaded Z-plane/crop dimensions.
    args={'spherize','yes','verbose',0, ...
        'MM_ITERS',opt.MM_ITERS,'WARM_UP',opt.WARM_UP,'LR',3e-4, ...
        'LAMBDA_VOL',0.008,'LAMBDA_NONNEG',3,'LAMBDA_EQ',100, ...
        'LAMBDA_SUMONE',0,'LAMBDA_ENCLOSE',opt.LAMBDA_ENCLOSE, ...
        'IMG_H',H,'IMG_W',W, ...
        'LAMBDA_SPATIAL',opt.LAMBDA_SPATIAL, ...
        'LAMBDA_SMOOTH',opt.LAMBDA_SMOOTH, ...
        'LAMBDA_MNONNEG',opt.LAMBDA_MNONNEG, ...
        'NOISE_MODEL',opt.NOISE_MODEL,'NOISE_WEIGHT',opt.NOISE_WEIGHT, ...
        'PHOTON_GAIN',opt.PHOTON_GAIN,'PHOTON_FLOOR',opt.PHOTON_FLOOR, ...
        'READ_SIGMA',opt.READ_SIGMA, ...
        'ETA',opt.ETA,'ETA_END',opt.ETA_END, ...
        'LAMBDA_BAND',opt.LAMBDA_BAND, ...
        'TAIL_ITERS',opt.TAIL_ITERS,'TAIL_LR',opt.TAIL_LR, ...
        'TAIL_REPORT_EVERY',opt.TAIL_REPORT_EVERY, ...
        'TAIL_ROLLBACK_IF_WORSE',opt.TAIL_ROLLBACK_IF_WORSE};
    if opt.PASS_SIGMA_CAP
        args=[args,{'SIGMA_CAP',opt.SIGMA_CAP}];
    end
end

function [p,src]=e9b_select_p(Y,opt)
% HySime is optional. If selected, require an external implementation and
% explicitly note that the spatial-difference noise model is approximate.
    switch lower(opt.P_METHOD)
        case 'fixed'
            p=opt.P_FIXED; src='fixed';
        case 'hysime'
            assert(exist('hysime','file')==2,'E9B:HySime', ...
                ['P_METHOD=hysime needs the externally installed hysime.m.' ...
                ' Set P_METHOD=fixed if unavailable.']);
            sample_count=min(16000,size(Y,2));
            inds=unique(round(linspace(1,size(Y,2),sample_count)));
            A=Y(:,inds);
            % Approximate spatial-pair differencing, not a calibrated
            % instrument noise estimate. Use HySime as a sensitivity check.
            if mod(size(A,2),2), A=A(:,1:end-1); end
            d=(A(:,1:2:end)-A(:,2:2:end))/2;
            w=zeros(size(A)); w(:,1:2:end)=d; w(:,2:2:end)=-d;
            try
                p=hysime(A,w,0);
            catch ME
                error('E9B:HySimeAPI', ...
                    ['hysime.m must support hysime(Y,noise,verbose). ' ...
                     'Original error: %s'],ME.message);
            end
            p=double(p(1)); src='hysime_approx_spatial_noise';
            assert(isfinite(p) && p==round(p) && p>=2 && p<=size(Y,1), ...
                'E9B:HySimeP','Invalid HySime p=%g.',p);
        otherwise
            error('E9B:PMethod','P_METHOD must be fixed or hysime.');
    end
end

function stats=e9b_residual_metrics(Y,M,S,mask,H,W,mode,block)
% Two candidate reconstructions are reported side-by-side:
% 1. linear: M*S
% 2. affine: M*S - my*(sum(S)-1), my=mean(Y,2).
% The affine form is ONLY justified if the PISCO trainer returns columns
% shifted by this exact my vector. Inspect trainer internals before citing.
% No dark-pixel-dominated mean of per-pixel ratios is used as headline.
    assert(size(Y,1)==size(M,1) && size(M,2)==size(S,1) && ...
        size(Y,2)==size(S,2),'E9B:ModelShape','M,S,Y sizes mismatch.');
    assert(nnz(mask)>0,'E9B:Mask','Empty ROI.');
    n=size(Y,2); p=size(M,2); %#ok<NASGU>
    my=mean(Y,2);
    normY=0; slin=0; saff=0;
    dev=0; pear=0; nz=0;
    map_lin=NaN(1,n,'single');
    map_aff=NaN(1,n,'single');
    % Reconstructed spectral cube is saved, not just a picture.
    yhat=zeros(size(Y),'single');
    for idx=1:block:n
        j=idx:min(idx+block-1,n);
        obs=Y(:,j);
        pred_lin=M*S(:,j);
        pred_aff=pred_lin-my*(sum(S(:,j),1)-1);
        elin=obs-pred_lin;
        eaff=obs-pred_aff;
        denom=sqrt(sum(obs.^2,1));
        msk=mask(j);
        map_lin(j)=single(sqrt(sum(elin.^2,1))./max(denom,1));
        map_aff(j)=single(sqrt(sum(eaff.^2,1))./max(denom,1));
        normY=normY+sum(sum(obs(:,msk).^2));
        slin=slin+sum(sum(elin(:,msk).^2));
        saff=saff+sum(sum(eaff(:,msk).^2));
        if strcmpi(mode,'affine_mean')
            pred=pred_aff;
        elseif strcmpi(mode,'linear')
            pred=pred_lin;
        else
            error('E9B:ReconMode','Select linear or affine_mean.');
        end
        yhat(:,j)=single(pred);
        mu=max(pred(:,msk),1e-8); yy=obs(:,msk);
        pear=pear+sum(sum((yy-mu).^2./mu));
        r=mu-yy;
        ispos=yy>0;
        r(ispos)=r(ispos)+yy(ispos).*log(yy(ispos)./mu(ispos));
        dev=dev+2*sum(r(:));
        nz=nz+numel(yy);
    end
    stats=struct();
    stats.linear_frob=sqrt(slin/max(normY,eps));
    stats.affine_frob=sqrt(saff/max(normY,eps));
    stats.pearson_per_count=pear/max(nz,1);
    stats.poisson_deviance_per_count=dev/max(nz,1);
    stats.n_signal_pixels=nnz(mask);
    stats.residual_linear=reshape(map_lin,H,W);
    stats.residual_affine=reshape(map_aff,H,W);
    stats.yhat_selected=yhat;
    stats.my_used=my;
    if strcmpi(mode,'affine_mean'),stats.selected_frob=stats.affine_frob;
    else,stats.selected_frob=stats.linear_frob;end
    stats.recon_mode=mode;
    fprintf('ROI Frobenius residual linear=%.5f | affine=%.5f | used=%s\n', ...
        stats.linear_frob,stats.affine_frob,mode);
end

function e9b_plot_spectra(wavelengths,M,t,filename,component_labels)
    p=size(M,2);
    if nargin<5 || isempty(component_labels)
        component_labels=arrayfun(@(k)sprintf('EM%02d',k),1:p,'UniformOutput',false);
    end
% Plot spectra as tiled subplots, similar in spirit to the abundance figure.
% Panels 1..p: one subplot per endmember. Final panel: overlay of all spectra.
    scale=max(abs(M),[],1); scale(scale==0)=1;
    Mplot=M./scale;

    plot_rgb=[ ...
        1.00 0.25 0.10; ...  % EM01 red-orange
        1.00 0.95 0.10; ...  % EM02 yellow
        0.95 0.10 0.95; ...  % EM03 magenta
        0.35 0.95 1.00; ...  % EM04 cyan
        0.58 0.15 0.95; ...  % EM05 violet
        0.30 1.00 0.20; ...  % EM06 green
        1.00 0.65 0.10; ...  % EM07 orange
        0.20 0.35 1.00];     % EM08 blue

    nPanels=p+1;                  % p individual subplots + 1 overlay subplot
    nCols=min(3,nPanels);
    nRows=ceil(nPanels/nCols);
    figH=min(1650,max(650,320*nRows));
    f=figure('Color','w','Visible','on','Position',[50 50 1550 figH]);
    tl=tiledlayout(f,nRows,nCols,'TileSpacing','compact','Padding','compact');

    yMin=min(Mplot(:));
    yMax=max(Mplot(:));
    if ~isfinite(yMin), yMin=0; end
    if ~isfinite(yMax) || yMax<=yMin, yMax=1; end

    for i=1:p
        ax=nexttile(tl,i);
        c=plot_rgb(mod(i-1,size(plot_rgb,1))+1,:);
        plot(ax,wavelengths,Mplot(:,i),'LineWidth',1.8,'Color',c);
        grid(ax,'on');
        xlim(ax,[min(wavelengths) max(wavelengths)]);
        ylim(ax,[min(0,yMin) yMax*1.02]);
        xlabel(ax,'Wavelength (nm)');
        ylabel(ax,'Norm. intensity');
        title(ax,sprintf('%s spectrum',component_labels{i}),'Interpreter','none','Color','k','FontSize',11);
    end

    ax=nexttile(tl,p+1);
    hold(ax,'on');
    for i=1:p
        c=plot_rgb(mod(i-1,size(plot_rgb,1))+1,:);
        plot(ax,wavelengths,Mplot(:,i),'LineWidth',1.4,'Color',c, ...
            'DisplayName',component_labels{i});
    end
    hold(ax,'off');
    grid(ax,'on');
    xlim(ax,[min(wavelengths) max(wavelengths)]);
    ylim(ax,[min(0,yMin) yMax*1.02]);
    xlabel(ax,'Wavelength (nm)');
    ylabel(ax,'Norm. intensity');
    title(ax,sprintf('All %d endmembers | overlay',p), ...
        'Interpreter','none','Color','k','FontSize',11);
    legend(ax,'Location','best');

    title(tl,[t ' | tiled endmember spectra'],'Interpreter','none', ...
        'Color','k','FontSize',13,'FontWeight','bold');
    exportgraphics(f,filename,'Resolution',160);
    drawnow;
end

function e9b_plot_abundances(S,H,W,filename,t,component_labels)
    p=size(S,1);
    if nargin<6 || isempty(component_labels)
        component_labels=arrayfun(@(k)sprintf('EM%02d',k),1:p,'UniformOutput',false);
    end
% E9-B1 fluorescence-style abundance figure; adapted from the E9-A
% replot_pisco_E9_A_E1_L2_generic_endmembers_with_full_residual script,
% Figure A4 and its percentile-range / colorize / additive-overlay helpers.
%
% WHITE figure canvas, BLACK only within individual RGB image panels.
% DISPLAY ONLY: native S_est, M_est, residuals and saved MAT stay unchanged.
% Each EM uses its own P65--P99.5 normalization + gamma=0.85.
% Displayed abundance panels are mirrored left-right (fliplr).
% This visualization cannot validate the biological identity of an EM.

    black_pct=45;
    white_pct=99.5;
    gamma_display=0.85;
    plot_rgb=[ ...
        1.00 0.25 0.10; ...  % EM01 red-orange
        1.00 0.95 0.10; ...  % EM02 yellow
        0.95 0.10 0.95; ...  % EM03 magenta
        0.35 0.95 1.00; ...  % EM04 cyan
        0.58 0.15 0.95; ...  % EM05 violet
        0.30 1.00 0.20; ...  % EM06 green
        1.00 0.65 0.10; ...  % EM07 orange
        0.20 0.35 1.00];     % EM08 blue

    nPanels=p+1;                  % p colored abundances + 1 RGB overlay
    nCols=min(3,nPanels);
    nRows=ceil(nPanels/nCols);
    figH=min(1650,max(650,335*nRows));
    f=figure('Name','E9-B1: colored abundance maps', ...
        'Visible','on','Color','w','Position',[35 35 1600 figH]);
    tl=tiledlayout(f,nRows,nCols, ...
        'TileSpacing','compact','Padding','compact');

    % Build RGB overlay incrementally: no extra H x W x p display cube.
    overlay_rgb=zeros(H,W,3,'single');
    for i=1:p
        A=reshape(S(i,:),H,W);
        A=fliplr(A);   % horizontal flip for each abundance map display
        intensity=e9b_display_percentile_range(A, ...
            black_pct,white_pct,gamma_display);
        c=plot_rgb(mod(i-1,size(plot_rgb,1))+1,:);
        colored=e9b_colorize_rgb(intensity,c);

        ax=nexttile(tl,i);
        image(ax,colored);            % truecolor RGB; black only within image
        axis(ax,'image');axis(ax,'off');
        title(ax,sprintf('%s abundance',component_labels{i}), ...
            'Interpreter','none','Color','k','FontSize',11);

        for ch=1:3
            overlay_rgb(:,:,ch)=overlay_rgb(:,:,ch)+intensity*single(c(ch));
        end
    end

    % Composite RGB overlay, exactly the Figure-A4 display concept.
    overlay_rgb=uint8(round(255*min(max(overlay_rgb,0),1)));
    ax=nexttile(tl,p+1);
    image(ax,overlay_rgb);
    axis(ax,'image');axis(ax,'off');
    title(ax,sprintf('All %d endmembers | RGB overlay',p), ...
        'Interpreter','none','Color','k','FontSize',11);

    title(tl,sprintf('%s | colored abundances (P%.1f - P%.1f, gamma %.2f)', ...
        t,black_pct,white_pct,gamma_display), ...
        'Interpreter','none','Color','k','FontSize',13, ...
        'FontWeight','bold');
    exportgraphics(f,filename,'Resolution',160,'BackgroundColor','white');
    drawnow;
end

function out=e9b_display_percentile_range(I,low_pct,high_pct,gamma_display)
% Identical normalization strategy to the E9-A replot helper.
    I=double(I);
    I(~isfinite(I))=0;
    I=max(I,0);
    lo=e9b_display_percentile(I,low_pct);
    hi=e9b_display_percentile(I,high_pct);
    if hi<=lo
        out=zeros(size(I),'single');
        return;
    end
    v=max(0,min(1,(I-lo)/(hi-lo)));
    out=single(v.^gamma_display);
end

function v=e9b_display_percentile(x,pct)
% Same deterministic sampling as the supplied E9-A replot script.
    x=double(x(:));
    x=x(isfinite(x));
    if isempty(x),v=0;return;end
    stride=max(1,ceil(numel(x)/200000));
    x=sort(x(1:stride:end));
    pct=max(0,min(100,double(pct)));
    pos=1+(numel(x)-1)*pct/100;
    lo=floor(pos);hi=ceil(pos);
    v=x(lo)+(pos-lo)*(x(hi)-x(lo));
end

function rgb=e9b_colorize_rgb(intensity,c)
% Same truecolor colorization as the E9-A helper, uint8 to save memory.
    [h,w]=size(intensity);
    rgb=zeros(h,w,3,'uint8');
    for ch=1:3
        rgb(:,:,ch)=uint8(round(255*intensity*single(c(ch))));
    end
end

function e9b_plot_residual(Y,mask,stats,H,W,filename,t)
    sumim=reshape(sum(Y,1),H,W);
    a=stats.residual_linear; b=stats.residual_affine;
    roiMask=reshape(mask,H,W);
    a(~roiMask)=NaN; b(~roiMask)=NaN;

    % Display only: flip residual-related images left-right to match abundances.
    sumim=fliplr(sumim);
    a=fliplr(a);
    b=fliplr(b);

    f=figure('Color','w','Visible','on','Position',[30 30 1500 520]);
    subplot(1,3,1); imagesc(log1p(sumim));axis image off;colorbar;
    title('log(1 + original intensity)');
    subplot(1,3,2);imagesc(a);axis image off;colorbar;
    title(sprintf('Linear residual (ROI Frobenius %.4f)',stats.linear_frob));
    subplot(1,3,3);imagesc(b);axis image off;colorbar;
    title(sprintf('Affine residual (ROI Frobenius %.4f)',stats.affine_frob));
    sgtitle(t,'Interpreter','none');
    exportgraphics(f,filename,'Resolution',140);drawnow;
end

function [ord,sadmean,abundCorr]=e9b_align_baseline(M0,S0,M1,S1)
% Greedy spectral matching; SAD is BETWEEN ESTIMATES, not ground-truth SAD.
    p=size(M0,2); assert(size(M1,2)==p,'E9B:EndmemberCount','p changed.');
    aa=M0./max(sqrt(sum(M0.^2,1)),eps);
    bb=M1./max(sqrt(sum(M1.^2,1)),eps);
    costs=acos(max(-1,min(1,aa'*bb)))*180/pi;
    ord=zeros(1,p);used=false(1,p);
    for i=1:p
        row=costs(i,:);row(used)=Inf;
        [~,j]=min(row);ord(i)=j;used(j)=true;
    end
    sadmean=mean(arrayfun(@(i)costs(i,ord(i)),1:p));
    % Abundance scaling is generally not identifiable without calibration;
    % Pearson correlation is invariant to positive per-endmember scaling.
    corrs=NaN(1,p);
    for i=1:p
        a=double(S0(i,:));b=double(S1(ord(i),:));
        a=a-mean(a);b=b-mean(b);
        den=sqrt(sum(a.^2)*sum(b.^2));
        if den>1e-12,corrs(i)=sum(a.*b)/den;end
    end
    tmp=corrs(isfinite(corrs));
    if isempty(tmp),abundCorr=NaN;else,abundCorr=mean(tmp);end
end


function composition=e9b_abundance_composition(S,mask)
% Row i: fractional *estimated* abundance mass of EM_j among high-EM_i
% pixels. This is only a spatial co-occurrence proxy; it has NO ground truth.
    p=size(S,1); A=max(S,0); composition=NaN(p,p);
    for i=1:p
        v=sort(A(i,mask));
        if isempty(v),continue;end
        threshold=v(max(1,min(numel(v),round(.80*numel(v)))));
        sel=(A(i,:)>threshold) & mask;
        if ~any(sel),continue;end
        masses=sum(A(:,sel),2); tot=sum(masses);
        if tot>0,composition(i,:)=masses(:).'/tot;end
    end
end

function e9b_plot_composition(C,filename,t)
    p=size(C,1); f=figure('Visible','on','Color','w', ...
        'Position',[50 50 850 700]);
    imagesc(C,[0 1]); axis image; colorbar;
    set(gca,'XTick',1:p,'YTick',1:p);
    xlabel('Estimated EM j');ylabel('Top-abundance ROI of estimated EM i');
    title(t,'Interpreter','none');
    exportgraphics(f,filename,'Resolution',150);drawnow;
end
