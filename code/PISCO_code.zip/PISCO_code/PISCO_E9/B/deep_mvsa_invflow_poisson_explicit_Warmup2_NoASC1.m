function [M_est, Sest, Up, my, theta] = deep_mvsa_invflow_poisson_explicit_Warmup2_NoASC(Y, p, varargin)
% E9-B1 / PISCO MINIMAL NoASC VARIANT (2026-10-26)
% Derived from the supplied, independently preserved Warmup2 paper model.
% NO abundance sum-to-one loss or projection is used. Sest holds
% UNNORMALIZED spectral coefficients A (not fractions); sum(A(:,j)) is free.
% Abundance NONNEGATIVITY is the ORIGINAL SOFT penalty, not a hard projection.
% The last working coordinate is pixel-integrated intensity relative to the
% mean, rather than the legacy constant 1. The existing Q equality is RETAINED
% with qm=sqrt(p)*e_p' so it anchors endmember SCALE; then ideally
% sum(A(:,j)) ~= sum(Y(:,j))/mean(sum(Y,1)), NOT 1 for every pixel.
% The original (p x p) Q, geometric volume, optimizer, warm-up, noise choices,
% function outputs, and plotting/MAT/CSV interfaces are preserved.
% One new validation caveat: this is a DIFFERENT objective and geometry from
% the published ASC model; previous published experiments remain legacy runs.
%
%% DeepMVSA-InvFlow-Poisson: Invertible Coupled Q + Nonlinear Attention
%  + Spatial Smoothness + POISSON CHANCE CONSTRAINTS
%
% Q = L * Q0 * R, L: unit lower-tri, R: upper-tri with positive diagonal.
% EXPLICIT ABUNDANCE VERSION:
%   E3d warm-up from pisco_e3_train_b1_15: freeze Q and its Adam moments,
%   pretrain the per-pixel abundances, then gradually release Q with a
%   separate Adam clock and an explicit Q learning-rate ramp.
%   The abundance matrix is optimized directly as theta.S_explicit (p x N),
%   initialized from nonnegative Q0*Y_work with per-pixel signal scaling.
%   This follows the ABUNDANCE_MODE='explicit'
%   arm used in the PISCO E3 trainer: all reconstruction, non-negativity,
%   spatial losses are retained, but the explicit ASC loss is REMOVED.
%   The below version history describes the LEGACY parent trainer.
%
% NEW relative to deep_mvsa_invflow.m (Gaussian version):
%   NOISE_MODEL  : 'gaussian' (default, identical to original) or 'poisson'.
%   Under 'poisson', the noise variance is intensity-dependent. Y may be in
%   any intensity unit; PHOTON_GAIN converts it to counts:
%       counts = Y * PHOTON_GAIN,  Var_counts = counts
%       => Var(Y) = max(Y, PHOTON_FLOOR/PHOTON_GAIN) / PHOTON_GAIN
%   Propagated to the working space (B = whitening/projection operator):
%       Vpix      = (B.^2) * Var(Y)                p x N, per-pixel noise var
%       sigma2_ij = (Q.^2) * Vpix                  q_i' Cov_j q_i,  p x N
%   and the chance-constraint margin becomes pixel-adaptive:
%       margin_ij = Phi^{-1}(ETA) * min(sqrt(sigma2_ij), SIGMA_CAP)  <= 0
%   (stop-gradient).  Two terms change:
%     (1) reconstruction  -> heteroscedastic GLS:  diff^2 ./ Vpix, with the
%         weights normalized to mean 1 so the global loss balance (and all
%         lambda settings) matches the Gaussian model;
%     (2) enclosure       -> min(Q*Y - margin, 0)^2  (RMVSA-style noise-
%         tolerant data enclosure: noisy pixels may poke outside the
%         simplex, bright pixels may not).
%   Abundance NON-NEGATIVITY uses the original penalty min(A_eff,0)^2
%   (soft constraint; not a hard projection). The noise margin does not
%   relax this penalty. Legacy description otherwise retained.
%   sigma2 is recomputed every iteration from the current Q and treated as
%   constant in the gradient (EM-style), so all gradients remain closed form.
%   ETA          : chance-constraint level (default 0.1; 0.5 = hard MVSA).
%   SIGMA_CAP    : cap on the per-pixel margin scale (default 0.1, in
%                  spherized working units). Prevents nearly-constraint-free
%                  behaviour at very low photon counts.
%   PHOTON_GAIN  : counts per unit of Y (default 1, i.e. Y is counts).
%                  Set it so both models can be compared on the SAME input
%                  scaling (see demo_pisco_vs_deeprmvsa.m).
%   PHOTON_FLOOR : variance floor in photon counts (default 1).
%
% v0.9 (2026-09-22):
%   - SPECTRAL SMOOTHNESS PRIOR (LAMBDA_SMOOTH, default 0.1; 0 = off):
%     2nd-difference Tikhonov penalty on the BAND-SPACE endmembers,
%     LAMBDA_SMOOTH*sum((M_band(3:end,:)-2*M_band(2:end-1,:)+M_band(1:end-2,:)).^2),
%     gradient chained through M = inv(Q) like LAMBDA_MNONNEG. Fluorescence
%     emission spectra are smooth on the ~9 nm channel grid, so this
%     suppresses the spurious narrow peaks/dips that shot noise imprints
%     on the recovered spectra without shifting the true (broad) peaks.
%     Also added to deep_mvsa_invflow.m (fair comparison).
%
% v0.8 (2026-09-21):
%   - MARGIN ANNEALING (ETA_END, default 0.5): the chance level eta is
%     linearly annealed from ETA to ETA_END over the joint phase, so the
%     enclosure margin Phi^{-1}(eta_t)*min(sigma,sigma_cap) decays to zero
%     at convergence. Rationale: in the capped regime the margin is a
%     CONSTANT inward relaxation of the enclosure (verified: sigma > cap
%     for 100% of pixels at all photon levels), which the volume term
%     exploits to pull the simplex inside the data cloud -- a systematic
%     bias that dominates once shot noise becomes small (high photon
%     budgets). Annealing removes the bias asymptotically while retaining
%     the noise tolerance during the critical simplex-formation phase.
%     Monte-Carlo verification (v0.9, self-contained Python package, 6
%     paired repeats, 96x96, real FP spectra): at 100 photons the annealed
%     margin beats the FIXED margin in 6/6 paired draws (mean SAD 7.25 vs
%     7.94 deg) and beats the Gaussian backbone in 6/6 paired draws (7.25
%     vs 7.71 deg, sign test p~0.03); neutral at 5-20 photons.
%     Set ETA_END = ETA to reproduce v0.7 behaviour.
%   - ENDMEMBER NON-NEGATIVITY (LAMBDA_MNONNEG, default 10): fluorescence
%     emission spectra are physically non-negative. Soft penalty
%     LAMBDA_MNONNEG*sum(min(M_band,0).^2) inside the objective (gradient
%     chained through M = inv(Q)), plus a final projection
%     M_est = max(M_est,0) on the returned endmembers. At 5 photons the
%     projection alone recovers ~2 deg SAD in bad-noise draws.
%   - Both mechanisms also added to deep_mvsa_invflow.m (fair comparison).
%
% v0.7 (2026-09-21):
%   - READ_SIGMA (default 0): Gaussian read-out noise in photon-count units,
%     added to the variance model Var(Y) = max(Y, floor/gain)/gain +
%     (READ_SIGMA/gain)^2, so the Poisson chance constraints remain
%     calibrated under the mixed Poisson + read-out noise of real detectors
%     (sCMOS/PMT analogue mode). Also honoured by NOISE_WEIGHT 'irls'.
%
% v0.6 (2026-09-21):
%   - SPATIAL TERM NORMALIZATION FIX (both algorithm files): the Laplacian
%     penalty was a SUM over ~2N neighbour pairs while reconstruction is a
%     MEAN, so the effective smoothing grew with N and compressed the
%     abundance range towards 1/p with over-smoothed maps. The penalty and
%     its gradient are now divided by N; use LAMBDA_SPATIAL ~ 20.
%   - NOISE_WEIGHT (default 'uniform'): after signal-covariance whitening,
%     the working-space noise is only weakly heteroscedastic, and uniform
%     weighting keeps the min-volume geometry anchored by all pixels; the
%     Poisson adaptation is carried by the (capped) enclosure margins.
%     'pearson' = v0.5 plug-in GLS; 'irls' = GLS with variances recomputed
%     from the current reconstruction every iteration (stop-grad), which
%     removes the Pearson plug-in noise feedback. Use 'pearson'/'irls' for
%     data with a large intensity dynamic range.
%   - SIGMA_CAP default tightened 0.1 -> 0.03: with a soft quadratic
%     enclosure penalty, noise excursions are already tolerated smoothly;
%     a wide extra margin double-counts the tolerance and lets the volume
%     term pull the simplex inside the data cloud (SAD degrades ~2 deg).
%   Verified (Python replica of the full pipeline, paired noise draws):
%   uniform+cap0.03 ties Deep RMVSA within ~0.1-0.8 deg SAD at matched MSE,
%   while every wider-margin or plug-in-weight variant trails by 1-2 deg.
%
% v0.5 (2026-09-21):
%   - FIX (critical): the affine working dimension carries no shot noise
%     (B(p,:) = 0), so Vpix(p,:) was exactly zero and its GLS weight
%     1/(0+eps) ~ 1e12 dominated the entire objective -- the network only
%     learned to fit the constant dimension, producing near-uniform
%     abundance maps with high-frequency stripe artifacts and oscillating
%     endmember spectra. The zero/too-small variances are now replaced by
%     the median variance (floor at 1e-3 x median).
%   - FIX: GLS weights normalized to mean 1 (keeps the loss scale, and
%     therefore every lambda, comparable to the Gaussian model; stops
%     dim-pixel noise from dominating the reconstruction).
%   - FIX: chance-constraint margin moved off the abundance non-negativity
%     (now strict, as in the Gaussian model) onto the data-enclosure term
%     only, and capped by SIGMA_CAP. Relaxing a physically exact
%     constraint (A >= 0) biased the solution; noise tolerance is only
%     statistically justified on the data enclosure.
%   Verified against a Python replica of the full pipeline: with these
%   fixes PISCO matches Deep RMVSA in endmember SAD and improves abundance
%   MSE at low photon budgets, and the stripe/oscillation artifacts vanish.
%
% v0.4 (2026-09-21):
%   - PHOTON_GAIN added (fixes the scale mismatch when comparing against
%     the Gaussian model on identically scaled inputs).
%   - FOURIER FEATURE encoding of coordinates (NeRF-style), new parameter
%     FF_K (default 6; 0 = off). Fixes INR spectral bias: plain (gx,gy)
%     inputs let the A-Net learn only smooth low-frequency abundance maps.
%   - Weight init scale raised 0.01 -> 0.05.
%
% Optional terms (unchanged):
%   LAMBDA_ENCLOSE : data-enclosure penalty (synthetic data: set 10).
%   LAMBDA_SPATIAL : 4-neighbour grid Laplacian on abundance maps.
%   IMG_H / IMG_W  : scene dimensions for 2-D coordinates and spatial term.
%
% GPU support (RTX 4060 Ti / MATLAB Parallel Computing Toolbox):
%   USE_GPU       : true (default) for GPU warm-up and joint training;
%                   false reproduces the original CPU execution path.
%   GPU_PRECISION : 'single' (default, fast on consumer NVIDIA GPUs), or
%                   'double' (closer to CPU double precision, generally slower).
%   GPU_DEVICE    : positive GPU device index (default 1).
% PCA/whitening and external VCA remain on CPU. Training matrices, explicit
% abundances, loss gradients, spatial regularization and Adam states are kept
% on the GPU; M_est, Sest, Up, my, theta are returned as ordinary CPU doubles
% when Y is double. The model equations and objective weights are unchanged.
% This does NOT implement minibatching or allocate shared/system GPU memory.

pStruct = inputParser;
addParameter(pStruct, 'MM_ITERS', 2500, @isnumeric);
addParameter(pStruct, 'WARM_UP', 600, ...
    @(x) isnumeric(x) && isscalar(x) && isfinite(x) && x >= 0 && mod(x,1) == 0);
% E3d warm-up transition controls (active only when WARM_UP > 0).
addParameter(pStruct, 'WARMUP_Q_RELEASE', 100, ...
    @(x) isnumeric(x) && isscalar(x) && isfinite(x) && x >= 0 && mod(x,1) == 0);
addParameter(pStruct, 'WARMUP_Q_MIN_LR_RATIO', 0.25, ...
    @(x) isnumeric(x) && isscalar(x) && isfinite(x) && x > 0 && x <= 1);
% Accepted for interface compatibility with pisco_e3_train_b1_15;
% no gate network exists in this explicit-abundance implementation.
addParameter(pStruct, 'WARMUP_GATE_RELEASE', 150, ...
    @(x) isnumeric(x) && isscalar(x) && isfinite(x) && x >= 0 && mod(x,1) == 0);
addParameter(pStruct, 'LR', 3e-4, @isnumeric);
addParameter(pStruct, 'LAMBDA_VOL', 0.005, @isnumeric);
addParameter(pStruct, 'LAMBDA_NONNEG', 3, @isnumeric);
addParameter(pStruct, 'LAMBDA_EQ', 80, @isnumeric);
addParameter(pStruct, 'LAMBDA_SUMONE', 0, @isnumeric); % accepted for old callers; IGNORED here
addParameter(pStruct, 'LAMBDA_ENCLOSE', 0, @isnumeric);   % enclosure term (synthetic data)
addParameter(pStruct, 'LAMBDA_SPATIAL', 0, @isnumeric);   % spatial smoothness (image data)
addParameter(pStruct, 'IMG_H', [], @isnumeric);           % scene height  (rows)
addParameter(pStruct, 'IMG_W', [], @isnumeric);           % scene width   (cols)
addParameter(pStruct, 'M0', [], @isnumeric);
addParameter(pStruct, 'spherize', 'yes', @ischar);
addParameter(pStruct, 'verbose', 1, @isnumeric);
addParameter(pStruct, 'NOISE_MODEL', 'gaussian', @ischar);% 'gaussian' | 'poisson'
addParameter(pStruct, 'NOISE_WEIGHT', 'uniform', @ischar); % 'uniform' | 'pearson' | 'irls' <<< NEW v0.6
addParameter(pStruct, 'ETA', 0.3, @isnumeric);            % chance level
addParameter(pStruct, 'ETA_END', 0.3, @isnumeric);        % annealed chance level (0.5 = margin -> 0) <<< NEW v0.8
addParameter(pStruct, 'LAMBDA_MNONNEG', 10, @isnumeric);  % endmember non-negativity (band space) <<< NEW v0.8
addParameter(pStruct, 'LAMBDA_SMOOTH', 0.1, @isnumeric);  % spectral smoothness, 2nd-diff Tikhonov on M (0 = off) <<< NEW v0.9
addParameter(pStruct, 'SIGMA_CAP', 0.15, @isnumeric);      %0.03 margin cap (working units; 0.03 in v0.6)
addParameter(pStruct, 'PHOTON_GAIN', 1, @isnumeric);      % counts per unit of Y  <<< NEW v0.4
addParameter(pStruct, 'PHOTON_FLOOR', 1, @isnumeric);
addParameter(pStruct, 'READ_SIGMA', 0, @isnumeric);        % Gaussian read-out noise, in COUNTS (v0.7)     % count variance floor
addParameter(pStruct, 'FF_K', 6, @isnumeric);             % retained for API compatibility; unused in explicit mode
addParameter(pStruct, 'USE_GPU', true, @(x) (islogical(x) || isnumeric(x)) && isscalar(x));
addParameter(pStruct, 'GPU_PRECISION', 'single', ...
    @(x) (ischar(x) || (isstring(x) && isscalar(x))) && ...
         any(strcmpi(char(x), {'single', 'double'})));
addParameter(pStruct, 'GPU_DEVICE', 1, ...
    @(x) isnumeric(x) && isscalar(x) && isfinite(x) && x >= 1 && x == fix(x));
parse(pStruct, varargin{:});
if pStruct.Results.LAMBDA_SUMONE ~= 0
    warning('PISCO:NoASCSumoneIgnored', ...
        'LAMBDA_SUMONE is ignored: NoASC model does not impose sum(A)=1.');
end

use_gpu = logical(pStruct.Results.USE_GPU);
gpu_precision = lower(char(pStruct.Results.GPU_PRECISION));
if use_gpu
    try
        % Request an actual MATLAB CUDA device; do not silently fall back.
        gdev = gpuDevice(pStruct.Results.GPU_DEVICE);
    catch gpuErr
        error('PISCO:GPUUnavailable', ...
            ['USE_GPU=true requires a supported NVIDIA CUDA GPU and ' ...
             'Parallel Computing Toolbox. Run gpuDevice in MATLAB. ' ...
             'To use CPU, pass ''USE_GPU'',false. GPU error: %s'], gpuErr.message);
    end
    if pStruct.Results.verbose
        fprintf('PISCO GPU: %s | precision: %s | available %.2f GiB\n', ...
            gdev.Name, gpu_precision, double(gdev.AvailableMemory)/2^30);
    end
end

[L, N] = size(Y);
if pStruct.Results.WARM_UP >= pStruct.Results.MM_ITERS && pStruct.Results.WARM_UP > 0
    error('WARM_UP must be strictly smaller than MM_ITERS.');
end

%% --------------------- Minimal non-ASC linear working transform ---------
% Legacy: project centered Y and append constant 1/sqrt(p). This forces an
% (implicit) ASC. NoASC: preserve the same p-dimensional invertible-Q model,
% but replace the constant by an OBSERVED, varying pixel intensity coordinate.
% Work-space encoding is LINEAR: Y_work = B*Y, which matters for Poisson GLS.
my = mean(Y,2);
intensity_ref = sum(my);  % units = 32-band integrated digital intensity
if ~(isfinite(intensity_ref) && intensity_ref > 0)
    error('PISCO:NoASCIntensity','Mean integrated intensity must be positive.');
end
pixel_scale = sum(Y,1)/intensity_ref;  % 1 x N; intentionally NOT constant 1
Yc = Y - my*pixel_scale;             % every column integrates to zero
[Up_sub, D] = svds(Yc*Yc'/N, p-1);
% Retain the same Up return dimensionality as the legacy model.
my_ortho = my - Up_sub*(Up_sub'*my);
if norm(my_ortho)>1e-10*max(norm(my),1)
    Up=[Up_sub,my_ortho/norm(my_ortho)];
else
    [Uall,~,~]=svd([Up_sub,my],'econ');
    Up=Uall(:,1:p);
end
if strcmp(pStruct.Results.spherize, 'yes')
    lambda_reg = 1e-10;
    whiten_scale = sqrt(diag(D+lambda_reg*eye(p-1)));
    C = diag(1./whiten_scale);
else
    lambda_reg = 0;
    whiten_scale = ones(p-1,1);
    C = eye(p-1);
end
Y_work = [C*Up_sub'*Yc; pixel_scale]/sqrt(p);
% Inverse lift for any p x N working matrix Z:
% Y_band = Up_sub*(whiten_scale.*(sqrt(p)*Z(1:p-1,:))) ...
%        + my*(sqrt(p)*Z(p,:)). Unlike legacy this is LINEAR in Z.

%% --------- Existing endmember band priors, with consistent linear lift --
lift_ctx = [];
if pStruct.Results.LAMBDA_MNONNEG > 0 || pStruct.Results.LAMBDA_SMOOTH > 0
    lift_ctx.mode   = 'noasc_linear';
    lift_ctx.Up_sub = Up_sub;
    lift_ctx.sD     = whiten_scale;
    lift_ctx.my     = my;
    lift_ctx.sqp    = sqrt(p);
end

%% --------------------- Poisson noise propagation ---------------------
use_poisson = strcmpi(pStruct.Results.NOISE_MODEL, 'poisson');
irls_ctx = [];
if use_poisson
    r = ones(1,L)/intensity_ref;
    B = [C*Up_sub'*(eye(L)-my*r); r] / sqrt(p); % EXACT linear Y->Y_work
    B2   = B.^2;                                             % p x L
    gain = pStruct.Results.PHOTON_GAIN;
    VarY = max(Y, pStruct.Results.PHOTON_FLOOR/gain) / gain ...  % shot noise, units of Y
         + (pStruct.Results.READ_SIGMA/gain)^2;               % v0.7: Gaussian read-out noise
    Vpix = B2 * VarY;                                        % p x N
    % ---- v0.5: stabilize the heteroscedastic variances -----------------
    % (a) NoASC intensity coordinate now has nonzero propagated variance;
    %     still guard zero variances for degenerate inputs.
    % (b) floor all variances at 1e-3 x median so the per-pixel weight
    %     ratio cannot exceed 1e3 (Pearson plug-in weights are unstable
    %     at very low counts).
    med_v = median(Vpix(Vpix > 0));
    Vpix(Vpix <= 0) = med_v;
    Vpix = max(Vpix, 1e-3*med_v);
    phi_inv = -sqrt(2)*erfcinv(2*pStruct.Results.ETA);       % Phi^{-1}(eta) <= 0
    % ---- v0.6: IRLS context (model-based weights from the reconstruction)
    if strcmpi(pStruct.Results.NOISE_WEIGHT, 'irls')
        irls_ctx.Up_sub = Up_sub;
        irls_ctx.Cinv   = whiten_scale;
        irls_ctx.my     = my;
        irls_ctx.gain   = gain;
        irls_ctx.floor  = pStruct.Results.PHOTON_FLOOR;
        irls_ctx.rs2    = (pStruct.Results.READ_SIGMA/gain)^2;
        irls_ctx.B2     = B2;
    end
    if pStruct.Results.verbose
        fprintf(['Poisson chance constraints: eta=%.2f, Phi^{-1}(eta)=%.3f, ' ...
                 'gain=%.3g\n'], pStruct.Results.ETA, phi_inv, gain);
    end
else
    Vpix = []; phi_inv = 0;
end

%% --------------------- Shape-simplex initialization, not ASC ---------
% VCA is applied to normalized SHAPE DATA to seed p spectral shapes. Only
% the initialization has affine last coordinate = 1/sqrt(p): optimization
% and reconstruction use the UNNORMALIZED intensity-varying Y_work.
if isempty(pStruct.Results.M0)
    positive_scale = pixel_scale(pixel_scale>0);
    if isempty(positive_scale), error('PISCO:NoASCVCA','No nonzero spectra.'); end
    threshold = median(positive_scale);
    valid = find(pixel_scale >= threshold & pixel_scale>0);
    if numel(valid) < p, valid=find(pixel_scale>0); end
    if numel(valid) < p, error('PISCO:NoASCVCA','Not enough valid pixels.'); end
    nsample = min(50000,numel(valid));
    sel = valid(unique(round(linspace(1,numel(valid),nsample))));
    Y_shapes = bsxfun(@rdivide,Y_work(:,sel),pixel_scale(sel));
    M0 = VCA(Y_shapes, 'Endmembers', p, 'verbose', 'off');
    M0(p,:) = 1/sqrt(p); % exact shape initialization
else
    M0_band = pStruct.Results.M0;
    if ~isequal(size(M0_band),[L p])
        error('PISCO:NoASCM0','M0 must be L x p in ORIGINAL spectral units.');
    end
    M0_band = bsxfun(@times,M0_band, ...
        intensity_ref./max(sum(M0_band,1),eps));
    M0 = [C*Up_sub'*(M0_band-my*ones(1,p));ones(1,p)]/sqrt(p);
end
Q0 = inv(M0);
% The legacy qm learnt a constant affine hyperplane from the original data.
% Keeping that value would IMPLICITLY reconstruct ASC. Here it instead
% anchors each shape endmember at the unit-relative-intensity hyperplane:
% 1'*Q ~= sqrt(p)*e_p' => sum(Q*Y_work(:,j)) ~= pixel_scale(j).
qm = zeros(1,p); qm(end) = sqrt(p);
if pStruct.Results.verbose
    fprintf('PISCO NoASC: pixel-scale median=%.5g range=[%.5g,%.5g] | Q equality targets intensity, not 1.\n', ...
        median(pixel_scale),min(pixel_scale),max(pixel_scale));
end

%% --------------------- Spatial dimensions ---------------------
% Explicit abundance does not use coordinate encoding or A-Net/S-Net.
% IMG_H / IMG_W are retained only for the spatial regularization term.
H_img = pStruct.Results.IMG_H;
W_img = pStruct.Results.IMG_W;
if isempty(H_img) || isempty(W_img)
    H_img = round(sqrt(N)); W_img = round(N/H_img);
end
use_spatial = (H_img * W_img == N);
if ~use_spatial
    if pStruct.Results.LAMBDA_SPATIAL > 0
        warning('IMG_H x IMG_W (%d x %d) ~= N (%d): spatial term disabled.', ...
            H_img, W_img, N);
    end
    H_img = 1; W_img = N;
end

%% --------------------- Move iterative computation to GPU ---------------------
% Keep CPU-only PCA, VCA and small initial inverses exactly as in the source.
% Conversion happens ONCE; do not gather full training arrays every iteration.
if use_gpu
    Y_work = gpuArray(cast(Y_work, gpu_precision));
    pixel_scale = gpuArray(cast(pixel_scale, gpu_precision));
    Q0     = gpuArray(cast(Q0,     gpu_precision));
    qm     = gpuArray(cast(qm,     gpu_precision));
    if use_poisson
        Vpix = gpuArray(cast(Vpix, gpu_precision));
    end
    if ~isempty(lift_ctx)
        lift_ctx.Up_sub = gpuArray(cast(lift_ctx.Up_sub, gpu_precision));
        lift_ctx.sD     = gpuArray(cast(lift_ctx.sD,     gpu_precision));
        lift_ctx.my     = gpuArray(cast(lift_ctx.my,     gpu_precision));
    end
    if ~isempty(irls_ctx)
        irls_ctx.Up_sub = gpuArray(cast(irls_ctx.Up_sub, gpu_precision));
        irls_ctx.Cinv   = gpuArray(cast(irls_ctx.Cinv,   gpu_precision));
        irls_ctx.my     = gpuArray(cast(irls_ctx.my,     gpu_precision));
        irls_ctx.B2     = gpuArray(cast(irls_ctx.B2,     gpu_precision));
    end
end

%% --------------------- Explicit abundance parameters ---------------------
% Nonnegative data-guided initialization from the same Q0 and Y_work.
% Multiplicative rescaling matches each pixel's INITIAL sum to its measured
% relative intensity, not 1. There is NO such hard constraint during training.
A0 = max(Q0*Y_work,0);
s0 = sum(A0,1);
theta.S_explicit = bsxfun(@times,A0,pixel_scale./max(s0,1e-8));
if pStruct.Results.verbose
    fprintf('PISCO NoASC: initialized nonnegative coefficients; no ASC projection.\n');
end

%% --------------------- Invertible Q: Q = L * Q0 * R ---------------------
theta.L = zeros(p,p, 'like', Y_work);       % strict lower triangular
theta.R = zeros(p,p, 'like', Y_work);       % strict upper triangular
theta.r_log = zeros(p,1, 'like', Y_work);  % R diagonal log

%% --------------------- Adam states ---------------------
m = init_adam(theta);
v = init_adam(theta);
lr = pStruct.Results.LR;
iter = 0;

%% --------------------- Warm-up (explicit abundance; Q exactly frozen) ---------------------
% E3d from pisco_e3_train_b1_15: optimize S_explicit while keeping
% Q = Q0.  Do not update Q parameters OR their Adam moment estimates.
if pStruct.Results.verbose, fprintf('Warm-up (explicit abundance, Q exactly frozen)...\n'); end
for k = 1:pStruct.Results.WARM_UP
    [loss, grad] = compute_gradients_invflow(theta, Y_work, Q0, qm, p, ...
        0, pStruct.Results.LAMBDA_NONNEG, pStruct.Results.LAMBDA_EQ, ...
        pStruct.Results.LAMBDA_ENCLOSE, ...
        pStruct.Results.LAMBDA_SPATIAL, H_img, W_img, ...
        use_poisson, Vpix, phi_inv, pStruct.Results.SIGMA_CAP, ...
        pStruct.Results.NOISE_WEIGHT, irls_ctx, ...
        pStruct.Results.LAMBDA_MNONNEG, pStruct.Results.LAMBDA_SMOOTH, lift_ctx);
    [theta, m, v] = adam_update_struct(theta, grad, m, v, iter+1, lr, ...
        0, 0);  % Q frozen, Q Adam moments untouched; abundance Adam continues.
    iter = iter + 1;
    if pStruct.Results.verbose && mod(k,100)==0
        loss_view = loss;
        if use_gpu, loss_view = gather(loss_view); end
        fprintf('Warm-up %d/%d, loss=%.6f (Q exactly frozen)\n', ...
            k, pStruct.Results.WARM_UP, double(loss_view));
    end
end

if pStruct.Results.WARM_UP > 0
    q_drift = norm(theta.L,'fro') + norm(theta.R,'fro') + norm(theta.r_log);
    if use_gpu, q_drift = gather(q_drift); end
    assert(q_drift == 0, 'E3d: Q changed during supposedly fixed-Q warm-up.');
    if pStruct.Results.verbose
        fprintf('Warm-up finished: Q parameter drift = %.3g (should be 0).\n', q_drift);
    end
end

%% --------------------- Joint training ---------------------
if pStruct.Results.verbose, fprintf('Joint training (invertible Q + explicit abundance)...\n'); end
n_joint = pStruct.Results.MM_ITERS - pStruct.Results.WARM_UP;
eta0 = pStruct.Results.ETA; eta1 = pStruct.Results.ETA_END;      % v0.8: anneal
for k = 1:n_joint
    % v0.8: anneal the chance level ETA -> ETA_END over the joint phase;
    % Phi^{-1}(0.5) = 0, so the enclosure margin decays to zero at
    % convergence (removes the systematic inward simplex bias at high SNR).
    if use_poisson
        prog  = (k-1)/max(1, n_joint-1);
        eta_t = min(max(eta0 + (eta1-eta0)*prog, 1e-6), 1-1e-6);
        phi_t = -sqrt(2)*erfcinv(2*eta_t);
    else
        phi_t = phi_inv;
    end
    % E3d: release Q smoothly after warm-up.  The smoothstep Q learning-
    % rate ramp is bypassed entirely for WARM_UP = 0.
    q_lr_scale = 1;
    if pStruct.Results.WARM_UP > 0 && pStruct.Results.WARMUP_Q_RELEASE > 0
        q_progress = min(1, k / pStruct.Results.WARMUP_Q_RELEASE);
        q_progress = q_progress^2 * (3 - 2*q_progress);
        q0_scale = pStruct.Results.WARMUP_Q_MIN_LR_RATIO;
        q_lr_scale = q0_scale + (1-q0_scale)*q_progress;
    end
    [loss, grad] = compute_gradients_invflow(theta, Y_work, Q0, qm, p, ...
        pStruct.Results.LAMBDA_VOL, pStruct.Results.LAMBDA_NONNEG, ...
        pStruct.Results.LAMBDA_EQ, ...
        pStruct.Results.LAMBDA_ENCLOSE, ...
        pStruct.Results.LAMBDA_SPATIAL, H_img, W_img, ...
        use_poisson, Vpix, phi_t, pStruct.Results.SIGMA_CAP, ...
        pStruct.Results.NOISE_WEIGHT, irls_ctx, ...
        pStruct.Results.LAMBDA_MNONNEG, pStruct.Results.LAMBDA_SMOOTH, lift_ctx);  % <<< v0.9 args
    % Q's bias-correction clock restarts at k=1 after being frozen,
    % whereas S_explicit keeps the full iteration count (iter+1).
    [theta, m, v] = adam_update_struct(theta, grad, m, v, iter+1, lr, ...
        q_lr_scale, k);
    iter = iter + 1;
    if pStruct.Results.verbose && mod(k,100)==0
        loss_view = loss;
        if use_gpu, loss_view = gather(loss_view); end
        fprintf('Joint %d/%d, loss=%.6f, explicit abundance\n', ...
            k, n_joint, double(loss_view));
    end
end

%% --------------------- Recover endmembers ---------------------
% All returned values must be ordinary CPU numeric arrays because the E9
% driver performs MATLAB reshaping, comparisons, plots, and MAT/CSV saving.
% Use double for output compatibility with the original MATLAB trainer.
if use_gpu
    fields_out = fieldnames(theta);
    for fi = 1:numel(fields_out)
        f = fields_out{fi};
        theta.(f) = double(gather(theta.(f)));
    end
    Q0 = double(gather(Q0));
end
A_eff = theta.S_explicit;
L_mat = eye(p, 'like', theta.L) + tril(theta.L, -1);
R_mat = diag(exp(theta.r_log)) + triu(theta.R, 1);
Q = L_mat * Q0 * R_mat;
M_sub = inv(Q);
Sest = A_eff;
M_est = Up_sub * bsxfun(@times,whiten_scale,sqrt(p)*M_sub(1:p-1,:)) ...
      + my*(sqrt(p)*M_sub(p,:));
M_est = max(M_est, 0);   % v0.8: fluorescence spectra are physically non-negative
end

%% ===================== Sub-functions =====================
function adam = init_adam(theta)
fields = fieldnames(theta);
adam = struct();
for i = 1:numel(fields)
    f = fields{i};
    adam.(f) = zeros(size(theta.(f)), 'like', theta.(f));
end
end

function [loss, grad] = compute_gradients_invflow(theta, Y, Q0, qm, p, ...
    lambda_vol, lambda_nonneg, lambda_eq, lambda_enclose, ...
    lambda_spatial, H_img, W_img, use_poisson, Vpix, phi_inv, sigma_cap, ...
    noise_weight, irls_ctx, lambda_mnn, lambda_smooth, lift_ctx)     % <<< v0.9 args
L_mat = eye(p, 'like', theta.L) + tril(theta.L, -1);
R_mat = diag(exp(theta.r_log)) + triu(theta.R, 1);
Q = L_mat * Q0 * R_mat;
M = inv(Q); % p is small, numerically safe

% Explicit per-pixel abundance variables (p x N).
A_eff = theta.S_explicit;

Y_hat = M * A_eff;
diff = Y_hat - Y;

% --- reconstruction weights (v0.6) ------------------------------------
% 'uniform' (default): after signal-covariance whitening the working-space
%   noise is only weakly heteroscedastic, and uniform weighting keeps the
%   min-volume geometry anchored by ALL pixels (bright vertices included);
%   the Poisson adaptation is carried by the enclosure margins below.
% 'pearson': heteroscedastic GLS with plug-in variances (v0.5 behaviour).
% 'irls'   : heteroscedastic GLS with variances recomputed from the
%   CURRENT RECONSTRUCTION every iteration (proper IRLS; removes the
%   Pearson plug-in feedback that lets the net fit its own weight noise).
eps_var = 1e-12;
use_w = use_poisson && ~strcmpi(noise_weight, 'uniform');
if use_poisson && strcmpi(noise_weight, 'irls')
    Yh_chan = irls_ctx.Up_sub * (irls_ctx.Cinv .* (sqrt(p)*Y_hat(1:p-1,:))) ...
             + irls_ctx.my*(sqrt(p)*Y_hat(p,:));
    VarY = max(Yh_chan, irls_ctx.floor/irls_ctx.gain) / irls_ctx.gain + irls_ctx.rs2;
    Vpix = irls_ctx.B2 * VarY;                          % stop-grad
    med_i = median(Vpix(Vpix > 0)); Vpix(Vpix <= 0) = med_i;
end
if use_w
    W_rec = 1./(Vpix + eps_var);                        % stop-grad weights
    W_rec = W_rec / mean(W_rec(:));                     % mean weight 1
    loss_recon = mean(sum(diff.^2 .* W_rec, 1));
else
    %loss_recon = mean(sum(diff.^2,1));
    loss_recon = sum(diff.^2,'all');
end

loss_vol = -sum(theta.r_log); % log|det(Q0)| omitted as constant

% --- pixel-adaptive chance-constraint margin (Poisson) ---              <<< NEW
% v0.5: the margin applies ONLY to the data-enclosure term (below), where
% noise tolerance is statistically justified (RMVSA heritage). Abundance
% non-negativity keeps its original soft penalty (no noise relaxation).
if use_poisson
    sigma2 = (Q.^2) * Vpix + eps_var;                  % q_i' Cov_j q_i, p x N
    margin = phi_inv * min(sqrt(sigma2), sigma_cap);   % <= 0, stop-grad, capped
else
    margin = 0;
end

penalty = min(A_eff, 0);      % original SOFT nonnegative coefficient penalty
loss_nonneg = sum(penalty.^2, 'all');

% NOASC: intentionally NO sum(A,1)-1 penalty and NO simplex projection.
col_sums = sum(Q,1);
loss_eq = sum((col_sums - qm).^2, 'all');

% --- optional data-enclosure penalty QY >= margin ---
QY = Q*Y;
pen_enclose = min(QY - margin, 0);
loss_enclose = sum(pen_enclose.^2, 'all');

% --- optional spatial smoothness of the abundance maps (4-neighbour
%     grid Laplacian):  sum_{adjacent (i,j)} ||a_i - a_j||^2  ---
loss_spatial = 0;
if lambda_spatial > 0 && H_img*W_img == size(Y,2)
    A3  = reshape(A_eff, p, H_img, W_img);
    Dh  = A3(:,2:end,:) - A3(:,1:end-1,:);   % vertical neighbour diffs
    Dw  = A3(:,:,2:end) - A3(:,:,1:end-1);   % horizontal neighbour diffs
    loss_spatial = (sum(Dh.^2,'all') + sum(Dw.^2,'all')) / size(Y,2);  % v0.6: mean over pixels
end

loss = loss_recon + lambda_vol*loss_vol + lambda_nonneg*loss_nonneg + ...
    lambda_eq*loss_eq + ...
    lambda_enclose*loss_enclose + lambda_spatial*loss_spatial;

N = size(Y,2);
if use_w
    dY_hat = 2*diff.*W_rec/N;                          % GLS gradient     <<< NEW
else
    %dY_hat = 2*diff/N;
    dY_hat = 2*diff;
end
dM = dY_hat * A_eff';

% --- v0.8/v0.9: band-space endmember priors (spectra >= 0; spectral smoothness)
if (lambda_mnn > 0 || lambda_smooth > 0) && ~isempty(lift_ctx)
    M_band = lift_ctx.Up_sub * (lift_ctx.sD .* (lift_ctx.sqp*M(1:p-1,:))) ...
           + lift_ctx.my*(lift_ctx.sqp*M(p,:));                % L x p
    dM_band = zeros(size(M_band), 'like', M_band);
    if lambda_mnn > 0
        pen_M = min(M_band, 0);
        loss  = loss + lambda_mnn * sum(pen_M.^2, 'all');
        dM_band = dM_band + 2*lambda_mnn*pen_M;                 % L x p
    end
    if lambda_smooth > 0                                        % <<< NEW v0.9
        % 2nd-difference Tikhonov on the band-space endmembers: suppresses
        % spurious narrow peaks/dips that shot noise imprints on M.
        D2M = M_band(3:end,:) - 2*M_band(2:end-1,:) + M_band(1:end-2,:);
        loss = loss + lambda_smooth * sum(D2M.^2, 'all');
        g2 = zeros(size(M_band), 'like', M_band);
        g2(3:end,:)   = g2(3:end,:)   + 2*lambda_smooth*D2M;
        g2(2:end-1,:) = g2(2:end-1,:) - 4*lambda_smooth*D2M;
        g2(1:end-2,:) = g2(1:end-2,:) + 2*lambda_smooth*D2M;
        dM_band = dM_band + g2;
    end
    gmnn = zeros(p,p, 'like', M);
    gmnn(1:p-1,:) = lift_ctx.sqp * (lift_ctx.sD .* (lift_ctx.Up_sub' * dM_band));
    gmnn(p,:) = lift_ctx.sqp*(lift_ctx.my'*dM_band);
    dM = dM + gmnn;   % chain rule through M = inv(Q) handled below
end

grad_Q_recon = -M' * dM * M';
grad_Q_eq = 2 * repmat(col_sums - qm, p, 1);
grad_Q_enclose = 2 * pen_enclose * Y';
grad_Q_clean = grad_Q_recon + lambda_eq * grad_Q_eq + lambda_enclose * grad_Q_enclose;

% Map Q-gradients to triangular parameters
grad_L_mat = grad_Q_clean * R_mat' * Q0';
grad_R_mat = Q0' * L_mat' * grad_Q_clean;
grad.L = tril(grad_L_mat, -1);
grad.R = triu(grad_R_mat, 1);
grad.r_log = diag(grad_R_mat) .* exp(theta.r_log) - lambda_vol;

% Gradient with respect to explicit abundance variables (margin treated as constant)
dA_eff = M' * dY_hat + 2*lambda_nonneg*penalty;

% gradient of the spatial penalty: 2 * (grid Laplacian) * A
if lambda_spatial > 0 && H_img*W_img == N
    G3 = zeros(p, H_img, W_img, 'like', A_eff);
    G3(:,1:end-1,:) = G3(:,1:end-1,:) - Dh;
    G3(:,2:end,:)   = G3(:,2:end,:)   + Dh;
    G3(:,:,1:end-1) = G3(:,:,1:end-1) - Dw;
    G3(:,:,2:end)   = G3(:,:,2:end)   + Dw;
    dA_eff = dA_eff + 2*lambda_spatial*reshape(G3, p, N)/N;   % v0.6: mean over pixels
end

% Direct nonnegative unnormalized coefficient optimization (NO ASC).
grad.S_explicit = dA_eff;
end

function [theta, m, v] = adam_update_struct(theta, grad, m, v, iter, lr, ...
    q_lr_scale, q_step)
% E3d: separate Adam bias-correction clocks for the Q group and S_explicit.
% A frozen Q group skips both the parameter step and its moment updates.
beta1 = 0.9; beta2 = 0.999; eps = 1e-8;
fields = fieldnames(theta);
for i = 1:numel(fields)
    f = fields{i};
    is_q = any(strcmp(f, {'L','R','r_log'}));
    if is_q
        if q_lr_scale <= 0, continue; end
        t = q_step;
        local_lr = lr*q_lr_scale;
    else
        t = iter;
        local_lr = lr;
    end
    m.(f) = beta1*m.(f) + (1-beta1)*grad.(f);
    v.(f) = beta2*v.(f) + (1-beta2)*grad.(f).^2;
    m_hat = m.(f) / (1 - beta1^t);
    v_hat = v.(f) / (1 - beta2^t);
    theta.(f) = theta.(f) - local_lr * m_hat ./ (sqrt(v_hat) + eps);
end
end
