function p_hysime = demo_pisco_E9_B1_HySime_only()
% E9-B1: load ONE Z plane of the original 32-channel LSM and estimate
% the signal-subspace dimension with the E14-style HySime estimator.
%
% READING: same Z indexing and TIFF -> Bio-Formats fallback as the E9-B1
%          NoASC BandLoss FixedQTail driver. No horizontal display flip.
% HYSIME : E14's bandwise-regression noise estimate + 4x4 superpixel
%          averaging + HySime minimum-error criterion.
% MEMORY : works on 128x128 image tiles; does NOT build full double(L x N),
%          or the full pixelwise noise array. The raw Z-plane cube is read
%          once. A second tile pass accumulates noise regression residuals.
% OUTPUT : ONLY prints and returns the RAW HySime dimension (no clamp).
%          No PISCO training, no changes to any existing model/MAT/PNG.
%
% Usage: p_hysime = demo_pisco_E9_B1_HySime_only;
%
% Provenance:
%   e9b_read_lsm_roi, e9b_fullres_dirs from E9-B1 driver (loading method)
%   e14_hysime, e14_estnoise from E14 Group C (estimator and noise model)
%   This implementation uses small covariance accumulators in place of
%   storing the 32-by-5,242,880 double cube and noise residual matrix.

%% USER CONFIGURATION ----------------------------------------------------
DATA_FILE = 'fig5_e_01-fish1-four-hinbrain_eye-autofl.lsm';
DATA_DIR  = 'data_E9';
Z_PLANE   = 12;
QUICK     = false;           % false: full 2048x2560; true: 256x256 center
CROP_HW   = [256 256];       % used only when QUICK = true
BIN       = 4;               % match E14 HySime: 4x4 superpixel averaging
TILE      = 128;             % must be a multiple of BIN
P_FIXED_REFERENCE = 8;       % report only; NEVER used to clamp HySime
%% ----------------------------------------------------------------------

L = 32;
ORIGINAL_H = 2048; ORIGINAL_W = 2560; EXPECTED_Z = 27;
assert(Z_PLANE >= 1 && Z_PLANE <= EXPECTED_Z && Z_PLANE == fix(Z_PLANE), ...
    'Z_PLANE must be an integer from 1 to %d.',EXPECTED_Z);
assert(BIN > 0 && BIN == fix(BIN) && TILE >= BIN && mod(TILE,BIN)==0, ...
    'BIN/TILE values must be positive integers and TILE a multiple of BIN.');

scriptDir = fileparts(mfilename('fullpath'));
if isempty(scriptDir), scriptDir = pwd; end
candidates = {DATA_FILE,fullfile(DATA_DIR,DATA_FILE), ...
    fullfile(scriptDir,DATA_FILE),fullfile(scriptDir,DATA_DIR,DATA_FILE)};
fname = '';
for i=1:numel(candidates)
    if exist(candidates{i},'file')==2
        fname=candidates{i}; break;
    end
end
assert(~isempty(fname),'Cannot find %s. Put it beside the script or in data_E9.',DATA_FILE);

if QUICK
    H = CROP_HW(1); W = CROP_HW(2);
    assert(all(CROP_HW > 0) && H<=ORIGINAL_H && W<=ORIGINAL_W, ...
        'Invalid QUICK crop.');
    r1=floor((ORIGINAL_H-H)/2)+1;
    c1=floor((ORIGINAL_W-W)/2)+1;
    rr=r1:(r1+H-1); cc=c1:(c1+W-1);
else
    H=ORIGINAL_H; W=ORIGINAL_W;
    rr=1:H; cc=1:W;
end
assert(mod(H,BIN)==0 && mod(W,BIN)==0 && ...
    mod(H,TILE)==0 && mod(W,TILE)==0, ...
    'Image/crop size must be divisible by BIN and TILE for exact tiling.');

fprintf('\n====== E9-B1 HySime: Z=%d, 32 bands, %dx%d ======\n',Z_PLANE,H,W);
fprintf('Only estimating signal-subspace dimension; NO PISCO training.\n');
tStart=tic;

% Read original Z using the E9-B1 driver strategy.
% Native MATLAB Tiff reads one full-resolution Z page (not all 27 Z planes).
% Bio-Formats fallback reads exactly 32 channels at the same Z index.
[cube,readMethod]=read_one_z_cube(fname,Z_PLANE,rr,cc, ...
    ORIGINAL_H,ORIGINAL_W,EXPECTED_Z,L,QUICK);
fprintf('Data loaded by %s, class=%s, %.1f MB in memory.\n', ...
    readMethod,class(cube),numel(cube)*bytes_per_element(cube)/1e6);

% First pass: RR = Y*Y', Ry = Yb*Yb', with no huge Y matrix.
% Yb is the E14-style 4x4 superpixel mean, with original raster order.
RR=zeros(L,L,'double');
RYsum=zeros(L,L,'double');
for col=1:TILE:W
    for row=1:TILE:H
        X = tile_as_L_by_N(cube,row,col,TILE,L);
        RR = RR + X*X.';
        Xb=reshape(mean(mean(reshape(X,L,BIN,TILE/BIN,BIN,TILE/BIN),2),4), ...
            L,[]);
        RYsum = RYsum + Xb*Xb.';
    end
end
N=H*W;
Nb=(H/BIN)*(W/BIN);

% Match e14_estnoise coefficients: bandwise multiple linear regression
% on ORIGINAL unbinned pixel data. No full residual matrix is allocated.
small=1e-6;
RRi=inv(RR+small*eye(L)); %#ok<MINV> % E14 exact regularization convention
beta=zeros(L,L);                 % column i predicts spectral band i
for i=1:L
    XX=RRi-(RRi(:,i)*RRi(i,:))/RRi(i,i);
    RRa=RR(:,i); RRa(i)=0;
    bb=XX*RRa; bb(i)=0;
    beta(:,i)=bb;
end

% Second pass: noise residual w(i,j)=Y(i,j)-beta(:,i)'*Y(:,j).
% Squared sums reproduce diag(w*w'/N) from e14_estnoise, without w.
noiseSquares=zeros(L,1);
for col=1:TILE:W
    for row=1:TILE:H
        X=tile_as_L_by_N(cube,row,col,TILE,L);
        noiseX=X-beta.'*X;
        noiseSquares=noiseSquares+sum(noiseX.^2,2);
    end
end
clear cube X Xb noiseX;
Rn=diag(noiseSquares/N);          % E14 diagonal additive-noise covariance
Rn=Rn/(BIN^2);                  % E14 assumes independent per-pixel noise
Ry=RYsum/Nb;
Rx=Ry-Rn;

% E14 HySime minimum-error criterion, without its forced p=6 clamp.
[E,D]=eig((Rx+Rx.')/2);
[~,ord]=sort(diag(D),'descend');
E=E(:,ord);
Rn=Rn + sum(diag(Rx))/L/1e10*eye(L);  % E14 regularization
Py=diag(E.'*Ry*E);
Pn=diag(E.'*Rn*E);
cost_F=-Py+2*Pn;
p_hysime=sum(cost_F<0);           % the original, unmodified estimate

assert(all(isfinite(cost_F)) && all(isfinite(noiseSquares)), ...
    'HySime produced invalid values. Check the raw LSM and noise estimation.');
fprintf('\n--- HySime result ---\n');
fprintf('Data: Z=%d, %d channels, %d pixels; 4x4 superpixels=%d\n', ...
    Z_PLANE,L,N,Nb);
fprintf('Original E9-B1 fixed endmembers: p=%d\n',P_FIXED_REFERENCE);
fprintf('HySime estimated signal-subspace dimension: p_raw=%d\n',p_hysime);
fprintf('Elapsed time: %.2f seconds\n',toc(tStart));
fprintf('NOTE: HySime estimates effective spectral dimension, not verified biological labels.\n');
fprintf('NOTE: Existing PISCO p=8 results were not modified.\n\n');
if p_hysime==0 || p_hysime>=L
    warning('HySime returned %d of %d possible dimensions. Review noise/model assumptions.', ...
        p_hysime,L);
end
end

function [cube,how]=read_one_z_cube(fname,z,rr,cc,fullH,fullW,expectedZ,L,fullSize)
% Same native-TIFF first / Bio-Formats second scheme as E9-B1 driver.
% fullSize = true means no crop, so avoid making a second full-size copy.
try
    tif=Tiff(fname,'r');
    guard=onCleanup(@()close(tif)); %#ok<NASGU>
    dirs=fullres_dirs(tif,fullW,fullH);
    assert(numel(dirs)>=expectedZ, ...
        'Only %d full-resolution TIFF pages; expected at least %d.',numel(dirs),expectedZ);
    tif.setDirectory(dirs(z));
    raw=tif.read();
    assert(size(raw,1)==fullH && size(raw,2)==fullW && size(raw,3)>=L, ...
        'Tiff.read returned the wrong shape: %s.',mat2str(size(raw)));
    if fullSize
        cube=raw(:,:,1:L);
    else
        cube=raw(rr,cc,1:L);
    end
    how='MATLAB Tiff';
    return;
catch ME
    fprintf(2,'Native TIFF unavailable (%s). Trying Bio-Formats.\n',ME.message);
end
assert(exist('bfGetReader','file')==2 && exist('bfGetPlane','file')==2, ...
    'Bio-Formats bfGetReader/bfGetPlane unavailable. Add Bio-Formats to MATLAB path.');
br=bfGetReader(fname);
guard=onCleanup(@()br.close()); %#ok<NASGU>
br.setSeries(0);
assert(double(br.getSizeX())==fullW && double(br.getSizeY())==fullH && ...
    double(br.getSizeZ())>=expectedZ && double(br.getSizeC())>=L, ...
    'Bio-Formats input has unexpected dimensions.');
frame=bfGetPlane(br,double(br.getIndex(z-1,0,0))+1);
assert(size(frame,1)==fullH && size(frame,2)==fullW, ...
    'Bad Bio-Formats first-channel plane shape.');
cube=zeros(numel(rr),numel(cc),L,'like',frame);
cube(:,:,1)=frame(rr,cc);
clear frame;
for c=2:L
    id=double(br.getIndex(z-1,c-1,0))+1;
    frame=bfGetPlane(br,id);
    cube(:,:,c)=frame(rr,cc);
end
how='Bio-Formats';
end

function dirs=fullres_dirs(tif,X,Y)
% Copied from E9-B1: select full-size TIFF directories; do not read thumbnails.
dirs=[];tif.setDirectory(1);idx=1;
while true
    x=double(tif.getTag(Tiff.TagID.ImageWidth));
    y=double(tif.getTag(Tiff.TagID.ImageLength));
    if x==X && y==Y, dirs(end+1)=idx; end %#ok<AGROW>
    if tif.lastDirectory(),break;end
    tif.nextDirectory();idx=idx+1;
    assert(idx<10000,'Too many TIFF directories.');
end
end

function X=tile_as_L_by_N(cube,row,col,tileSize,L)
% Image is H x W x L; spectrum is the fastest dimension in L x N.
% No left/right flip, no spatial subsampling and no channel normalization.
A=double(cube(row:row+tileSize-1,col:col+tileSize-1,1:L));
assert(all(isfinite(A(:))) && all(A(:)>=0), ...
    'Nonfinite or negative detector levels in Z plane.');
X=reshape(permute(A,[3,1,2]),L,[]);
end

function n=bytes_per_element(x)
switch class(x)
    case {'uint8','int8','logical'},n=1;
    case {'uint16','int16'},n=2;
    case {'uint32','int32','single'},n=4;
    otherwise,n=8;
end
end
