%% demo_pisco_E9_B2_Binomial_AB_Final_GYL.m
% E9-B2 FINAL binomial-count-thinning comparison, Z=12, 32 spectral channels.
% TWO MODEL ARMS: original spectral priors (legacy) vs q=1-referenced scale
% normalization of the two quadratic band-space endmember priors.
%
% ONLY randomized Binomial(Y0,q) inputs; NO pure q*Y0 control runs.
% Both arms receive EXACTLY the same thinning seeds, the same training seeds,
% the same original ROI, the same number of endmembers and hyperparameters.
% The model is a diagnostic ABlation; do not change the original B1 model.
%
% FINAL TWO FIGURES (saved AND displayed, not closed):
%   pisco_E9_B2_dose_residual.png
%   pisco_E9_B2_spectral_stability.png
% Each: mean +/- 95% Student-t CI across independent stochastic runs.
% Additional CSVs retain individual/summary numeric results and loss terms.
% Full MAT files: only rep=1 for EACH arm and dose; rep>=2 saves no MAT.
%
% WARNING: the LSM intensity levels are uncalibrated digital values rather
% than verified physical photon counts. q is a simulated retained digital
% count fraction, NOT measured laser power. SAD is estimated spectral
% stability relative to the corresponding arm's SAME-REPEAT q=1 output,
% NOT spectral accuracy against biological ground truth.
clear; close all; clc;

%% ---------------------------- SETTINGS --------------------------------
DATA_FILE='fig5_e_01-fish1-four-hinbrain_eye-autofl.lsm';
DATA_DIR='data_E9';
OUT_DIR='E9_B2_Binomial_AB_Final_output';  % new folder: no legacy overwrite
Z_PLANE=12;
QUICK=true;     % FORMAL: full 2048x2560. Set true for 256x256 debugging.
if QUICK
    CROP_HW=[256 256]; MAX_PIXELS=256*256;
else
    CROP_HW=[0 0]; MAX_PIXELS=2048*2560;
end
DOSES=[1 .75 .50 .25 .10];
N_REPEATS=10;    % FORMAL: 10 paired stochastic repetitions (100 trainings)
TRAIN_SEEDS=[1001];   % ONLY base seed; remaining seeds auto-generated
THIN_SEEDS=[1101];    % ONLY base seed; independent per (rep,dose)
PRIOR_MODES={'legacy','reference_scaled'};
THINNING_METHOD='gpu_chunked'; % 'gpu_chunked' (recommended) or 'cpu'
THIN_BLOCK_PIXELS=131072;
SAVE_MAT_REP1=true;   % only rep=1 per arm/dose (full images => large files)
RECON_BLOCK=20000;
P_METHOD='fixed'; P_FIXED=8;
SIGNAL_PERCENTILE=25;
TRAINER='deep_mvsa_invflow_poisson_explicit_Warmup2_ScaleAudit';
% Exactly the E9-B1 NoASC BandLoss Fixed-Q-tail settings. Arms differ ONLY
% by SCALE_PRIOR_MODE, passed separately below.
OPT=struct('MM_ITERS',2500,'WARM_UP',600, ...
    'LAMBDA_BAND',5,'LAMBDA_ENCLOSE',10,'LAMBDA_SPATIAL',2, ...
    'LAMBDA_SMOOTH',0.1,'LAMBDA_MNONNEG',10, ...
    'NOISE_MODEL','poisson','NOISE_WEIGHT','uniform', ...
    'PHOTON_GAIN',0.1,'PHOTON_FLOOR',1,'READ_SIGMA',1, ...
    'ETA',0.4,'ETA_END',0.4, ...
    'SIGMA_CAP',0.15,'PASS_SIGMA_CAP',true, ...
    'P_METHOD',P_METHOD,'P_FIXED',P_FIXED, ...
    'TAIL_ITERS',400,'TAIL_LR',3e-4, ...
    'TAIL_REPORT_EVERY',100,'TAIL_ROLLBACK_IF_WORSE',true);

%% ------------------------ VALIDATE / LOAD ------------------------------
assert(exist(TRAINER,'file')==2,'E9B2Final:Trainer', ...
    'ScaleAudit model missing from MATLAB path: %s',TRAINER);
assert(isequal(PRIOR_MODES,{'legacy','reference_scaled'}), ...
    'E9B2Final:Arms','Two predefined arms are needed for paired A/B.');
assert(all(DOSES>0 & DOSES<=1) && DOSES(1)==1 && ...
    all(diff(DOSES)<0),'E9B2Final:Doses', ...
    'DOSES must start at 1, decrease strictly and remain in (0,1].');
assert(isscalar(N_REPEATS) && N_REPEATS>=2 && N_REPEATS==fix(N_REPEATS), ...
    'E9B2Final:Repeats','N_REPEATS >= 2 is required for 95%% CIs.');
assert(isscalar(TRAIN_SEEDS) && isscalar(THIN_SEEDS) && ...
    all(isfinite([TRAIN_SEEDS THIN_SEEDS])) && ...
    all([TRAIN_SEEDS THIN_SEEDS] >= 0) && ...
    all([TRAIN_SEEDS THIN_SEEDS] == fix([TRAIN_SEEDS THIN_SEEDS])), ...
    'E9B2Final:Seeds','TRAIN_SEEDS and THIN_SEEDS must each be ONE nonnegative integer.');
assert(TRAIN_SEEDS+(N_REPEATS-1)*1001<=double(intmax('uint32')) && ...
    THIN_SEEDS+N_REPEATS*numel(DOSES)*7919<=double(intmax('uint32')), ...
    'E9B2Final:Seeds','Automatically derived seeds exceed uint32 range.');
assert(any(strcmpi(THINNING_METHOD,{'cpu','gpu_chunked'})), ...
    'E9B2Final:Thinning','THINNING_METHOD must be cpu or gpu_chunked.');
assert(isscalar(THIN_BLOCK_PIXELS) && THIN_BLOCK_PIXELS>=1 && ...
    THIN_BLOCK_PIXELS==fix(THIN_BLOCK_PIXELS), ...
    'E9B2Final:Block','THIN_BLOCK_PIXELS must be a positive integer.');
assert(exist('binornd','file')==2,'E9B2Final:Binomial', ...
    'Requires Statistics and Machine Learning Toolbox binornd().');
% The trainer defaults to GPU=true; reset both streams for paired runs.
try
    gpuDevice(1);
catch ME
    error('E9B2Final:GPU', ...
      'ScaleAudit trainer needs a supported NVIDIA GPU. Details: %s',ME.message);
end
scriptdir=fileparts(mfilename('fullpath'));
if isempty(scriptdir),scriptdir=pwd;end
candidates={DATA_FILE,fullfile(DATA_DIR,DATA_FILE), ...
    fullfile(scriptdir,DATA_FILE),fullfile(scriptdir,DATA_DIR,DATA_FILE)};
fname='';
for ii=1:numel(candidates)
    if exist(candidates{ii},'file')==2
        fname=candidates{ii}; break;
    end
end
assert(~isempty(fname),'E9B2Final:LSM','Cannot locate LSM: %s',DATA_FILE);
if ~exist(OUT_DIR,'dir'),mkdir(OUT_DIR);end
[Y0,roi_info]=e9b_read_lsm_roi(fname,Z_PLANE,CROP_HW,MAX_PIXELS);
H=roi_info.H; W=roi_info.W;
mask=e9b_signal_mask(Y0,SIGNAL_PERCENTILE); % SAME original-data ROI for all q
[p,p_source]=e9b_select_p(Y0,OPT);             % SAME p across all runs
assert(all(Y0(:)==round(Y0(:))),'E9B2Final:Integers', ...
    'Original LSM contains noninteger samples; cannot apply exact binornd.');
REFERENCE_INTENSITY=mean(sum(Y0,1));
assert(isfinite(REFERENCE_INTENSITY) && REFERENCE_INTENSITY>0, ...
    'E9B2Final:Reference','q=1 intensity reference must be positive.');
if max(Y0(:))<=flintmax('single')
    thinClass='single';
else
    thinClass='double';
end
fprintf('\nE9-B2 FINAL BINOMIAL A/B | Z=%d, p=%d, %dx%d, ROI=%d pixels\n', ...
    Z_PLANE,p,H,W,nnz(mask));
fprintf('DOSES=%s | N_REPEATS=%d | total trainings=%d\n', ...
    mat2str(DOSES),N_REPEATS,numel(DOSES)*N_REPEATS*numel(PRIOR_MODES));
fprintf('Trainer: %s\n',which(TRAINER));
fprintf(2,['WARNING: count-thinning of uncalibrated digital levels; ' ...
    'NOT actual laser-power reduction.\n']);
if ~QUICK && SAVE_MAT_REP1
    fprintf(2,['WARNING: Saving full MAT for 2 arms x %d doses in rep1 ' ...
        'may consume tens of GB; ensure sufficient disk space.\n'],numel(DOSES));
end

%% ---------------------- PAIRED EXPERIMENT ------------------------------
results=struct([]); losses=struct([]);
results_file=fullfile(OUT_DIR,'pisco_E9_B2_binomial_AB_results.csv');
loss_file=fullfile(OUT_DIR,'pisco_E9_B2_binomial_AB_loss_components.csv');
for arm=1:numel(PRIOR_MODES)
    prior_mode=PRIOR_MODES{arm};
    for rep=1:N_REPEATS
        train_seed=TRAIN_SEEDS(1)+(rep-1)*1001;
        M_ref=[]; S_ref=[];
        for k=1:numel(DOSES)
            q=DOSES(k);
            thin_seed=THIN_SEEDS(1)+((rep-1)*numel(DOSES)+k)*7919;
            fprintf('\n[B2] arm=%s | rep=%d/%d | q=%.2f | train_seed=%d thin_seed=%d\n', ...
                prior_mode,rep,N_REPEATS,q,train_seed,thin_seed);
            if q==1
                Y=Y0; thinning_s=0;
            else
                tthin=tic;
                if strcmpi(THINNING_METHOD,'gpu_chunked')
                    gpurng(thin_seed,'threefry');
                    Y=zeros(size(Y0),'double');
                    Nthin=size(Y0,2);
                    for j0=1:THIN_BLOCK_PIXELS:Nthin
                        jj=j0:min(Nthin,j0+THIN_BLOCK_PIXELS-1);
                        gTrials=gpuArray(cast(Y0(:,jj),thinClass));
                        gDraw=binornd(gTrials,cast(q,thinClass));
                        Y(:,jj)=double(gather(gDraw));
                        clear gTrials gDraw;
                    end
                else
                    rng(thin_seed,'twister');
                    Y=double(binornd(Y0,q));
                end
                thinning_s=toc(tthin);
                fprintf('[Binomial] q=%.2f | time=%.3f s | mean input=%.5g (expected=%.5g)\n', ...
                    q,thinning_s,mean(Y(:)),q*mean(Y0(:)));
            end
            % Both arms see identical Y when using same (repeat,q) seed;
            % reset the RNGs AGAIN before each training to make initialization paired.
            rng(train_seed,'twister');
            gpurng(train_seed,'threefry');
            args=e9b_train_options(H,W,OPT);
            args=[args,{'SCALE_PRIOR_MODE',prior_mode, ...
                'SCALE_PRIOR_REFERENCE_INTENSITY',REFERENCE_INTENSITY}];
            ttrain=tic;
            [M_est,S_est,~,~,theta]=feval(TRAINER,Y,p,args{:});
            train_time_s=toc(ttrain);
            required={'M_before_clip_bandloss_audit','S_before_tail', ...
                'loss_components_joint','loss_components_final', ...
                'spectral_prior_scale_audit','tail_info'};
            for ia=1:numel(required)
                assert(isfield(theta,required{ia}), 'E9B2Final:Audit', ...
                    'Trainer audit missing theta.%s: check ScaleAudit model file.',required{ia});
            end
            M_preclip=theta.M_before_clip_bandloss_audit;
            S_joint=theta.S_before_tail;
            prior_audit=theta.spectral_prior_scale_audit;
            clip_relative=theta.endmember_clip_relative;
            tail_info=theta.tail_info;
            loss_joint=theta.loss_components_joint;
            loss_final=theta.loss_components_final;
            clear theta;
            % Same fixed original ROI for both arms and all q; NoASC linear
            % prediction uses POSTCLIP M_est*S_est, not the affine diagnostic.
            r_tail_post=e9b_frob_only(Y,M_est,S_est,mask,RECON_BLOCK);
            r_tail_pre=e9b_frob_only(Y,M_preclip,S_est,mask,RECON_BLOCK);
            r_joint_post=e9b_frob_only(Y,M_est,S_joint,mask,RECON_BLOCK);
            r_joint_pre=e9b_frob_only(Y,M_preclip,S_joint,mask,RECON_BLOCK);
            if k==1
                M_ref=M_est; S_ref=S_est;
                sad_vs_q1=0; abundance_corr=1;
            else
                [~,sad_vs_q1,abundance_corr]=e9b_align_baseline( ...
                    M_ref,S_ref,M_est,S_est);
            end
            % Use a fixed, identical field order for all result rows.
            a=struct();
            a.input_mode='binomial'; a.prior_mode=prior_mode;
            a.dose=q; a.repeat=rep; a.train_seed=train_seed;
            a.thin_seed=thin_seed; a.z=Z_PLANE; a.H=H; a.W=W; a.p=p;
            a.mean_original_digital_count=mean(Y0(:));
            a.mean_input_digital_count=mean(Y(:));
            a.relative_input_intensity=mean(sum(Y,1))/REFERENCE_INTENSITY;
            a.prior_factor=prior_audit.factor;
            a.lambda_mnonneg_effective=prior_audit.effective_lambda_mnonneg;
            a.lambda_smooth_effective=prior_audit.effective_lambda_smooth;
            a.rel_frob_tail_postclip=r_tail_post;
            a.rel_frob_tail_preclip=r_tail_pre;
            a.rel_frob_joint_postclip=r_joint_post;
            a.rel_frob_joint_preclip=r_joint_pre;
            a.delta_clip=r_tail_post-r_tail_pre;
            a.endmember_clip_relative=clip_relative;
            a.tail_rolled_back=double(tail_info.rolled_back);
            a.sad_vs_same_arm_q1_deg=sad_vs_q1;
            a.abundance_corr_vs_q1=abundance_corr;
            a.train_time_s=train_time_s; a.thinning_time_s=thinning_s;
            a.enclosure_weighted=loss_final.enclosure_weighted;
            a.enclosure_weighted_per_pixel=loss_final.enclosure_weighted/size(Y,2);
            a.smooth_weighted=loss_final.endmember_smooth_weighted;
            a.endmember_nonneg_weighted=loss_final.endmember_nonneg_weighted;
            a.band_weighted=loss_final.band_weighted;
            a.reconstruction_weighted=loss_final.reconstruction_weighted;
            a.loss_total_weighted=loss_final.total_weighted;
            if isempty(results)
                results=a;
            else
                results(end+1)=orderfields(a,results(1)); %#ok<SAGROW>
            end
            % Durable progress saved after EACH successful run.
            writetable(struct2table(results),results_file);
            stages={'joint','final'}; components={loss_joint,loss_final};
            for stageidx=1:2
                pp=components{stageidx};
                b=struct('input_mode','binomial','prior_mode',prior_mode, ...
                    'dose',q,'repeat',rep,'stage',stages{stageidx}, ...
                    'prior_factor',prior_audit.factor);
                fn=fieldnames(pp);
                for jj=1:numel(fn)
                    b.(fn{jj})=pp.(fn{jj});
                end
                b.enclosure_weighted_per_pixel=pp.enclosure_weighted/size(Y,2);
                if isempty(losses)
                    losses=b;
                else
                    losses(end+1)=orderfields(b,losses(1)); %#ok<SAGROW>
                end
            end
            writetable(struct2table(losses),loss_file);
            fprintf('[B2 result] %s rep%02d q=%.2f | relFrob=%.8f | SAD=%.6g deg | clipDelta=%+.3g\n', ...
                prior_mode,rep,q,r_tail_post,sad_vs_q1,a.delta_clip);
            if SAVE_MAT_REP1 && rep==1
                tag=sprintf('pisco_E9_B2_binomial_%s_q%03d_rep01',prior_mode,round(q*100));
                config=struct('input_mode','binomial','prior_mode',prior_mode, ...
                    'dose',q,'repeat',rep,'train_seed',train_seed, ...
                    'thin_seed',thin_seed,'z',Z_PLANE,'p',p,'p_source',p_source, ...
                    'options',OPT,'trainer',TRAINER,'source_file',fname, ...
                    'roi_info',roi_info,'roi_percentile',SIGNAL_PERCENTILE, ...
                    'q1_reference_intensity',REFERENCE_INTENSITY, ...
                    'not_real_laser_power',true);
                roi_mask=reshape(mask,H,W);
                save(fullfile(OUT_DIR,[tag '_full.mat']), ...
                    'Y0','Y','M_est','M_preclip','S_est','S_joint', ...
                    'mask','roi_mask','roi_info','config','a', ...
                    'loss_joint','loss_final','prior_audit','tail_info','-v7.3');
            end
            clear M_preclip S_joint;
        end
        clear M_ref S_ref;
    end
end

%% ------------------ SUMMARY / 95% STUDENT-T CI -------------------------
T=struct2table(results);
summaryRows=struct([]);
for arm=1:numel(PRIOR_MODES)
    prior_mode=PRIOR_MODES{arm};
    for k=1:numel(DOSES)
        q=DOSES(k);
        ix=strcmp(T.prior_mode,prior_mode) & abs(T.dose-q)<1e-12;
        [nm,rMean,rSD,rLo,rHi]=e9b_mean_ci95(T.rel_frob_tail_postclip(ix));
        [ns,sMean,sSD,sLo,sHi]=e9b_mean_ci95(T.sad_vs_same_arm_q1_deg(ix));
        assert(nm==N_REPEATS && ns==N_REPEATS,'E9B2Final:MissingResults', ...
            'Expected %d successful runs per model arm and dose.',N_REPEATS);
        z=struct('prior_mode',prior_mode,'dose',q,'n',nm, ...
            'frob_mean',rMean,'frob_std',rSD,'frob_ci95_low',rLo,'frob_ci95_high',rHi, ...
            'sad_mean_deg',sMean,'sad_std_deg',sSD, ...
            'sad_ci95_low_deg',sLo,'sad_ci95_high_deg',sHi, ...
            'smooth_weighted_mean',mean(T.smooth_weighted(ix)), ...
            'enclosure_per_pixel_mean',mean(T.enclosure_weighted_per_pixel(ix)));
        if isempty(summaryRows)
            summaryRows=z;
        else
            summaryRows(end+1)=orderfields(z,summaryRows(1)); %#ok<SAGROW>
        end
    end
end
writetable(struct2table(summaryRows), ...
    fullfile(OUT_DIR,'pisco_E9_B2_binomial_AB_summary.csv'));
% Paired, per-repeat A-vs-B differences allow quantitative A/B inference.
pairedRows=struct([]);
for k=1:numel(DOSES)
    q=DOSES(k);
    idxA=strcmp(T.prior_mode,'legacy') & abs(T.dose-q)<1e-12;
    idxB=strcmp(T.prior_mode,'reference_scaled') & abs(T.dose-q)<1e-12;
    AA=T(idxA,:); BB=T(idxB,:);
    AA=sortrows(AA,'repeat'); BB=sortrows(BB,'repeat');
    assert(isequal(AA.repeat,BB.repeat) && all(AA.train_seed==BB.train_seed) && ...
        all(AA.thin_seed==BB.thin_seed),'E9B2Final:Pairing', ...
        'A/B model arms are not properly paired at dose %.2f.',q);
    dF=BB.rel_frob_tail_postclip-AA.rel_frob_tail_postclip;
    dS=BB.sad_vs_same_arm_q1_deg-AA.sad_vs_same_arm_q1_deg;
    [~,dFm,~,dFlo,dFhi]=e9b_mean_ci95(dF);
    [~,dSm,~,dSlo,dShi]=e9b_mean_ci95(dS);
    for rep=1:N_REPEATS
        row=struct('dose',q,'repeat',rep, ...
            'frob_scaled_minus_legacy',dF(rep), ...
            'sad_scaled_minus_legacy_deg',dS(rep), ...
            'frob_paired_mean',dFm,'frob_paired_ci95_low',dFlo, ...
            'frob_paired_ci95_high',dFhi, ...
            'sad_paired_mean_deg',dSm,'sad_paired_ci95_low_deg',dSlo, ...
            'sad_paired_ci95_high_deg',dShi);
        if isempty(pairedRows)
            pairedRows=row;
        else
            pairedRows(end+1)=orderfields(row,pairedRows(1)); %#ok<SAGROW>
        end
    end
end
writetable(struct2table(pairedRows), ...
    fullfile(OUT_DIR,'pisco_E9_B2_binomial_AB_paired.csv'));

%% --------------------- EXACTLY TWO FIGURES -----------------------------
% No other figure creation occurs in this script. Both show after training.
% 95% CI is across stochastic seeds, not independent biological acquisitions.
[xSorted,ord]=sort(DOSES(:)*100,'ascend');
armLabels={'Original endmember priors','Intensity-scaled endmember priors'};

f1=figure('Visible','on','Color','w','Position',[50 50 1010 620]);
hold on; legends=cell(1,numel(PRIOR_MODES));
for arm=1:numel(PRIOR_MODES)
    ix=strcmp({summaryRows.prior_mode},PRIOR_MODES{arm});
    armData=summaryRows(ix); % saved in DOSES order
    y=[armData.frob_mean]';
    yLo=[armData.frob_ci95_low]'; yHi=[armData.frob_ci95_high]';
    y=y(ord); errLow=max(0,y-yLo(ord)); errHigh=max(0,yHi(ord)-y);
    errorbar(xSorted,y,errLow,errHigh,'-o','LineWidth',1.5,'MarkerSize',6);
    legends{arm}=armLabels{arm};
end
grid on; xlabel('Simulated retained digital-count fraction (%)');
ylabel('ROI relative Frobenius reconstruction residual');
title(sprintf('E9-B2 simulated count thinning | %d runs | mean +/- 95%% CI',N_REPEATS));
legend(legends,'Location','best');
exportgraphics(f1,fullfile(OUT_DIR,'pisco_E9_B2_dose_residual.png'),'Resolution',180);
drawnow; % DO NOT close(f1)

f2=figure('Visible','on','Color','w','Position',[100 90 1010 620]);
hold on; legends=cell(1,numel(PRIOR_MODES));
for arm=1:numel(PRIOR_MODES)
    ix=strcmp({summaryRows.prior_mode},PRIOR_MODES{arm});
    armData=summaryRows(ix);
    y=[armData.sad_mean_deg]';
    yLo=[armData.sad_ci95_low_deg]'; yHi=[armData.sad_ci95_high_deg]';
    y=y(ord); errLow=max(0,y-yLo(ord)); errHigh=max(0,yHi(ord)-y);
    errorbar(xSorted,y,errLow,errHigh,'-o','LineWidth',1.5,'MarkerSize',6);
    legends{arm}=armLabels{arm};
end
grid on; xlabel('Simulated retained digital-count fraction (%)');
ylabel('Mean endmember SAD vs own-arm q=1 estimate (degrees)');
title(sprintf('E9-B2 estimated endmember stability | %d runs | mean +/- 95%% CI',N_REPEATS));
legend(legends,'Location','best');
exportgraphics(f2,fullfile(OUT_DIR,'pisco_E9_B2_spectral_stability.png'),'Resolution',180);
drawnow; % DO NOT close(f2)
fprintf('\nE9-B2 FINISHED. Two figures DISPLAYED and saved to %s\n',OUT_DIR);
fprintf('  - pisco_E9_B2_dose_residual.png\n');
fprintf('  - pisco_E9_B2_spectral_stability.png\n');

%% ---------------------------- UTILITIES --------------------------------
function [n,mu,sd,lo,hi]=e9b_mean_ci95(x)
% Student-t 95% CI for the mean of finite replicate values.
    x=double(x(:)); x=x(isfinite(x)); n=numel(x);
    assert(n>=2,'E9B2Final:CI','At least 2 observations needed for 95%% CI.');
    mu=mean(x); sd=std(x,0);
    half=tinv(.975,n-1)*sd/sqrt(n); % Statistics Toolbox already required
    lo=mu-half; hi=mu+half;
end

%% ==== Preserved E9-B2 utility functions ====
function [Y, roi_info] = e9b_read_lsm_roi(fname, z, cropHW, max_pixels)
% Reads ONLY one Z (32 spectral bands). Native Tiff first, Bio-Formats fallback.
% Note: native Tiff.read decodes one full-resolution uint16 Z page in RAM;
% ROI is cropped before conversion to double. No full volume is loaded.
    originalH = 2048; originalW = 2560; expectedZ = 27; C = 32;
    assert(isscalar(z) && z == round(z) && z >= 1 && z <= expectedZ, ...
        'E9B:Z','Z must be an integer from 1 to %d.',expectedZ);
    assert(numel(cropHW)==2 && all(cropHW >= 0),'E9B:Crop','Bad crop size.');
    if all(cropHW == 0)
        rr = 1:originalH; cc = 1:originalW;
    else
        h = cropHW(1); w = cropHW(2);
        assert(h<=originalH && w<=originalW && h>=1 && w>=1 && ...
            h==round(h) && w==round(w),'E9B:Crop','Invalid crop size.');
        r1 = floor((originalH - h)/2) + 1;
        c1 = floor((originalW - w)/2) + 1;
        rr = r1:(r1+h-1); cc = c1:(c1+w-1);
    end
    H = numel(rr); W = numel(cc);
    assert(H*W <= max_pixels,'E9B:MemoryGuard', ...
        ['Requested %d pixels exceeds MAX_PIXELS=%d. The original trainer' ...
         ' is NOT a verified full-frame streaming solver. Increase the' ...
         ' limit only after reviewing available RAM and trainer behavior.'], ...
        H*W,max_pixels);
    roi_info = struct('z',z,'H',H,'W',W,'rows',[rr(1),rr(end)], ...
        'cols',[cc(1),cc(end)],'fullH',originalH,'fullW',originalW, ...
        'channels',C,'pixel_count',H*W,'method','');
    Y = [];
    native_error = '';
    try
        tif = Tiff(fname,'r');
        tif_close = onCleanup(@() tif.close()); %#ok<NASGU>
        dirs = e9b_fullres_dirs(tif,originalW,originalH);
        assert(numel(dirs)>=expectedZ,'E9B:Directories', ...
            'Only %d full-resolution TIFF pages; expected at least %d.', ...
            numel(dirs),expectedZ);
        tif.setDirectory(dirs(z));
        A = tif.read();
        assert(size(A,1)==originalH && size(A,2)==originalW && ...
            size(A,3)>=C,'E9B:TiffShape', ...
            'Tiff.read returned %s, expected H x W x >=32.',mat2str(size(A)));
        Y = zeros(C,H*W,'double');
        for c=1:C
            tmp = A(rr,cc,c);
            Y(c,:) = reshape(double(tmp),1,[]);
        end
        clear A;
        roi_info.method = 'MATLAB Tiff';
    catch ME
        native_error = ME.message;
        Y = [];
    end
    if isempty(Y)
        if exist('bfGetReader','file') ~= 2 || exist('bfGetPlane','file') ~= 2
            error('E9B:Reader',[...
                'Native TIFF reader failed: %s\n' ...
                'Install the MATLAB Bio-Formats package (bfGetReader and' ...
                ' bfGetPlane) or inspect this >4GB LSM image encoding.'], ...
                native_error);
        end
        fprintf(2,'Native TIFF read unavailable: %s\nTrying Bio-Formats...\n',native_error);
        br = bfGetReader(fname);
        br_close = onCleanup(@() br.close()); %#ok<NASGU>
        br.setSeries(0);
        assert(double(br.getSizeX())==originalW && double(br.getSizeY())==originalH && ...
            double(br.getSizeZ())>=expectedZ && double(br.getSizeC())>=C, ...
            'E9B:BFShape','Unexpected Bio-Formats series dimensions.');
        Y = zeros(C,H*W,'double');
        for c=1:C
            plane_id = double(br.getIndex(z-1,c-1,0))+1;
            A = bfGetPlane(br,plane_id);
            tmp = A(rr,cc);
            Y(c,:) = reshape(double(tmp),1,[]);
        end
        roi_info.method = 'Bio-Formats';
    end
    assert(isequal(size(Y),[C H*W]) && all(isfinite(Y(:))) && ...
        all(Y(:)>=0),'E9B:BadY','Invalid intensity values in imported cube.');
    fprintf('Read Z=%d by %s | %d x %d | 32 bands | count range %.5g..%.5g\n', ...
        z,roi_info.method,H,W,min(Y(:)),max(Y(:)));
end

function dirs=e9b_fullres_dirs(tif,X,Y)
% Use dimensions, never assume alternating thumbnails, never read pixels.
    dirs=[]; tif.setDirectory(1); idx=1;
    while true
        x=double(tif.getTag(Tiff.TagID.ImageWidth));
        y=double(tif.getTag(Tiff.TagID.ImageLength));
        if x==X && y==Y
            dirs(end+1)=idx; %#ok<AGROW>
        end
        if tif.lastDirectory(), break; end
        tif.nextDirectory(); idx=idx+1;
        assert(idx<10000,'E9B:IFD','Too many TIFF directories.');
    end
end

function mask=e9b_signal_mask(Y,percentile)
% Fixed ROI from ORIGINAL data, not from each thinned observation.
    brightness = sum(Y,1);
    v = sort(brightness(isfinite(brightness)));
    assert(~isempty(v),'E9B:EmptyData','All pixel intensities are invalid.');
    rank=max(1,min(numel(v),round(1+(numel(v)-1)*percentile/100)));
    threshold=v(rank);
    mask=brightness>max(0,threshold);
    if nnz(mask)<max(100,ceil(.03*numel(mask)))
        mask=brightness>0;
    end
    assert(nnz(mask)>0,'E9B:Mask','There are no illuminated pixels.');
end

function args=e9b_train_options(H,W,opt)
% Exact option mapping from demo_pisco_E9_B1_NoASC_BandLoss_FixedQTail.
% Keep NoASC (LAMBDA_SUMONE=0), BandLoss and fixed-Q terminal S refinement.
    args={'spherize','yes','verbose',0, ...
        'MM_ITERS',opt.MM_ITERS,'WARM_UP',opt.WARM_UP,'LR',3e-4, ...
        'LAMBDA_VOL',0.008,'LAMBDA_NONNEG',3,'LAMBDA_EQ',100, ...
        'LAMBDA_SUMONE',0,'LAMBDA_ENCLOSE',opt.LAMBDA_ENCLOSE, ...
        'IMG_H',H,'IMG_W',W, ...
        'LAMBDA_SPATIAL',opt.LAMBDA_SPATIAL, ...
        'LAMBDA_SMOOTH',opt.LAMBDA_SMOOTH, ...
        'LAMBDA_MNONNEG',opt.LAMBDA_MNONNEG, ...
        'NOISE_MODEL',opt.NOISE_MODEL,'NOISE_WEIGHT',opt.NOISE_WEIGHT, ...
        'PHOTON_GAIN',opt.PHOTON_GAIN,'PHOTON_FLOOR',opt.PHOTON_FLOOR, ...
        'READ_SIGMA',opt.READ_SIGMA, ...
        'ETA',opt.ETA,'ETA_END',opt.ETA_END, ...
        'LAMBDA_BAND',opt.LAMBDA_BAND, ...
        'TAIL_ITERS',opt.TAIL_ITERS,'TAIL_LR',opt.TAIL_LR, ...
        'TAIL_REPORT_EVERY',opt.TAIL_REPORT_EVERY, ...
        'TAIL_ROLLBACK_IF_WORSE',opt.TAIL_ROLLBACK_IF_WORSE};
    if opt.PASS_SIGMA_CAP
        args=[args,{'SIGMA_CAP',opt.SIGMA_CAP}];
    end
end

function [p,src]=e9b_select_p(Y,opt)
% HySime is optional. If selected, require an external implementation and
% explicitly note that the spatial-difference noise model is approximate.
    switch lower(opt.P_METHOD)
        case 'fixed'
            p=opt.P_FIXED; src='fixed';
        case 'hysime'
            assert(exist('hysime','file')==2,'E9B:HySime', ...
                ['P_METHOD=hysime needs the externally installed hysime.m.' ...
                ' Set P_METHOD=fixed if unavailable.']);
            sample_count=min(16000,size(Y,2));
            inds=unique(round(linspace(1,size(Y,2),sample_count)));
            A=Y(:,inds);
            % Approximate spatial-pair differencing, not a calibrated
            % instrument noise estimate. Use HySime as a sensitivity check.
            if mod(size(A,2),2), A=A(:,1:end-1); end
            d=(A(:,1:2:end)-A(:,2:2:end))/2;
            w=zeros(size(A)); w(:,1:2:end)=d; w(:,2:2:end)=-d;
            try
                p=hysime(A,w,0);
            catch ME
                error('E9B:HySimeAPI', ...
                    ['hysime.m must support hysime(Y,noise,verbose). ' ...
                     'Original error: %s'],ME.message);
            end
            p=double(p(1)); src='hysime_approx_spatial_noise';
            assert(isfinite(p) && p==round(p) && p>=2 && p<=size(Y,1), ...
                'E9B:HySimeP','Invalid HySime p=%g.',p);
        otherwise
            error('E9B:PMethod','P_METHOD must be fixed or hysime.');
    end
end

function r=e9b_frob_only(Y,M,S,mask,block)
% Blocked ROI-only relative Frobenius residual for a specified M,S pair.
% No full 32xN reconstruction cube is allocated.
    assert(size(Y,1)==size(M,1) && size(M,2)==size(S,1) && ...
        size(Y,2)==size(S,2),'E9B2:FrobShape','M,S,Y sizes mismatch.');
    acc=0;den=0;N=size(Y,2);
    for idx=1:block:N
        j=idx:min(idx+block-1,N);
        msk=logical(mask(j));
        if ~any(msk),continue;end
        obs=double(Y(:,j(msk)));
        pred=double(M)*double(S(:,j(msk)));
        d=obs-pred;
        acc=acc+sum(d(:).^2);
        den=den+sum(obs(:).^2);
    end
    r=sqrt(acc/max(den,eps));
end

function [ord,sadmean,abundCorr]=e9b_align_baseline(M0,S0,M1,S1)
% Greedy spectral matching; SAD is BETWEEN ESTIMATES, not ground-truth SAD.
    p=size(M0,2); assert(size(M1,2)==p,'E9B:EndmemberCount','p changed.');
    aa=M0./max(sqrt(sum(M0.^2,1)),eps);
    bb=M1./max(sqrt(sum(M1.^2,1)),eps);
    costs=acos(max(-1,min(1,aa'*bb)))*180/pi;
    ord=zeros(1,p);used=false(1,p);
    for i=1:p
        row=costs(i,:);row(used)=Inf;
        [~,j]=min(row);ord(i)=j;used(j)=true;
    end
    sadmean=mean(arrayfun(@(i)costs(i,ord(i)),1:p));
    % Abundance scaling is generally not identifiable without calibration;
    % Pearson correlation is invariant to positive per-endmember scaling.
    corrs=NaN(1,p);
    for i=1:p
        a=double(S0(i,:));b=double(S1(ord(i),:));
        a=a-mean(a);b=b-mean(b);
        den=sqrt(sum(a.^2)*sum(b.^2));
        if den>1e-12,corrs(i)=sum(a.*b)/den;end
    end
    tmp=corrs(isfinite(corrs));
    if isempty(tmp),abundCorr=NaN;else,abundCorr=mean(tmp);end
end
