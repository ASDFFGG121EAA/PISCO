%% demo_pisco_E9_B2_poisson_thinning_BandLoss_FixedQTail_GPU.m
% E9-B2 | NO-ASC PISCO BandLoss + Fixed-Q Tail, COUNT-THINNING / DOSE-RESIDUAL
% Based on E9-B in demo_pisco_E9_invivo(5).m, extended per A+ plan.
% This is NOT multi-laser-power experimental acquisition.
%
% Data: HyU fig5_e_01-fish1-four-hinbrain_eye-autofl.lsm
% X=2560,Y=2048,Z=27,C=32,T=1. The same crop and Z should be used
% as B1 when comparing figures. No B1 .mat or .csv file is required.
%
% Physics qualification: conditional thinning Yq | Y~Binomial(Y,q) is
% exact for independent integer photon counts and Poisson incident photons.
% Actual LSM digital levels are UNCALIBRATED: the experiment is explicitly
% a count-thinning proxy until detector gain/offset and count origin
% have been validated. DO NOT report q as actual excitation laser power.
%
% Requirements: Statistics and Machine Learning Toolbox (binornd),
%             and deep_mvsa_invflow_poisson_explicit_Warmup2_FixedQTail.m on path.
% Model configuration is synchronized with:
% demo_pisco_E9_B1_NoASC_BandLoss_FixedQTail.m
%
% Outputs (under E9_B2_NoASC_BandLoss_FixedQTail_output/):
%   pisco_E9_B2_dose_results.csv (each q x thinning/training replicate)
%   pisco_E9_B2_summary.csv (mean/std, paired deltas and 95% CIs)
%   pisco_E9_B2_paired_differences.csv (paired replicate deltas vs q=1)
%   pisco_E9_B2_loss_components.csv (joint and post-tail objective terms)
%   pisco_E9_B2_dose_residual.png
%   pisco_E9_B2_spectral_stability.png
%   pisco_E9_B2_Z##_q##_rep01_full.mat (ONLY rep=1 for each q; LARGE for QUICK=false)
%   pisco_E9_B2_Z##_q##_rep01_abundances/spectra/residual.png (rep 1 only)
%   The two summary figures are saved AND shown after all repeats.
%   GPU-CHUNKED binornd option keeps the exact binomial distribution.
% Data geometry synchronized with B1: QUICK=false uses the full 2048x2560 Z=12 plane.
% QUICK=true is available as a matched 256x256 center-crop debug mode.
% To compare with B1 quantitatively, also match B1's QUICK and Z settings.
%
% Metric interpretations:
% - reconstruction errors measured on each THINNED observation, fixed mask;
% - FixedQTail remains NoASC: ONLY M_est*S_est (linear) is the physical prediction;
%   affine residual is retained as a legacy diagnostic, not physical model.
% - Pearson/deviance compare fitting to thinned digital counts;
% - pre/post-clip and joint/tail residuals are same-ROI diagnostics;
% - loss_components CSV separates raw terms from weighted objective terms;
% - spectral match SAD is *within-method stability against q=1* not
%   a ground-truth spectral angle.
clear;close all;clc;

%% ------------------------------ SETTINGS ------------------------------
DATA_FILE='fig5_e_01-fish1-four-hinbrain_eye-autofl.lsm';
DATA_DIR='data_E9';
OUT_DIR='E9_B2_NoASC_BandLoss_FixedQTail_output'; % preserve previous B2 results
Z_PLANE=12;                 % same Z as current E9-B1; valid 1..27
QUICK=true;                % match E9-B1: full 2048x2560 Z=12 plane
if QUICK
    CROP_HW=[256 256];       % matched quick/debug crop from E9-B1
    MAX_PIXELS=256*256;
else
    CROP_HW=[0 0];         % full image, no crop
    MAX_PIXELS=2048*2560;
end
DOSES=[1 .75 .50 .25 .10]; % simulated retained-count fractions
N_REPEATS=1;
TRAIN_SEEDS=[1001];  % base training seed; rep 2,3,... generated automatically
THIN_SEEDS=[1101];   % base thinning seed; unique per (repeat, dose)
% NEW: Choose the original CPU thinning or exact-distribution GPU thinning.
% gpu_chunked: call binornd on small gpuArray blocks and gather to CPU;
%              never hold the full original cube on the GPU.
% cpu: retain the original rng(thin_seed,'twister') + binornd(Y0,q).
THINNING_METHOD='gpu_chunked';  % 'gpu_chunked' | 'cpu'
THIN_BLOCK_PIXELS=131072;       % 32 x 131072 elements per GPU chunk
P_METHOD='fixed';          % fixed | hysime (same p across ALL dose levels)
P_FIXED=8;
TRAINER='deep_mvsa_invflow_poisson_explicit_Warmup2_FixedQTail';
RECON_MODE='linear';       % NoASC physical reconstruction is M_est*S_est
SIGNAL_PERCENTILE=25;     % original Y mask fixed for ALL dose levels
RECON_BLOCK=20000;
% If false, abort rather than treating uncalibrated DL as photons.
ALLOW_UNCALIBRATED_DIGITAL_COUNT_THINNING=true;
% EXACT model configuration copied from E9-B1:
% demo_pisco_E9_B1_NoASC_BandLoss_FixedQTail.
% This includes the original-band reconstruction term and fixed-Q S-only tail.
OPT=struct('MM_ITERS',2500,'WARM_UP',600, ...
    'LAMBDA_BAND',5, ...
    'LAMBDA_ENCLOSE',10, ...
    'LAMBDA_SPATIAL',2, ...
    'LAMBDA_SMOOTH',0.1,'LAMBDA_MNONNEG',10, ...
    'NOISE_MODEL','poisson','NOISE_WEIGHT','uniform', ...
    'PHOTON_GAIN',0.1,'PHOTON_FLOOR',1,'READ_SIGMA',1, ...
    'ETA',0.4,'ETA_END',0.4, ...
    'SIGMA_CAP',0.15,'PASS_SIGMA_CAP',true, ...
    'P_METHOD',P_METHOD,'P_FIXED',P_FIXED, ...
    'TAIL_ITERS',400,'TAIL_LR',3e-4, ...
    'TAIL_REPORT_EVERY',100,'TAIL_ROLLBACK_IF_WORSE',true);
%% ---------------------------------------------------------------------

if QUICK
    fprintf('E9-B2 NoASC QUICK=true: center %d x %d crop (N=%d).\n', ...
        CROP_HW(1),CROP_HW(2),MAX_PIXELS);
else
    fprintf(2,'E9-B2 NoASC QUICK=false: full 2048 x 2560 frame.\n');
    fprintf(2,['WARNING: 5 doses x N_REPEATS can require significant RAM, ' ...
        'GPU VRAM and disk capacity; this trainer is not a streaming solver.\n']);
end
assert(strcmpi(RECON_MODE,'linear'),'E9B2:NoASCReconstruction', ...
    'NoASC physical prediction must use RECON_MODE=linear.');
assert(exist('binornd','file')==2,'E9B2:Binornd', ...
    ['Exact independent binomial thinning needs binornd, part of' ...
     ' the Statistics and Machine Learning Toolbox.']);
assert(any(strcmpi(THINNING_METHOD,{'gpu_chunked','cpu'})), ...
    'E9B2:ThinningMethod','THINNING_METHOD must be gpu_chunked or cpu.');
assert(isscalar(THIN_BLOCK_PIXELS) && THIN_BLOCK_PIXELS>=1 && ...
    THIN_BLOCK_PIXELS==floor(THIN_BLOCK_PIXELS), ...
    'E9B2:ThinBlock','THIN_BLOCK_PIXELS must be a positive integer.');
if strcmpi(THINNING_METHOD,'gpu_chunked')
    try
        thinGpuDevice=gpuDevice(1); %#ok<NASGU> % GPU also used by the trainer
    catch ME
        error('E9B2:ThinningGPU', ...
            ['GPU binomial thinning requires a supported GPU and Parallel ' ...
             'Computing Toolbox. Select THINNING_METHOD=''cpu'' to use the ' ...
             'original CPU implementation. Reason: %s'],ME.message);
    end
    fprintf('E9-B2 GPU binomial thinning enabled, %d pixels per block.\n', ...
        THIN_BLOCK_PIXELS);
end
assert(exist(TRAINER,'file')==2,'E9B2:Trainer', ...
    ['Cannot find FixedQTail trainer %s on MATLAB path. ' ...
     'Put deep_mvsa_invflow_poisson_explicit_Warmup2_FixedQTail.m on path.'],TRAINER);
fprintf('FixedQTail trainer: %s\n',which(TRAINER));
fprintf(['B2 model config | MM=%d | warmup=%d | band=%.4g | enclose=%.4g | ' ...
    'spatial=%.4g | eta=%.3g->%.3g | sigma_cap=%.3g | tail=%d @ %.4g\n'], ...
    OPT.MM_ITERS,OPT.WARM_UP,OPT.LAMBDA_BAND,OPT.LAMBDA_ENCLOSE, ...
    OPT.LAMBDA_SPATIAL,OPT.ETA,OPT.ETA_END,OPT.SIGMA_CAP, ...
    OPT.TAIL_ITERS,OPT.TAIL_LR);
assert(isscalar(N_REPEATS) && isfinite(N_REPEATS) && ...
    N_REPEATS==floor(N_REPEATS) && N_REPEATS>=1, ...
    'E9B2:Repeats','N_REPEATS must be a positive integer.');
assert(isscalar(TRAIN_SEEDS) && isscalar(THIN_SEEDS) && ...
    all(isfinite([TRAIN_SEEDS THIN_SEEDS])) && ...
    all([TRAIN_SEEDS THIN_SEEDS]>=0) && ...
    all([TRAIN_SEEDS THIN_SEEDS]==floor([TRAIN_SEEDS THIN_SEEDS])), ...
    'E9B2:Seeds','TRAIN_SEEDS and THIN_SEEDS must each contain one nonnegative integer.');
% MATLAB rng('twister') requires seeds in the uint32 range.
assert(TRAIN_SEEDS(1)+(N_REPEATS-1)*1001<=double(intmax('uint32')) && ...
    THIN_SEEDS(1)+(N_REPEATS*numel(DOSES))*7919<=double(intmax('uint32')), ...
    'E9B2:Seeds','Automatically generated seeds exceed the uint32 range.');
assert(all(DOSES>0 & DOSES<=1) && any(abs(DOSES-1)<1e-12), ...
    'E9B2:Doses','Doses must be in (0,1], including q=1 baseline.');
assert(all(diff(DOSES)<=0),'E9B2:Order', ...
    'Put q=1 first and the remaining doses in decreasing order.');
if ~ALLOW_UNCALIBRATED_DIGITAL_COUNT_THINNING
    error('E9B2:Calibration', ...
        'Detector calibration must be established before photon claims.');
end
warning('E9B2:NotCalibrated', ...
    ['LSM intensities are NOT verified photon counts. Results describe' ...
     ' simulated DIGITAL-COUNT thinning, NOT measured reduced laser power.']);
scriptdir=fileparts(mfilename('fullpath'));
if isempty(scriptdir),scriptdir=pwd;end
candidates={DATA_FILE,fullfile(DATA_DIR,DATA_FILE), ...
    fullfile(scriptdir,DATA_FILE),fullfile(scriptdir,DATA_DIR,DATA_FILE)};
fname='';
for ii=1:numel(candidates)
    if exist(candidates{ii},'file')==2,fname=candidates{ii};break;end
end
assert(~isempty(fname),'E9B2:LSM','Cannot locate %s.',DATA_FILE);
if ~exist(OUT_DIR,'dir'),mkdir(OUT_DIR);end

[Y0,roi_info]=e9b_read_lsm_roi(fname,Z_PLANE,CROP_HW,MAX_PIXELS);
H=roi_info.H;W=roi_info.W;
mask=e9b_signal_mask(Y0,SIGNAL_PERCENTILE);
[p,p_source]=e9b_select_p(Y0,OPT); % FIX p across dose; never reselect from each q
if any(abs(Y0(:)-round(Y0(:)))>1e-9)
    error('E9B2:Integers','Input contains noninteger intensities; cannot binomial-thin.');
end
fprintf('\n=== E9-B2 dose experiment | Z=%d | p=%d | ROI=%dx%d ===\n', ...
    Z_PLANE,p,H,W);

csvpath=fullfile(OUT_DIR,'pisco_E9_B2_dose_results.csv');
fid=fopen(csvpath,'w');assert(fid>0,'E9B2:CSV','Cannot create CSV.');
fprintf(fid,['z,dose,repeat,train_seed,thin_seed,p,p_source,H,W,' ...
    'mean_original_digital_count,mean_thinned_digital_count,train_time_s,' ...
    'n_signal_pixels,rel_frob_linear,rel_frob_affine,' ...
    'rel_frob_linear_preclip,rel_frob_joint_preclip,rel_frob_joint_postclip,' ...
    'clip_delta_tail_post_minus_pre,clip_delta_joint_post_minus_pre,' ...
    'endmember_clip_relative,tail_iters_done,tail_loss_before,tail_loss_accepted,tail_rolled_back,' ...
    'pearson_per_count,poisson_deviance_per_count,' ...
    'spectral_match_sad_deg,mean_abundance_corr,recon_mode\n']);
fclose(fid);

loss_csvpath=fullfile(OUT_DIR,'pisco_E9_B2_loss_components.csv');
fid=fopen(loss_csvpath,'w');assert(fid>0,'E9B2:LossCSV','Cannot create loss CSV.');
fprintf(fid,['z,dose,repeat,train_seed,thin_seed,stage,' ...
    'reconstruction_raw,reconstruction_weighted,' ...
    'volume_raw,volume_weighted,' ...
    'abundance_nonneg_raw,abundance_nonneg_weighted,' ...
    'equality_raw,equality_weighted,' ...
    'enclosure_raw,enclosure_weighted,' ...
    'spatial_raw,spatial_weighted,' ...
    'band_raw,band_weighted,' ...
    'endmember_nonneg_raw,endmember_nonneg_weighted,' ...
    'endmember_smooth_raw,endmember_smooth_weighted,total_weighted\n']);
fclose(fid);

nD=numel(DOSES);nR=N_REPEATS;
relL=NaN(nD,nR);relA=NaN(nD,nR);
relLpre=NaN(nD,nR);
relLjointpre=NaN(nD,nR);relLjointpost=NaN(nD,nR);
clipDeltaTail=NaN(nD,nR);clipDeltaJoint=NaN(nD,nR);
clipRel=NaN(nD,nR);
tailDone=NaN(nD,nR);tailLossBefore=NaN(nD,nR);
tailLossAccepted=NaN(nD,nR);tailRolledBack=NaN(nD,nR);
pear=NaN(nD,nR);dev=NaN(nD,nR);
sad=NaN(nD,nR);acor=NaN(nD,nR);
% Replicate 1 uses the supplied initial seed; later replicates are generated
% deterministically. All doses within one replicate share its train seed.
seedTrain=TRAIN_SEEDS(1)+(0:nR-1)*1001;

for rep=1:nR
    M_ref=[]; S_ref=[];
    for k=1:nD
        q=DOSES(k);
        train_seed=seedTrain(rep);
        % Unique and reproducible thinning seed for each (rep, dose).
        % For rep=1, this retains the original per-dose seed sequence.
        thin_seed=THIN_SEEDS(1)+((rep-1)*nD+k)*7919;
        if q==1
            Y=Y0; % original observation; no thinning or extra copy needed
            thin_time_s=0;
        else
            fprintf('B2 thinning START | rep=%d/%d | q=%.2f | method=%s\n', ...
                rep,nR,q,THINNING_METHOD);
            ticThin=tic;
            if strcmpi(THINNING_METHOD,'gpu_chunked')
                % IMPORTANT: gpuArray random numbers use an independent GPU
                % stream. Set ONCE per dose, NOT once per block; otherwise
                % blocks would reuse identical random subsequences.
                gpurng(thin_seed,'threefry');
                % Preserve the double CPU input expected by the trainer.
                Y=zeros(size(Y0),'double');
                % Single represents all integer levels <= 2^24 exactly.
                % Use double if count levels exceed that threshold.
                if max(Y0(:)) <= flintmax('single')
                    thinClass='single';
                else
                    thinClass='double';
                end
                Nthin=size(Y0,2);
                for j0=1:THIN_BLOCK_PIXELS:Nthin
                    jj=j0:min(j0+THIN_BLOCK_PIXELS-1,Nthin);
                    gTrials=gpuArray(cast(Y0(:,jj),thinClass));
                    gThinned=binornd(gTrials,cast(q,thinClass));
                    Y(:,jj)=double(gather(gThinned));
                    clear gTrials gThinned;
                end
            else
                % Original implementation. Retains original CPU random stream.
                rng(thin_seed,'twister');
                Y=double(binornd(Y0,q));
            end
            thin_time_s=toc(ticThin);
            fprintf('B2 thinning DONE  | rep=%d/%d | q=%.2f | time=%.2f s\n', ...
                rep,nR,q,thin_time_s);
        end
        rng(train_seed,'twister'); % Same CPU training seed across all doses.
        if strcmpi(THINNING_METHOD,'gpu_chunked')
            % Also reset GPU RNG before training to decouple the training
            % stream from however many GPU draws thinning just consumed.
            gpurng(train_seed,'threefry');
        end
        args=e9b_train_options(H,W,OPT);
        fprintf('\nB2 rep=%d/%d, q=%.3f, train seed=%d, thin seed=%d ...\n', ...
            rep,nR,q,train_seed,thin_seed);
        ticTrain=tic;
        % Request the trainer audit outputs used by E9-B1:
        % M_preclip, S_joint, Fixed-Q tail diagnostics and loss decomposition.
        [M_est,S_est,~,~,theta_audit]=feval(TRAINER,Y,p,args{:});
        train_time_s=toc(ticTrain);
        required_audit={'M_before_clip_bandloss_audit','S_before_tail', ...
            'tail_info','endmember_clip_relative', ...
            'loss_components_joint','loss_components_final'};
        for ia=1:numel(required_audit)
            assert(isfield(theta_audit,required_audit{ia}), ...
                'E9B2:TrainerAudit','Trainer audit is missing theta.%s. Replace the trainer with the diagnostic-instrumented FixedQTail file.', ...
                required_audit{ia});
        end
        M_preclip=theta_audit.M_before_clip_bandloss_audit;
        S_joint=theta_audit.S_before_tail;
        tail_info=theta_audit.tail_info;
        clip_relative=theta_audit.endmember_clip_relative;
        loss_components_joint=theta_audit.loss_components_joint;
        loss_components_final=theta_audit.loss_components_final;
        clear theta_audit;

        stats=e9b_residual_metrics(Y,M_est,S_est,mask,H,W,RECON_MODE,RECON_BLOCK);
        % Same-ROI, blocked reconstruction audit, exactly matching E9-B1:
        % (1) preclip M with final-tail S; (2) joint S before tail, both
        % before and after output endmember clipping.
        r_preclip=e9b_frob_only(Y,M_preclip,S_est,mask,RECON_BLOCK);
        r_joint_preclip=e9b_frob_only(Y,M_preclip,S_joint,mask,RECON_BLOCK);
        r_joint_postclip=e9b_frob_only(Y,M_est,S_joint,mask,RECON_BLOCK);
        fprintf(['[FixedQ-tail] Same ROI | joint PRECLIP %.9f | ' ...
            'joint POSTCLIP %.9f | tail PRECLIP %.9f | tail POSTCLIP %.9f\n'], ...
            r_joint_preclip,r_joint_postclip,r_preclip,stats.linear_frob);
        fprintf('[FixedQ-tail] Joint -> tail ROI SSE change = %+.4f%%\n', ...
            100*(stats.linear_frob^2/max(r_joint_postclip^2,eps)-1));
        fprintf(['[BandLoss] raw ROI PRE-CLIP=%.9f | POST-CLIP=%.9f | ' ...
            'endmember clip rel=%.5g\n'], ...
            r_preclip,stats.linear_frob,clip_relative);
        if q==1
            M_ref=M_est;S_ref=S_est;
            spectral_match_sad_deg=0;
            mean_abundance_corr=1;
            match_order=1:p;
        else
            [match_order,spectral_match_sad_deg,mean_abundance_corr]= ...
                e9b_align_baseline(M_ref,S_ref,M_est,S_est);
        end
        relL(k,rep)=stats.linear_frob;
        relA(k,rep)=stats.affine_frob;
        relLpre(k,rep)=r_preclip;
        relLjointpre(k,rep)=r_joint_preclip;
        relLjointpost(k,rep)=r_joint_postclip;
        clipDeltaTail(k,rep)=stats.linear_frob-r_preclip;
        clipDeltaJoint(k,rep)=r_joint_postclip-r_joint_preclip;
        clipRel(k,rep)=clip_relative;
        tailDone(k,rep)=tail_info.iterations_done;
        tailLossBefore(k,rep)=tail_info.loss_before;
        tailLossAccepted(k,rep)=tail_info.loss_accepted;
        tailRolledBack(k,rep)=double(tail_info.rolled_back);
        pear(k,rep)=stats.pearson_per_count;
        dev(k,rep)=stats.poisson_deviance_per_count;
        sad(k,rep)=spectral_match_sad_deg;
        acor(k,rep)=mean_abundance_corr;
        tag=sprintf('pisco_E9_B2_Z%02d_q%03d_rep%02d', ...
            Z_PLANE,round(100*q),rep);
        % Save MAT and dose-specific PNG files only during rep=1.
        % All repeats still contribute to the CSV statistics and final figures.
        if rep==1
            config=struct('dose',q,'repeat',rep,'train_seed',train_seed, ...
                'thin_seed',thin_seed,'p',p,'p_source',p_source, ...
                'z',Z_PLANE,'roi',roi_info,'QUICK',QUICK, ...
                'crop_hw',CROP_HW,'max_pixels',MAX_PIXELS,'trainer',TRAINER, ...
                'trainer_path',which(TRAINER),'input_file',fname,'options',OPT, ...
                'recon_mode',RECON_MODE, ...
                'abundance_interpretation','free NoASC mixing coefficients, NOT sum-to-one proportions', ...
                'affine_metric_note','legacy diagnostic only; NOT NoASC physical prediction', ...
                'count_calibrated',false, ...
                'interpretation','simulated uncalibrated digital-count thinning');
            data_original_cube_32HW=reshape(single(Y0),32,H,W);
            data_thinned_cube_32HW=reshape(single(Y),32,H,W);
            reconstructed_cube_32HW=reshape(stats.yhat_selected,32,H,W);
            residual_linear=stats.residual_linear;
            residual_affine=stats.residual_affine;
            roi_mask=reshape(mask,H,W);
            bandloss_diagnostic=struct('raw_roi_frob_before_clip',r_preclip, ...
                'raw_roi_frob_after_clip',stats.linear_frob, ...
                'joint_roi_frob_before_clip',r_joint_preclip, ...
                'joint_roi_frob_after_clip',r_joint_postclip, ...
                'clip_delta_tail_post_minus_pre',stats.linear_frob-r_preclip, ...
                'clip_delta_joint_post_minus_pre',r_joint_postclip-r_joint_preclip, ...
                'clip_relative',clip_relative, ...
                'note','TRAIN uses preclip M; returned M_est=max(M_preclip,0).');
            save(fullfile(OUT_DIR,[tag '_full.mat']), ...
                'Y0','Y','data_original_cube_32HW','data_thinned_cube_32HW', ...
                'reconstructed_cube_32HW','M_est','M_preclip','S_est','S_joint','roi_mask', ...
                'roi_info','mask','stats','config','match_order', ...
                'spectral_match_sad_deg','mean_abundance_corr', ...
                'residual_linear','residual_affine','train_time_s', ...
                'bandloss_diagnostic','r_preclip','r_joint_preclip', ...
                'r_joint_postclip','clip_relative','tail_info', ...
                'loss_components_joint','loss_components_final','-v7.3');
            % Dose-specific spectra + maps for direct visual stability checks.
            e9b_plot_abundances(S_est,H,W, ...
                fullfile(OUT_DIR,[tag '_abundances.png']), ...
                sprintf('E9-B2 Z=%d dose %.2f, p=%d',Z_PLANE,q,p));
            e9b_plot_spectra(410.5+(0:31)*8.9,M_est, ...
                sprintf('E9-B2 spectral estimates, q=%.2f',q), ...
                fullfile(OUT_DIR,[tag '_spectra.png']));
            e9b_plot_residual(Y,mask,stats,H,W, ...
                fullfile(OUT_DIR,[tag '_residual.png']), ...
                sprintf('E9-B2 thinned observation, Z=%d, q=%.2f',Z_PLANE,q));
        end
        fid=fopen(csvpath,'a');
        fprintf(fid,['%d,%.4f,%d,%d,%d,%d,%s,%d,%d,%.7g,%.7g,%.6f,%d,' ...
            '%.9g,%.9g,%.9g,%.9g,%.9g,%.9g,%.9g,%.9g,%d,%.9g,%.9g,%d,' ...
            '%.9g,%.9g,%.9g,%.9g,%s\n'], ...
            Z_PLANE,q,rep,train_seed,thin_seed,p,p_source,H,W, ...
            mean(Y0(:)),mean(Y(:)),train_time_s,nnz(mask), ...
            stats.linear_frob,stats.affine_frob,r_preclip, ...
            r_joint_preclip,r_joint_postclip,clipDeltaTail(k,rep), ...
            clipDeltaJoint(k,rep),clip_relative, ...
            tail_info.iterations_done,tail_info.loss_before, ...
            tail_info.loss_accepted,double(tail_info.rolled_back), ...
            stats.pearson_per_count,stats.poisson_deviance_per_count, ...
            spectral_match_sad_deg,mean_abundance_corr,RECON_MODE);
        fclose(fid);

        fid=fopen(loss_csvpath,'a');
        e9b_write_loss_component_row(fid,Z_PLANE,q,rep,train_seed,thin_seed, ...
            'joint',loss_components_joint);
        e9b_write_loss_component_row(fid,Z_PLANE,q,rep,train_seed,thin_seed, ...
            'final',loss_components_final);
        fclose(fid);

        fprintf('Completed %s | q=%.2f | postclip=%.5f | preclip=%.5f | MAT/PNG saved only for rep=1\n', ...
            tag,q,stats.linear_frob,r_preclip);
        clear M_preclip S_joint;
    end
end

% Paired replicate differences versus q=1. Repeat r at each q is paired
% with the q=1 result from the SAME replicate.
paired_post=relL-relL(1,:);
paired_pre=relLpre-relLpre(1,:);

paired_path=fullfile(OUT_DIR,'pisco_E9_B2_paired_differences.csv');
fid=fopen(paired_path,'w');assert(fid>0,'E9B2:PairedCSV','Cannot create paired CSV.');
fprintf(fid,['dose,repeat,linear_delta_vs_q1,preclip_delta_vs_q1,' ...
    'joint_preclip_delta_vs_q1,joint_postclip_delta_vs_q1\n']);
for k=1:nD
    for rep=1:nR
        fprintf(fid,'%.4f,%d,%.12g,%.12g,%.12g,%.12g\n', ...
            DOSES(k),rep,paired_post(k,rep),paired_pre(k,rep), ...
            relLjointpre(k,rep)-relLjointpre(1,rep), ...
            relLjointpost(k,rep)-relLjointpost(1,rep));
    end
end
fclose(fid);

summary_path=fullfile(OUT_DIR,'pisco_E9_B2_summary.csv');
fid=fopen(summary_path,'w');assert(fid>0,'E9B2:Summary','Cannot create summary.');
fprintf(fid,['dose,n_repeats,linear_mean,linear_std,affine_mean,affine_std,' ...
    'preclip_mean,preclip_std,joint_preclip_mean,joint_preclip_std,' ...
    'joint_postclip_mean,joint_postclip_std,clip_delta_tail_mean,clip_delta_tail_std,' ...
    'clip_delta_joint_mean,clip_delta_joint_std,clip_relative_mean,clip_relative_std,' ...
    'paired_post_mean,paired_post_std,paired_post_ci95_low,paired_post_ci95_high,' ...
    'paired_pre_mean,paired_pre_std,paired_pre_ci95_low,paired_pre_ci95_high,n_pairs,' ...
    'pearson_mean,pearson_std,deviance_mean,deviance_std,' ...
    'spectral_sad_mean_deg,spectral_sad_std_deg,abundance_corr_mean,abundance_corr_std\n']);
for k=1:nD
    [nPair,dm,ds,ciLo,ciHi]=e9b_paired_summary(paired_post(k,:));
    [~,pm,ps,pciLo,pciHi]=e9b_paired_summary(paired_pre(k,:));
    fprintf(fid,['%.4f,%d,%.9g,%.9g,%.9g,%.9g,%.9g,%.9g,' ...
        '%.9g,%.9g,%.9g,%.9g,%.9g,%.9g,' ...
        '%.9g,%.9g,%.9g,%.9g,%.9g,%.9g,%.9g,%.9g,%d,' ...
        '%.9g,%.9g,%.9g,%.9g,%.9g,%.9g,%.9g,%.9g,%.9g,%.9g,%.9g,%.9g\n'], ...
        DOSES(k),nR,mean(relL(k,:)),std(relL(k,:)), ...
        mean(relA(k,:)),std(relA(k,:)), ...
        mean(relLpre(k,:)),std(relLpre(k,:)), ...
        mean(relLjointpre(k,:)),std(relLjointpre(k,:)), ...
        mean(relLjointpost(k,:)),std(relLjointpost(k,:)), ...
        mean(clipDeltaTail(k,:)),std(clipDeltaTail(k,:)), ...
        mean(clipDeltaJoint(k,:)),std(clipDeltaJoint(k,:)), ...
        mean(clipRel(k,:)),std(clipRel(k,:)), ...
        dm,ds,ciLo,ciHi,pm,ps,pciLo,pciHi,nPair, ...
        mean(pear(k,:)),std(pear(k,:)),mean(dev(k,:)),std(dev(k,:)), ...
        mean(sad(k,:)),std(sad(k,:)),mean(acor(k,:)),std(acor(k,:)));
end
fclose(fid);

if nR<2
    warning('E9B2:CIRequiresRepeats', ...
        ['N_REPEATS=%d: paired 95%% confidence intervals are NaN. ' ...
         'Use at least 2 repeats (preferably 10 or more) for uncertainty estimates.'],nR);
end

f=figure('Visible','on','Color','w','Position',[30 30 1020 600]);
x=100*DOSES;
errorbar(x,mean(relL,2),std(relL,0,2),'-o','LineWidth',1.5);hold on;
errorbar(x,mean(relLpre,2),std(relLpre,0,2),'-d','LineWidth',1.5);
errorbar(x,mean(relA,2),std(relA,0,2),'-s','LineWidth',1.3);
grid on;xlabel('Simulated retained count fraction (%)');
ylabel('ROI relative Frobenius reconstruction residual');
legend('Linear (post-clip M; physical output)', ...
    'Linear (pre-clip M; training endmembers)', ...
    'Affine (legacy diagnostic only)','Location','best');
title('E9-B2 count thinning: dose-residual (NOT measured laser power)');
exportgraphics(f,fullfile(OUT_DIR,'pisco_E9_B2_dose_residual.png'),'Resolution',170);
drawnow; % Keep the saved summary figure visible in MATLAB.

f=figure('Visible','on','Color','w','Position',[30 30 900 560]);
errorbar(x,mean(sad,2),std(sad,0,2),'-o','LineWidth',1.5);
grid on;xlabel('Simulated retained count fraction (%)');
ylabel('Mean spectral SAD vs same-replicate q=1 estimate (deg)');
title('E9-B2 estimated endmember stability; NOT ground-truth SAD');
exportgraphics(f,fullfile(OUT_DIR,'pisco_E9_B2_spectral_stability.png'), ...
    'Resolution',170);
drawnow; % Both summary figures remain open after the script ends.

fprintf('\nE9-B2 complete. CSVs and figures saved to %s\n',OUT_DIR);


%% ========================================================================
% Local utilities. Duplicated deliberately so this .m is self contained.
% No E9-A script or additional project helper file is required.
% ========================================================================
function [Y, roi_info] = e9b_read_lsm_roi(fname, z, cropHW, max_pixels)
% Reads ONLY one Z (32 spectral bands). Native Tiff first, Bio-Formats fallback.
% Note: native Tiff.read decodes one full-resolution uint16 Z page in RAM;
% ROI is cropped before conversion to double. No full volume is loaded.
    originalH = 2048; originalW = 2560; expectedZ = 27; C = 32;
    assert(isscalar(z) && z == round(z) && z >= 1 && z <= expectedZ, ...
        'E9B:Z','Z must be an integer from 1 to %d.',expectedZ);
    assert(numel(cropHW)==2 && all(cropHW >= 0),'E9B:Crop','Bad crop size.');
    if all(cropHW == 0)
        rr = 1:originalH; cc = 1:originalW;
    else
        h = cropHW(1); w = cropHW(2);
        assert(h<=originalH && w<=originalW && h>=1 && w>=1 && ...
            h==round(h) && w==round(w),'E9B:Crop','Invalid crop size.');
        r1 = floor((originalH - h)/2) + 1;
        c1 = floor((originalW - w)/2) + 1;
        rr = r1:(r1+h-1); cc = c1:(c1+w-1);
    end
    H = numel(rr); W = numel(cc);
    assert(H*W <= max_pixels,'E9B:MemoryGuard', ...
        ['Requested %d pixels exceeds MAX_PIXELS=%d. The original trainer' ...
         ' is NOT a verified full-frame streaming solver. Increase the' ...
         ' limit only after reviewing available RAM and trainer behavior.'], ...
        H*W,max_pixels);
    roi_info = struct('z',z,'H',H,'W',W,'rows',[rr(1),rr(end)], ...
        'cols',[cc(1),cc(end)],'fullH',originalH,'fullW',originalW, ...
        'channels',C,'pixel_count',H*W,'method','');
    Y = [];
    native_error = '';
    try
        tif = Tiff(fname,'r');
        tif_close = onCleanup(@() tif.close()); %#ok<NASGU>
        dirs = e9b_fullres_dirs(tif,originalW,originalH);
        assert(numel(dirs)>=expectedZ,'E9B:Directories', ...
            'Only %d full-resolution TIFF pages; expected at least %d.', ...
            numel(dirs),expectedZ);
        tif.setDirectory(dirs(z));
        A = tif.read();
        assert(size(A,1)==originalH && size(A,2)==originalW && ...
            size(A,3)>=C,'E9B:TiffShape', ...
            'Tiff.read returned %s, expected H x W x >=32.',mat2str(size(A)));
        Y = zeros(C,H*W,'double');
        for c=1:C
            tmp = A(rr,cc,c);
            Y(c,:) = reshape(double(tmp),1,[]);
        end
        clear A;
        roi_info.method = 'MATLAB Tiff';
    catch ME
        native_error = ME.message;
        Y = [];
    end
    if isempty(Y)
        if exist('bfGetReader','file') ~= 2 || exist('bfGetPlane','file') ~= 2
            error('E9B:Reader',[...
                'Native TIFF reader failed: %s\n' ...
                'Install the MATLAB Bio-Formats package (bfGetReader and' ...
                ' bfGetPlane) or inspect this >4GB LSM image encoding.'], ...
                native_error);
        end
        fprintf(2,'Native TIFF read unavailable: %s\nTrying Bio-Formats...\n',native_error);
        br = bfGetReader(fname);
        br_close = onCleanup(@() br.close()); %#ok<NASGU>
        br.setSeries(0);
        assert(double(br.getSizeX())==originalW && double(br.getSizeY())==originalH && ...
            double(br.getSizeZ())>=expectedZ && double(br.getSizeC())>=C, ...
            'E9B:BFShape','Unexpected Bio-Formats series dimensions.');
        Y = zeros(C,H*W,'double');
        for c=1:C
            plane_id = double(br.getIndex(z-1,c-1,0))+1;
            A = bfGetPlane(br,plane_id);
            tmp = A(rr,cc);
            Y(c,:) = reshape(double(tmp),1,[]);
        end
        roi_info.method = 'Bio-Formats';
    end
    assert(isequal(size(Y),[C H*W]) && all(isfinite(Y(:))) && ...
        all(Y(:)>=0),'E9B:BadY','Invalid intensity values in imported cube.');
    fprintf('Read Z=%d by %s | %d x %d | 32 bands | count range %.5g..%.5g\n', ...
        z,roi_info.method,H,W,min(Y(:)),max(Y(:)));
end

function dirs=e9b_fullres_dirs(tif,X,Y)
% Use dimensions, never assume alternating thumbnails, never read pixels.
    dirs=[]; tif.setDirectory(1); idx=1;
    while true
        x=double(tif.getTag(Tiff.TagID.ImageWidth));
        y=double(tif.getTag(Tiff.TagID.ImageLength));
        if x==X && y==Y
            dirs(end+1)=idx; %#ok<AGROW>
        end
        if tif.lastDirectory(), break; end
        tif.nextDirectory(); idx=idx+1;
        assert(idx<10000,'E9B:IFD','Too many TIFF directories.');
    end
end

function mask=e9b_signal_mask(Y,percentile)
% Fixed ROI from ORIGINAL data, not from each thinned observation.
    brightness = sum(Y,1);
    v = sort(brightness(isfinite(brightness)));
    assert(~isempty(v),'E9B:EmptyData','All pixel intensities are invalid.');
    rank=max(1,min(numel(v),round(1+(numel(v)-1)*percentile/100)));
    threshold=v(rank);
    mask=brightness>max(0,threshold);
    if nnz(mask)<max(100,ceil(.03*numel(mask)))
        mask=brightness>0;
    end
    assert(nnz(mask)>0,'E9B:Mask','There are no illuminated pixels.');
end

function args=e9b_train_options(H,W,opt)
% Exact option mapping from demo_pisco_E9_B1_NoASC_BandLoss_FixedQTail.
% Keep NoASC (LAMBDA_SUMONE=0), BandLoss and fixed-Q terminal S refinement.
    args={'spherize','yes','verbose',0, ...
        'MM_ITERS',opt.MM_ITERS,'WARM_UP',opt.WARM_UP,'LR',3e-4, ...
        'LAMBDA_VOL',0.008,'LAMBDA_NONNEG',3,'LAMBDA_EQ',100, ...
        'LAMBDA_SUMONE',0,'LAMBDA_ENCLOSE',opt.LAMBDA_ENCLOSE, ...
        'IMG_H',H,'IMG_W',W, ...
        'LAMBDA_SPATIAL',opt.LAMBDA_SPATIAL, ...
        'LAMBDA_SMOOTH',opt.LAMBDA_SMOOTH, ...
        'LAMBDA_MNONNEG',opt.LAMBDA_MNONNEG, ...
        'NOISE_MODEL',opt.NOISE_MODEL,'NOISE_WEIGHT',opt.NOISE_WEIGHT, ...
        'PHOTON_GAIN',opt.PHOTON_GAIN,'PHOTON_FLOOR',opt.PHOTON_FLOOR, ...
        'READ_SIGMA',opt.READ_SIGMA, ...
        'ETA',opt.ETA,'ETA_END',opt.ETA_END, ...
        'LAMBDA_BAND',opt.LAMBDA_BAND, ...
        'TAIL_ITERS',opt.TAIL_ITERS,'TAIL_LR',opt.TAIL_LR, ...
        'TAIL_REPORT_EVERY',opt.TAIL_REPORT_EVERY, ...
        'TAIL_ROLLBACK_IF_WORSE',opt.TAIL_ROLLBACK_IF_WORSE};
    if opt.PASS_SIGMA_CAP
        args=[args,{'SIGMA_CAP',opt.SIGMA_CAP}];
    end
end

function [p,src]=e9b_select_p(Y,opt)
% HySime is optional. If selected, require an external implementation and
% explicitly note that the spatial-difference noise model is approximate.
    switch lower(opt.P_METHOD)
        case 'fixed'
            p=opt.P_FIXED; src='fixed';
        case 'hysime'
            assert(exist('hysime','file')==2,'E9B:HySime', ...
                ['P_METHOD=hysime needs the externally installed hysime.m.' ...
                ' Set P_METHOD=fixed if unavailable.']);
            sample_count=min(16000,size(Y,2));
            inds=unique(round(linspace(1,size(Y,2),sample_count)));
            A=Y(:,inds);
            % Approximate spatial-pair differencing, not a calibrated
            % instrument noise estimate. Use HySime as a sensitivity check.
            if mod(size(A,2),2), A=A(:,1:end-1); end
            d=(A(:,1:2:end)-A(:,2:2:end))/2;
            w=zeros(size(A)); w(:,1:2:end)=d; w(:,2:2:end)=-d;
            try
                p=hysime(A,w,0);
            catch ME
                error('E9B:HySimeAPI', ...
                    ['hysime.m must support hysime(Y,noise,verbose). ' ...
                     'Original error: %s'],ME.message);
            end
            p=double(p(1)); src='hysime_approx_spatial_noise';
            assert(isfinite(p) && p==round(p) && p>=2 && p<=size(Y,1), ...
                'E9B:HySimeP','Invalid HySime p=%g.',p);
        otherwise
            error('E9B:PMethod','P_METHOD must be fixed or hysime.');
    end
end

function r=e9b_frob_only(Y,M,S,mask,block)
% Blocked ROI-only relative Frobenius residual for a specified M,S pair.
% No full 32xN reconstruction cube is allocated.
    assert(size(Y,1)==size(M,1) && size(M,2)==size(S,1) && ...
        size(Y,2)==size(S,2),'E9B2:FrobShape','M,S,Y sizes mismatch.');
    acc=0;den=0;N=size(Y,2);
    for idx=1:block:N
        j=idx:min(idx+block-1,N);
        msk=logical(mask(j));
        if ~any(msk),continue;end
        obs=double(Y(:,j(msk)));
        pred=double(M)*double(S(:,j(msk)));
        d=obs-pred;
        acc=acc+sum(d(:).^2);
        den=den+sum(obs(:).^2);
    end
    r=sqrt(acc/max(den,eps));
end

function e9b_write_loss_component_row(fid,z,q,rep,trainSeed,thinSeed,stage,parts)
% Write raw component values and the weighted contribution to the objective.
    names={'reconstruction_raw','reconstruction_weighted', ...
        'volume_raw','volume_weighted', ...
        'abundance_nonneg_raw','abundance_nonneg_weighted', ...
        'equality_raw','equality_weighted', ...
        'enclosure_raw','enclosure_weighted', ...
        'spatial_raw','spatial_weighted', ...
        'band_raw','band_weighted', ...
        'endmember_nonneg_raw','endmember_nonneg_weighted', ...
        'endmember_smooth_raw','endmember_smooth_weighted','total_weighted'};
    fprintf(fid,'%d,%.4f,%d,%d,%d,%s',z,q,rep,trainSeed,thinSeed,stage);
    for ii=1:numel(names)
        assert(isfield(parts,names{ii}),'E9B2:LossPart', ...
            'Missing loss component %s in trainer output.',names{ii});
        fprintf(fid,',%.12g',parts.(names{ii}));
    end
    fprintf(fid,'\n');
end

function [n,mu,sd,ciLo,ciHi]=e9b_paired_summary(delta)
% Paired mean and two-sided 95% Student-t CI; no CI is claimed for n<2.
    d=double(delta(isfinite(delta)));
    n=numel(d);
    if n==0
        mu=NaN;sd=NaN;ciLo=NaN;ciHi=NaN;
    elseif n==1
        mu=d(1);sd=NaN;ciLo=NaN;ciHi=NaN;
    else
        mu=mean(d);
        sd=std(d,0);
        half=tinv(0.975,n-1)*sd/sqrt(n);
        ciLo=mu-half;ciHi=mu+half;
    end
end

function stats=e9b_residual_metrics(Y,M,S,mask,H,W,mode,block)
% Two candidate reconstructions are reported side-by-side:
% 1. linear: M*S
% 2. affine: M*S - my*(sum(S)-1), my=mean(Y,2).
% The affine form is ONLY justified if the PISCO trainer returns columns
% shifted by this exact my vector. Inspect trainer internals before citing.
% No dark-pixel-dominated mean of per-pixel ratios is used as headline.
    assert(size(Y,1)==size(M,1) && size(M,2)==size(S,1) && ...
        size(Y,2)==size(S,2),'E9B:ModelShape','M,S,Y sizes mismatch.');
    assert(nnz(mask)>0,'E9B:Mask','Empty ROI.');
    n=size(Y,2); p=size(M,2); %#ok<NASGU>
    my=mean(Y,2);
    normY=0; slin=0; saff=0;
    dev=0; pear=0; nz=0;
    map_lin=NaN(1,n,'single');
    map_aff=NaN(1,n,'single');
    % Reconstructed spectral cube is saved, not just a picture.
    yhat=zeros(size(Y),'single');
    for idx=1:block:n
        j=idx:min(idx+block-1,n);
        obs=Y(:,j);
        pred_lin=M*S(:,j);
        pred_aff=pred_lin-my*(sum(S(:,j),1)-1);
        elin=obs-pred_lin;
        eaff=obs-pred_aff;
        denom=sqrt(sum(obs.^2,1));
        msk=mask(j);
        map_lin(j)=single(sqrt(sum(elin.^2,1))./max(denom,1));
        map_aff(j)=single(sqrt(sum(eaff.^2,1))./max(denom,1));
        normY=normY+sum(sum(obs(:,msk).^2));
        slin=slin+sum(sum(elin(:,msk).^2));
        saff=saff+sum(sum(eaff(:,msk).^2));
        if strcmpi(mode,'affine_mean')
            pred=pred_aff;
        elseif strcmpi(mode,'linear')
            pred=pred_lin;
        else
            error('E9B:ReconMode','Select linear or affine_mean.');
        end
        yhat(:,j)=single(pred);
        mu=max(pred(:,msk),1e-8); yy=obs(:,msk);
        pear=pear+sum(sum((yy-mu).^2./mu));
        r=mu-yy;
        ispos=yy>0;
        r(ispos)=r(ispos)+yy(ispos).*log(yy(ispos)./mu(ispos));
        dev=dev+2*sum(r(:));
        nz=nz+numel(yy);
    end
    stats=struct();
    stats.linear_frob=sqrt(slin/max(normY,eps));
    stats.affine_frob=sqrt(saff/max(normY,eps));
    stats.pearson_per_count=pear/max(nz,1);
    stats.poisson_deviance_per_count=dev/max(nz,1);
    stats.n_signal_pixels=nnz(mask);
    stats.residual_linear=reshape(map_lin,H,W);
    stats.residual_affine=reshape(map_aff,H,W);
    stats.yhat_selected=yhat;
    stats.my_used=my;
    if strcmpi(mode,'affine_mean'),stats.selected_frob=stats.affine_frob;
    else,stats.selected_frob=stats.linear_frob;end
    stats.recon_mode=mode;
    fprintf('ROI Frobenius residual linear=%.5f | affine=%.5f | used=%s\n', ...
        stats.linear_frob,stats.affine_frob,mode);
end

function e9b_plot_spectra(wavelengths,M,t,filename)
    p=size(M,2); f=figure('Color','w','Visible','off', ...
        'Position',[60 60 1020 650]);
    scale=max(abs(M),[],1); scale(scale==0)=1;
    plot(wavelengths,M./scale,'LineWidth',1.2);
    grid on;xlabel('Wavelength (nm)');ylabel('Endmember (max-abs-normalized)');
    title(t,'Interpreter','none');
    legend(arrayfun(@(j)sprintf('EM%02d',j),1:p,'UniformOutput',false), ...
        'Location','eastoutside');
    exportgraphics(f,filename,'Resolution',160);close(f);
end

function e9b_plot_abundances(S,H,W,filename,t)
    p=size(S,1); cols=4; rows=ceil((p+2)/cols);
    f=figure('Color','w','Visible','off','Position',[30 30 1600 320*rows]);
    for i=1:p
        subplot(rows,cols,i);
        imagesc(reshape(S(i,:),H,W));axis image off;colorbar;
        title(sprintf('EM%02d abundance',i));
    end
    subplot(rows,cols,p+1);
    imagesc(reshape(sum(max(S,0),1),H,W));axis image off;colorbar;
    title('Sum of nonnegative abundances');
    sgtitle(t,'Interpreter','none');
    exportgraphics(f,filename,'Resolution',140);close(f);
end

function e9b_plot_residual(Y,mask,stats,H,W,filename,t)
    sumim=reshape(sum(Y,1),H,W);
    a=stats.residual_linear; b=stats.residual_affine;
    a(~reshape(mask,H,W))=NaN;b(~reshape(mask,H,W))=NaN;
    f=figure('Color','w','Visible','off','Position',[30 30 1500 520]);
    subplot(1,3,1); imagesc(log1p(sumim));axis image off;colorbar;
    title('log(1 + original intensity)');
    subplot(1,3,2);imagesc(a);axis image off;colorbar;
    title(sprintf('Linear residual (ROI Frobenius %.4f)',stats.linear_frob));
    subplot(1,3,3);imagesc(b);axis image off;colorbar;
    title(sprintf('Affine residual (ROI Frobenius %.4f)',stats.affine_frob));
    sgtitle(t,'Interpreter','none');
    exportgraphics(f,filename,'Resolution',140);close(f);
end

function [ord,sadmean,abundCorr]=e9b_align_baseline(M0,S0,M1,S1)
% Greedy spectral matching; SAD is BETWEEN ESTIMATES, not ground-truth SAD.
    p=size(M0,2); assert(size(M1,2)==p,'E9B:EndmemberCount','p changed.');
    aa=M0./max(sqrt(sum(M0.^2,1)),eps);
    bb=M1./max(sqrt(sum(M1.^2,1)),eps);
    costs=acos(max(-1,min(1,aa'*bb)))*180/pi;
    ord=zeros(1,p);used=false(1,p);
    for i=1:p
        row=costs(i,:);row(used)=Inf;
        [~,j]=min(row);ord(i)=j;used(j)=true;
    end
    sadmean=mean(arrayfun(@(i)costs(i,ord(i)),1:p));
    % Abundance scaling is generally not identifiable without calibration;
    % Pearson correlation is invariant to positive per-endmember scaling.
    corrs=NaN(1,p);
    for i=1:p
        a=double(S0(i,:));b=double(S1(ord(i),:));
        a=a-mean(a);b=b-mean(b);
        den=sqrt(sum(a.^2)*sum(b.^2));
        if den>1e-12,corrs(i)=sum(a.*b)/den;end
    end
    tmp=corrs(isfinite(corrs));
    if isempty(tmp),abundCorr=NaN;else,abundCorr=mean(tmp);end
end


function composition=e9b_abundance_composition(S,mask)
% Row i: fractional *estimated* abundance mass of EM_j among high-EM_i
% pixels. This is only a spatial co-occurrence proxy; it has NO ground truth.
    p=size(S,1); A=max(S,0); composition=NaN(p,p);
    for i=1:p
        v=sort(A(i,mask));
        if isempty(v),continue;end
        threshold=v(max(1,min(numel(v),round(.80*numel(v)))));
        sel=(A(i,:)>threshold) & mask;
        if ~any(sel),continue;end
        masses=sum(A(:,sel),2); tot=sum(masses);
        if tot>0,composition(i,:)=masses(:).'/tot;end
    end
end

function e9b_plot_composition(C,filename,t)
    p=size(C,1); f=figure('Visible','off','Color','w', ...
        'Position',[50 50 850 700]);
    imagesc(C,[0 1]); axis image; colorbar;
    set(gca,'XTick',1:p,'YTick',1:p);
    xlabel('Estimated EM j');ylabel('Top-abundance ROI of estimated EM i');
    title(t,'Interpreter','none');
    exportgraphics(f,filename,'Resolution',150);close(f);
end
