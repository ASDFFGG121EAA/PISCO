function [M_est, Sest, Up, my, theta] = deep_mvsa_invflow_poisson_explicit_Warmup2_ScaleAudit(Y, p, varargin)
% E9-B2 SCALE-AUDIT CLONE. Original FixedQTail trainer is NOT modified.
% E9-B1 / PISCO BandLoss + terminal fixed-Q abundance refinement.
% SCALE_PRIOR_MODE=legacy reproduces the original objective.
% SCALE_PRIOR_MODE=reference_scaled changes ONLY the two original-band
% quadratic endmember priors, via multiplier (I_ref/I_current)^2.
% Identical q=1 loss/gradients under both modes when I_ref=I_current.
% This is an ABLATION (not a validated scientific correction).

% First MM_ITERS: original warm-up and joint Q/S Adam training UNCHANGED.
% Then TAIL_ITERS additional S-only Adam steps with Q fixed EXACTLY.
% Tail objective is the same S-dependent objective: work reconstruction,
% original-band BandLoss, soft nonnegativity, and existing spatial penalty.
% Q-only volume, equality, enclosure and endmember priors are constant and
% need no gradients in the fixed-Q stage. No NNLS and no ASC imposed.
% S_before_tail is returned as single precision audit in theta; Sest is final.
% E9-B1 / PISCO BandLoss experiment (2026-10-30)
% EXACT NEW MECHANISM: add optional original-32-band relative reconstruction
% loss, without producing a 32 x N prediction during the training loop.
% Setting LAMBDA_BAND=0 reproduces the original loss and gradients.
% No changes to Q parameterization, Adam, Warm-up, Poisson enclosure, NoASC,
% endmember priors or spatial regularization. Original trainer left untouched.
% 32-band MSE uses the PRE-CLIP band-space endmembers during optimization.
% Return-only endmember clipping is audited separately by the driver.
% Diagnostic instrumentation records final joint/final-tail loss components;
% it does not change the training objective, gradients, or optimizer updates.
% Original reference model: E9-B1 / PISCO MINIMAL NoASC VARIANT (2026-10-26)
% Derived from the supplied, independently preserved Warmup2 paper model.
% NO abundance sum-to-one loss or projection is used. Sest holds
% UNNORMALIZED spectral coefficients A (not fractions); sum(A(:,j)) is free.
% Abundance NONNEGATIVITY is the ORIGINAL SOFT penalty, not a hard projection.
% The last working coordinate is pixel-integrated intensity relative to the
% mean, rather than the legacy constant 1. The existing Q equality is RETAINED
% with qm=sqrt(p)*e_p' so it anchors endmember SCALE; then ideally
% sum(A(:,j)) ~= sum(Y(:,j))/mean(sum(Y,1)), NOT 1 for every pixel.
% The original (p x p) Q, geometric volume, optimizer, warm-up, noise choices,
% function outputs, and plotting/MAT/CSV interfaces are preserved.
% One new validation caveat: this is a DIFFERENT objective and geometry from
% the published ASC model; previous published experiments remain legacy runs.
%
%% DeepMVSA-InvFlow-Poisson: Invertible Coupled Q + Nonlinear Attention
%  + Spatial Smoothness + POISSON CHANCE CONSTRAINTS
%
% Q = L * Q0 * R, L: unit lower-tri, R: upper-tri with positive diagonal.
% EXPLICIT ABUNDANCE VERSION:
%   E3d warm-up from pisco_e3_train_b1_15: freeze Q and its Adam moments,
%   pretrain the per-pixel abundances, then gradually release Q with a
%   separate Adam clock and an explicit Q learning-rate ramp.
%   The abundance matrix is optimized directly as theta.S_explicit (p x N),
%   initialized from nonnegative Q0*Y_work with per-pixel signal scaling.
%   This follows the ABUNDANCE_MODE='explicit'
%   arm used in the PISCO E3 trainer: all reconstruction, non-negativity,
%   spatial losses are retained, but the explicit ASC loss is REMOVED.
%   The below version history describes the LEGACY parent trainer.
%
% NEW relative to deep_mvsa_invflow.m (Gaussian version):
%   NOISE_MODEL  : 'gaussian' (default, identical to original) or 'poisson'.
%   Under 'poisson', the noise variance is intensity-dependent. Y may be in
%   any intensity unit; PHOTON_GAIN converts it to counts:
%       counts = Y * PHOTON_GAIN,  Var_counts = counts
%       => Var(Y) = max(Y, PHOTON_FLOOR/PHOTON_GAIN) / PHOTON_GAIN
%   Propagated to the working space (B = whitening/projection operator):
%       Vpix      = (B.^2) * Var(Y)                p x N, per-pixel noise var
%       sigma2_ij = (Q.^2) * Vpix                  q_i' Cov_j q_i,  p x N
%   and the chance-constraint margin becomes pixel-adaptive:
%       margin_ij = Phi^{-1}(ETA) * min(sqrt(sigma2_ij), SIGMA_CAP)  <= 0
%   (stop-gradient).  Two terms change:
%     (1) reconstruction  -> heteroscedastic GLS:  diff^2 ./ Vpix, with the
%         weights normalized to mean 1 so the global loss balance (and all
%         lambda settings) matches the Gaussian model;
%     (2) enclosure       -> min(Q*Y - margin, 0)^2  (RMVSA-style noise-
%         tolerant data enclosure: noisy pixels may poke outside the
%         simplex, bright pixels may not).
%   Abundance NON-NEGATIVITY uses the original penalty min(A_eff,0)^2
%   (soft constraint; not a hard projection). The noise margin does not
%   relax this penalty. Legacy description otherwise retained.
%   sigma2 is recomputed every iteration from the current Q and treated as
%   constant in the gradient (EM-style), so all gradients remain closed form.
%   ETA          : chance-constraint level (default 0.1; 0.5 = hard MVSA).
%   SIGMA_CAP    : cap on the per-pixel margin scale (default 0.1, in
%                  spherized working units). Prevents nearly-constraint-free
%                  behaviour at very low photon counts.
%   PHOTON_GAIN  : counts per unit of Y (default 1, i.e. Y is counts).
%                  Set it so both models can be compared on the SAME input
%                  scaling (see demo_pisco_vs_deeprmvsa.m).
%   PHOTON_FLOOR : variance floor in photon counts (default 1).
%
% v0.9 (2026-09-22):
%   - SPECTRAL SMOOTHNESS PRIOR (LAMBDA_SMOOTH, default 0.1; 0 = off):
%     2nd-difference Tikhonov penalty on the BAND-SPACE endmembers,
%     LAMBDA_SMOOTH*sum((M_band(3:end,:)-2*M_band(2:end-1,:)+M_band(1:end-2,:)).^2),
%     gradient chained through M = inv(Q) like LAMBDA_MNONNEG. Fluorescence
%     emission spectra are smooth on the ~9 nm channel grid, so this
%     suppresses the spurious narrow peaks/dips that shot noise imprints
%     on the recovered spectra without shifting the true (broad) peaks.
%     Also added to deep_mvsa_invflow.m (fair comparison).
%
% v0.8 (2026-09-21):
%   - MARGIN ANNEALING (ETA_END, default 0.5): the chance level eta is
%     linearly annealed from ETA to ETA_END over the joint phase, so the
%     enclosure margin Phi^{-1}(eta_t)*min(sigma,sigma_cap) decays to zero
%     at convergence. Rationale: in the capped regime the margin is a
%     CONSTANT inward relaxation of the enclosure (verified: sigma > cap
%     for 100% of pixels at all photon levels), which the volume term
%     exploits to pull the simplex inside the data cloud -- a systematic
%     bias that dominates once shot noise becomes small (high photon
%     budgets). Annealing removes the bias asymptotically while retaining
%     the noise tolerance during the critical simplex-formation phase.
%     Monte-Carlo verification (v0.9, self-contained Python package, 6
%     paired repeats, 96x96, real FP spectra): at 100 photons the annealed
%     margin beats the FIXED margin in 6/6 paired draws (mean SAD 7.25 vs
%     7.94 deg) and beats the Gaussian backbone in 6/6 paired draws (7.25
%     vs 7.71 deg, sign test p~0.03); neutral at 5-20 photons.
%     Set ETA_END = ETA to reproduce v0.7 behaviour.
%   - ENDMEMBER NON-NEGATIVITY (LAMBDA_MNONNEG, default 10): fluorescence
%     emission spectra are physically non-negative. Soft penalty
%     LAMBDA_MNONNEG*sum(min(M_band,0).^2) inside the objective (gradient
%     chained through M = inv(Q)), plus a final projection
%     M_est = max(M_est,0) on the returned endmembers. At 5 photons the
%     projection alone recovers ~2 deg SAD in bad-noise draws.
%   - Both mechanisms also added to deep_mvsa_invflow.m (fair comparison).
%
% v0.7 (2026-09-21):
%   - READ_SIGMA (default 0): Gaussian read-out noise in photon-count units,
%     added to the variance model Var(Y) = max(Y, floor/gain)/gain +
%     (READ_SIGMA/gain)^2, so the Poisson chance constraints remain
%     calibrated under the mixed Poisson + read-out noise of real detectors
%     (sCMOS/PMT analogue mode). Also honoured by NOISE_WEIGHT 'irls'.
%
% v0.6 (2026-09-21):
%   - SPATIAL TERM NORMALIZATION FIX (both algorithm files): the Laplacian
%     penalty was a SUM over ~2N neighbour pairs while reconstruction is a
%     MEAN, so the effective smoothing grew with N and compressed the
%     abundance range towards 1/p with over-smoothed maps. The penalty and
%     its gradient are now divided by N; use LAMBDA_SPATIAL ~ 20.
%   - NOISE_WEIGHT (default 'uniform'): after signal-covariance whitening,
%     the working-space noise is only weakly heteroscedastic, and uniform
%     weighting keeps the min-volume geometry anchored by all pixels; the
%     Poisson adaptation is carried by the (capped) enclosure margins.
%     'pearson' = v0.5 plug-in GLS; 'irls' = GLS with variances recomputed
%     from the current reconstruction every iteration (stop-grad), which
%     removes the Pearson plug-in noise feedback. Use 'pearson'/'irls' for
%     data with a large intensity dynamic range.
%   - SIGMA_CAP default tightened 0.1 -> 0.03: with a soft quadratic
%     enclosure penalty, noise excursions are already tolerated smoothly;
%     a wide extra margin double-counts the tolerance and lets the volume
%     term pull the simplex inside the data cloud (SAD degrades ~2 deg).
%   Verified (Python replica of the full pipeline, paired noise draws):
%   uniform+cap0.03 ties Deep RMVSA within ~0.1-0.8 deg SAD at matched MSE,
%   while every wider-margin or plug-in-weight variant trails by 1-2 deg.
%
% v0.5 (2026-09-21):
%   - FIX (critical): the affine working dimension carries no shot noise
%     (B(p,:) = 0), so Vpix(p,:) was exactly zero and its GLS weight
%     1/(0+eps) ~ 1e12 dominated the entire objective -- the network only
%     learned to fit the constant dimension, producing near-uniform
%     abundance maps with high-frequency stripe artifacts and oscillating
%     endmember spectra. The zero/too-small variances are now replaced by
%     the median variance (floor at 1e-3 x median).
%   - FIX: GLS weights normalized to mean 1 (keeps the loss scale, and
%     therefore every lambda, comparable to the Gaussian model; stops
%     dim-pixel noise from dominating the reconstruction).
%   - FIX: chance-constraint margin moved off the abundance non-negativity
%     (now strict, as in the Gaussian model) onto the data-enclosure term
%     only, and capped by SIGMA_CAP. Relaxing a physically exact
%     constraint (A >= 0) biased the solution; noise tolerance is only
%     statistically justified on the data enclosure.
%   Verified against a Python replica of the full pipeline: with these
%   fixes PISCO matches Deep RMVSA in endmember SAD and improves abundance
%   MSE at low photon budgets, and the stripe/oscillation artifacts vanish.
%
% v0.4 (2026-09-21):
%   - PHOTON_GAIN added (fixes the scale mismatch when comparing against
%     the Gaussian model on identically scaled inputs).
%   - FOURIER FEATURE encoding of coordinates (NeRF-style), new parameter
%     FF_K (default 6; 0 = off). Fixes INR spectral bias: plain (gx,gy)
%     inputs let the A-Net learn only smooth low-frequency abundance maps.
%   - Weight init scale raised 0.01 -> 0.05.
%
% Optional terms (unchanged):
%   LAMBDA_ENCLOSE : data-enclosure penalty (synthetic data: set 10).
%   LAMBDA_SPATIAL : 4-neighbour grid Laplacian on abundance maps.
%   IMG_H / IMG_W  : scene dimensions for 2-D coordinates and spatial term.
%
% GPU support (RTX 4060 Ti / MATLAB Parallel Computing Toolbox):
%   USE_GPU       : true (default) for GPU warm-up and joint training;
%                   false reproduces the original CPU execution path.
%   GPU_PRECISION : 'single' (default, fast on consumer NVIDIA GPUs), or
%                   'double' (closer to CPU double precision, generally slower).
%   GPU_DEVICE    : positive GPU device index (default 1).
% PCA/whitening and external VCA remain on CPU. Training matrices, explicit
% abundances, loss gradients, spatial regularization and Adam states are kept
% on the GPU; M_est, Sest, Up, my, theta are returned as ordinary CPU doubles
% when Y is double. The model equations and objective weights are unchanged.
% This does NOT implement minibatching or allocate shared/system GPU memory.

pStruct = inputParser;
addParameter(pStruct, 'MM_ITERS', 2500, @isnumeric);
addParameter(pStruct, 'WARM_UP', 600, ...
    @(x) isnumeric(x) && isscalar(x) && isfinite(x) && x >= 0 && mod(x,1) == 0);
% E3d warm-up transition controls (active only when WARM_UP > 0).
addParameter(pStruct, 'WARMUP_Q_RELEASE', 100, ...
    @(x) isnumeric(x) && isscalar(x) && isfinite(x) && x >= 0 && mod(x,1) == 0);
addParameter(pStruct, 'WARMUP_Q_MIN_LR_RATIO', 0.25, ...
    @(x) isnumeric(x) && isscalar(x) && isfinite(x) && x > 0 && x <= 1);
% Accepted for interface compatibility with pisco_e3_train_b1_15;
% no gate network exists in this explicit-abundance implementation.
addParameter(pStruct, 'WARMUP_GATE_RELEASE', 150, ...
    @(x) isnumeric(x) && isscalar(x) && isfinite(x) && x >= 0 && mod(x,1) == 0);
addParameter(pStruct, 'LR', 3e-4, @isnumeric);
addParameter(pStruct, 'LAMBDA_VOL', 0.005, @isnumeric);
addParameter(pStruct, 'LAMBDA_NONNEG', 3, @isnumeric);
addParameter(pStruct, 'LAMBDA_EQ', 80, @isnumeric);
addParameter(pStruct, 'LAMBDA_SUMONE', 0, @isnumeric); % accepted for old callers; IGNORED here
addParameter(pStruct, 'LAMBDA_ENCLOSE', 0, @isnumeric);   % enclosure term (synthetic data)
addParameter(pStruct, 'LAMBDA_SPATIAL', 0, @isnumeric);   % spatial smoothness (image data)
addParameter(pStruct, 'IMG_H', [], @isnumeric);           % scene height  (rows)
addParameter(pStruct, 'IMG_W', [], @isnumeric);           % scene width   (cols)
addParameter(pStruct, 'M0', [], @isnumeric);
addParameter(pStruct, 'spherize', 'yes', @ischar);
addParameter(pStruct, 'verbose', 1, @isnumeric);
addParameter(pStruct, 'NOISE_MODEL', 'gaussian', @ischar);% 'gaussian' | 'poisson'
addParameter(pStruct, 'NOISE_WEIGHT', 'uniform', @ischar); % 'uniform' | 'pearson' | 'irls' <<< NEW v0.6
addParameter(pStruct, 'ETA', 0.3, @isnumeric);            % chance level
addParameter(pStruct, 'ETA_END', 0.3, @isnumeric);        % annealed chance level (0.5 = margin -> 0) <<< NEW v0.8
addParameter(pStruct, 'LAMBDA_MNONNEG', 10, @isnumeric);  % endmember non-negativity (band space) <<< NEW v0.8
addParameter(pStruct, 'LAMBDA_BAND', 0, ...
    @(x) isnumeric(x) && isscalar(x) && isfinite(x) && x >= 0);  % NEW: raw L-band relative Frobenius^2
% New terminal S-only stage; zero restores the original BandLoss trainer.
addParameter(pStruct, 'TAIL_ITERS', 400, ...
    @(x) isnumeric(x) && isscalar(x) && isfinite(x) && x >= 0 && x == fix(x));
addParameter(pStruct, 'TAIL_LR', 3e-4, ...
    @(x) isnumeric(x) && isscalar(x) && isfinite(x) && x > 0);
addParameter(pStruct, 'TAIL_REPORT_EVERY', 100, ...
    @(x) isnumeric(x) && isscalar(x) && x >= 1 && x == fix(x));
addParameter(pStruct, 'TAIL_ROLLBACK_IF_WORSE', true, ...
    @(x) (islogical(x) || isnumeric(x)) && isscalar(x));
addParameter(pStruct,'SCALE_PRIOR_MODE','legacy', ...
    @(x) (ischar(x)||isstring(x)) && ...
    any(strcmpi(char(x),{'legacy','reference_scaled'})));
addParameter(pStruct,'SCALE_PRIOR_REFERENCE_INTENSITY',[], ...
    @(x) isempty(x) || (isnumeric(x) && isscalar(x) && ...
    isfinite(x) && x>0));
addParameter(pStruct, 'LAMBDA_SMOOTH', 0.1, @isnumeric);  % spectral smoothness, 2nd-diff Tikhonov on M (0 = off) <<< NEW v0.9
addParameter(pStruct, 'SIGMA_CAP', 0.15, @isnumeric);      %0.03 margin cap (working units; 0.03 in v0.6)
addParameter(pStruct, 'PHOTON_GAIN', 1, @isnumeric);      % counts per unit of Y  <<< NEW v0.4
addParameter(pStruct, 'PHOTON_FLOOR', 1, @isnumeric);
addParameter(pStruct, 'READ_SIGMA', 0, @isnumeric);        % Gaussian read-out noise, in COUNTS (v0.7)     % count variance floor
addParameter(pStruct, 'FF_K', 6, @isnumeric);             % retained for API compatibility; unused in explicit mode
addParameter(pStruct, 'USE_GPU', true, @(x) (islogical(x) || isnumeric(x)) && isscalar(x));
addParameter(pStruct, 'GPU_PRECISION', 'single', ...
    @(x) (ischar(x) || (isstring(x) && isscalar(x))) && ...
         any(strcmpi(char(x), {'single', 'double'})));
addParameter(pStruct, 'GPU_DEVICE', 1, ...
    @(x) isnumeric(x) && isscalar(x) && isfinite(x) && x >= 1 && x == fix(x));
parse(pStruct, varargin{:});
if pStruct.Results.LAMBDA_SUMONE ~= 0
    warning('PISCO:NoASCSumoneIgnored', ...
        'LAMBDA_SUMONE is ignored: NoASC model does not impose sum(A)=1.');
end

use_gpu = logical(pStruct.Results.USE_GPU);
gpu_precision = lower(char(pStruct.Results.GPU_PRECISION));
if use_gpu
    try
        % Request an actual MATLAB CUDA device; do not silently fall back.
        gdev = gpuDevice(pStruct.Results.GPU_DEVICE);
    catch gpuErr
        error('PISCO:GPUUnavailable', ...
            ['USE_GPU=true requires a supported NVIDIA CUDA GPU and ' ...
             'Parallel Computing Toolbox. Run gpuDevice in MATLAB. ' ...
             'To use CPU, pass ''USE_GPU'',false. GPU error: %s'], gpuErr.message);
    end
    if pStruct.Results.verbose
        fprintf('PISCO GPU: %s | precision: %s | available %.2f GiB\n', ...
            gdev.Name, gpu_precision, double(gdev.AvailableMemory)/2^30);
    end
end

[L, N] = size(Y);
if pStruct.Results.WARM_UP >= pStruct.Results.MM_ITERS && pStruct.Results.WARM_UP > 0
    error('WARM_UP must be strictly smaller than MM_ITERS.');
end

%% --------------------- Minimal non-ASC linear working transform ---------
% Legacy: project centered Y and append constant 1/sqrt(p). This forces an
% (implicit) ASC. NoASC: preserve the same p-dimensional invertible-Q model,
% but replace the constant by an OBSERVED, varying pixel intensity coordinate.
% Work-space encoding is LINEAR: Y_work = B*Y, which matters for Poisson GLS.
my = mean(Y,2);
intensity_ref = sum(my);  % units = 32-band integrated digital intensity
if ~(isfinite(intensity_ref) && intensity_ref > 0)
    error('PISCO:NoASCIntensity','Mean integrated intensity must be positive.');
end
% Fixed reference intensity is taken from the SAME q=1 original image.
% For q-scaled data, this multiplier is exactly 1/q^2.  Since it is
% computed once from INPUT data, it is constant during differentiation.
scale_prior_mode=lower(char(pStruct.Results.SCALE_PRIOR_MODE));
scale_prior_reference=pStruct.Results.SCALE_PRIOR_REFERENCE_INTENSITY;
if strcmp(scale_prior_mode,'reference_scaled')
    assert(~isempty(scale_prior_reference), ...
       'PISCO:ScaleAuditReference', ...
       'reference_scaled mode requires q=1 reference intensity.');
    spectral_prior_factor=(scale_prior_reference/intensity_ref)^2;
else
    spectral_prior_factor=1;
    if isempty(scale_prior_reference)
        scale_prior_reference=intensity_ref;
    end
end
assert(isfinite(spectral_prior_factor) && spectral_prior_factor>0, ...
    'PISCO:ScaleAuditFactor','Invalid prior intensity scale factor.');
fprintf('[ScaleAudit] prior=%s | current intensity=%.9g | q1 reference=%.9g | spectral multiplier=%.9g\\n', ...
    scale_prior_mode,intensity_ref,scale_prior_reference,spectral_prior_factor);
pixel_scale = sum(Y,1)/intensity_ref;  % 1 x N; intentionally NOT constant 1
Yc = Y - my*pixel_scale;             % every column integrates to zero
[Up_sub, D] = svds(Yc*Yc'/N, p-1);
% Retain the same Up return dimensionality as the legacy model.
my_ortho = my - Up_sub*(Up_sub'*my);
if norm(my_ortho)>1e-10*max(norm(my),1)
    Up=[Up_sub,my_ortho/norm(my_ortho)];
else
    [Uall,~,~]=svd([Up_sub,my],'econ');
    Up=Uall(:,1:p);
end
if strcmp(pStruct.Results.spherize, 'yes')
    lambda_reg = 1e-10;
    whiten_scale = sqrt(diag(D+lambda_reg*eye(p-1)));
    C = diag(1./whiten_scale);
else
    lambda_reg = 0;
    whiten_scale = ones(p-1,1);
    C = eye(p-1);
end
Y_work = [C*Up_sub'*Yc; pixel_scale]/sqrt(p);

%% ---------- NEW: exact original-band loss, compact p-dimensional form ----
% Define F=sqrt(p)*[Up_sub*diag(whiten_scale), my], so band M(F)=F*inv(Q).
% Y_work is the actual transformed observation. E=Y-F*Y_work satisfies
% Up_sub'*E=0. Therefore F'*E=[0;...;0;r_last] exactly, with
% r_last=sqrt(p)*my'*Y - (F'*F)(p,:)*Y_work.
% For d=inv(Q)*S-Y_work:
%   ||Y-F*inv(Q)*S||_F^2 = ||E||^2 + sum(d.*(K*d),'all')
%                             - 2*sum(d(p,:).*r_last), K=F'*F.
% The constant ||E||^2 is included in the LOSS, not its gradient.
% Crucially r_last need not be zero: the lift F is not orthonormal.
% Only K (p*p), r_last (1*N) and scalars persist on GPU. NO 32*N GPU cube.
band_ctx = [];
if pStruct.Results.LAMBDA_BAND > 0
    F_band = sqrt(p) * [bsxfun(@times,Up_sub,whiten_scale(:).'),my];
    K_band = F_band' * F_band;
    K_band = (K_band+K_band')/2;
    r_last_band = sqrt(p)*(my'*Y) - K_band(p,:)*Y_work;
    raw_norm2_band = norm(Y,'fro')^2;
    assert(isfinite(raw_norm2_band) && raw_norm2_band>0, ...
        'PISCO:BandLossNorm','Original spectral cube has zero/invalid energy.');
    % Use small p*p covariance, NOT a temporary p*N Gram multiplication.
    work_cov = Y_work*Y_work';
    fywork_norm2 = sum(sum(K_band.*work_cov'));
    e_norm2_band = raw_norm2_band - fywork_norm2 ...
        - 2*sum(Y_work(p,:).*r_last_band);
    e_norm2_band = max(0,e_norm2_band);  % roundoff protection only
    % Check the only potentially nonzero F'*E component on sample pixels.
    jcheck = unique(round(linspace(1,N,min(32,N))));
    Echeck = Y(:,jcheck) - F_band*Y_work(:,jcheck);
    cc = F_band'*Echeck;
    cc(p,:) = cc(p,:) - r_last_band(jcheck);
    relative_check = norm(cc,'fro') / max(1,norm(F_band'*Y(:,jcheck),'fro'));
    assert(relative_check < 1e-8,'PISCO:BandLossAlgebra', ...
        'Compact band-loss cross term is inconsistent (relative %.4g).',relative_check);
    band_ctx = struct('K',K_band,'r_last',r_last_band, ...
        'norm2Y',raw_norm2_band,'resid_const',e_norm2_band);
    if pStruct.Results.verbose
        fprintf(['[BandLoss] enabled lambda=%.4g | p=%d,L=%d,N=%d | ' ...
            'lift residual ratio=%.6g | cross-check=%.3g\n'], ...
            pStruct.Results.LAMBDA_BAND,p,L,N, ...
            sqrt(e_norm2_band/raw_norm2_band),relative_check);
    end
end

% Inverse lift for any p x N working matrix Z:
% Y_band = Up_sub*(whiten_scale.*(sqrt(p)*Z(1:p-1,:))) ...
%        + my*(sqrt(p)*Z(p,:)). Unlike legacy this is LINEAR in Z.

%% --------- Existing endmember band priors, with consistent linear lift --
lift_ctx = [];
if pStruct.Results.LAMBDA_MNONNEG > 0 || pStruct.Results.LAMBDA_SMOOTH > 0
    lift_ctx.mode   = 'noasc_linear';
    lift_ctx.Up_sub = Up_sub;
    lift_ctx.sD     = whiten_scale;
    lift_ctx.my     = my;
    lift_ctx.sqp    = sqrt(p);
    lift_ctx.prior_factor = spectral_prior_factor;
end

%% --------------------- Poisson noise propagation ---------------------
use_poisson = strcmpi(pStruct.Results.NOISE_MODEL, 'poisson');
irls_ctx = [];
if use_poisson
    r = ones(1,L)/intensity_ref;
    B = [C*Up_sub'*(eye(L)-my*r); r] / sqrt(p); % EXACT linear Y->Y_work
    B2   = B.^2;                                             % p x L
    gain = pStruct.Results.PHOTON_GAIN;
    VarY = max(Y, pStruct.Results.PHOTON_FLOOR/gain) / gain ...  % shot noise, units of Y
         + (pStruct.Results.READ_SIGMA/gain)^2;               % v0.7: Gaussian read-out noise
    Vpix = B2 * VarY;                                        % p x N
    % ---- v0.5: stabilize the heteroscedastic variances -----------------
    % (a) NoASC intensity coordinate now has nonzero propagated variance;
    %     still guard zero variances for degenerate inputs.
    % (b) floor all variances at 1e-3 x median so the per-pixel weight
    %     ratio cannot exceed 1e3 (Pearson plug-in weights are unstable
    %     at very low counts).
    med_v = median(Vpix(Vpix > 0));
    Vpix(Vpix <= 0) = med_v;
    Vpix = max(Vpix, 1e-3*med_v);
    phi_inv = -sqrt(2)*erfcinv(2*pStruct.Results.ETA);       % Phi^{-1}(eta) <= 0
    % ---- v0.6: IRLS context (model-based weights from the reconstruction)
    if strcmpi(pStruct.Results.NOISE_WEIGHT, 'irls')
        irls_ctx.Up_sub = Up_sub;
        irls_ctx.Cinv   = whiten_scale;
        irls_ctx.my     = my;
        irls_ctx.gain   = gain;
        irls_ctx.floor  = pStruct.Results.PHOTON_FLOOR;
        irls_ctx.rs2    = (pStruct.Results.READ_SIGMA/gain)^2;
        irls_ctx.B2     = B2;
    end
    if pStruct.Results.verbose
        fprintf(['Poisson chance constraints: eta=%.2f, Phi^{-1}(eta)=%.3f, ' ...
                 'gain=%.3g\n'], pStruct.Results.ETA, phi_inv, gain);
    end
else
    Vpix = []; phi_inv = 0;
end

%% --------------------- Shape-simplex initialization, not ASC ---------
% VCA is applied to normalized SHAPE DATA to seed p spectral shapes. Only
% the initialization has affine last coordinate = 1/sqrt(p): optimization
% and reconstruction use the UNNORMALIZED intensity-varying Y_work.
if isempty(pStruct.Results.M0)
    positive_scale = pixel_scale(pixel_scale>0);
    if isempty(positive_scale), error('PISCO:NoASCVCA','No nonzero spectra.'); end
    threshold = median(positive_scale);
    valid = find(pixel_scale >= threshold & pixel_scale>0);
    if numel(valid) < p, valid=find(pixel_scale>0); end
    if numel(valid) < p, error('PISCO:NoASCVCA','Not enough valid pixels.'); end
    nsample = min(50000,numel(valid));
    sel = valid(unique(round(linspace(1,numel(valid),nsample))));
    Y_shapes = bsxfun(@rdivide,Y_work(:,sel),pixel_scale(sel));
    M0 = VCA(Y_shapes, 'Endmembers', p, 'verbose', 'off');
    M0(p,:) = 1/sqrt(p); % exact shape initialization
else
    M0_band = pStruct.Results.M0;
    if ~isequal(size(M0_band),[L p])
        error('PISCO:NoASCM0','M0 must be L x p in ORIGINAL spectral units.');
    end
    M0_band = bsxfun(@times,M0_band, ...
        intensity_ref./max(sum(M0_band,1),eps));
    M0 = [C*Up_sub'*(M0_band-my*ones(1,p));ones(1,p)]/sqrt(p);
end
Q0 = inv(M0);
% The legacy qm learnt a constant affine hyperplane from the original data.
% Keeping that value would IMPLICITLY reconstruct ASC. Here it instead
% anchors each shape endmember at the unit-relative-intensity hyperplane:
% 1'*Q ~= sqrt(p)*e_p' => sum(Q*Y_work(:,j)) ~= pixel_scale(j).
qm = zeros(1,p); qm(end) = sqrt(p);
if pStruct.Results.verbose
    fprintf('PISCO NoASC: pixel-scale median=%.5g range=[%.5g,%.5g] | Q equality targets intensity, not 1.\n', ...
        median(pixel_scale),min(pixel_scale),max(pixel_scale));
end

%% --------------------- Spatial dimensions ---------------------
% Explicit abundance does not use coordinate encoding or A-Net/S-Net.
% IMG_H / IMG_W are retained only for the spatial regularization term.
H_img = pStruct.Results.IMG_H;
W_img = pStruct.Results.IMG_W;
if isempty(H_img) || isempty(W_img)
    H_img = round(sqrt(N)); W_img = round(N/H_img);
end
use_spatial = (H_img * W_img == N);
if ~use_spatial
    if pStruct.Results.LAMBDA_SPATIAL > 0
        warning('IMG_H x IMG_W (%d x %d) ~= N (%d): spatial term disabled.', ...
            H_img, W_img, N);
    end
    H_img = 1; W_img = N;
end

%% --------------------- Move iterative computation to GPU ---------------------
% Keep CPU-only PCA, VCA and small initial inverses exactly as in the source.
% Conversion happens ONCE; do not gather full training arrays every iteration.
if use_gpu
    Y_work = gpuArray(cast(Y_work, gpu_precision));
    pixel_scale = gpuArray(cast(pixel_scale, gpu_precision));
    Q0     = gpuArray(cast(Q0,     gpu_precision));
    qm     = gpuArray(cast(qm,     gpu_precision));
    if use_poisson
        Vpix = gpuArray(cast(Vpix, gpu_precision));
    end
    if ~isempty(lift_ctx)
        lift_ctx.Up_sub = gpuArray(cast(lift_ctx.Up_sub, gpu_precision));
        lift_ctx.sD     = gpuArray(cast(lift_ctx.sD,     gpu_precision));
        lift_ctx.my     = gpuArray(cast(lift_ctx.my,     gpu_precision));
    end
    if ~isempty(irls_ctx)
        irls_ctx.Up_sub = gpuArray(cast(irls_ctx.Up_sub, gpu_precision));
        irls_ctx.Cinv   = gpuArray(cast(irls_ctx.Cinv,   gpu_precision));
        irls_ctx.my     = gpuArray(cast(irls_ctx.my,     gpu_precision));
        irls_ctx.B2     = gpuArray(cast(irls_ctx.B2,     gpu_precision));
    end
    if ~isempty(band_ctx)
        band_ctx.K = gpuArray(cast(band_ctx.K, gpu_precision));
        band_ctx.r_last = gpuArray(cast(band_ctx.r_last, gpu_precision));
        band_ctx.norm2Y = gpuArray(cast(band_ctx.norm2Y, gpu_precision));
        band_ctx.resid_const = gpuArray(cast(band_ctx.resid_const, gpu_precision));
    end
end

%% --------------------- Explicit abundance parameters ---------------------
% Nonnegative data-guided initialization from the same Q0 and Y_work.
% Multiplicative rescaling matches each pixel's INITIAL sum to its measured
% relative intensity, not 1. There is NO such hard constraint during training.
A0 = max(Q0*Y_work,0);
s0 = sum(A0,1);
theta.S_explicit = bsxfun(@times,A0,pixel_scale./max(s0,1e-8));
if pStruct.Results.verbose
    fprintf('PISCO NoASC: initialized nonnegative coefficients; no ASC projection.\n');
end

%% --------------------- Invertible Q: Q = L * Q0 * R ---------------------
theta.L = zeros(p,p, 'like', Y_work);       % strict lower triangular
theta.R = zeros(p,p, 'like', Y_work);       % strict upper triangular
theta.r_log = zeros(p,1, 'like', Y_work);  % R diagonal log

%% --------------------- Adam states ---------------------
m = init_adam(theta);
v = init_adam(theta);
lr = pStruct.Results.LR;
iter = 0;

%% --------------------- Warm-up (explicit abundance; Q exactly frozen) ---------------------
% E3d from pisco_e3_train_b1_15: optimize S_explicit while keeping
% Q = Q0.  Do not update Q parameters OR their Adam moment estimates.
if pStruct.Results.verbose, fprintf('Warm-up (explicit abundance, Q exactly frozen)...\n'); end
for k = 1:pStruct.Results.WARM_UP
    [loss, grad] = compute_gradients_invflow(theta, Y_work, Q0, qm, p, ...
        0, pStruct.Results.LAMBDA_NONNEG, pStruct.Results.LAMBDA_EQ, ...
        pStruct.Results.LAMBDA_ENCLOSE, ...
        pStruct.Results.LAMBDA_SPATIAL, H_img, W_img, ...
        use_poisson, Vpix, phi_inv, pStruct.Results.SIGMA_CAP, ...
        pStruct.Results.NOISE_WEIGHT, irls_ctx, ...
        pStruct.Results.LAMBDA_MNONNEG, pStruct.Results.LAMBDA_SMOOTH, lift_ctx, ...
        pStruct.Results.LAMBDA_BAND, band_ctx);
    [theta, m, v] = adam_update_struct(theta, grad, m, v, iter+1, lr, ...
        0, 0);  % Q frozen, Q Adam moments untouched; abundance Adam continues.
    iter = iter + 1;
    if pStruct.Results.verbose && mod(k,100)==0
        loss_view = loss;
        if use_gpu, loss_view = gather(loss_view); end
        fprintf('Warm-up %d/%d, loss=%.6f (Q exactly frozen)\n', ...
            k, pStruct.Results.WARM_UP, double(loss_view));
    end
end

if pStruct.Results.WARM_UP > 0
    q_drift = norm(theta.L,'fro') + norm(theta.R,'fro') + norm(theta.r_log);
    if use_gpu, q_drift = gather(q_drift); end
    assert(q_drift == 0, 'E3d: Q changed during supposedly fixed-Q warm-up.');
    if pStruct.Results.verbose
        fprintf('Warm-up finished: Q parameter drift = %.3g (should be 0).\n', q_drift);
    end
end

%% --------------------- Joint training ---------------------
if pStruct.Results.verbose, fprintf('Joint training (invertible Q + explicit abundance)...\n'); end
n_joint = pStruct.Results.MM_ITERS - pStruct.Results.WARM_UP;
eta0 = pStruct.Results.ETA; eta1 = pStruct.Results.ETA_END;      % v0.8: anneal
loss_parts_joint = struct();
for k = 1:n_joint
    % v0.8: anneal the chance level ETA -> ETA_END over the joint phase;
    % Phi^{-1}(0.5) = 0, so the enclosure margin decays to zero at
    % convergence (removes the systematic inward simplex bias at high SNR).
    if use_poisson
        prog  = (k-1)/max(1, n_joint-1);
        eta_t = min(max(eta0 + (eta1-eta0)*prog, 1e-6), 1-1e-6);
        phi_t = -sqrt(2)*erfcinv(2*eta_t);
    else
        phi_t = phi_inv;
    end
    % E3d: release Q smoothly after warm-up.  The smoothstep Q learning-
    % rate ramp is bypassed entirely for WARM_UP = 0.
    q_lr_scale = 1;
    if pStruct.Results.WARM_UP > 0 && pStruct.Results.WARMUP_Q_RELEASE > 0
        q_progress = min(1, k / pStruct.Results.WARMUP_Q_RELEASE);
        q_progress = q_progress^2 * (3 - 2*q_progress);
        q0_scale = pStruct.Results.WARMUP_Q_MIN_LR_RATIO;
        q_lr_scale = q0_scale + (1-q0_scale)*q_progress;
    end
    [loss, grad] = compute_gradients_invflow(theta, Y_work, Q0, qm, p, ...
        pStruct.Results.LAMBDA_VOL, pStruct.Results.LAMBDA_NONNEG, ...
        pStruct.Results.LAMBDA_EQ, ...
        pStruct.Results.LAMBDA_ENCLOSE, ...
        pStruct.Results.LAMBDA_SPATIAL, H_img, W_img, ...
        use_poisson, Vpix, phi_t, pStruct.Results.SIGMA_CAP, ...
        pStruct.Results.NOISE_WEIGHT, irls_ctx, ...
        pStruct.Results.LAMBDA_MNONNEG, pStruct.Results.LAMBDA_SMOOTH, lift_ctx, ...
        pStruct.Results.LAMBDA_BAND, band_ctx);  % <<< v0.9 args
    % Q's bias-correction clock restarts at k=1 after being frozen,
    % whereas S_explicit keeps the full iteration count (iter+1).
    [theta, m, v] = adam_update_struct(theta, grad, m, v, iter+1, lr, ...
        q_lr_scale, k);
    iter = iter + 1;
    if pStruct.Results.verbose && mod(k,100)==0
        loss_view = loss;
        if use_gpu, loss_view = gather(loss_view); end
        fprintf('Joint %d/%d, loss=%.6f, explicit abundance\n', ...
            k, n_joint, double(loss_view));
    end
end

% Diagnostic-only: evaluate the final JOINT objective decomposition once.
% This does not update parameters or alter the optimization trajectory.
clear grad; % release the last p-by-N gradient before this diagnostic pass
if n_joint > 0
    phi_final = phi_t;
else
    phi_final = phi_inv;
end
[loss_joint_final,~,loss_parts_joint] = compute_gradients_invflow( ...
    theta,Y_work,Q0,qm,p, ...
    pStruct.Results.LAMBDA_VOL,pStruct.Results.LAMBDA_NONNEG, ...
    pStruct.Results.LAMBDA_EQ,pStruct.Results.LAMBDA_ENCLOSE, ...
    pStruct.Results.LAMBDA_SPATIAL,H_img,W_img, ...
    use_poisson,Vpix,phi_final,pStruct.Results.SIGMA_CAP, ...
    pStruct.Results.NOISE_WEIGHT,irls_ctx, ...
    pStruct.Results.LAMBDA_MNONNEG,pStruct.Results.LAMBDA_SMOOTH,lift_ctx, ...
    pStruct.Results.LAMBDA_BAND,band_ctx);
clear loss_joint_final;

%% -------------------- Terminal fixed-Q, S-only refinement ----------------
% Snapshot the original JOINT output on CPU. Do not clone the full p*N matrix
% on GPU: full 2048x2560 frames are already large. GPU single -> CPU single.
if use_gpu
    S_before_tail = single(gather(theta.S_explicit));
else
    S_before_tail = theta.S_explicit;   % original precision on CPU
end
tail_info = struct('enabled',logical(pStruct.Results.TAIL_ITERS>0), ...
    'iters_requested',pStruct.Results.TAIL_ITERS, ...
    'lr',pStruct.Results.TAIL_LR,'iterations_done',0, ...
    'loss_before',NaN,'loss_proposed',NaN,'loss_accepted',NaN, ...
    'rolled_back',false,'q_parameter_drift',0, ...
    'objective','work + lambda_band*raw32 + lambda_nonneg*softneg + lambda_spatial*grid');
if pStruct.Results.TAIL_ITERS > 0
    % These small matrices are fixed for ALL tail steps.
    QL_fixed = theta.L; QR_fixed = theta.R; Qlog_fixed = theta.r_log;
    LL_fix = eye(p,'like',theta.L) + tril(theta.L,-1);
    RR_fix = diag(exp(theta.r_log)) + triu(theta.R,1);
    M_work_fixed = inv(LL_fix*Q0*RR_fix);
    [loss_start,~,parts_start] = fixedQ_tail_S_loss_grad( ...
        theta.S_explicit,M_work_fixed,Y_work,pStruct.Results, ...
        H_img,W_img,use_poisson,Vpix,irls_ctx,band_ctx);
    tail_info.loss_before = tail_scalar(loss_start);
    fprintf('[FixedQ-tail] starting %d S-only iterations | LR=%.4g | S-only objective=%.9g\n', ...
        pStruct.Results.TAIL_ITERS,pStruct.Results.TAIL_LR,tail_info.loss_before);

    % Fresh S-only Adam moments and bias clock. Never update Q or its moments.
    m.S_explicit = zeros(size(theta.S_explicit),'like',theta.S_explicit);
    v.S_explicit = zeros(size(theta.S_explicit),'like',theta.S_explicit);
    for kt=1:pStruct.Results.TAIL_ITERS
        [~,gS] = fixedQ_tail_S_loss_grad(theta.S_explicit,M_work_fixed, ...
            Y_work,pStruct.Results,H_img,W_img,use_poisson,Vpix,irls_ctx,band_ctx);
        gtail = struct('S_explicit',gS);
        [theta,m,v] = adam_update_struct(theta,gtail,m,v,kt, ...
            pStruct.Results.TAIL_LR,0,0); % Q parameters and moments EXACTLY frozen
        if mod(kt,pStruct.Results.TAIL_REPORT_EVERY)==0 || ...
                kt==1 || kt==pStruct.Results.TAIL_ITERS
            [this_loss,~,parts] = fixedQ_tail_S_loss_grad(theta.S_explicit, ...
                M_work_fixed,Y_work,pStruct.Results,H_img,W_img, ...
                use_poisson,Vpix,irls_ctx,band_ctx);
            fprintf(['[FixedQ-tail] %d/%d | S-loss=%.9g | work=%.6g ' ...
                'band=%.6g | spatial=%.6g\n'], ...
                kt,pStruct.Results.TAIL_ITERS,tail_scalar(this_loss), ...
                tail_scalar(parts.work),tail_scalar(parts.band), ...
                tail_scalar(parts.spatial));
        end
    end
    tail_info.iterations_done=pStruct.Results.TAIL_ITERS;
    [loss_proposal,~,~] = fixedQ_tail_S_loss_grad(theta.S_explicit, ...
        M_work_fixed,Y_work,pStruct.Results,H_img,W_img,use_poisson,Vpix,irls_ctx,band_ctx);
    tail_info.loss_proposed = tail_scalar(loss_proposal);
    tail_info.loss_accepted = tail_info.loss_proposed;
    if logical(pStruct.Results.TAIL_ROLLBACK_IF_WORSE) && ...
            (~isfinite(tail_info.loss_proposed) || ...
            tail_info.loss_proposed > tail_info.loss_before+1e-7*max(1,abs(tail_info.loss_before)))
        if use_gpu
            theta.S_explicit = gpuArray(cast(S_before_tail,gpu_precision));
        else
            theta.S_explicit = S_before_tail;
        end
        tail_info.loss_accepted=tail_info.loss_before;
        tail_info.rolled_back=true;
        fprintf('[FixedQ-tail] objective increased: restored original joint S.\n');
    end
    drift = norm(theta.L-QL_fixed,'fro')+norm(theta.R-QR_fixed,'fro') ...
          +norm(theta.r_log-Qlog_fixed);
    tail_info.q_parameter_drift=tail_scalar(drift);
    assert(tail_info.q_parameter_drift==0,'PISCO:FixedQTailQModified', ...
        'Fixed Q unexpectedly changed in terminal abundance refinement.');
    fprintf(['[FixedQ-tail] S-only objective: %.9g -> %.9g | ' ...
        'Q drift=%.3g | rollback=%d\n'], ...
        tail_info.loss_before,tail_info.loss_accepted, ...
        tail_info.q_parameter_drift,tail_info.rolled_back);
end

% Diagnostic-only: final S-dependent terms after Fixed-Q Tail (or unchanged
% joint S if TAIL_ITERS=0). Q and endmember priors remain fixed from joint.
clear gS; % release the last p-by-N tail gradient before this diagnostic pass
LL_diag = eye(p,'like',theta.L) + tril(theta.L,-1);
RR_diag = diag(exp(theta.r_log)) + triu(theta.R,1);
M_work_diag = inv(LL_diag*Q0*RR_diag);
[~,~,parts_tail_final] = fixedQ_tail_S_loss_grad( ...
    theta.S_explicit,M_work_diag,Y_work,pStruct.Results, ...
    H_img,W_img,use_poisson,Vpix,irls_ctx,band_ctx);
clear M_work_diag LL_diag RR_diag;

%% --------------------- Recover endmembers ---------------------
% All returned values must be ordinary CPU numeric arrays because the E9
% driver performs MATLAB reshaping, comparisons, plots, and MAT/CSV saving.
% Use double for output compatibility with the original MATLAB trainer.
if use_gpu
    fields_out = fieldnames(theta);
    for fi = 1:numel(fields_out)
        f = fields_out{fi};
        theta.(f) = double(gather(theta.(f)));
    end
    Q0 = double(gather(Q0));
end
loss_parts_joint_cpu = pisco_loss_parts_to_cpu(loss_parts_joint);
parts_tail_cpu = pisco_loss_parts_to_cpu(parts_tail_final);
loss_parts_final_cpu = loss_parts_joint_cpu;
% The terminal tail changes only S-dependent terms; Q-dependent terms and
% endmember priors are exactly those of the final joint iterate.
loss_parts_final_cpu.reconstruction_raw = parts_tail_cpu.work;
loss_parts_final_cpu.reconstruction_weighted = parts_tail_cpu.work;
loss_parts_final_cpu.band_raw = parts_tail_cpu.band;
loss_parts_final_cpu.band_weighted = pStruct.Results.LAMBDA_BAND*parts_tail_cpu.band;
loss_parts_final_cpu.abundance_nonneg_raw = parts_tail_cpu.nonneg;
loss_parts_final_cpu.abundance_nonneg_weighted = ...
    pStruct.Results.LAMBDA_NONNEG*parts_tail_cpu.nonneg;
loss_parts_final_cpu.spatial_raw = parts_tail_cpu.spatial;
loss_parts_final_cpu.spatial_weighted = pStruct.Results.LAMBDA_SPATIAL*parts_tail_cpu.spatial;
loss_parts_final_cpu.total_weighted = ...
    loss_parts_final_cpu.reconstruction_weighted + ...
    loss_parts_final_cpu.volume_weighted + ...
    loss_parts_final_cpu.abundance_nonneg_weighted + ...
    loss_parts_final_cpu.equality_weighted + ...
    loss_parts_final_cpu.enclosure_weighted + ...
    loss_parts_final_cpu.spatial_weighted + ...
    loss_parts_final_cpu.band_weighted + ...
    loss_parts_final_cpu.endmember_nonneg_weighted + ...
    loss_parts_final_cpu.endmember_smooth_weighted;
A_eff = theta.S_explicit;
L_mat = eye(p, 'like', theta.L) + tril(theta.L, -1);
R_mat = diag(exp(theta.r_log)) + triu(theta.R, 1);
Q = L_mat * Q0 * R_mat;
M_sub = inv(Q);
Sest = A_eff;
M_est = Up_sub * bsxfun(@times,whiten_scale,sqrt(p)*M_sub(1:p-1,:)) ...
      + my*(sqrt(p)*M_sub(p,:));
% Lightweight output audit (no change to M_est/Sest or the training objective).
% The saved Sest corresponds to M_preclip, whereas output M_est is clipped.
theta.M_before_clip_bandloss_audit = M_est;
theta.endmember_clip_relative = norm(min(M_est,0),'fro')/max(norm(M_est,'fro'),eps);
M_est = max(M_est, 0);   % original output nonnegativity projection
% Audits attached AFTER all Adam steps and GPU->CPU trainable-field transfer.
theta.S_before_tail = S_before_tail;
theta.tail_info = tail_info;
theta.loss_components_joint = loss_parts_joint_cpu;
theta.loss_components_final = loss_parts_final_cpu;
theta.spectral_prior_scale_audit=struct( ...
    'mode',scale_prior_mode, ...
    'factor',spectral_prior_factor, ...
    'q1_reference_intensity',scale_prior_reference, ...
    'current_intensity',intensity_ref, ...
    'effective_lambda_mnonneg',pStruct.Results.LAMBDA_MNONNEG*spectral_prior_factor, ...
    'effective_lambda_smooth',pStruct.Results.LAMBDA_SMOOTH*spectral_prior_factor);
end

%% =================== S-only tail loss and gradient =======================
function [loss,gS,parts] = fixedQ_tail_S_loss_grad(A,M,Y,opts,H,W, ...
    use_poisson,Vpix,irls_ctx,band_ctx)
% EXACT abundance-dependent portion of compute_gradients_invflow.
% Q-only terms have zero derivative w.r.t. A and are omitted here.
N=size(A,2); p=size(A,1);
diff=M*A-Y;
use_w=use_poisson && ~strcmpi(opts.NOISE_WEIGHT,'uniform');
if use_poisson && strcmpi(opts.NOISE_WEIGHT,'irls')
    Yhat=M*A;
    Yh=irls_ctx.Up_sub*(irls_ctx.Cinv.*(sqrt(p)*Yhat(1:p-1,:))) ...
       + irls_ctx.my*(sqrt(p)*Yhat(p,:));
    VarY=max(Yh,irls_ctx.floor/irls_ctx.gain)/irls_ctx.gain+irls_ctx.rs2;
    Vpix=irls_ctx.B2*VarY;
    med_i=median(Vpix(Vpix>0));
    Vpix(Vpix<=0)=med_i;
end
if use_w
    Wrec=1./(Vpix+1e-12);
    Wrec=Wrec/mean(Wrec(:));
    work=mean(sum(diff.^2.*Wrec,1));
    dY=2*diff.*Wrec/N;
else
    work=mean(sum(diff.^2,1));
    dY=2*diff/N;
end
band=0;
if opts.LAMBDA_BAND>0
    hd=band_ctx.K*diff;
    hd(p,:)=hd(p,:)-band_ctx.r_last;
    numerator=band_ctx.resid_const+sum(diff.*hd,'all') ...
        -sum(diff(p,:).*band_ctx.r_last,'all');
    band=numerator/band_ctx.norm2Y;
    dY=dY+(2*opts.LAMBDA_BAND/band_ctx.norm2Y)*hd;
end
pen=min(A,0);
nonneg=sum(pen.^2,'all');
gS=M'*dY+2*opts.LAMBDA_NONNEG*pen;
spatial=0;
if opts.LAMBDA_SPATIAL>0 && H*W==N
    A3=reshape(A,p,H,W);
    Dh=A3(:,2:end,:)-A3(:,1:end-1,:);
    Dw=A3(:,:,2:end)-A3(:,:,1:end-1);
    spatial=(sum(Dh.^2,'all')+sum(Dw.^2,'all'))/N;
    G3=zeros(p,H,W,'like',A);
    G3(:,1:end-1,:)=G3(:,1:end-1,:)-Dh;
    G3(:,2:end,:)=G3(:,2:end,:)+Dh;
    G3(:,:,1:end-1)=G3(:,:,1:end-1)-Dw;
    G3(:,:,2:end)=G3(:,:,2:end)+Dw;
    gS=gS+(2*opts.LAMBDA_SPATIAL/N)*reshape(G3,p,N);
end
loss=work+opts.LAMBDA_BAND*band+opts.LAMBDA_NONNEG*nonneg ...
    +opts.LAMBDA_SPATIAL*spatial;
parts=struct('work',work,'band',band,'spatial',spatial,'nonneg',nonneg);
end
function v = tail_scalar(x)
if isa(x,'gpuArray'),x=gather(x);end
v=double(x);
end

function out = pisco_loss_parts_to_cpu(parts)
% Convert a struct of scalar GPU/CPU loss diagnostics to ordinary doubles.
out = struct();
names = fieldnames(parts);
for ii = 1:numel(names)
    x = parts.(names{ii});
    if isa(x,'gpuArray'),x=gather(x);end
    out.(names{ii}) = double(x);
end
end

%% ===================== Sub-functions =====================
function adam = init_adam(theta)
fields = fieldnames(theta);
adam = struct();
for i = 1:numel(fields)
    f = fields{i};
    adam.(f) = zeros(size(theta.(f)), 'like', theta.(f));
end
end

function [loss, grad, parts] = compute_gradients_invflow(theta, Y, Q0, qm, p, ...
    lambda_vol, lambda_nonneg, lambda_eq, lambda_enclose, ...
    lambda_spatial, H_img, W_img, use_poisson, Vpix, phi_inv, sigma_cap, ...
    noise_weight, irls_ctx, lambda_mnn, lambda_smooth, lift_ctx, ...
    lambda_band, band_ctx)   % NEW: original spectral-domain loss
L_mat = eye(p, 'like', theta.L) + tril(theta.L, -1);
R_mat = diag(exp(theta.r_log)) + triu(theta.R, 1);
Q = L_mat * Q0 * R_mat;
M = inv(Q); % p is small, numerically safe

% Explicit per-pixel abundance variables (p x N).
A_eff = theta.S_explicit;

Y_hat = M * A_eff;
diff = Y_hat - Y;

% --- reconstruction weights (v0.6) ------------------------------------
% 'uniform' (default): after signal-covariance whitening the working-space
%   noise is only weakly heteroscedastic, and uniform weighting keeps the
%   min-volume geometry anchored by ALL pixels (bright vertices included);
%   the Poisson adaptation is carried by the enclosure margins below.
% 'pearson': heteroscedastic GLS with plug-in variances (v0.5 behaviour).
% 'irls'   : heteroscedastic GLS with variances recomputed from the
%   CURRENT RECONSTRUCTION every iteration (proper IRLS; removes the
%   Pearson plug-in feedback that lets the net fit its own weight noise).
eps_var = 1e-12;
use_w = use_poisson && ~strcmpi(noise_weight, 'uniform');
if use_poisson && strcmpi(noise_weight, 'irls')
    Yh_chan = irls_ctx.Up_sub * (irls_ctx.Cinv .* (sqrt(p)*Y_hat(1:p-1,:))) ...
             + irls_ctx.my*(sqrt(p)*Y_hat(p,:));
    VarY = max(Yh_chan, irls_ctx.floor/irls_ctx.gain) / irls_ctx.gain + irls_ctx.rs2;
    Vpix = irls_ctx.B2 * VarY;                          % stop-grad
    med_i = median(Vpix(Vpix > 0)); Vpix(Vpix <= 0) = med_i;
end
if use_w
    W_rec = 1./(Vpix + eps_var);                        % stop-grad weights
    W_rec = W_rec / mean(W_rec(:));                     % mean weight 1
    loss_recon = mean(sum(diff.^2 .* W_rec, 1));
else
    loss_recon = mean(sum(diff.^2,1));
end

loss_vol = -sum(theta.r_log); % log|det(Q0)| omitted as constant

% --- pixel-adaptive chance-constraint margin (Poisson) ---              <<< NEW
% v0.5: the margin applies ONLY to the data-enclosure term (below), where
% noise tolerance is statistically justified (RMVSA heritage). Abundance
% non-negativity keeps its original soft penalty (no noise relaxation).
if use_poisson
    sigma2 = (Q.^2) * Vpix + eps_var;                  % q_i' Cov_j q_i, p x N
    margin = phi_inv * min(sqrt(sigma2), sigma_cap);   % <= 0, stop-grad, capped
else
    margin = 0;
end

penalty = min(A_eff, 0);      % original SOFT nonnegative coefficient penalty
loss_nonneg = sum(penalty.^2, 'all');

% NOASC: intentionally NO sum(A,1)-1 penalty and NO simplex projection.
col_sums = sum(Q,1);
loss_eq = sum((col_sums - qm).^2, 'all');

% --- optional data-enclosure penalty QY >= margin ---
QY = Q*Y;
pen_enclose = min(QY - margin, 0);
loss_enclose = sum(pen_enclose.^2, 'all');

% --- optional spatial smoothness of the abundance maps (4-neighbour
%     grid Laplacian):  sum_{adjacent (i,j)} ||a_i - a_j||^2  ---
loss_spatial = 0;
if lambda_spatial > 0 && H_img*W_img == size(Y,2)
    A3  = reshape(A_eff, p, H_img, W_img);
    Dh  = A3(:,2:end,:) - A3(:,1:end-1,:);   % vertical neighbour diffs
    Dw  = A3(:,:,2:end) - A3(:,:,1:end-1);   % horizontal neighbour diffs
    loss_spatial = (sum(Dh.^2,'all') + sum(Dw.^2,'all')) / size(Y,2);  % v0.6: mean over pixels
end

% --- NEW: true original-L-band loss, exactly computed in p dimensions ---
% H*d = K*d; its last row subtracts r_last=F'*(Y-F*Y_work)(end).
% The spectral residual outside span(F) contributes to loss as a CONSTANT.
% This is NOT the incorrect surrogate d'*K*d alone.
loss_band = 0;
if lambda_band > 0
    assert(~isempty(band_ctx),'PISCO:BandCtx','Missing band-loss constants.');
    band_hd = band_ctx.K*diff;
    band_hd(p,:) = band_hd(p,:) - band_ctx.r_last;
    band_numer = band_ctx.resid_const + sum(diff.*band_hd,'all') ...
        - sum(diff(p,:).*band_ctx.r_last,'all');
    loss_band = band_numer/band_ctx.norm2Y;
end

loss = loss_recon + lambda_vol*loss_vol + lambda_nonneg*loss_nonneg + ...
    lambda_eq*loss_eq + ...
    lambda_enclose*loss_enclose + lambda_spatial*loss_spatial + ...
    lambda_band*loss_band;

N = size(Y,2);
if use_w
    dY_hat = 2*diff.*W_rec/N;                          % GLS gradient     <<< NEW
else
    dY_hat = 2*diff/N;
end
% Exact chain gradient of (||Y_raw-F*M*A||_F^2 / ||Y_raw||_F^2).
% Both Q (through M=inv(Q)) and explicit abundances receive this gradient.
if lambda_band > 0
    dY_hat = dY_hat + (2*lambda_band/band_ctx.norm2Y)*band_hd;
end
dM = dY_hat * A_eff';

% --- v0.8/v0.9: band-space endmember priors (spectra >= 0; spectral smoothness)
loss_mnn = 0;
loss_smooth = 0;
% Scale raw L-band quadratic priors and their gradients by the SAME factor.
% Q-only priors; no change to S-only fixed-Q terminal objective.
prior_factor=1;
if ~isempty(lift_ctx) && isfield(lift_ctx,'prior_factor')
    prior_factor=lift_ctx.prior_factor;
end
lambda_mnn_effective=lambda_mnn*prior_factor;
lambda_smooth_effective=lambda_smooth*prior_factor;
if (lambda_mnn > 0 || lambda_smooth > 0) && ~isempty(lift_ctx)
    M_band = lift_ctx.Up_sub * (lift_ctx.sD .* (lift_ctx.sqp*M(1:p-1,:))) ...
           + lift_ctx.my*(lift_ctx.sqp*M(p,:));                % L x p
    dM_band = zeros(size(M_band), 'like', M_band);
    if lambda_mnn > 0
        pen_M = min(M_band, 0);
        loss_mnn = sum(pen_M.^2, 'all');
        loss  = loss + lambda_mnn_effective * loss_mnn;
        dM_band = dM_band + 2*lambda_mnn_effective*pen_M;                 % L x p
    end
    if lambda_smooth > 0                                        % <<< NEW v0.9
        % 2nd-difference Tikhonov on the band-space endmembers: suppresses
        % spurious narrow peaks/dips that shot noise imprints on M.
        D2M = M_band(3:end,:) - 2*M_band(2:end-1,:) + M_band(1:end-2,:);
        loss_smooth = sum(D2M.^2, 'all');
        loss = loss + lambda_smooth_effective * loss_smooth;
        g2 = zeros(size(M_band), 'like', M_band);
        g2(3:end,:)   = g2(3:end,:)   + 2*lambda_smooth_effective*D2M;
        g2(2:end-1,:) = g2(2:end-1,:) - 4*lambda_smooth_effective*D2M;
        g2(1:end-2,:) = g2(1:end-2,:) + 2*lambda_smooth_effective*D2M;
        dM_band = dM_band + g2;
    end
    gmnn = zeros(p,p, 'like', M);
    gmnn(1:p-1,:) = lift_ctx.sqp * (lift_ctx.sD .* (lift_ctx.Up_sub' * dM_band));
    gmnn(p,:) = lift_ctx.sqp*(lift_ctx.my'*dM_band);
    dM = dM + gmnn;   % chain rule through M = inv(Q) handled below
end

grad_Q_recon = -M' * dM * M';
grad_Q_eq = 2 * repmat(col_sums - qm, p, 1);
grad_Q_enclose = 2 * pen_enclose * Y';
grad_Q_clean = grad_Q_recon + lambda_eq * grad_Q_eq + lambda_enclose * grad_Q_enclose;

% Map Q-gradients to triangular parameters
grad_L_mat = grad_Q_clean * R_mat' * Q0';
grad_R_mat = Q0' * L_mat' * grad_Q_clean;
grad.L = tril(grad_L_mat, -1);
grad.R = triu(grad_R_mat, 1);
grad.r_log = diag(grad_R_mat) .* exp(theta.r_log) - lambda_vol;

% Gradient with respect to explicit abundance variables (margin treated as constant)
dA_eff = M' * dY_hat + 2*lambda_nonneg*penalty;

% gradient of the spatial penalty: 2 * (grid Laplacian) * A
if lambda_spatial > 0 && H_img*W_img == N
    G3 = zeros(p, H_img, W_img, 'like', A_eff);
    G3(:,1:end-1,:) = G3(:,1:end-1,:) - Dh;
    G3(:,2:end,:)   = G3(:,2:end,:)   + Dh;
    G3(:,:,1:end-1) = G3(:,:,1:end-1) - Dw;
    G3(:,:,2:end)   = G3(:,:,2:end)   + Dw;
    dA_eff = dA_eff + 2*lambda_spatial*reshape(G3, p, N)/N;   % v0.6: mean over pixels
end

% Direct nonnegative unnormalized coefficient optimization (NO ASC).
grad.S_explicit = dA_eff;

% Unweighted term values and their actual weighted contributions.
% These diagnostics are scalar-only and do not affect the optimizer.
parts = struct();
parts.reconstruction_raw = loss_recon;
parts.reconstruction_weighted = loss_recon;
parts.volume_raw = loss_vol;
parts.volume_weighted = lambda_vol*loss_vol;
parts.abundance_nonneg_raw = loss_nonneg;
parts.abundance_nonneg_weighted = lambda_nonneg*loss_nonneg;
parts.equality_raw = loss_eq;
parts.equality_weighted = lambda_eq*loss_eq;
parts.enclosure_raw = loss_enclose;
parts.enclosure_weighted = lambda_enclose*loss_enclose;
parts.spatial_raw = loss_spatial;
parts.spatial_weighted = lambda_spatial*loss_spatial;
parts.band_raw = loss_band;
parts.band_weighted = lambda_band*loss_band;
parts.endmember_nonneg_raw = loss_mnn;
parts.endmember_nonneg_weighted = lambda_mnn_effective*loss_mnn;
parts.endmember_smooth_raw = loss_smooth;
parts.endmember_smooth_weighted = lambda_smooth_effective*loss_smooth;
parts.total_weighted = loss;
end

function [theta, m, v] = adam_update_struct(theta, grad, m, v, iter, lr, ...
    q_lr_scale, q_step)
% E3d: separate Adam bias-correction clocks for the Q group and S_explicit.
% A frozen Q group skips both the parameter step and its moment updates.
beta1 = 0.9; beta2 = 0.999; eps = 1e-8;
fields = fieldnames(theta);
for i = 1:numel(fields)
    f = fields{i};
    is_q = any(strcmp(f, {'L','R','r_log'}));
    if is_q
        if q_lr_scale <= 0, continue; end
        t = q_step;
        local_lr = lr*q_lr_scale;
    else
        t = iter;
        local_lr = lr;
    end
    m.(f) = beta1*m.(f) + (1-beta1)*grad.(f);
    v.(f) = beta2*v.(f) + (1-beta2)*grad.(f).^2;
    m_hat = m.(f) / (1 - beta1^t);
    v_hat = v.(f) / (1 - beta2^t);
    theta.(f) = theta.(f) - local_lr * m_hat ./ (sqrt(v_hat) + eps);
end
end
